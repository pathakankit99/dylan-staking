(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./hooks/useWalletBalance.tsx":
/*!************************************!*\
  !*** ./hooks/useWalletBalance.tsx ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ useWalletBalance),
/* harmony export */   "WalletBalanceProvider": () => (/* binding */ WalletBalanceProvider)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @solana/web3.js */ "@solana/web3.js");
/* harmony import */ var _solana_web3_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_solana_web3_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _project_serum_anchor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @project-serum/anchor */ "@project-serum/anchor");
/* harmony import */ var _project_serum_anchor__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_project_serum_anchor__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\hooks\\useWalletBalance.tsx";





const BalanceContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
const rpcHost = "https://api.devnet.solana.com";
const connection = new _project_serum_anchor__WEBPACK_IMPORTED_MODULE_2__.web3.Connection(rpcHost);
function useWalletBalance() {
  const {
    0: balance,
    1: setBalance
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(BalanceContext);
  return [balance, setBalance];
}
const WalletBalanceProvider = ({
  children
}) => {
  const wallet = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_4__.useWallet)();
  const {
    0: balance,
    1: setBalance
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    (async () => {
      if (wallet !== null && wallet !== void 0 && wallet.publicKey) {
        const balance = await connection.getBalance(wallet.publicKey);
        setBalance(balance / _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__.LAMPORTS_PER_SOL);
      }
    })();
  }, [wallet, connection]);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    (async () => {
      if (wallet !== null && wallet !== void 0 && wallet.publicKey) {
        const balance = await connection.getBalance(wallet.publicKey);
        setBalance(balance / _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__.LAMPORTS_PER_SOL);
      }
    })();
  }, [wallet, connection]);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(BalanceContext.Provider, {
    value: [balance, setBalance],
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 40,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./node_modules/next/dist/shared/lib/dynamic.js":
/*!******************************************************!*\
  !*** ./node_modules/next/dist/shared/lib/dynamic.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.noSSR = noSSR;
exports.default = dynamic;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _loadable = _interopRequireDefault(__webpack_require__(/*! ./loadable */ "./loadable"));

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

const isServerSide = true;

function noSSR(LoadableInitializer, loadableOptions) {
  // Removing webpack and modules means react-loadable won't try preloading
  delete loadableOptions.webpack;
  delete loadableOptions.modules; // This check is necessary to prevent react-loadable from initializing on the server

  if (!isServerSide) {
    return LoadableInitializer(loadableOptions);
  }

  const Loading = loadableOptions.loading; // This will only be rendered on the server side

  return () => /*#__PURE__*/_react.default.createElement(Loading, {
    error: null,
    isLoading: true,
    pastDelay: false,
    timedOut: false
  });
}

function dynamic(dynamicOptions, options) {
  let loadableFn = _loadable.default;
  let loadableOptions = {
    // A loading component is not required, so we default it
    loading: ({
      error,
      isLoading,
      pastDelay
    }) => {
      if (!pastDelay) return null;

      if (true) {
        if (isLoading) {
          return null;
        }

        if (error) {
          return /*#__PURE__*/_react.default.createElement("p", null, error.message, /*#__PURE__*/_react.default.createElement("br", null), error.stack);
        }
      }

      return null;
    }
  }; // Support for direct import(), eg: dynamic(import('../hello-world'))
  // Note that this is only kept for the edge case where someone is passing in a promise as first argument
  // The react-loadable babel plugin will turn dynamic(import('../hello-world')) into dynamic(() => import('../hello-world'))
  // To make sure we don't execute the import without rendering first

  if (dynamicOptions instanceof Promise) {
    loadableOptions.loader = () => dynamicOptions; // Support for having import as a function, eg: dynamic(() => import('../hello-world'))

  } else if (typeof dynamicOptions === 'function') {
    loadableOptions.loader = dynamicOptions; // Support for having first argument being options, eg: dynamic({loader: import('../hello-world')})
  } else if (typeof dynamicOptions === 'object') {
    loadableOptions = _objectSpread(_objectSpread({}, loadableOptions), dynamicOptions);
  } // Support for passing options, eg: dynamic(import('../hello-world'), {loading: () => <p>Loading something</p>})


  loadableOptions = _objectSpread(_objectSpread({}, loadableOptions), options);
  const suspenseOptions = loadableOptions;

  if (true) {
    // Error if react root is not enabled and `suspense` option is set to true
    if ( true && suspenseOptions.suspense) {
      // TODO: add error doc when this feature is stable
      throw new Error(`Invalid suspense option usage in next/dynamic. Read more: https://nextjs.org/docs/messages/invalid-dynamic-suspense`);
    }
  }

  if (suspenseOptions.suspense) {
    return loadableFn(suspenseOptions);
  } // coming from build/babel/plugins/react-loadable-plugin.js


  if (loadableOptions.loadableGenerated) {
    loadableOptions = _objectSpread(_objectSpread({}, loadableOptions), loadableOptions.loadableGenerated);
    delete loadableOptions.loadableGenerated;
  } // support for disabling server side rendering, eg: dynamic(import('../hello-world'), {ssr: false})


  if (typeof loadableOptions.ssr === 'boolean') {
    if (!loadableOptions.ssr) {
      delete loadableOptions.ssr;
      return noSSR(loadableFn, loadableOptions);
    }

    delete loadableOptions.ssr;
  }

  return loadableFn(loadableOptions);
}

/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux-persist/integration/react */ "redux-persist/integration/react");
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../store */ "./store/index.tsx");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/dynamic */ "./node_modules/next/dynamic.js");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hooks_useWalletBalance__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../hooks/useWalletBalance */ "./hooks/useWalletBalance.tsx");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ "./node_modules/slick-carousel/slick/slick.css");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ "./node_modules/slick-carousel/slick/slick-theme.css");
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../styles/globals.css */ "./styles/globals.css");
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\pages\\_app.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // import "bootstrap/dist/css/bootstrap.css";
//imports for redux



 //imports for web3




__webpack_require__(/*! @solana/wallet-adapter-react-ui/styles.css */ "./node_modules/@solana/wallet-adapter-react-ui/styles.css"); // import Navbar from "../components/Navbar"






const WalletConnectionProvider = next_dynamic__WEBPACK_IMPORTED_MODULE_4___default()(() => __webpack_require__.e(/*! import() */ "components_WalletConnection_WalletConnectionProvider_tsx").then(__webpack_require__.bind(__webpack_require__, /*! ../components/WalletConnection/WalletConnectionProvider */ "./components/WalletConnection/WalletConnectionProvider.tsx")), {
  ssr: false,
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(/*! ../components/WalletConnection/WalletConnectionProvider */ "./components/WalletConnection/WalletConnectionProvider.tsx")],
    modules: ["_app.tsx -> " + "../components/WalletConnection/WalletConnectionProvider"]
  }
});

function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(WalletConnectionProvider, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_hooks_useWalletBalance__WEBPACK_IMPORTED_MODULE_5__.WalletBalanceProvider, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(react_redux__WEBPACK_IMPORTED_MODULE_3__.Provider, {
        store: _store__WEBPACK_IMPORTED_MODULE_2__.store,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_1__.PersistGate, {
          loading: null,
          persistor: _store__WEBPACK_IMPORTED_MODULE_2__.persistor,
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("div", {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_0___default()), {
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("title", {
                children: "Stake NFT"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 32,
                columnNumber: 17
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("link", {
                rel: "icon",
                href: "/favicon.ico"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 33,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 31,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("div", {
              className: "min-h-screen bg-brand_bg text-white p-6 lg:px-64",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(Component, _objectSpread({}, pageProps), void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 37,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 36,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 30,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 26,
    columnNumber: 5
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

/***/ }),

/***/ "./store/index.tsx":
/*!*************************!*\
  !*** ./store/index.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "store": () => (/* binding */ store),
/* harmony export */   "persistor": () => (/* binding */ persistor)
/* harmony export */ });
/* harmony import */ var _reducers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reducers */ "./store/reducers/index.js");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! redux-thunk */ "redux-thunk");
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_thunk__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! redux-persist */ "redux-persist");
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! redux-persist/lib/storage */ "redux-persist/lib/storage");
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4__);




 // defaults to localStorage for web
// import { composeWithDevTools } from "redux-devtools-extension";

const persistConfig = {
  key: "admin",
  timeout: 0,
  storage: (redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4___default()) //   whitelist: ["download_list"]

};
const persistedReducer = (0,redux_persist__WEBPACK_IMPORTED_MODULE_3__.persistReducer)(persistConfig, _reducers__WEBPACK_IMPORTED_MODULE_0__.default);
const composeEnhancers = redux__WEBPACK_IMPORTED_MODULE_1__.compose;
let store = (0,redux__WEBPACK_IMPORTED_MODULE_1__.createStore)(persistedReducer, composeEnhancers((0,redux__WEBPACK_IMPORTED_MODULE_1__.applyMiddleware)((redux_thunk__WEBPACK_IMPORTED_MODULE_2___default()))));
let persistor = (0,redux_persist__WEBPACK_IMPORTED_MODULE_3__.persistStore)(store);

const final = () => {};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (final);


/***/ }),

/***/ "./store/reducers/app_reducer.tsx":
/*!****************************************!*\
  !*** ./store/reducers/app_reducer.tsx ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const INITIAL_STATE = {
  loading: false,
  wallet_id: "",
  nft_list: null
};

const app_reducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case "WALLET_ID":
      return _objectSpread(_objectSpread({}, state), {}, {
        wallet_id: action.payload,
        loading: false
      });

    case "SETNFT":
      return _objectSpread(_objectSpread({}, state), {}, {
        nft_list: action.payload,
        loading: false
      });

    default:
      return state;
  }
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (app_reducer);

/***/ }),

/***/ "./store/reducers/index.js":
/*!*********************************!*\
  !*** ./store/reducers/index.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _app_reducer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app_reducer */ "./store/reducers/app_reducer.tsx");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_1__);
 // import menu from "./menu";


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,redux__WEBPACK_IMPORTED_MODULE_1__.combineReducers)({
  app_reducer: _app_reducer__WEBPACK_IMPORTED_MODULE_0__.default
}));

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/adapter.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/adapter.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventEmitter": () => (/* reexport default from dynamic */ eventemitter3__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "BaseWalletAdapter": () => (/* binding */ BaseWalletAdapter),
/* harmony export */   "WalletAdapterNetwork": () => (/* binding */ WalletAdapterNetwork)
/* harmony export */ });
/* harmony import */ var eventemitter3__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! eventemitter3 */ "eventemitter3");
/* harmony import */ var eventemitter3__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(eventemitter3__WEBPACK_IMPORTED_MODULE_0__);


class BaseWalletAdapter extends (eventemitter3__WEBPACK_IMPORTED_MODULE_0___default()) {}
var WalletAdapterNetwork;

(function (WalletAdapterNetwork) {
  WalletAdapterNetwork["Mainnet"] = "mainnet-beta";
  WalletAdapterNetwork["Testnet"] = "testnet";
  WalletAdapterNetwork["Devnet"] = "devnet";
})(WalletAdapterNetwork || (WalletAdapterNetwork = {}));

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/errors.js":
/*!****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/errors.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletError": () => (/* binding */ WalletError),
/* harmony export */   "WalletNotFoundError": () => (/* binding */ WalletNotFoundError),
/* harmony export */   "WalletNotInstalledError": () => (/* binding */ WalletNotInstalledError),
/* harmony export */   "WalletNotReadyError": () => (/* binding */ WalletNotReadyError),
/* harmony export */   "WalletConnectionError": () => (/* binding */ WalletConnectionError),
/* harmony export */   "WalletDisconnectedError": () => (/* binding */ WalletDisconnectedError),
/* harmony export */   "WalletDisconnectionError": () => (/* binding */ WalletDisconnectionError),
/* harmony export */   "WalletAccountError": () => (/* binding */ WalletAccountError),
/* harmony export */   "WalletPublicKeyError": () => (/* binding */ WalletPublicKeyError),
/* harmony export */   "WalletKeypairError": () => (/* binding */ WalletKeypairError),
/* harmony export */   "WalletNotConnectedError": () => (/* binding */ WalletNotConnectedError),
/* harmony export */   "WalletSendTransactionError": () => (/* binding */ WalletSendTransactionError),
/* harmony export */   "WalletSignMessageError": () => (/* binding */ WalletSignMessageError),
/* harmony export */   "WalletSignTransactionError": () => (/* binding */ WalletSignTransactionError),
/* harmony export */   "WalletTimeoutError": () => (/* binding */ WalletTimeoutError),
/* harmony export */   "WalletWindowBlockedError": () => (/* binding */ WalletWindowBlockedError),
/* harmony export */   "WalletWindowClosedError": () => (/* binding */ WalletWindowClosedError)
/* harmony export */ });
class WalletError extends Error {
  // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
  constructor(message, error) {
    super(message);
    this.error = error;
  }

}
class WalletNotFoundError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotFoundError';
  }

}
class WalletNotInstalledError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotInstalledError';
  }

}
class WalletNotReadyError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotReadyError';
  }

}
class WalletConnectionError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletConnectionError';
  }

}
class WalletDisconnectedError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletDisconnectedError';
  }

}
class WalletDisconnectionError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletDisconnectionError';
  }

}
class WalletAccountError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletAccountError';
  }

}
class WalletPublicKeyError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletPublicKeyError';
  }

}
class WalletKeypairError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletKeypairError';
  }

}
class WalletNotConnectedError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotConnectedError';
  }

}
class WalletSendTransactionError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletSendTransactionError';
  }

}
class WalletSignMessageError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletSignMessageError';
  }

}
class WalletSignTransactionError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletSignTransactionError';
  }

}
class WalletTimeoutError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletTimeoutError';
  }

}
class WalletWindowBlockedError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletWindowBlockedError';
  }

}
class WalletWindowClosedError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletWindowClosedError';
  }

}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/index.js":
/*!***************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _adapter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./adapter */ "./node_modules/@solana/wallet-adapter-base/lib/adapter.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _adapter__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _adapter__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors */ "./node_modules/@solana/wallet-adapter-base/lib/errors.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _errors__WEBPACK_IMPORTED_MODULE_1__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _errors__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _poll__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./poll */ "./node_modules/@solana/wallet-adapter-base/lib/poll.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _poll__WEBPACK_IMPORTED_MODULE_2__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _poll__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _signer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./signer */ "./node_modules/@solana/wallet-adapter-base/lib/signer.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _signer__WEBPACK_IMPORTED_MODULE_3__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _signer__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);





/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/poll.js":
/*!**************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/poll.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "poll": () => (/* binding */ poll),
/* harmony export */   "pollUntilReady": () => (/* binding */ pollUntilReady)
/* harmony export */ });
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

function poll(callback, interval, count) {
  if (count > 0) {
    setTimeout(() => __awaiter(this, void 0, void 0, function* () {
      const done = yield callback();
      if (!done) poll(callback, interval, count - 1);
    }), interval);
  }
}
function pollUntilReady(adapter, pollInterval, pollCount) {
  poll(() => {
    const {
      ready
    } = adapter;

    if (ready) {
      if (!adapter.emit('ready')) {
        console.warn(`${adapter.constructor.name} is ready but no listener was registered`);
      }
    }

    return ready;
  }, pollInterval, pollCount);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/signer.js":
/*!****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/signer.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BaseSignerWalletAdapter": () => (/* binding */ BaseSignerWalletAdapter),
/* harmony export */   "BaseMessageSignerWalletAdapter": () => (/* binding */ BaseMessageSignerWalletAdapter)
/* harmony export */ });
/* harmony import */ var _adapter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./adapter */ "./node_modules/@solana/wallet-adapter-base/lib/adapter.js");
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors */ "./node_modules/@solana/wallet-adapter-base/lib/errors.js");
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};



class BaseSignerWalletAdapter extends _adapter__WEBPACK_IMPORTED_MODULE_0__.BaseWalletAdapter {
  sendTransaction(transaction, connection, options = {}) {
    return __awaiter(this, void 0, void 0, function* () {
      let emit = true;

      try {
        try {
          transaction.feePayer || (transaction.feePayer = this.publicKey || undefined);
          transaction.recentBlockhash || (transaction.recentBlockhash = (yield connection.getRecentBlockhash('finalized')).blockhash);

          const {
            signers
          } = options,
                sendOptions = __rest(options, ["signers"]);

          (signers === null || signers === void 0 ? void 0 : signers.length) && transaction.partialSign(...signers);
          transaction = yield this.signTransaction(transaction);
          const rawTransaction = transaction.serialize();
          return yield connection.sendRawTransaction(rawTransaction, sendOptions);
        } catch (error) {
          // If the error was thrown by `signTransaction`, rethrow it and don't emit a duplicate event
          if (error instanceof _errors__WEBPACK_IMPORTED_MODULE_1__.WalletError) {
            emit = false;
            throw error;
          }

          throw new _errors__WEBPACK_IMPORTED_MODULE_1__.WalletSendTransactionError(error === null || error === void 0 ? void 0 : error.message, error);
        }
      } catch (error) {
        if (emit) {
          this.emit('error', error);
        }

        throw error;
      }
    });
  }

}
class BaseMessageSignerWalletAdapter extends BaseSignerWalletAdapter {}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/ConnectionProvider.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/ConnectionProvider.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConnectionProvider": () => (/* binding */ ConnectionProvider)
/* harmony export */ });
/* harmony import */ var _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @solana/web3.js */ "@solana/web3.js");
/* harmony import */ var _solana_web3_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_solana_web3_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _useConnection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useConnection */ "./node_modules/@solana/wallet-adapter-react/lib/useConnection.js");



const ConnectionProvider = ({
  children,
  endpoint,
  config = {
    commitment: 'confirmed'
  }
}) => {
  const connection = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => new _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__.Connection(endpoint, config), [endpoint, config]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_useConnection__WEBPACK_IMPORTED_MODULE_2__.ConnectionContext.Provider, {
    value: {
      connection
    }
  }, children);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/WalletProvider.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/WalletProvider.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletProvider": () => (/* binding */ WalletProvider)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @solana/wallet-adapter-base */ "./node_modules/@solana/wallet-adapter-base/lib/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./errors */ "./node_modules/@solana/wallet-adapter-react/lib/errors.js");
/* harmony import */ var _useLocalStorage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./useLocalStorage */ "./node_modules/@solana/wallet-adapter-react/lib/useLocalStorage.js");
/* harmony import */ var _useWallet__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./useWallet */ "./node_modules/@solana/wallet-adapter-react/lib/useWallet.js");
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};






const initialState = {
  wallet: null,
  adapter: null,
  ready: false,
  publicKey: null,
  connected: false
};
const WalletProvider = ({
  children,
  wallets,
  autoConnect = false,
  onError: _onError = error => console.error(error),
  localStorageKey = 'walletName'
}) => {
  const [name, setName] = (0,_useLocalStorage__WEBPACK_IMPORTED_MODULE_1__.useLocalStorage)(localStorageKey, null);
  const {
    0: {
      wallet,
      adapter,
      ready,
      publicKey,
      connected
    },
    1: setState
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialState);
  const {
    0: connecting,
    1: setConnecting
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: disconnecting,
    1: setDisconnecting
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const isConnecting = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
  const isDisconnecting = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
  const isUnloading = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false); // Map of wallet names to wallets

  const walletsByName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => wallets.reduce((walletsByName, wallet) => {
    walletsByName[wallet.name] = wallet;
    return walletsByName;
  }, {}), [wallets]); // When the selected wallet changes, initialize the state

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const wallet = name && walletsByName[name] || null;
    const adapter = wallet && wallet.adapter();

    if (adapter) {
      const {
        ready,
        publicKey,
        connected
      } = adapter;
      setState({
        wallet,
        adapter,
        connected,
        publicKey,
        ready
      });
    } else {
      setState(initialState);
    }
  }, [name, walletsByName, setState]); // If autoConnect is enabled, try to connect when the adapter changes and is ready

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (isConnecting.current || connecting || connected || !autoConnect || !adapter || !ready) return;

    (function () {
      return __awaiter(this, void 0, void 0, function* () {
        isConnecting.current = true;
        setConnecting(true);

        try {
          yield adapter.connect();
        } catch (error) {
          // Clear the selected wallet
          setName(null); // Don't throw error, but onError will still be called
        } finally {
          setConnecting(false);
          isConnecting.current = false;
        }
      });
    })();
  }, [isConnecting, connecting, connected, autoConnect, adapter, ready, setConnecting, setName]); // If the window is closing or reloading, ignore disconnect and error events from the adapter

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    function listener() {
      isUnloading.current = true;
    }

    window.addEventListener('beforeunload', listener);
    return () => window.removeEventListener('beforeunload', listener);
  }, [isUnloading]); // Select a wallet by name

  const select = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(newName => __awaiter(void 0, void 0, void 0, function* () {
    if (name === newName) return;
    if (adapter) yield adapter.disconnect();
    setName(newName);
  }), [name, adapter, setName]); // Handle the adapter's ready event

  const onReady = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => setState(state => Object.assign(Object.assign({}, state), {
    ready: true
  })), [setState]); // Handle the adapter's connect event

  const onConnect = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    if (!adapter) return;
    const {
      connected,
      publicKey,
      ready
    } = adapter;
    setState(state => Object.assign(Object.assign({}, state), {
      connected,
      publicKey,
      ready
    }));
  }, [adapter, setState]); // Handle the adapter's disconnect event

  const onDisconnect = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    // Clear the selected wallet unless the window is unloading
    if (!isUnloading.current) setName(null);
  }, [isUnloading, setName]); // Handle the adapter's error event, and local errors

  const onError = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(error => {
    // Call the provided error handler unless the window is unloading
    if (!isUnloading.current) _onError(error);
    return error;
  }, [isUnloading, _onError]); // Connect the adapter to the wallet

  const connect = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => __awaiter(void 0, void 0, void 0, function* () {
    if (isConnecting.current || connecting || disconnecting || connected) return;
    if (!wallet || !adapter) throw onError(new _errors__WEBPACK_IMPORTED_MODULE_2__.WalletNotSelectedError());

    if (!ready) {
      // Clear the selected wallet
      setName(null);

      if (false) {}

      throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotReadyError());
    }

    isConnecting.current = true;
    setConnecting(true);

    try {
      yield adapter.connect();
    } catch (error) {
      // Clear the selected wallet
      setName(null); // Rethrow the error, and onError will also be called

      throw error;
    } finally {
      setConnecting(false);
      isConnecting.current = false;
    }
  }), [isConnecting, connecting, disconnecting, connected, wallet, adapter, onError, ready, setConnecting, setName]); // Disconnect the adapter from the wallet

  const disconnect = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => __awaiter(void 0, void 0, void 0, function* () {
    if (isDisconnecting.current || disconnecting) return;
    if (!adapter) return setName(null);
    isDisconnecting.current = true;
    setDisconnecting(true);

    try {
      yield adapter.disconnect();
    } catch (error) {
      // Clear the selected wallet
      setName(null); // Rethrow the error, and onError will also be called

      throw error;
    } finally {
      setDisconnecting(false);
      isDisconnecting.current = false;
    }
  }), [isDisconnecting, disconnecting, adapter, setDisconnecting, setName]); // Send a transaction using the provided connection

  const sendTransaction = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((transaction, connection, options) => __awaiter(void 0, void 0, void 0, function* () {
    if (!adapter) throw onError(new _errors__WEBPACK_IMPORTED_MODULE_2__.WalletNotSelectedError());
    if (!connected) throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotConnectedError());
    return yield adapter.sendTransaction(transaction, connection, options);
  }), [adapter, onError, connected]); // Sign a transaction if the wallet supports it

  const signTransaction = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => adapter && 'signTransaction' in adapter ? transaction => __awaiter(void 0, void 0, void 0, function* () {
    if (!connected) throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotConnectedError());
    return yield adapter.signTransaction(transaction);
  }) : undefined, [adapter, onError, connected]); // Sign multiple transactions if the wallet supports it

  const signAllTransactions = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => adapter && 'signAllTransactions' in adapter ? transactions => __awaiter(void 0, void 0, void 0, function* () {
    if (!connected) throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotConnectedError());
    return yield adapter.signAllTransactions(transactions);
  }) : undefined, [adapter, onError, connected]); // Sign an arbitrary message if the wallet supports it

  const signMessage = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => adapter && 'signMessage' in adapter ? message => __awaiter(void 0, void 0, void 0, function* () {
    if (!connected) throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotConnectedError());
    return yield adapter.signMessage(message);
  }) : undefined, [adapter, onError, connected]); // Setup and teardown event listeners when the adapter changes

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (adapter) {
      adapter.on('ready', onReady);
      adapter.on('connect', onConnect);
      adapter.on('disconnect', onDisconnect);
      adapter.on('error', onError);
      return () => {
        adapter.off('ready', onReady);
        adapter.off('connect', onConnect);
        adapter.off('disconnect', onDisconnect);
        adapter.off('error', onError);
      };
    }
  }, [adapter, onReady, onConnect, onDisconnect, onError]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_useWallet__WEBPACK_IMPORTED_MODULE_4__.WalletContext.Provider, {
    value: {
      wallets,
      autoConnect,
      wallet,
      adapter,
      publicKey,
      ready,
      connected,
      connecting,
      disconnecting,
      select,
      connect,
      disconnect,
      sendTransaction,
      signTransaction,
      signAllTransactions,
      signMessage
    }
  }, children);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/errors.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/errors.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletNotSelectedError": () => (/* binding */ WalletNotSelectedError)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @solana/wallet-adapter-base */ "./node_modules/@solana/wallet-adapter-base/lib/index.js");

class WalletNotSelectedError extends _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_0__.WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotSelectedError';
  }

}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/index.js":
/*!****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/index.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ConnectionProvider__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ConnectionProvider */ "./node_modules/@solana/wallet-adapter-react/lib/ConnectionProvider.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _ConnectionProvider__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _ConnectionProvider__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors */ "./node_modules/@solana/wallet-adapter-react/lib/errors.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _errors__WEBPACK_IMPORTED_MODULE_1__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _errors__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _useAnchorWallet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useAnchorWallet */ "./node_modules/@solana/wallet-adapter-react/lib/useAnchorWallet.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useAnchorWallet__WEBPACK_IMPORTED_MODULE_2__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useAnchorWallet__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _useConnection__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./useConnection */ "./node_modules/@solana/wallet-adapter-react/lib/useConnection.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useConnection__WEBPACK_IMPORTED_MODULE_3__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useConnection__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _useLocalStorage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./useLocalStorage */ "./node_modules/@solana/wallet-adapter-react/lib/useLocalStorage.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useLocalStorage__WEBPACK_IMPORTED_MODULE_4__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useLocalStorage__WEBPACK_IMPORTED_MODULE_4__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _useWallet__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./useWallet */ "./node_modules/@solana/wallet-adapter-react/lib/useWallet.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useWallet__WEBPACK_IMPORTED_MODULE_5__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useWallet__WEBPACK_IMPORTED_MODULE_5__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletProvider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./WalletProvider */ "./node_modules/@solana/wallet-adapter-react/lib/WalletProvider.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletProvider__WEBPACK_IMPORTED_MODULE_6__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletProvider__WEBPACK_IMPORTED_MODULE_6__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);








/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/useAnchorWallet.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/useAnchorWallet.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useAnchorWallet": () => (/* binding */ useAnchorWallet)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _useWallet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./useWallet */ "./node_modules/@solana/wallet-adapter-react/lib/useWallet.js");


function useAnchorWallet() {
  const {
    publicKey,
    signTransaction,
    signAllTransactions
  } = (0,_useWallet__WEBPACK_IMPORTED_MODULE_1__.useWallet)();
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => publicKey && signTransaction && signAllTransactions ? {
    publicKey,
    signTransaction,
    signAllTransactions
  } : undefined, [publicKey, signTransaction, signAllTransactions]);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/useConnection.js":
/*!************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/useConnection.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConnectionContext": () => (/* binding */ ConnectionContext),
/* harmony export */   "useConnection": () => (/* binding */ useConnection)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const ConnectionContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
function useConnection() {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(ConnectionContext);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/useLocalStorage.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/useLocalStorage.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useLocalStorage": () => (/* binding */ useLocalStorage)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useLocalStorage(key, defaultState) {
  const {
    0: value,
    1: setValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => {
    if (typeof localStorage === 'undefined') return defaultState;
    const value = localStorage.getItem(key);

    try {
      return value ? JSON.parse(value) : defaultState;
    } catch (error) {
      console.warn(error);
      return defaultState;
    }
  });
  const setLocalStorage = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(newValue => {
    if (newValue === value) return;
    setValue(newValue);

    if (newValue === null) {
      localStorage.removeItem(key);
    } else {
      try {
        localStorage.setItem(key, JSON.stringify(newValue));
      } catch (error) {
        console.error(error);
      }
    }
  }, [value, setValue, key]);
  return [value, setLocalStorage];
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/useWallet.js":
/*!********************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/useWallet.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletContext": () => (/* binding */ WalletContext),
/* harmony export */   "useWallet": () => (/* binding */ useWallet)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const WalletContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
function useWallet() {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(WalletContext);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/styles.css":
/*!*****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/styles.css ***!
  \*****************************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick-theme.css":
/*!***********************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick-theme.css ***!
  \***********************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick.css":
/*!*****************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick.css ***!
  \*****************************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/next/dynamic.js":
/*!**************************************!*\
  !*** ./node_modules/next/dynamic.js ***!
  \**************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(/*! ./dist/shared/lib/dynamic */ "./node_modules/next/dist/shared/lib/dynamic.js")


/***/ }),

/***/ "@ledgerhq/hw-transport":
/*!*****************************************!*\
  !*** external "@ledgerhq/hw-transport" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ledgerhq/hw-transport");

/***/ }),

/***/ "@ledgerhq/hw-transport-webhid":
/*!************************************************!*\
  !*** external "@ledgerhq/hw-transport-webhid" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ledgerhq/hw-transport-webhid");

/***/ }),

/***/ "@project-serum/anchor":
/*!****************************************!*\
  !*** external "@project-serum/anchor" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@project-serum/anchor");

/***/ }),

/***/ "@solana/wallet-adapter-bitkeep":
/*!*************************************************!*\
  !*** external "@solana/wallet-adapter-bitkeep" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = import("@solana/wallet-adapter-bitkeep");;

/***/ }),

/***/ "@solana/wallet-adapter-clover":
/*!************************************************!*\
  !*** external "@solana/wallet-adapter-clover" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = import("@solana/wallet-adapter-clover");;

/***/ }),

/***/ "@solana/wallet-adapter-coinhub":
/*!*************************************************!*\
  !*** external "@solana/wallet-adapter-coinhub" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = import("@solana/wallet-adapter-coinhub");;

/***/ }),

/***/ "@solana/web3.js":
/*!**********************************!*\
  !*** external "@solana/web3.js" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@solana/web3.js");

/***/ }),

/***/ "@toruslabs/openlogin":
/*!***************************************!*\
  !*** external "@toruslabs/openlogin" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@toruslabs/openlogin");

/***/ }),

/***/ "@toruslabs/openlogin-ed25519":
/*!***********************************************!*\
  !*** external "@toruslabs/openlogin-ed25519" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@toruslabs/openlogin-ed25519");

/***/ }),

/***/ "bs58":
/*!***********************!*\
  !*** external "bs58" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("bs58");

/***/ }),

/***/ "eventemitter3":
/*!********************************!*\
  !*** external "eventemitter3" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("eventemitter3");

/***/ }),

/***/ "./loadable":
/*!***************************************************!*\
  !*** external "next/dist/shared/lib/loadable.js" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "redux":
/*!************************!*\
  !*** external "redux" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux");

/***/ }),

/***/ "redux-persist":
/*!********************************!*\
  !*** external "redux-persist" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist");

/***/ }),

/***/ "redux-persist/integration/react":
/*!**************************************************!*\
  !*** external "redux-persist/integration/react" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist/integration/react");

/***/ }),

/***/ "redux-persist/lib/storage":
/*!********************************************!*\
  !*** external "redux-persist/lib/storage" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ "redux-thunk":
/*!******************************!*\
  !*** external "redux-thunk" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-thunk");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvX2FwcC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTU8sY0FBYyxnQkFBR0wsb0RBQWEsQ0FBQyxJQUFELENBQXBDO0FBRUEsTUFBTU0sT0FBTyxHQUFHQywrQkFBaEI7QUFFQSxNQUFNRyxVQUFVLEdBQUcsSUFBSU4sa0VBQUosQ0FBMkJFLE9BQTNCLENBQW5CO0FBRWUsU0FBU08sZ0JBQVQsR0FBNEI7QUFDekMsUUFBTTtBQUFBLE9BQUNDLE9BQUQ7QUFBQSxPQUFVQztBQUFWLE1BQTZCZCxpREFBVSxDQUFDSSxjQUFELENBQTdDO0FBQ0EsU0FBTyxDQUFDUyxPQUFELEVBQVVDLFVBQVYsQ0FBUDtBQUNEO0FBRU0sTUFBTUMscUJBQW1DLEdBQUcsQ0FBQztBQUFFQyxFQUFBQTtBQUFGLENBQUQsS0FBa0I7QUFDbkUsUUFBTUMsTUFBTSxHQUFHcEIsdUVBQVMsRUFBeEI7QUFDQSxRQUFNO0FBQUEsT0FBQ2dCLE9BQUQ7QUFBQSxPQUFVQztBQUFWLE1BQXdCWiwrQ0FBUSxDQUFDLENBQUQsQ0FBdEM7QUFFQUQsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ2QsS0FBQyxZQUFZO0FBQ1gsVUFBSWdCLE1BQUosYUFBSUEsTUFBSixlQUFJQSxNQUFNLENBQUVDLFNBQVosRUFBdUI7QUFDckIsY0FBTUwsT0FBTyxHQUFHLE1BQU1KLFVBQVUsQ0FBQ1UsVUFBWCxDQUFzQkYsTUFBTSxDQUFDQyxTQUE3QixDQUF0QjtBQUNBSixRQUFBQSxVQUFVLENBQUNELE9BQU8sR0FBR2YsNkRBQVgsQ0FBVjtBQUNEO0FBQ0YsS0FMRDtBQU1ELEdBUFEsRUFPTixDQUFDbUIsTUFBRCxFQUFTUixVQUFULENBUE0sQ0FBVDtBQVNBUixFQUFBQSxnREFBUyxDQUFDLE1BQU07QUFDZCxLQUFDLFlBQVk7QUFDWCxVQUFJZ0IsTUFBSixhQUFJQSxNQUFKLGVBQUlBLE1BQU0sQ0FBRUMsU0FBWixFQUF1QjtBQUNyQixjQUFNTCxPQUFPLEdBQUcsTUFBTUosVUFBVSxDQUFDVSxVQUFYLENBQXNCRixNQUFNLENBQUNDLFNBQTdCLENBQXRCO0FBQ0FKLFFBQUFBLFVBQVUsQ0FBQ0QsT0FBTyxHQUFHZiw2REFBWCxDQUFWO0FBQ0Q7QUFDRixLQUxEO0FBTUQsR0FQUSxFQU9OLENBQUNtQixNQUFELEVBQVNSLFVBQVQsQ0FQTSxDQUFUO0FBU0Esc0JBQ0UsOERBQUMsY0FBRCxDQUFnQixRQUFoQjtBQUF5QixTQUFLLEVBQUUsQ0FBQ0ksT0FBRCxFQUFVQyxVQUFWLENBQWhDO0FBQUEsY0FDR0U7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFLRCxDQTNCTTs7Ozs7Ozs7Ozs7QUNoQk07Ozs7Ozs7O0FBQ2JJLDhDQUE2QztBQUN6Q0csRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0FELGFBQUEsR0FBZ0JFLEtBQWhCO0FBQ0FGLGVBQUEsR0FBa0JJLE9BQWxCOztBQUNBLElBQUlDLE1BQU0sR0FBR0Msc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsb0JBQUQsQ0FBUixDQUFuQzs7QUFDQSxJQUFJQyxTQUFTLEdBQUdGLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLDhCQUFELENBQVIsQ0FBdEM7O0FBQ0EsU0FBU0Qsc0JBQVQsQ0FBZ0NHLEdBQWhDLEVBQXFDO0FBQ2pDLFNBQU9BLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxVQUFYLEdBQXdCRCxHQUF4QixHQUE4QjtBQUNqQ04sSUFBQUEsT0FBTyxFQUFFTTtBQUR3QixHQUFyQztBQUdIOztBQUNELE1BQU1FLFlBQVksT0FBbEI7O0FBQ0EsU0FBU1QsS0FBVCxDQUFlVSxtQkFBZixFQUFvQ0MsZUFBcEMsRUFBcUQ7QUFDakQ7QUFDQSxTQUFPQSxlQUFlLENBQUNDLE9BQXZCO0FBQ0EsU0FBT0QsZUFBZSxDQUFDRSxPQUF2QixDQUhpRCxDQUlqRDs7QUFDQSxNQUFJLENBQUNKLFlBQUwsRUFBbUI7QUFDZixXQUFPQyxtQkFBbUIsQ0FBQ0MsZUFBRCxDQUExQjtBQUNIOztBQUNELFFBQU1HLE9BQU8sR0FBR0gsZUFBZSxDQUFDSSxPQUFoQyxDQVJpRCxDQVNqRDs7QUFDQSxTQUFPLE1BQUksYUFBY1osTUFBTSxDQUFDRixPQUFQLENBQWVlLGFBQWYsQ0FBNkJGLE9BQTdCLEVBQXNDO0FBQ3ZERyxJQUFBQSxLQUFLLEVBQUUsSUFEZ0Q7QUFFdkRDLElBQUFBLFNBQVMsRUFBRSxJQUY0QztBQUd2REMsSUFBQUEsU0FBUyxFQUFFLEtBSDRDO0FBSXZEQyxJQUFBQSxRQUFRLEVBQUU7QUFKNkMsR0FBdEMsQ0FBekI7QUFPSDs7QUFDRCxTQUFTbEIsT0FBVCxDQUFpQm1CLGNBQWpCLEVBQWlDQyxPQUFqQyxFQUEwQztBQUN0QyxNQUFJQyxVQUFVLEdBQUdqQixTQUFTLENBQUNMLE9BQTNCO0FBQ0EsTUFBSVUsZUFBZSxHQUFHO0FBQ2xCO0FBQ0FJLElBQUFBLE9BQU8sRUFBRSxDQUFDO0FBQUVFLE1BQUFBLEtBQUY7QUFBVUMsTUFBQUEsU0FBVjtBQUFzQkMsTUFBQUE7QUFBdEIsS0FBRCxLQUFzQztBQUMzQyxVQUFJLENBQUNBLFNBQUwsRUFBZ0IsT0FBTyxJQUFQOztBQUNoQixnQkFBNEM7QUFDeEMsWUFBSUQsU0FBSixFQUFlO0FBQ1gsaUJBQU8sSUFBUDtBQUNIOztBQUNELFlBQUlELEtBQUosRUFBVztBQUNQLGlCQUFPLGFBQWNkLE1BQU0sQ0FBQ0YsT0FBUCxDQUFlZSxhQUFmLENBQTZCLEdBQTdCLEVBQWtDLElBQWxDLEVBQXdDQyxLQUFLLENBQUNPLE9BQTlDLEVBQXVELGFBQWNyQixNQUFNLENBQUNGLE9BQVAsQ0FBZWUsYUFBZixDQUE2QixJQUE3QixFQUFtQyxJQUFuQyxDQUFyRSxFQUErR0MsS0FBSyxDQUFDUSxLQUFySCxDQUFyQjtBQUNIO0FBQ0o7O0FBQ0QsYUFBTyxJQUFQO0FBQ0g7QUFiaUIsR0FBdEIsQ0FGc0MsQ0FpQnRDO0FBQ0E7QUFDQTtBQUNBOztBQUNBLE1BQUlKLGNBQWMsWUFBWUssT0FBOUIsRUFBdUM7QUFDbkNmLElBQUFBLGVBQWUsQ0FBQ2dCLE1BQWhCLEdBQXlCLE1BQUlOLGNBQTdCLENBRG1DLENBR3ZDOztBQUNDLEdBSkQsTUFJTyxJQUFJLE9BQU9BLGNBQVAsS0FBMEIsVUFBOUIsRUFBMEM7QUFDN0NWLElBQUFBLGVBQWUsQ0FBQ2dCLE1BQWhCLEdBQXlCTixjQUF6QixDQUQ2QyxDQUVqRDtBQUNDLEdBSE0sTUFHQSxJQUFJLE9BQU9BLGNBQVAsS0FBMEIsUUFBOUIsRUFBd0M7QUFDM0NWLElBQUFBLGVBQWUsbUNBQ1JBLGVBRFEsR0FFUlUsY0FGUSxDQUFmO0FBSUgsR0FqQ3FDLENBa0N0Qzs7O0FBQ0FWLEVBQUFBLGVBQWUsbUNBQ1JBLGVBRFEsR0FFUlcsT0FGUSxDQUFmO0FBSUEsUUFBTU0sZUFBZSxHQUFHakIsZUFBeEI7O0FBQ0EsTUFBSSxJQUFKLEVBQTZDO0FBQ3pDO0FBQ0EsUUFBSSxTQUFrQ2lCLGVBQWUsQ0FBQ0csUUFBdEQsRUFBZ0U7QUFDNUQ7QUFDQSxZQUFNLElBQUlDLEtBQUosQ0FBVyxxSEFBWCxDQUFOO0FBQ0g7QUFDSjs7QUFDRCxNQUFJSixlQUFlLENBQUNHLFFBQXBCLEVBQThCO0FBQzFCLFdBQU9SLFVBQVUsQ0FBQ0ssZUFBRCxDQUFqQjtBQUNILEdBakRxQyxDQWtEdEM7OztBQUNBLE1BQUlqQixlQUFlLENBQUNzQixpQkFBcEIsRUFBdUM7QUFDbkN0QixJQUFBQSxlQUFlLG1DQUNSQSxlQURRLEdBRVJBLGVBQWUsQ0FBQ3NCLGlCQUZSLENBQWY7QUFJQSxXQUFPdEIsZUFBZSxDQUFDc0IsaUJBQXZCO0FBQ0gsR0F6RHFDLENBMER0Qzs7O0FBQ0EsTUFBSSxPQUFPdEIsZUFBZSxDQUFDdUIsR0FBdkIsS0FBK0IsU0FBbkMsRUFBOEM7QUFDMUMsUUFBSSxDQUFDdkIsZUFBZSxDQUFDdUIsR0FBckIsRUFBMEI7QUFDdEIsYUFBT3ZCLGVBQWUsQ0FBQ3VCLEdBQXZCO0FBQ0EsYUFBT2xDLEtBQUssQ0FBQ3VCLFVBQUQsRUFBYVosZUFBYixDQUFaO0FBQ0g7O0FBQ0QsV0FBT0EsZUFBZSxDQUFDdUIsR0FBdkI7QUFDSDs7QUFDRCxTQUFPWCxVQUFVLENBQUNaLGVBQUQsQ0FBakI7QUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0NqR0Q7QUFDQTs7QUFDQTtBQUNBO0NBR0E7O0FBQ0E7QUFDQTs7QUFDQU4sbUJBQU8sQ0FBQyw2R0FBRCxDQUFQLEVBQ0E7OztBQUNBO0FBQ0E7QUFDQTs7QUFDQSxNQUFNbUMsd0JBQXdCLEdBQUd0QyxtREFBTyxDQUN0QyxNQUFNLGtSQURnQyxFQUV0QztBQUNFZ0MsRUFBQUEsR0FBRyxFQUFFLEtBRFA7QUFBQTtBQUFBLHdDQURhLDJIQUNiO0FBQUEsK0JBRGEseURBQ2I7QUFBQTtBQUFBLENBRnNDLENBQXhDOztBQU9BLFNBQVNPLEtBQVQsQ0FBZTtBQUFFQyxFQUFBQSxTQUFGO0FBQWFDLEVBQUFBO0FBQWIsQ0FBZixFQUFtRDtBQUNqRCxzQkFDRSw4REFBQyx3QkFBRDtBQUFBLDJCQUNFLDhEQUFDLDBFQUFEO0FBQUEsNkJBQ0UsOERBQUMsaURBQUQ7QUFBVSxhQUFLLEVBQUVOLHlDQUFqQjtBQUFBLCtCQUNFLDhEQUFDLHdFQUFEO0FBQWEsaUJBQU8sRUFBRSxJQUF0QjtBQUE0QixtQkFBUyxFQUFFQyw2Q0FBdkM7QUFBQSxpQ0FDRTtBQUFBLG9DQUNFLDhEQUFDLGtEQUFEO0FBQUEsc0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREYsZUFFRTtBQUFNLG1CQUFHLEVBQUMsTUFBVjtBQUFpQixvQkFBSSxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBTUU7QUFBSyx1QkFBUyxFQUFDLGtEQUFmO0FBQUEscUNBQ0UsOERBQUMsU0FBRCxvQkFBZUssU0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFvQkQ7O0FBQ0QsaUVBQWVGLEtBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN0NBO0FBQ0E7QUFDQTtBQUNBO0NBTWlEO0FBQ2pEOztBQUNBLE1BQU1XLGFBQWEsR0FBRztBQUNwQkMsRUFBQUEsR0FBRyxFQUFFLE9BRGU7QUFFcEJDLEVBQUFBLE9BQU8sRUFBRSxDQUZXO0FBR3BCSCxFQUFBQSxPQUhvQixxRUFJcEI7O0FBSm9CLENBQXRCO0FBT0EsTUFBTUksZ0JBQWdCLEdBQUdMLDZEQUFjLENBQUNFLGFBQUQsRUFBZ0JSLDhDQUFoQixDQUF2QztBQUNBLE1BQU1ZLGdCQUFnQixHQUFHVCwwQ0FBekI7QUFDQSxJQUFJVixLQUFLLEdBQUdRLGtEQUFXLENBQ3JCVSxnQkFEcUIsRUFFckJDLGdCQUFnQixDQUFDVixzREFBZSxDQUFDRSxvREFBRCxDQUFoQixDQUZLLENBQXZCO0FBSUEsSUFBSVYsU0FBUyxHQUFHVywyREFBWSxDQUFDWixLQUFELENBQTVCOztBQUNBLE1BQU1vQixLQUFLLEdBQUcsTUFBTSxDQUVuQixDQUZEOztBQUdBLGlFQUFlQSxLQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUJBLE1BQU1DLGFBQWEsR0FBRztBQUNwQjNDLEVBQUFBLE9BQU8sRUFBRSxLQURXO0FBRXBCNEMsRUFBQUEsU0FBUyxFQUFFLEVBRlM7QUFHcEJDLEVBQUFBLFFBQVEsRUFBRTtBQUhVLENBQXRCOztBQU1DLE1BQU1DLFdBQVcsR0FBRyxDQUFDQyxLQUFLLEdBQUdKLGFBQVQsRUFBd0JLLE1BQXhCLEtBQXdDO0FBQzNELFVBQVFBLE1BQU0sQ0FBQ0MsSUFBZjtBQUNFLFNBQUssV0FBTDtBQUNFLDZDQUNLRixLQURMO0FBRUVILFFBQUFBLFNBQVMsRUFBRUksTUFBTSxDQUFDRSxPQUZwQjtBQUdFbEQsUUFBQUEsT0FBTyxFQUFFO0FBSFg7O0FBS0YsU0FBSyxRQUFMO0FBQ0UsNkNBQ0srQyxLQURMO0FBRUVGLFFBQUFBLFFBQVEsRUFBRUcsTUFBTSxDQUFDRSxPQUZuQjtBQUdFbEQsUUFBQUEsT0FBTyxFQUFFO0FBSFg7O0FBS0Y7QUFDRSxhQUFPK0MsS0FBUDtBQWRKO0FBZ0JELENBakJBOztBQW1CRCxpRUFBZUQsV0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NDdkJBOztBQUNBO0FBRUEsaUVBQWVLLHNEQUFlLENBQUM7QUFDN0JMLEVBQUFBLFdBQVdBLG1EQUFBQTtBQURrQixDQUFELENBQTlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTEE7QUFDQTtBQUNPLE1BQU1PLGlCQUFOLFNBQWdDRCxzREFBaEMsQ0FBNkM7QUFFN0MsSUFBSUUsb0JBQUo7O0FBQ1AsQ0FBQyxVQUFVQSxvQkFBVixFQUFnQztBQUM3QkEsRUFBQUEsb0JBQW9CLENBQUMsU0FBRCxDQUFwQixHQUFrQyxjQUFsQztBQUNBQSxFQUFBQSxvQkFBb0IsQ0FBQyxTQUFELENBQXBCLEdBQWtDLFNBQWxDO0FBQ0FBLEVBQUFBLG9CQUFvQixDQUFDLFFBQUQsQ0FBcEIsR0FBaUMsUUFBakM7QUFDSCxDQUpELEVBSUdBLG9CQUFvQixLQUFLQSxvQkFBb0IsR0FBRyxFQUE1QixDQUp2Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0xPLE1BQU1DLFdBQU4sU0FBMEJ0QyxLQUExQixDQUFnQztBQUNuQztBQUNBdUMsRUFBQUEsV0FBVyxDQUFDL0MsT0FBRCxFQUFVUCxLQUFWLEVBQWlCO0FBQ3hCLFVBQU1PLE9BQU47QUFDQSxTQUFLUCxLQUFMLEdBQWFBLEtBQWI7QUFDSDs7QUFMa0M7QUFPaEMsTUFBTXVELG1CQUFOLFNBQWtDRixXQUFsQyxDQUE4QztBQUNqREMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLHFCQUFaO0FBQ0g7O0FBSmdEO0FBTTlDLE1BQU1DLHVCQUFOLFNBQXNDTCxXQUF0QyxDQUFrRDtBQUNyREMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLHlCQUFaO0FBQ0g7O0FBSm9EO0FBTWxELE1BQU1FLG1CQUFOLFNBQWtDTixXQUFsQyxDQUE4QztBQUNqREMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLHFCQUFaO0FBQ0g7O0FBSmdEO0FBTTlDLE1BQU1HLHFCQUFOLFNBQW9DUCxXQUFwQyxDQUFnRDtBQUNuREMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLHVCQUFaO0FBQ0g7O0FBSmtEO0FBTWhELE1BQU1JLHVCQUFOLFNBQXNDUixXQUF0QyxDQUFrRDtBQUNyREMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLHlCQUFaO0FBQ0g7O0FBSm9EO0FBTWxELE1BQU1LLHdCQUFOLFNBQXVDVCxXQUF2QyxDQUFtRDtBQUN0REMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLDBCQUFaO0FBQ0g7O0FBSnFEO0FBTW5ELE1BQU1NLGtCQUFOLFNBQWlDVixXQUFqQyxDQUE2QztBQUNoREMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLG9CQUFaO0FBQ0g7O0FBSitDO0FBTTdDLE1BQU1PLG9CQUFOLFNBQW1DWCxXQUFuQyxDQUErQztBQUNsREMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLHNCQUFaO0FBQ0g7O0FBSmlEO0FBTS9DLE1BQU1RLGtCQUFOLFNBQWlDWixXQUFqQyxDQUE2QztBQUNoREMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLG9CQUFaO0FBQ0g7O0FBSitDO0FBTTdDLE1BQU1TLHVCQUFOLFNBQXNDYixXQUF0QyxDQUFrRDtBQUNyREMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLHlCQUFaO0FBQ0g7O0FBSm9EO0FBTWxELE1BQU1VLDBCQUFOLFNBQXlDZCxXQUF6QyxDQUFxRDtBQUN4REMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLDRCQUFaO0FBQ0g7O0FBSnVEO0FBTXJELE1BQU1XLHNCQUFOLFNBQXFDZixXQUFyQyxDQUFpRDtBQUNwREMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLHdCQUFaO0FBQ0g7O0FBSm1EO0FBTWpELE1BQU1ZLDBCQUFOLFNBQXlDaEIsV0FBekMsQ0FBcUQ7QUFDeERDLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0UsU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSw0QkFBWjtBQUNIOztBQUp1RDtBQU1yRCxNQUFNYSxrQkFBTixTQUFpQ2pCLFdBQWpDLENBQTZDO0FBQ2hEQyxFQUFBQSxXQUFXLEdBQUc7QUFDVixVQUFNLEdBQUdFLFNBQVQ7QUFDQSxTQUFLQyxJQUFMLEdBQVksb0JBQVo7QUFDSDs7QUFKK0M7QUFNN0MsTUFBTWMsd0JBQU4sU0FBdUNsQixXQUF2QyxDQUFtRDtBQUN0REMsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHRSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLDBCQUFaO0FBQ0g7O0FBSnFEO0FBTW5ELE1BQU1lLHVCQUFOLFNBQXNDbkIsV0FBdEMsQ0FBa0Q7QUFDckRDLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0UsU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSx5QkFBWjtBQUNIOztBQUpvRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pHekQ7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZBLElBQUlnQixTQUFTLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsU0FBZCxJQUE0QixVQUFVQyxPQUFWLEVBQW1CQyxVQUFuQixFQUErQkMsQ0FBL0IsRUFBa0NDLFNBQWxDLEVBQTZDO0FBQ3JGLFdBQVNDLEtBQVQsQ0FBZWhHLEtBQWYsRUFBc0I7QUFBRSxXQUFPQSxLQUFLLFlBQVk4RixDQUFqQixHQUFxQjlGLEtBQXJCLEdBQTZCLElBQUk4RixDQUFKLENBQU0sVUFBVUcsT0FBVixFQUFtQjtBQUFFQSxNQUFBQSxPQUFPLENBQUNqRyxLQUFELENBQVA7QUFBaUIsS0FBNUMsQ0FBcEM7QUFBb0Y7O0FBQzVHLFNBQU8sS0FBSzhGLENBQUMsS0FBS0EsQ0FBQyxHQUFHbkUsT0FBVCxDQUFOLEVBQXlCLFVBQVVzRSxPQUFWLEVBQW1CQyxNQUFuQixFQUEyQjtBQUN2RCxhQUFTQyxTQUFULENBQW1CbkcsS0FBbkIsRUFBMEI7QUFBRSxVQUFJO0FBQUVvRyxRQUFBQSxJQUFJLENBQUNMLFNBQVMsQ0FBQ00sSUFBVixDQUFlckcsS0FBZixDQUFELENBQUo7QUFBOEIsT0FBcEMsQ0FBcUMsT0FBT3NHLENBQVAsRUFBVTtBQUFFSixRQUFBQSxNQUFNLENBQUNJLENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzNGLGFBQVNDLFFBQVQsQ0FBa0J2RyxLQUFsQixFQUF5QjtBQUFFLFVBQUk7QUFBRW9HLFFBQUFBLElBQUksQ0FBQ0wsU0FBUyxDQUFDLE9BQUQsQ0FBVCxDQUFtQi9GLEtBQW5CLENBQUQsQ0FBSjtBQUFrQyxPQUF4QyxDQUF5QyxPQUFPc0csQ0FBUCxFQUFVO0FBQUVKLFFBQUFBLE1BQU0sQ0FBQ0ksQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDOUYsYUFBU0YsSUFBVCxDQUFjSSxNQUFkLEVBQXNCO0FBQUVBLE1BQUFBLE1BQU0sQ0FBQ0MsSUFBUCxHQUFjUixPQUFPLENBQUNPLE1BQU0sQ0FBQ3hHLEtBQVIsQ0FBckIsR0FBc0NnRyxLQUFLLENBQUNRLE1BQU0sQ0FBQ3hHLEtBQVIsQ0FBTCxDQUFvQjBHLElBQXBCLENBQXlCUCxTQUF6QixFQUFvQ0ksUUFBcEMsQ0FBdEM7QUFBc0Y7O0FBQzlHSCxJQUFBQSxJQUFJLENBQUMsQ0FBQ0wsU0FBUyxHQUFHQSxTQUFTLENBQUNZLEtBQVYsQ0FBZ0JmLE9BQWhCLEVBQXlCQyxVQUFVLElBQUksRUFBdkMsQ0FBYixFQUF5RFEsSUFBekQsRUFBRCxDQUFKO0FBQ0gsR0FMTSxDQUFQO0FBTUgsQ0FSRDs7QUFTTyxTQUFTTyxJQUFULENBQWNDLFFBQWQsRUFBd0JDLFFBQXhCLEVBQWtDQyxLQUFsQyxFQUF5QztBQUM1QyxNQUFJQSxLQUFLLEdBQUcsQ0FBWixFQUFlO0FBQ1hDLElBQUFBLFVBQVUsQ0FBQyxNQUFNckIsU0FBUyxDQUFDLElBQUQsRUFBTyxLQUFLLENBQVosRUFBZSxLQUFLLENBQXBCLEVBQXVCLGFBQWE7QUFDMUQsWUFBTWMsSUFBSSxHQUFHLE1BQU1JLFFBQVEsRUFBM0I7QUFDQSxVQUFJLENBQUNKLElBQUwsRUFDSUcsSUFBSSxDQUFDQyxRQUFELEVBQVdDLFFBQVgsRUFBcUJDLEtBQUssR0FBRyxDQUE3QixDQUFKO0FBQ1AsS0FKeUIsQ0FBaEIsRUFJTkQsUUFKTSxDQUFWO0FBS0g7QUFDSjtBQUNNLFNBQVNHLGNBQVQsQ0FBd0JDLE9BQXhCLEVBQWlDQyxZQUFqQyxFQUErQ0MsU0FBL0MsRUFBMEQ7QUFDN0RSLEVBQUFBLElBQUksQ0FBQyxNQUFNO0FBQ1AsVUFBTTtBQUFFUyxNQUFBQTtBQUFGLFFBQVlILE9BQWxCOztBQUNBLFFBQUlHLEtBQUosRUFBVztBQUNQLFVBQUksQ0FBQ0gsT0FBTyxDQUFDSSxJQUFSLENBQWEsT0FBYixDQUFMLEVBQTRCO0FBQ3hCQyxRQUFBQSxPQUFPLENBQUNDLElBQVIsQ0FBYyxHQUFFTixPQUFPLENBQUMxQyxXQUFSLENBQW9CRyxJQUFLLDBDQUF6QztBQUNIO0FBQ0o7O0FBQ0QsV0FBTzBDLEtBQVA7QUFDSCxHQVJHLEVBUURGLFlBUkMsRUFRYUMsU0FSYixDQUFKO0FBU0g7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVCRCxJQUFJekIsU0FBUyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFNBQWQsSUFBNEIsVUFBVUMsT0FBVixFQUFtQkMsVUFBbkIsRUFBK0JDLENBQS9CLEVBQWtDQyxTQUFsQyxFQUE2QztBQUNyRixXQUFTQyxLQUFULENBQWVoRyxLQUFmLEVBQXNCO0FBQUUsV0FBT0EsS0FBSyxZQUFZOEYsQ0FBakIsR0FBcUI5RixLQUFyQixHQUE2QixJQUFJOEYsQ0FBSixDQUFNLFVBQVVHLE9BQVYsRUFBbUI7QUFBRUEsTUFBQUEsT0FBTyxDQUFDakcsS0FBRCxDQUFQO0FBQWlCLEtBQTVDLENBQXBDO0FBQW9GOztBQUM1RyxTQUFPLEtBQUs4RixDQUFDLEtBQUtBLENBQUMsR0FBR25FLE9BQVQsQ0FBTixFQUF5QixVQUFVc0UsT0FBVixFQUFtQkMsTUFBbkIsRUFBMkI7QUFDdkQsYUFBU0MsU0FBVCxDQUFtQm5HLEtBQW5CLEVBQTBCO0FBQUUsVUFBSTtBQUFFb0csUUFBQUEsSUFBSSxDQUFDTCxTQUFTLENBQUNNLElBQVYsQ0FBZXJHLEtBQWYsQ0FBRCxDQUFKO0FBQThCLE9BQXBDLENBQXFDLE9BQU9zRyxDQUFQLEVBQVU7QUFBRUosUUFBQUEsTUFBTSxDQUFDSSxDQUFELENBQU47QUFBWTtBQUFFOztBQUMzRixhQUFTQyxRQUFULENBQWtCdkcsS0FBbEIsRUFBeUI7QUFBRSxVQUFJO0FBQUVvRyxRQUFBQSxJQUFJLENBQUNMLFNBQVMsQ0FBQyxPQUFELENBQVQsQ0FBbUIvRixLQUFuQixDQUFELENBQUo7QUFBa0MsT0FBeEMsQ0FBeUMsT0FBT3NHLENBQVAsRUFBVTtBQUFFSixRQUFBQSxNQUFNLENBQUNJLENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzlGLGFBQVNGLElBQVQsQ0FBY0ksTUFBZCxFQUFzQjtBQUFFQSxNQUFBQSxNQUFNLENBQUNDLElBQVAsR0FBY1IsT0FBTyxDQUFDTyxNQUFNLENBQUN4RyxLQUFSLENBQXJCLEdBQXNDZ0csS0FBSyxDQUFDUSxNQUFNLENBQUN4RyxLQUFSLENBQUwsQ0FBb0IwRyxJQUFwQixDQUF5QlAsU0FBekIsRUFBb0NJLFFBQXBDLENBQXRDO0FBQXNGOztBQUM5R0gsSUFBQUEsSUFBSSxDQUFDLENBQUNMLFNBQVMsR0FBR0EsU0FBUyxDQUFDWSxLQUFWLENBQWdCZixPQUFoQixFQUF5QkMsVUFBVSxJQUFJLEVBQXZDLENBQWIsRUFBeURRLElBQXpELEVBQUQsQ0FBSjtBQUNILEdBTE0sQ0FBUDtBQU1ILENBUkQ7O0FBU0EsSUFBSW9CLE1BQU0sR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxNQUFkLElBQXlCLFVBQVVDLENBQVYsRUFBYXBCLENBQWIsRUFBZ0I7QUFDbEQsTUFBSXFCLENBQUMsR0FBRyxFQUFSOztBQUNBLE9BQUssSUFBSUMsQ0FBVCxJQUFjRixDQUFkLEVBQWlCLElBQUk3SCxNQUFNLENBQUNnSSxTQUFQLENBQWlCQyxjQUFqQixDQUFnQ0MsSUFBaEMsQ0FBcUNMLENBQXJDLEVBQXdDRSxDQUF4QyxLQUE4Q3RCLENBQUMsQ0FBQzBCLE9BQUYsQ0FBVUosQ0FBVixJQUFlLENBQWpFLEVBQ2JELENBQUMsQ0FBQ0MsQ0FBRCxDQUFELEdBQU9GLENBQUMsQ0FBQ0UsQ0FBRCxDQUFSOztBQUNKLE1BQUlGLENBQUMsSUFBSSxJQUFMLElBQWEsT0FBTzdILE1BQU0sQ0FBQ29JLHFCQUFkLEtBQXdDLFVBQXpELEVBQ0ksS0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBUixFQUFXTixDQUFDLEdBQUcvSCxNQUFNLENBQUNvSSxxQkFBUCxDQUE2QlAsQ0FBN0IsQ0FBcEIsRUFBcURRLENBQUMsR0FBR04sQ0FBQyxDQUFDTyxNQUEzRCxFQUFtRUQsQ0FBQyxFQUFwRSxFQUF3RTtBQUNwRSxRQUFJNUIsQ0FBQyxDQUFDMEIsT0FBRixDQUFVSixDQUFDLENBQUNNLENBQUQsQ0FBWCxJQUFrQixDQUFsQixJQUF1QnJJLE1BQU0sQ0FBQ2dJLFNBQVAsQ0FBaUJPLG9CQUFqQixDQUFzQ0wsSUFBdEMsQ0FBMkNMLENBQTNDLEVBQThDRSxDQUFDLENBQUNNLENBQUQsQ0FBL0MsQ0FBM0IsRUFDSVAsQ0FBQyxDQUFDQyxDQUFDLENBQUNNLENBQUQsQ0FBRixDQUFELEdBQVVSLENBQUMsQ0FBQ0UsQ0FBQyxDQUFDTSxDQUFELENBQUYsQ0FBWDtBQUNQO0FBQ0wsU0FBT1AsQ0FBUDtBQUNILENBVkQ7O0FBV0E7QUFDQTtBQUNPLE1BQU1VLHVCQUFOLFNBQXNDaEUsdURBQXRDLENBQXdEO0FBQzNEaUUsRUFBQUEsZUFBZSxDQUFDQyxXQUFELEVBQWNySixVQUFkLEVBQTBCcUMsT0FBTyxHQUFHLEVBQXBDLEVBQXdDO0FBQ25ELFdBQU9vRSxTQUFTLENBQUMsSUFBRCxFQUFPLEtBQUssQ0FBWixFQUFlLEtBQUssQ0FBcEIsRUFBdUIsYUFBYTtBQUNoRCxVQUFJMkIsSUFBSSxHQUFHLElBQVg7O0FBQ0EsVUFBSTtBQUNBLFlBQUk7QUFDQWlCLFVBQUFBLFdBQVcsQ0FBQ0MsUUFBWixLQUF5QkQsV0FBVyxDQUFDQyxRQUFaLEdBQXVCLEtBQUs3SSxTQUFMLElBQWtCOEksU0FBbEU7QUFDQUYsVUFBQUEsV0FBVyxDQUFDRyxlQUFaLEtBQWdDSCxXQUFXLENBQUNHLGVBQVosR0FBOEIsQ0FBQyxNQUFNeEosVUFBVSxDQUFDeUosa0JBQVgsQ0FBOEIsV0FBOUIsQ0FBUCxFQUFtREMsU0FBakg7O0FBQ0EsZ0JBQU07QUFBRUMsWUFBQUE7QUFBRixjQUFjdEgsT0FBcEI7QUFBQSxnQkFBNkJ1SCxXQUFXLEdBQUdyQixNQUFNLENBQUNsRyxPQUFELEVBQVUsQ0FBQyxTQUFELENBQVYsQ0FBakQ7O0FBQ0EsV0FBQ3NILE9BQU8sS0FBSyxJQUFaLElBQW9CQSxPQUFPLEtBQUssS0FBSyxDQUFyQyxHQUF5QyxLQUFLLENBQTlDLEdBQWtEQSxPQUFPLENBQUNWLE1BQTNELEtBQXNFSSxXQUFXLENBQUNRLFdBQVosQ0FBd0IsR0FBR0YsT0FBM0IsQ0FBdEU7QUFDQU4sVUFBQUEsV0FBVyxHQUFHLE1BQU0sS0FBS1MsZUFBTCxDQUFxQlQsV0FBckIsQ0FBcEI7QUFDQSxnQkFBTVUsY0FBYyxHQUFHVixXQUFXLENBQUNXLFNBQVosRUFBdkI7QUFDQSxpQkFBTyxNQUFNaEssVUFBVSxDQUFDaUssa0JBQVgsQ0FBOEJGLGNBQTlCLEVBQThDSCxXQUE5QyxDQUFiO0FBQ0gsU0FSRCxDQVNBLE9BQU81SCxLQUFQLEVBQWM7QUFDVjtBQUNBLGNBQUlBLEtBQUssWUFBWXFELGdEQUFyQixFQUFrQztBQUM5QitDLFlBQUFBLElBQUksR0FBRyxLQUFQO0FBQ0Esa0JBQU1wRyxLQUFOO0FBQ0g7O0FBQ0QsZ0JBQU0sSUFBSW1FLCtEQUFKLENBQStCbkUsS0FBSyxLQUFLLElBQVYsSUFBa0JBLEtBQUssS0FBSyxLQUFLLENBQWpDLEdBQXFDLEtBQUssQ0FBMUMsR0FBOENBLEtBQUssQ0FBQ08sT0FBbkYsRUFBNEZQLEtBQTVGLENBQU47QUFDSDtBQUNKLE9BbEJELENBbUJBLE9BQU9BLEtBQVAsRUFBYztBQUNWLFlBQUlvRyxJQUFKLEVBQVU7QUFDTixlQUFLQSxJQUFMLENBQVUsT0FBVixFQUFtQnBHLEtBQW5CO0FBQ0g7O0FBQ0QsY0FBTUEsS0FBTjtBQUNIO0FBQ0osS0EzQmUsQ0FBaEI7QUE0Qkg7O0FBOUIwRDtBQWdDeEQsTUFBTWtJLDhCQUFOLFNBQTZDZix1QkFBN0MsQ0FBcUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEQ1RTtBQUNBO0FBQ0E7QUFDTyxNQUFNbUIsa0JBQWtCLEdBQUcsQ0FBQztBQUFFL0osRUFBQUEsUUFBRjtBQUFZZ0ssRUFBQUEsUUFBWjtBQUFzQkMsRUFBQUEsTUFBTSxHQUFHO0FBQUVDLElBQUFBLFVBQVUsRUFBRTtBQUFkO0FBQS9CLENBQUQsS0FBbUU7QUFDakcsUUFBTXpLLFVBQVUsR0FBR29LLDhDQUFPLENBQUMsTUFBTSxJQUFJbEssdURBQUosQ0FBZXFLLFFBQWYsRUFBeUJDLE1BQXpCLENBQVAsRUFBeUMsQ0FBQ0QsUUFBRCxFQUFXQyxNQUFYLENBQXpDLENBQTFCO0FBQ0Esc0JBQU9MLDBEQUFBLENBQW9CRSxzRUFBcEIsRUFBZ0Q7QUFBRXZKLElBQUFBLEtBQUssRUFBRTtBQUFFZCxNQUFBQTtBQUFGO0FBQVQsR0FBaEQsRUFBMkVPLFFBQTNFLENBQVA7QUFDSCxDQUhNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIUCxJQUFJa0csU0FBUyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFNBQWQsSUFBNEIsVUFBVUMsT0FBVixFQUFtQkMsVUFBbkIsRUFBK0JDLENBQS9CLEVBQWtDQyxTQUFsQyxFQUE2QztBQUNyRixXQUFTQyxLQUFULENBQWVoRyxLQUFmLEVBQXNCO0FBQUUsV0FBT0EsS0FBSyxZQUFZOEYsQ0FBakIsR0FBcUI5RixLQUFyQixHQUE2QixJQUFJOEYsQ0FBSixDQUFNLFVBQVVHLE9BQVYsRUFBbUI7QUFBRUEsTUFBQUEsT0FBTyxDQUFDakcsS0FBRCxDQUFQO0FBQWlCLEtBQTVDLENBQXBDO0FBQW9GOztBQUM1RyxTQUFPLEtBQUs4RixDQUFDLEtBQUtBLENBQUMsR0FBR25FLE9BQVQsQ0FBTixFQUF5QixVQUFVc0UsT0FBVixFQUFtQkMsTUFBbkIsRUFBMkI7QUFDdkQsYUFBU0MsU0FBVCxDQUFtQm5HLEtBQW5CLEVBQTBCO0FBQUUsVUFBSTtBQUFFb0csUUFBQUEsSUFBSSxDQUFDTCxTQUFTLENBQUNNLElBQVYsQ0FBZXJHLEtBQWYsQ0FBRCxDQUFKO0FBQThCLE9BQXBDLENBQXFDLE9BQU9zRyxDQUFQLEVBQVU7QUFBRUosUUFBQUEsTUFBTSxDQUFDSSxDQUFELENBQU47QUFBWTtBQUFFOztBQUMzRixhQUFTQyxRQUFULENBQWtCdkcsS0FBbEIsRUFBeUI7QUFBRSxVQUFJO0FBQUVvRyxRQUFBQSxJQUFJLENBQUNMLFNBQVMsQ0FBQyxPQUFELENBQVQsQ0FBbUIvRixLQUFuQixDQUFELENBQUo7QUFBa0MsT0FBeEMsQ0FBeUMsT0FBT3NHLENBQVAsRUFBVTtBQUFFSixRQUFBQSxNQUFNLENBQUNJLENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzlGLGFBQVNGLElBQVQsQ0FBY0ksTUFBZCxFQUFzQjtBQUFFQSxNQUFBQSxNQUFNLENBQUNDLElBQVAsR0FBY1IsT0FBTyxDQUFDTyxNQUFNLENBQUN4RyxLQUFSLENBQXJCLEdBQXNDZ0csS0FBSyxDQUFDUSxNQUFNLENBQUN4RyxLQUFSLENBQUwsQ0FBb0IwRyxJQUFwQixDQUF5QlAsU0FBekIsRUFBb0NJLFFBQXBDLENBQXRDO0FBQXNGOztBQUM5R0gsSUFBQUEsSUFBSSxDQUFDLENBQUNMLFNBQVMsR0FBR0EsU0FBUyxDQUFDWSxLQUFWLENBQWdCZixPQUFoQixFQUF5QkMsVUFBVSxJQUFJLEVBQXZDLENBQWIsRUFBeURRLElBQXpELEVBQUQsQ0FBSjtBQUNILEdBTE0sQ0FBUDtBQU1ILENBUkQ7O0FBU0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU00RCxZQUFZLEdBQUc7QUFDakJ2SyxFQUFBQSxNQUFNLEVBQUUsSUFEUztBQUVqQndILEVBQUFBLE9BQU8sRUFBRSxJQUZRO0FBR2pCRyxFQUFBQSxLQUFLLEVBQUUsS0FIVTtBQUlqQjFILEVBQUFBLFNBQVMsRUFBRSxJQUpNO0FBS2pCdUssRUFBQUEsU0FBUyxFQUFFO0FBTE0sQ0FBckI7QUFPTyxNQUFNQyxjQUFjLEdBQUcsQ0FBQztBQUFFMUssRUFBQUEsUUFBRjtBQUFZMkssRUFBQUEsT0FBWjtBQUFxQkMsRUFBQUEsV0FBVyxHQUFHLEtBQW5DO0FBQTBDQyxFQUFBQSxPQUFPLEVBQUVDLFFBQVEsR0FBSXJKLEtBQUQsSUFBV3FHLE9BQU8sQ0FBQ3JHLEtBQVIsQ0FBY0EsS0FBZCxDQUF6RTtBQUErRnNKLEVBQUFBLGVBQWUsR0FBRztBQUFqSCxDQUFELEtBQXNJO0FBQ2hLLFFBQU0sQ0FBQzdGLElBQUQsRUFBTzhGLE9BQVAsSUFBa0JWLGlFQUFlLENBQUNTLGVBQUQsRUFBa0IsSUFBbEIsQ0FBdkM7QUFDQSxRQUFNO0FBQUEsT0FBQztBQUFFOUssTUFBQUEsTUFBRjtBQUFVd0gsTUFBQUEsT0FBVjtBQUFtQkcsTUFBQUEsS0FBbkI7QUFBMEIxSCxNQUFBQSxTQUExQjtBQUFxQ3VLLE1BQUFBO0FBQXJDLEtBQUQ7QUFBQSxPQUFtRFE7QUFBbkQsTUFBK0QvTCwrQ0FBUSxDQUFDc0wsWUFBRCxDQUE3RTtBQUNBLFFBQU07QUFBQSxPQUFDVSxVQUFEO0FBQUEsT0FBYUM7QUFBYixNQUE4QmpNLCtDQUFRLENBQUMsS0FBRCxDQUE1QztBQUNBLFFBQU07QUFBQSxPQUFDa00sYUFBRDtBQUFBLE9BQWdCQztBQUFoQixNQUFvQ25NLCtDQUFRLENBQUMsS0FBRCxDQUFsRDtBQUNBLFFBQU1vTSxZQUFZLEdBQUdsQiw2Q0FBTSxDQUFDLEtBQUQsQ0FBM0I7QUFDQSxRQUFNbUIsZUFBZSxHQUFHbkIsNkNBQU0sQ0FBQyxLQUFELENBQTlCO0FBQ0EsUUFBTW9CLFdBQVcsR0FBR3BCLDZDQUFNLENBQUMsS0FBRCxDQUExQixDQVBnSyxDQVFoSzs7QUFDQSxRQUFNcUIsYUFBYSxHQUFHNUIsOENBQU8sQ0FBQyxNQUFNYyxPQUFPLENBQUNlLE1BQVIsQ0FBZSxDQUFDRCxhQUFELEVBQWdCeEwsTUFBaEIsS0FBMkI7QUFDMUV3TCxJQUFBQSxhQUFhLENBQUN4TCxNQUFNLENBQUNpRixJQUFSLENBQWIsR0FBNkJqRixNQUE3QjtBQUNBLFdBQU93TCxhQUFQO0FBQ0gsR0FIbUMsRUFHakMsRUFIaUMsQ0FBUCxFQUdyQixDQUFDZCxPQUFELENBSHFCLENBQTdCLENBVGdLLENBYWhLOztBQUNBMUwsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ1osVUFBTWdCLE1BQU0sR0FBSWlGLElBQUksSUFBSXVHLGFBQWEsQ0FBQ3ZHLElBQUQsQ0FBdEIsSUFBaUMsSUFBaEQ7QUFDQSxVQUFNdUMsT0FBTyxHQUFHeEgsTUFBTSxJQUFJQSxNQUFNLENBQUN3SCxPQUFQLEVBQTFCOztBQUNBLFFBQUlBLE9BQUosRUFBYTtBQUNULFlBQU07QUFBRUcsUUFBQUEsS0FBRjtBQUFTMUgsUUFBQUEsU0FBVDtBQUFvQnVLLFFBQUFBO0FBQXBCLFVBQWtDaEQsT0FBeEM7QUFDQXdELE1BQUFBLFFBQVEsQ0FBQztBQUFFaEwsUUFBQUEsTUFBRjtBQUFVd0gsUUFBQUEsT0FBVjtBQUFtQmdELFFBQUFBLFNBQW5CO0FBQThCdkssUUFBQUEsU0FBOUI7QUFBeUMwSCxRQUFBQTtBQUF6QyxPQUFELENBQVI7QUFDSCxLQUhELE1BSUs7QUFDRHFELE1BQUFBLFFBQVEsQ0FBQ1QsWUFBRCxDQUFSO0FBQ0g7QUFDSixHQVZRLEVBVU4sQ0FBQ3RGLElBQUQsRUFBT3VHLGFBQVAsRUFBc0JSLFFBQXRCLENBVk0sQ0FBVCxDQWRnSyxDQXlCaEs7O0FBQ0FoTSxFQUFBQSxnREFBUyxDQUFDLE1BQU07QUFDWixRQUFJcU0sWUFBWSxDQUFDSyxPQUFiLElBQXdCVCxVQUF4QixJQUFzQ1QsU0FBdEMsSUFBbUQsQ0FBQ0csV0FBcEQsSUFBbUUsQ0FBQ25ELE9BQXBFLElBQStFLENBQUNHLEtBQXBGLEVBQ0k7O0FBQ0osS0FBQyxZQUFZO0FBQ1QsYUFBTzFCLFNBQVMsQ0FBQyxJQUFELEVBQU8sS0FBSyxDQUFaLEVBQWUsS0FBSyxDQUFwQixFQUF1QixhQUFhO0FBQ2hEb0YsUUFBQUEsWUFBWSxDQUFDSyxPQUFiLEdBQXVCLElBQXZCO0FBQ0FSLFFBQUFBLGFBQWEsQ0FBQyxJQUFELENBQWI7O0FBQ0EsWUFBSTtBQUNBLGdCQUFNMUQsT0FBTyxDQUFDbUUsT0FBUixFQUFOO0FBQ0gsU0FGRCxDQUdBLE9BQU9uSyxLQUFQLEVBQWM7QUFDVjtBQUNBdUosVUFBQUEsT0FBTyxDQUFDLElBQUQsQ0FBUCxDQUZVLENBR1Y7QUFDSCxTQVBELFNBUVE7QUFDSkcsVUFBQUEsYUFBYSxDQUFDLEtBQUQsQ0FBYjtBQUNBRyxVQUFBQSxZQUFZLENBQUNLLE9BQWIsR0FBdUIsS0FBdkI7QUFDSDtBQUNKLE9BZmUsQ0FBaEI7QUFnQkgsS0FqQkQ7QUFrQkgsR0FyQlEsRUFxQk4sQ0FBQ0wsWUFBRCxFQUFlSixVQUFmLEVBQTJCVCxTQUEzQixFQUFzQ0csV0FBdEMsRUFBbURuRCxPQUFuRCxFQUE0REcsS0FBNUQsRUFBbUV1RCxhQUFuRSxFQUFrRkgsT0FBbEYsQ0FyQk0sQ0FBVCxDQTFCZ0ssQ0FnRGhLOztBQUNBL0wsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ1osYUFBUzRNLFFBQVQsR0FBb0I7QUFDaEJMLE1BQUFBLFdBQVcsQ0FBQ0csT0FBWixHQUFzQixJQUF0QjtBQUNIOztBQUNERyxJQUFBQSxNQUFNLENBQUNDLGdCQUFQLENBQXdCLGNBQXhCLEVBQXdDRixRQUF4QztBQUNBLFdBQU8sTUFBTUMsTUFBTSxDQUFDRSxtQkFBUCxDQUEyQixjQUEzQixFQUEyQ0gsUUFBM0MsQ0FBYjtBQUNILEdBTlEsRUFNTixDQUFDTCxXQUFELENBTk0sQ0FBVCxDQWpEZ0ssQ0F3RGhLOztBQUNBLFFBQU1TLE1BQU0sR0FBRzlCLGtEQUFXLENBQUUrQixPQUFELElBQWFoRyxTQUFTLENBQUMsS0FBSyxDQUFOLEVBQVMsS0FBSyxDQUFkLEVBQWlCLEtBQUssQ0FBdEIsRUFBeUIsYUFBYTtBQUNuRixRQUFJaEIsSUFBSSxLQUFLZ0gsT0FBYixFQUNJO0FBQ0osUUFBSXpFLE9BQUosRUFDSSxNQUFNQSxPQUFPLENBQUMwRSxVQUFSLEVBQU47QUFDSm5CLElBQUFBLE9BQU8sQ0FBQ2tCLE9BQUQsQ0FBUDtBQUNILEdBTmdELENBQXZCLEVBTXRCLENBQUNoSCxJQUFELEVBQU91QyxPQUFQLEVBQWdCdUQsT0FBaEIsQ0FOc0IsQ0FBMUIsQ0F6RGdLLENBZ0VoSzs7QUFDQSxRQUFNb0IsT0FBTyxHQUFHakMsa0RBQVcsQ0FBQyxNQUFNYyxRQUFRLENBQUUzRyxLQUFELElBQVlsRSxNQUFNLENBQUNpTSxNQUFQLENBQWNqTSxNQUFNLENBQUNpTSxNQUFQLENBQWMsRUFBZCxFQUFrQi9ILEtBQWxCLENBQWQsRUFBd0M7QUFBRXNELElBQUFBLEtBQUssRUFBRTtBQUFULEdBQXhDLENBQWIsQ0FBZixFQUF3RixDQUFDcUQsUUFBRCxDQUF4RixDQUEzQixDQWpFZ0ssQ0FrRWhLOztBQUNBLFFBQU1xQixTQUFTLEdBQUduQyxrREFBVyxDQUFDLE1BQU07QUFDaEMsUUFBSSxDQUFDMUMsT0FBTCxFQUNJO0FBQ0osVUFBTTtBQUFFZ0QsTUFBQUEsU0FBRjtBQUFhdkssTUFBQUEsU0FBYjtBQUF3QjBILE1BQUFBO0FBQXhCLFFBQWtDSCxPQUF4QztBQUNBd0QsSUFBQUEsUUFBUSxDQUFFM0csS0FBRCxJQUFZbEUsTUFBTSxDQUFDaU0sTUFBUCxDQUFjak0sTUFBTSxDQUFDaU0sTUFBUCxDQUFjLEVBQWQsRUFBa0IvSCxLQUFsQixDQUFkLEVBQXdDO0FBQUVtRyxNQUFBQSxTQUFGO0FBQ3pEdkssTUFBQUEsU0FEeUQ7QUFFekQwSCxNQUFBQTtBQUZ5RCxLQUF4QyxDQUFiLENBQVI7QUFHSCxHQVA0QixFQU8xQixDQUFDSCxPQUFELEVBQVV3RCxRQUFWLENBUDBCLENBQTdCLENBbkVnSyxDQTJFaEs7O0FBQ0EsUUFBTXNCLFlBQVksR0FBR3BDLGtEQUFXLENBQUMsTUFBTTtBQUNuQztBQUNBLFFBQUksQ0FBQ3FCLFdBQVcsQ0FBQ0csT0FBakIsRUFDSVgsT0FBTyxDQUFDLElBQUQsQ0FBUDtBQUNQLEdBSitCLEVBSTdCLENBQUNRLFdBQUQsRUFBY1IsT0FBZCxDQUo2QixDQUFoQyxDQTVFZ0ssQ0FpRmhLOztBQUNBLFFBQU1ILE9BQU8sR0FBR1Ysa0RBQVcsQ0FBRTFJLEtBQUQsSUFBVztBQUNuQztBQUNBLFFBQUksQ0FBQytKLFdBQVcsQ0FBQ0csT0FBakIsRUFDSWIsUUFBUSxDQUFDckosS0FBRCxDQUFSO0FBQ0osV0FBT0EsS0FBUDtBQUNILEdBTDBCLEVBS3hCLENBQUMrSixXQUFELEVBQWNWLFFBQWQsQ0FMd0IsQ0FBM0IsQ0FsRmdLLENBd0ZoSzs7QUFDQSxRQUFNYyxPQUFPLEdBQUd6QixrREFBVyxDQUFDLE1BQU1qRSxTQUFTLENBQUMsS0FBSyxDQUFOLEVBQVMsS0FBSyxDQUFkLEVBQWlCLEtBQUssQ0FBdEIsRUFBeUIsYUFBYTtBQUM3RSxRQUFJb0YsWUFBWSxDQUFDSyxPQUFiLElBQXdCVCxVQUF4QixJQUFzQ0UsYUFBdEMsSUFBdURYLFNBQTNELEVBQ0k7QUFDSixRQUFJLENBQUN4SyxNQUFELElBQVcsQ0FBQ3dILE9BQWhCLEVBQ0ksTUFBTW9ELE9BQU8sQ0FBQyxJQUFJUiwyREFBSixFQUFELENBQWI7O0FBQ0osUUFBSSxDQUFDekMsS0FBTCxFQUFZO0FBQ1I7QUFDQW9ELE1BQUFBLE9BQU8sQ0FBQyxJQUFELENBQVA7O0FBQ0EsaUJBQW1DLEVBRWxDOztBQUNELFlBQU1ILE9BQU8sQ0FBQyxJQUFJekYsNEVBQUosRUFBRCxDQUFiO0FBQ0g7O0FBQ0RrRyxJQUFBQSxZQUFZLENBQUNLLE9BQWIsR0FBdUIsSUFBdkI7QUFDQVIsSUFBQUEsYUFBYSxDQUFDLElBQUQsQ0FBYjs7QUFDQSxRQUFJO0FBQ0EsWUFBTTFELE9BQU8sQ0FBQ21FLE9BQVIsRUFBTjtBQUNILEtBRkQsQ0FHQSxPQUFPbkssS0FBUCxFQUFjO0FBQ1Y7QUFDQXVKLE1BQUFBLE9BQU8sQ0FBQyxJQUFELENBQVAsQ0FGVSxDQUdWOztBQUNBLFlBQU12SixLQUFOO0FBQ0gsS0FSRCxTQVNRO0FBQ0owSixNQUFBQSxhQUFhLENBQUMsS0FBRCxDQUFiO0FBQ0FHLE1BQUFBLFlBQVksQ0FBQ0ssT0FBYixHQUF1QixLQUF2QjtBQUNIO0FBQ0osR0E1QjBDLENBQWhCLEVBNEJ2QixDQUFDTCxZQUFELEVBQWVKLFVBQWYsRUFBMkJFLGFBQTNCLEVBQTBDWCxTQUExQyxFQUFxRHhLLE1BQXJELEVBQTZEd0gsT0FBN0QsRUFBc0VvRCxPQUF0RSxFQUErRWpELEtBQS9FLEVBQXNGdUQsYUFBdEYsRUFBcUdILE9BQXJHLENBNUJ1QixDQUEzQixDQXpGZ0ssQ0FzSGhLOztBQUNBLFFBQU1tQixVQUFVLEdBQUdoQyxrREFBVyxDQUFDLE1BQU1qRSxTQUFTLENBQUMsS0FBSyxDQUFOLEVBQVMsS0FBSyxDQUFkLEVBQWlCLEtBQUssQ0FBdEIsRUFBeUIsYUFBYTtBQUNoRixRQUFJcUYsZUFBZSxDQUFDSSxPQUFoQixJQUEyQlAsYUFBL0IsRUFDSTtBQUNKLFFBQUksQ0FBQzNELE9BQUwsRUFDSSxPQUFPdUQsT0FBTyxDQUFDLElBQUQsQ0FBZDtBQUNKTyxJQUFBQSxlQUFlLENBQUNJLE9BQWhCLEdBQTBCLElBQTFCO0FBQ0FOLElBQUFBLGdCQUFnQixDQUFDLElBQUQsQ0FBaEI7O0FBQ0EsUUFBSTtBQUNBLFlBQU01RCxPQUFPLENBQUMwRSxVQUFSLEVBQU47QUFDSCxLQUZELENBR0EsT0FBTzFLLEtBQVAsRUFBYztBQUNWO0FBQ0F1SixNQUFBQSxPQUFPLENBQUMsSUFBRCxDQUFQLENBRlUsQ0FHVjs7QUFDQSxZQUFNdkosS0FBTjtBQUNILEtBUkQsU0FTUTtBQUNKNEosTUFBQUEsZ0JBQWdCLENBQUMsS0FBRCxDQUFoQjtBQUNBRSxNQUFBQSxlQUFlLENBQUNJLE9BQWhCLEdBQTBCLEtBQTFCO0FBQ0g7QUFDSixHQXBCNkMsQ0FBaEIsRUFvQjFCLENBQUNKLGVBQUQsRUFBa0JILGFBQWxCLEVBQWlDM0QsT0FBakMsRUFBMEM0RCxnQkFBMUMsRUFBNERMLE9BQTVELENBcEIwQixDQUE5QixDQXZIZ0ssQ0E0SWhLOztBQUNBLFFBQU1uQyxlQUFlLEdBQUdzQixrREFBVyxDQUFDLENBQUNyQixXQUFELEVBQWNySixVQUFkLEVBQTBCcUMsT0FBMUIsS0FBc0NvRSxTQUFTLENBQUMsS0FBSyxDQUFOLEVBQVMsS0FBSyxDQUFkLEVBQWlCLEtBQUssQ0FBdEIsRUFBeUIsYUFBYTtBQUNySCxRQUFJLENBQUN1QixPQUFMLEVBQ0ksTUFBTW9ELE9BQU8sQ0FBQyxJQUFJUiwyREFBSixFQUFELENBQWI7QUFDSixRQUFJLENBQUNJLFNBQUwsRUFDSSxNQUFNSSxPQUFPLENBQUMsSUFBSWxGLGdGQUFKLEVBQUQsQ0FBYjtBQUNKLFdBQU8sTUFBTThCLE9BQU8sQ0FBQ29CLGVBQVIsQ0FBd0JDLFdBQXhCLEVBQXFDckosVUFBckMsRUFBaURxQyxPQUFqRCxDQUFiO0FBQ0gsR0FOa0YsQ0FBaEQsRUFNL0IsQ0FBQzJGLE9BQUQsRUFBVW9ELE9BQVYsRUFBbUJKLFNBQW5CLENBTitCLENBQW5DLENBN0lnSyxDQW9KaEs7O0FBQ0EsUUFBTWxCLGVBQWUsR0FBR00sOENBQU8sQ0FBQyxNQUFNcEMsT0FBTyxJQUFJLHFCQUFxQkEsT0FBaEMsR0FDL0JxQixXQUFELElBQWlCNUMsU0FBUyxDQUFDLEtBQUssQ0FBTixFQUFTLEtBQUssQ0FBZCxFQUFpQixLQUFLLENBQXRCLEVBQXlCLGFBQWE7QUFDOUQsUUFBSSxDQUFDdUUsU0FBTCxFQUNJLE1BQU1JLE9BQU8sQ0FBQyxJQUFJbEYsZ0ZBQUosRUFBRCxDQUFiO0FBQ0osV0FBTyxNQUFNOEIsT0FBTyxDQUFDOEIsZUFBUixDQUF3QlQsV0FBeEIsQ0FBYjtBQUNILEdBSjJCLENBRE0sR0FNaENFLFNBTnlCLEVBTWQsQ0FBQ3ZCLE9BQUQsRUFBVW9ELE9BQVYsRUFBbUJKLFNBQW5CLENBTmMsQ0FBL0IsQ0FySmdLLENBNEpoSzs7QUFDQSxRQUFNaUMsbUJBQW1CLEdBQUc3Qyw4Q0FBTyxDQUFDLE1BQU1wQyxPQUFPLElBQUkseUJBQXlCQSxPQUFwQyxHQUNuQ2tGLFlBQUQsSUFBa0J6RyxTQUFTLENBQUMsS0FBSyxDQUFOLEVBQVMsS0FBSyxDQUFkLEVBQWlCLEtBQUssQ0FBdEIsRUFBeUIsYUFBYTtBQUMvRCxRQUFJLENBQUN1RSxTQUFMLEVBQ0ksTUFBTUksT0FBTyxDQUFDLElBQUlsRixnRkFBSixFQUFELENBQWI7QUFDSixXQUFPLE1BQU04QixPQUFPLENBQUNpRixtQkFBUixDQUE0QkMsWUFBNUIsQ0FBYjtBQUNILEdBSjRCLENBRFMsR0FNcEMzRCxTQU42QixFQU1sQixDQUFDdkIsT0FBRCxFQUFVb0QsT0FBVixFQUFtQkosU0FBbkIsQ0FOa0IsQ0FBbkMsQ0E3SmdLLENBb0toSzs7QUFDQSxRQUFNbUMsV0FBVyxHQUFHL0MsOENBQU8sQ0FBQyxNQUFNcEMsT0FBTyxJQUFJLGlCQUFpQkEsT0FBNUIsR0FDM0J6RixPQUFELElBQWFrRSxTQUFTLENBQUMsS0FBSyxDQUFOLEVBQVMsS0FBSyxDQUFkLEVBQWlCLEtBQUssQ0FBdEIsRUFBeUIsYUFBYTtBQUMxRCxRQUFJLENBQUN1RSxTQUFMLEVBQ0ksTUFBTUksT0FBTyxDQUFDLElBQUlsRixnRkFBSixFQUFELENBQWI7QUFDSixXQUFPLE1BQU04QixPQUFPLENBQUNtRixXQUFSLENBQW9CNUssT0FBcEIsQ0FBYjtBQUNILEdBSnVCLENBRE0sR0FNNUJnSCxTQU5xQixFQU1WLENBQUN2QixPQUFELEVBQVVvRCxPQUFWLEVBQW1CSixTQUFuQixDQU5VLENBQTNCLENBcktnSyxDQTRLaEs7O0FBQ0F4TCxFQUFBQSxnREFBUyxDQUFDLE1BQU07QUFDWixRQUFJd0ksT0FBSixFQUFhO0FBQ1RBLE1BQUFBLE9BQU8sQ0FBQ29GLEVBQVIsQ0FBVyxPQUFYLEVBQW9CVCxPQUFwQjtBQUNBM0UsTUFBQUEsT0FBTyxDQUFDb0YsRUFBUixDQUFXLFNBQVgsRUFBc0JQLFNBQXRCO0FBQ0E3RSxNQUFBQSxPQUFPLENBQUNvRixFQUFSLENBQVcsWUFBWCxFQUF5Qk4sWUFBekI7QUFDQTlFLE1BQUFBLE9BQU8sQ0FBQ29GLEVBQVIsQ0FBVyxPQUFYLEVBQW9CaEMsT0FBcEI7QUFDQSxhQUFPLE1BQU07QUFDVHBELFFBQUFBLE9BQU8sQ0FBQ3FGLEdBQVIsQ0FBWSxPQUFaLEVBQXFCVixPQUFyQjtBQUNBM0UsUUFBQUEsT0FBTyxDQUFDcUYsR0FBUixDQUFZLFNBQVosRUFBdUJSLFNBQXZCO0FBQ0E3RSxRQUFBQSxPQUFPLENBQUNxRixHQUFSLENBQVksWUFBWixFQUEwQlAsWUFBMUI7QUFDQTlFLFFBQUFBLE9BQU8sQ0FBQ3FGLEdBQVIsQ0FBWSxPQUFaLEVBQXFCakMsT0FBckI7QUFDSCxPQUxEO0FBTUg7QUFDSixHQWJRLEVBYU4sQ0FBQ3BELE9BQUQsRUFBVTJFLE9BQVYsRUFBbUJFLFNBQW5CLEVBQThCQyxZQUE5QixFQUE0QzFCLE9BQTVDLENBYk0sQ0FBVDtBQWNBLHNCQUFRakIsMERBQUEsQ0FBb0JXLDhEQUFwQixFQUE0QztBQUFFaEssSUFBQUEsS0FBSyxFQUFFO0FBQ3JEb0ssTUFBQUEsT0FEcUQ7QUFFckRDLE1BQUFBLFdBRnFEO0FBR3JEM0ssTUFBQUEsTUFIcUQ7QUFJckR3SCxNQUFBQSxPQUpxRDtBQUtyRHZILE1BQUFBLFNBTHFEO0FBTXJEMEgsTUFBQUEsS0FOcUQ7QUFPckQ2QyxNQUFBQSxTQVBxRDtBQVFyRFMsTUFBQUEsVUFScUQ7QUFTckRFLE1BQUFBLGFBVHFEO0FBVXJEYSxNQUFBQSxNQVZxRDtBQVdyREwsTUFBQUEsT0FYcUQ7QUFZckRPLE1BQUFBLFVBWnFEO0FBYXJEdEQsTUFBQUEsZUFicUQ7QUFjckRVLE1BQUFBLGVBZHFEO0FBZXJEbUQsTUFBQUEsbUJBZnFEO0FBZ0JyREUsTUFBQUE7QUFoQnFEO0FBQVQsR0FBNUMsRUFpQkM1TSxRQWpCRCxDQUFSO0FBa0JILENBN01NOzs7Ozs7Ozs7Ozs7Ozs7O0FDckJQO0FBQ08sTUFBTXFLLHNCQUFOLFNBQXFDdkYsb0VBQXJDLENBQWlEO0FBQ3BEQyxFQUFBQSxXQUFXLEdBQUc7QUFDVixVQUFNLEdBQUdFLFNBQVQ7QUFDQSxTQUFLQyxJQUFMLEdBQVksd0JBQVo7QUFDSDs7QUFKbUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTEE7QUFDQTtBQUNPLFNBQVM2SCxlQUFULEdBQTJCO0FBQzlCLFFBQU07QUFBRTdNLElBQUFBLFNBQUY7QUFBYXFKLElBQUFBLGVBQWI7QUFBOEJtRCxJQUFBQTtBQUE5QixNQUFzRDdOLHFEQUFTLEVBQXJFO0FBQ0EsU0FBT2dMLDhDQUFPLENBQUMsTUFBTTNKLFNBQVMsSUFBSXFKLGVBQWIsSUFBZ0NtRCxtQkFBaEMsR0FDZjtBQUFFeE0sSUFBQUEsU0FBRjtBQUFhcUosSUFBQUEsZUFBYjtBQUE4Qm1ELElBQUFBO0FBQTlCLEdBRGUsR0FFZjFELFNBRlEsRUFFRyxDQUFDOUksU0FBRCxFQUFZcUosZUFBWixFQUE2Qm1ELG1CQUE3QixDQUZILENBQWQ7QUFHSDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUEQ7QUFDTyxNQUFNNUMsaUJBQWlCLGdCQUFHL0ssb0RBQWEsQ0FBQyxFQUFELENBQXZDO0FBQ0EsU0FBU2lPLGFBQVQsR0FBeUI7QUFDNUIsU0FBT2hPLGlEQUFVLENBQUM4SyxpQkFBRCxDQUFqQjtBQUNIOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0pEO0FBQ08sU0FBU1EsZUFBVCxDQUF5QnpHLEdBQXpCLEVBQThCb0osWUFBOUIsRUFBNEM7QUFDL0MsUUFBTTtBQUFBLE9BQUMxTSxLQUFEO0FBQUEsT0FBUTJNO0FBQVIsTUFBb0JoTywrQ0FBUSxDQUFDLE1BQU07QUFDckMsUUFBSSxPQUFPaU8sWUFBUCxLQUF3QixXQUE1QixFQUNJLE9BQU9GLFlBQVA7QUFDSixVQUFNMU0sS0FBSyxHQUFHNE0sWUFBWSxDQUFDQyxPQUFiLENBQXFCdkosR0FBckIsQ0FBZDs7QUFDQSxRQUFJO0FBQ0EsYUFBT3RELEtBQUssR0FBRzhNLElBQUksQ0FBQ0MsS0FBTCxDQUFXL00sS0FBWCxDQUFILEdBQXVCME0sWUFBbkM7QUFDSCxLQUZELENBR0EsT0FBT3hMLEtBQVAsRUFBYztBQUNWcUcsTUFBQUEsT0FBTyxDQUFDQyxJQUFSLENBQWF0RyxLQUFiO0FBQ0EsYUFBT3dMLFlBQVA7QUFDSDtBQUNKLEdBWGlDLENBQWxDO0FBWUEsUUFBTU0sZUFBZSxHQUFHcEQsa0RBQVcsQ0FBRXFELFFBQUQsSUFBYztBQUM5QyxRQUFJQSxRQUFRLEtBQUtqTixLQUFqQixFQUNJO0FBQ0oyTSxJQUFBQSxRQUFRLENBQUNNLFFBQUQsQ0FBUjs7QUFDQSxRQUFJQSxRQUFRLEtBQUssSUFBakIsRUFBdUI7QUFDbkJMLE1BQUFBLFlBQVksQ0FBQ00sVUFBYixDQUF3QjVKLEdBQXhCO0FBQ0gsS0FGRCxNQUdLO0FBQ0QsVUFBSTtBQUNBc0osUUFBQUEsWUFBWSxDQUFDTyxPQUFiLENBQXFCN0osR0FBckIsRUFBMEJ3SixJQUFJLENBQUNNLFNBQUwsQ0FBZUgsUUFBZixDQUExQjtBQUNILE9BRkQsQ0FHQSxPQUFPL0wsS0FBUCxFQUFjO0FBQ1ZxRyxRQUFBQSxPQUFPLENBQUNyRyxLQUFSLENBQWNBLEtBQWQ7QUFDSDtBQUNKO0FBQ0osR0Fma0MsRUFlaEMsQ0FBQ2xCLEtBQUQsRUFBUTJNLFFBQVIsRUFBa0JySixHQUFsQixDQWZnQyxDQUFuQztBQWdCQSxTQUFPLENBQUN0RCxLQUFELEVBQVFnTixlQUFSLENBQVA7QUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0JEO0FBQ08sTUFBTWhELGFBQWEsZ0JBQUd4TCxvREFBYSxDQUFDLEVBQUQsQ0FBbkM7QUFDQSxTQUFTRixTQUFULEdBQXFCO0FBQ3hCLFNBQU9HLGlEQUFVLENBQUN1TCxhQUFELENBQWpCO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FLSkQsdUhBQXFEOzs7Ozs7Ozs7Ozs7QUNBckQ7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7O0FDQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vaG9va3MvdXNlV2FsbGV0QmFsYW5jZS50c3giLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3Qvc2hhcmVkL2xpYi9keW5hbWljLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9wYWdlcy9fYXBwLnRzeCIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vc3RvcmUvaW5kZXgudHN4Iiwid2VicGFjazovL25leHQtY20tdjIvLi9zdG9yZS9yZWR1Y2Vycy9hcHBfcmVkdWNlci50c3giLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL3N0b3JlL3JlZHVjZXJzL2luZGV4LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlL2xpYi9hZGFwdGVyLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlL2xpYi9lcnJvcnMuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLWJhc2UvbGliL2luZGV4LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlL2xpYi9wb2xsLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlL2xpYi9zaWduZXIuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0L2xpYi9Db25uZWN0aW9uUHJvdmlkZXIuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0L2xpYi9XYWxsZXRQcm92aWRlci5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QvbGliL2Vycm9ycy5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QvbGliL2luZGV4LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC9saWIvdXNlQW5jaG9yV2FsbGV0LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC9saWIvdXNlQ29ubmVjdGlvbi5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QvbGliL3VzZUxvY2FsU3RvcmFnZS5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QvbGliL3VzZVdhbGxldC5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QtdWkvc3R5bGVzLmNzcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL3NsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLXRoZW1lLmNzcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL3NsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLmNzcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vc3R5bGVzL2dsb2JhbHMuY3NzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvbmV4dC9keW5hbWljLmpzIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJAbGVkZ2VyaHEvaHctdHJhbnNwb3J0XCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcIkBsZWRnZXJocS9ody10cmFuc3BvcnQtd2ViaGlkXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcIkBwcm9qZWN0LXNlcnVtL2FuY2hvclwiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJAc29sYW5hL3dhbGxldC1hZGFwdGVyLWJpdGtlZXBcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwiQHNvbGFuYS93YWxsZXQtYWRhcHRlci1jbG92ZXJcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwiQHNvbGFuYS93YWxsZXQtYWRhcHRlci1jb2luaHViXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcIkBzb2xhbmEvd2ViMy5qc1wiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJAdG9ydXNsYWJzL29wZW5sb2dpblwiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJAdG9ydXNsYWJzL29wZW5sb2dpbi1lZDI1NTE5XCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcImJzNThcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwiZXZlbnRlbWl0dGVyM1wiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9sb2FkYWJsZS5qc1wiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJuZXh0L2hlYWRcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwicmVhY3RcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwicmVhY3QtZG9tXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcInJlYWN0LXJlZHV4XCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJyZWR1eFwiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJyZWR1eC1wZXJzaXN0XCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcInJlZHV4LXBlcnNpc3QvaW50ZWdyYXRpb24vcmVhY3RcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwicmVkdXgtcGVyc2lzdC9saWIvc3RvcmFnZVwiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJyZWR1eC10aHVua1wiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVdhbGxldCB9IGZyb20gXCJAc29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0XCI7XHJcbmltcG9ydCB7IExBTVBPUlRTX1BFUl9TT0wgfSBmcm9tIFwiQHNvbGFuYS93ZWIzLmpzXCI7XHJcbmltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0ICogYXMgYW5jaG9yIGZyb20gXCJAcHJvamVjdC1zZXJ1bS9hbmNob3JcIjtcclxuXHJcbmNvbnN0IEJhbGFuY2VDb250ZXh0ID0gY3JlYXRlQ29udGV4dChudWxsKTtcclxuXHJcbmNvbnN0IHJwY0hvc3QgPSBwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19TT0xBTkFfUlBDX0hPU1QhO1xyXG5cclxuY29uc3QgY29ubmVjdGlvbiA9IG5ldyBhbmNob3Iud2ViMy5Db25uZWN0aW9uKHJwY0hvc3QpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gdXNlV2FsbGV0QmFsYW5jZSgpIHtcclxuICBjb25zdCBbYmFsYW5jZSwgc2V0QmFsYW5jZV06IGFueSA9IHVzZUNvbnRleHQoQmFsYW5jZUNvbnRleHQpO1xyXG4gIHJldHVybiBbYmFsYW5jZSwgc2V0QmFsYW5jZV07XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBXYWxsZXRCYWxhbmNlUHJvdmlkZXI6IFJlYWN0LkZDPHt9PiA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICBjb25zdCB3YWxsZXQgPSB1c2VXYWxsZXQoKTtcclxuICBjb25zdCBbYmFsYW5jZSwgc2V0QmFsYW5jZV0gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIChhc3luYyAoKSA9PiB7XHJcbiAgICAgIGlmICh3YWxsZXQ/LnB1YmxpY0tleSkge1xyXG4gICAgICAgIGNvbnN0IGJhbGFuY2UgPSBhd2FpdCBjb25uZWN0aW9uLmdldEJhbGFuY2Uod2FsbGV0LnB1YmxpY0tleSk7XHJcbiAgICAgICAgc2V0QmFsYW5jZShiYWxhbmNlIC8gTEFNUE9SVFNfUEVSX1NPTCk7XHJcbiAgICAgIH1cclxuICAgIH0pKCk7XHJcbiAgfSwgW3dhbGxldCwgY29ubmVjdGlvbl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgKGFzeW5jICgpID0+IHtcclxuICAgICAgaWYgKHdhbGxldD8ucHVibGljS2V5KSB7XHJcbiAgICAgICAgY29uc3QgYmFsYW5jZSA9IGF3YWl0IGNvbm5lY3Rpb24uZ2V0QmFsYW5jZSh3YWxsZXQucHVibGljS2V5KTtcclxuICAgICAgICBzZXRCYWxhbmNlKGJhbGFuY2UgLyBMQU1QT1JUU19QRVJfU09MKTtcclxuICAgICAgfVxyXG4gICAgfSkoKTtcclxuICB9LCBbd2FsbGV0LCBjb25uZWN0aW9uXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8QmFsYW5jZUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e1tiYWxhbmNlLCBzZXRCYWxhbmNlXSBhcyBhbnl9PlxyXG4gICAgICB7Y2hpbGRyZW59XHJcbiAgICA8L0JhbGFuY2VDb250ZXh0LlByb3ZpZGVyPlxyXG4gICk7XHJcbn07XHJcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0cy5ub1NTUiA9IG5vU1NSO1xuZXhwb3J0cy5kZWZhdWx0ID0gZHluYW1pYztcbnZhciBfcmVhY3QgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJyZWFjdFwiKSk7XG52YXIgX2xvYWRhYmxlID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi9sb2FkYWJsZVwiKSk7XG5mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICAgIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgICAgIGRlZmF1bHQ6IG9ialxuICAgIH07XG59XG5jb25zdCBpc1NlcnZlclNpZGUgPSB0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJztcbmZ1bmN0aW9uIG5vU1NSKExvYWRhYmxlSW5pdGlhbGl6ZXIsIGxvYWRhYmxlT3B0aW9ucykge1xuICAgIC8vIFJlbW92aW5nIHdlYnBhY2sgYW5kIG1vZHVsZXMgbWVhbnMgcmVhY3QtbG9hZGFibGUgd29uJ3QgdHJ5IHByZWxvYWRpbmdcbiAgICBkZWxldGUgbG9hZGFibGVPcHRpb25zLndlYnBhY2s7XG4gICAgZGVsZXRlIGxvYWRhYmxlT3B0aW9ucy5tb2R1bGVzO1xuICAgIC8vIFRoaXMgY2hlY2sgaXMgbmVjZXNzYXJ5IHRvIHByZXZlbnQgcmVhY3QtbG9hZGFibGUgZnJvbSBpbml0aWFsaXppbmcgb24gdGhlIHNlcnZlclxuICAgIGlmICghaXNTZXJ2ZXJTaWRlKSB7XG4gICAgICAgIHJldHVybiBMb2FkYWJsZUluaXRpYWxpemVyKGxvYWRhYmxlT3B0aW9ucyk7XG4gICAgfVxuICAgIGNvbnN0IExvYWRpbmcgPSBsb2FkYWJsZU9wdGlvbnMubG9hZGluZztcbiAgICAvLyBUaGlzIHdpbGwgb25seSBiZSByZW5kZXJlZCBvbiB0aGUgc2VydmVyIHNpZGVcbiAgICByZXR1cm4gKCk9Pi8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChMb2FkaW5nLCB7XG4gICAgICAgICAgICBlcnJvcjogbnVsbCxcbiAgICAgICAgICAgIGlzTG9hZGluZzogdHJ1ZSxcbiAgICAgICAgICAgIHBhc3REZWxheTogZmFsc2UsXG4gICAgICAgICAgICB0aW1lZE91dDogZmFsc2VcbiAgICAgICAgfSlcbiAgICA7XG59XG5mdW5jdGlvbiBkeW5hbWljKGR5bmFtaWNPcHRpb25zLCBvcHRpb25zKSB7XG4gICAgbGV0IGxvYWRhYmxlRm4gPSBfbG9hZGFibGUuZGVmYXVsdDtcbiAgICBsZXQgbG9hZGFibGVPcHRpb25zID0ge1xuICAgICAgICAvLyBBIGxvYWRpbmcgY29tcG9uZW50IGlzIG5vdCByZXF1aXJlZCwgc28gd2UgZGVmYXVsdCBpdFxuICAgICAgICBsb2FkaW5nOiAoeyBlcnJvciAsIGlzTG9hZGluZyAsIHBhc3REZWxheSAgfSk9PntcbiAgICAgICAgICAgIGlmICghcGFzdERlbGF5KSByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ2RldmVsb3BtZW50Jykge1xuICAgICAgICAgICAgICAgIGlmIChpc0xvYWRpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4oLyojX19QVVJFX18qLyBfcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwicFwiLCBudWxsLCBlcnJvci5tZXNzYWdlLCAvKiNfX1BVUkVfXyovIF9yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJiclwiLCBudWxsKSwgZXJyb3Iuc3RhY2spKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLy8gU3VwcG9ydCBmb3IgZGlyZWN0IGltcG9ydCgpLCBlZzogZHluYW1pYyhpbXBvcnQoJy4uL2hlbGxvLXdvcmxkJykpXG4gICAgLy8gTm90ZSB0aGF0IHRoaXMgaXMgb25seSBrZXB0IGZvciB0aGUgZWRnZSBjYXNlIHdoZXJlIHNvbWVvbmUgaXMgcGFzc2luZyBpbiBhIHByb21pc2UgYXMgZmlyc3QgYXJndW1lbnRcbiAgICAvLyBUaGUgcmVhY3QtbG9hZGFibGUgYmFiZWwgcGx1Z2luIHdpbGwgdHVybiBkeW5hbWljKGltcG9ydCgnLi4vaGVsbG8td29ybGQnKSkgaW50byBkeW5hbWljKCgpID0+IGltcG9ydCgnLi4vaGVsbG8td29ybGQnKSlcbiAgICAvLyBUbyBtYWtlIHN1cmUgd2UgZG9uJ3QgZXhlY3V0ZSB0aGUgaW1wb3J0IHdpdGhvdXQgcmVuZGVyaW5nIGZpcnN0XG4gICAgaWYgKGR5bmFtaWNPcHRpb25zIGluc3RhbmNlb2YgUHJvbWlzZSkge1xuICAgICAgICBsb2FkYWJsZU9wdGlvbnMubG9hZGVyID0gKCk9PmR5bmFtaWNPcHRpb25zXG4gICAgICAgIDtcbiAgICAvLyBTdXBwb3J0IGZvciBoYXZpbmcgaW1wb3J0IGFzIGEgZnVuY3Rpb24sIGVnOiBkeW5hbWljKCgpID0+IGltcG9ydCgnLi4vaGVsbG8td29ybGQnKSlcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBkeW5hbWljT3B0aW9ucyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBsb2FkYWJsZU9wdGlvbnMubG9hZGVyID0gZHluYW1pY09wdGlvbnM7XG4gICAgLy8gU3VwcG9ydCBmb3IgaGF2aW5nIGZpcnN0IGFyZ3VtZW50IGJlaW5nIG9wdGlvbnMsIGVnOiBkeW5hbWljKHtsb2FkZXI6IGltcG9ydCgnLi4vaGVsbG8td29ybGQnKX0pXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgZHluYW1pY09wdGlvbnMgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGxvYWRhYmxlT3B0aW9ucyA9IHtcbiAgICAgICAgICAgIC4uLmxvYWRhYmxlT3B0aW9ucyxcbiAgICAgICAgICAgIC4uLmR5bmFtaWNPcHRpb25zXG4gICAgICAgIH07XG4gICAgfVxuICAgIC8vIFN1cHBvcnQgZm9yIHBhc3Npbmcgb3B0aW9ucywgZWc6IGR5bmFtaWMoaW1wb3J0KCcuLi9oZWxsby13b3JsZCcpLCB7bG9hZGluZzogKCkgPT4gPHA+TG9hZGluZyBzb21ldGhpbmc8L3A+fSlcbiAgICBsb2FkYWJsZU9wdGlvbnMgPSB7XG4gICAgICAgIC4uLmxvYWRhYmxlT3B0aW9ucyxcbiAgICAgICAgLi4ub3B0aW9uc1xuICAgIH07XG4gICAgY29uc3Qgc3VzcGVuc2VPcHRpb25zID0gbG9hZGFibGVPcHRpb25zO1xuICAgIGlmICghcHJvY2Vzcy5lbnYuX19ORVhUX0NPTkNVUlJFTlRfRkVBVFVSRVMpIHtcbiAgICAgICAgLy8gRXJyb3IgaWYgcmVhY3Qgcm9vdCBpcyBub3QgZW5hYmxlZCBhbmQgYHN1c3BlbnNlYCBvcHRpb24gaXMgc2V0IHRvIHRydWVcbiAgICAgICAgaWYgKCFwcm9jZXNzLmVudi5fX05FWFRfUkVBQ1RfUk9PVCAmJiBzdXNwZW5zZU9wdGlvbnMuc3VzcGVuc2UpIHtcbiAgICAgICAgICAgIC8vIFRPRE86IGFkZCBlcnJvciBkb2Mgd2hlbiB0aGlzIGZlYXR1cmUgaXMgc3RhYmxlXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEludmFsaWQgc3VzcGVuc2Ugb3B0aW9uIHVzYWdlIGluIG5leHQvZHluYW1pYy4gUmVhZCBtb3JlOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9pbnZhbGlkLWR5bmFtaWMtc3VzcGVuc2VgKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoc3VzcGVuc2VPcHRpb25zLnN1c3BlbnNlKSB7XG4gICAgICAgIHJldHVybiBsb2FkYWJsZUZuKHN1c3BlbnNlT3B0aW9ucyk7XG4gICAgfVxuICAgIC8vIGNvbWluZyBmcm9tIGJ1aWxkL2JhYmVsL3BsdWdpbnMvcmVhY3QtbG9hZGFibGUtcGx1Z2luLmpzXG4gICAgaWYgKGxvYWRhYmxlT3B0aW9ucy5sb2FkYWJsZUdlbmVyYXRlZCkge1xuICAgICAgICBsb2FkYWJsZU9wdGlvbnMgPSB7XG4gICAgICAgICAgICAuLi5sb2FkYWJsZU9wdGlvbnMsXG4gICAgICAgICAgICAuLi5sb2FkYWJsZU9wdGlvbnMubG9hZGFibGVHZW5lcmF0ZWRcbiAgICAgICAgfTtcbiAgICAgICAgZGVsZXRlIGxvYWRhYmxlT3B0aW9ucy5sb2FkYWJsZUdlbmVyYXRlZDtcbiAgICB9XG4gICAgLy8gc3VwcG9ydCBmb3IgZGlzYWJsaW5nIHNlcnZlciBzaWRlIHJlbmRlcmluZywgZWc6IGR5bmFtaWMoaW1wb3J0KCcuLi9oZWxsby13b3JsZCcpLCB7c3NyOiBmYWxzZX0pXG4gICAgaWYgKHR5cGVvZiBsb2FkYWJsZU9wdGlvbnMuc3NyID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgaWYgKCFsb2FkYWJsZU9wdGlvbnMuc3NyKSB7XG4gICAgICAgICAgICBkZWxldGUgbG9hZGFibGVPcHRpb25zLnNzcjtcbiAgICAgICAgICAgIHJldHVybiBub1NTUihsb2FkYWJsZUZuLCBsb2FkYWJsZU9wdGlvbnMpO1xuICAgICAgICB9XG4gICAgICAgIGRlbGV0ZSBsb2FkYWJsZU9wdGlvbnMuc3NyO1xuICAgIH1cbiAgICByZXR1cm4gbG9hZGFibGVGbihsb2FkYWJsZU9wdGlvbnMpO1xufVxuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1keW5hbWljLmpzLm1hcCIsImltcG9ydCB0eXBlIHsgQXBwUHJvcHMgfSBmcm9tIFwibmV4dC9hcHBcIjtcclxuaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xyXG4vLyBpbXBvcnQgXCJib290c3RyYXAvZGlzdC9jc3MvYm9vdHN0cmFwLmNzc1wiO1xyXG4vL2ltcG9ydHMgZm9yIHJlZHV4XHJcbmltcG9ydCB7IFBlcnNpc3RHYXRlIH0gZnJvbSBcInJlZHV4LXBlcnNpc3QvaW50ZWdyYXRpb24vcmVhY3RcIjtcclxuaW1wb3J0IHsgc3RvcmUsIHBlcnNpc3RvciB9IGZyb20gXCIuLi9zdG9yZVwiO1xyXG5pbXBvcnQgeyBQcm92aWRlciB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5cclxuLy9pbXBvcnRzIGZvciB3ZWIzXHJcbmltcG9ydCBkeW5hbWljIGZyb20gXCJuZXh0L2R5bmFtaWNcIjtcclxuaW1wb3J0IHsgV2FsbGV0QmFsYW5jZVByb3ZpZGVyIH0gZnJvbSBcIi4uL2hvb2tzL3VzZVdhbGxldEJhbGFuY2VcIjtcclxucmVxdWlyZShcIkBzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QtdWkvc3R5bGVzLmNzc1wiKTtcclxuLy8gaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9OYXZiYXJcIlxyXG5pbXBvcnQgXCJzbGljay1jYXJvdXNlbC9zbGljay9zbGljay5jc3NcIjtcclxuaW1wb3J0IFwic2xpY2stY2Fyb3VzZWwvc2xpY2svc2xpY2stdGhlbWUuY3NzXCI7XHJcbmltcG9ydCBcIi4uL3N0eWxlcy9nbG9iYWxzLmNzc1wiO1xyXG5jb25zdCBXYWxsZXRDb25uZWN0aW9uUHJvdmlkZXIgPSBkeW5hbWljKFxyXG4gICgpID0+IGltcG9ydChcIi4uL2NvbXBvbmVudHMvV2FsbGV0Q29ubmVjdGlvbi9XYWxsZXRDb25uZWN0aW9uUHJvdmlkZXJcIiksXHJcbiAge1xyXG4gICAgc3NyOiBmYWxzZSxcclxuICB9XHJcbik7XHJcblxyXG5mdW5jdGlvbiBNeUFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH06IEFwcFByb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxXYWxsZXRDb25uZWN0aW9uUHJvdmlkZXI+XHJcbiAgICAgIDxXYWxsZXRCYWxhbmNlUHJvdmlkZXI+XHJcbiAgICAgICAgPFByb3ZpZGVyIHN0b3JlPXtzdG9yZX0+XHJcbiAgICAgICAgICA8UGVyc2lzdEdhdGUgbG9hZGluZz17bnVsbH0gcGVyc2lzdG9yPXtwZXJzaXN0b3J9PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxIZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRpdGxlPlN0YWtlIE5GVDwvdGl0bGU+XHJcbiAgICAgICAgICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XHJcbiAgICAgICAgICAgICAgPC9IZWFkPlxyXG4gICAgICAgICAgICAgIHsvKiA8TmF2YmFyIC8+ICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLWJyYW5kX2JnIHRleHQtd2hpdGUgcC02IGxnOnB4LTY0XCI+XHJcbiAgICAgICAgICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9QZXJzaXN0R2F0ZT5cclxuICAgICAgICA8L1Byb3ZpZGVyPlxyXG4gICAgICA8L1dhbGxldEJhbGFuY2VQcm92aWRlcj5cclxuICAgIDwvV2FsbGV0Q29ubmVjdGlvblByb3ZpZGVyPlxyXG4gICk7XHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgTXlBcHA7XHJcbiIsImltcG9ydCByb290UmVkdWNlciBmcm9tIFwiLi9yZWR1Y2Vyc1wiO1xyXG5pbXBvcnQgeyBjcmVhdGVTdG9yZSwgYXBwbHlNaWRkbGV3YXJlLCBjb21wb3NlIH0gZnJvbSBcInJlZHV4XCI7XHJcbmltcG9ydCB0aHVuayBmcm9tIFwicmVkdXgtdGh1bmtcIjtcclxuaW1wb3J0IHsgcGVyc2lzdFN0b3JlLCBwZXJzaXN0UmVkdWNlciB9IGZyb20gXCJyZWR1eC1wZXJzaXN0XCI7XHJcbmRlY2xhcmUgZ2xvYmFsIHtcclxuICBpbnRlcmZhY2UgV2luZG93IHtcclxuICAgIF9fUkVEVVhfREVWVE9PTFNfRVhURU5TSU9OX0NPTVBPU0VfXz86IHR5cGVvZiBjb21wb3NlO1xyXG4gIH1cclxufVxyXG5pbXBvcnQgc3RvcmFnZSBmcm9tIFwicmVkdXgtcGVyc2lzdC9saWIvc3RvcmFnZVwiOyAvLyBkZWZhdWx0cyB0byBsb2NhbFN0b3JhZ2UgZm9yIHdlYlxyXG4vLyBpbXBvcnQgeyBjb21wb3NlV2l0aERldlRvb2xzIH0gZnJvbSBcInJlZHV4LWRldnRvb2xzLWV4dGVuc2lvblwiO1xyXG5jb25zdCBwZXJzaXN0Q29uZmlnID0ge1xyXG4gIGtleTogXCJhZG1pblwiLFxyXG4gIHRpbWVvdXQ6IDAsXHJcbiAgc3RvcmFnZSxcclxuICAvLyAgIHdoaXRlbGlzdDogW1wiZG93bmxvYWRfbGlzdFwiXVxyXG59O1xyXG5cclxuY29uc3QgcGVyc2lzdGVkUmVkdWNlciA9IHBlcnNpc3RSZWR1Y2VyKHBlcnNpc3RDb25maWcsIHJvb3RSZWR1Y2VyKTtcclxuY29uc3QgY29tcG9zZUVuaGFuY2VycyA9IGNvbXBvc2U7XHJcbmxldCBzdG9yZSA9IGNyZWF0ZVN0b3JlKFxyXG4gIHBlcnNpc3RlZFJlZHVjZXIsXHJcbiAgY29tcG9zZUVuaGFuY2VycyhhcHBseU1pZGRsZXdhcmUodGh1bmspKVxyXG4pO1xyXG5sZXQgcGVyc2lzdG9yID0gcGVyc2lzdFN0b3JlKHN0b3JlKTtcclxuY29uc3QgZmluYWwgPSAoKSA9PiB7XHJcbiAgXHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgZmluYWw7XHJcbmV4cG9ydCB7IHN0b3JlLCBwZXJzaXN0b3IgfTtcclxuIiwiY29uc3QgSU5JVElBTF9TVEFURSA9IHtcclxuICBsb2FkaW5nOiBmYWxzZSxcclxuICB3YWxsZXRfaWQ6IFwiXCIsXHJcbiAgbmZ0X2xpc3Q6IG51bGwsXHJcbn07XHJcblxyXG4gY29uc3QgYXBwX3JlZHVjZXIgPSAoc3RhdGUgPSBJTklUSUFMX1NUQVRFLCBhY3Rpb246IGFueSkgPT4ge1xyXG4gIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcclxuICAgIGNhc2UgXCJXQUxMRVRfSURcIjpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICB3YWxsZXRfaWQ6IGFjdGlvbi5wYXlsb2FkLFxyXG4gICAgICAgIGxvYWRpbmc6IGZhbHNlLFxyXG4gICAgICB9O1xyXG4gICAgY2FzZSBcIlNFVE5GVFwiOlxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgIG5mdF9saXN0OiBhY3Rpb24ucGF5bG9hZCxcclxuICAgICAgICBsb2FkaW5nOiBmYWxzZSxcclxuICAgICAgfTtcclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIHJldHVybiBzdGF0ZTtcclxuICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBhcHBfcmVkdWNlclxyXG4iLCJcclxuaW1wb3J0IGFwcF9yZWR1Y2VyIGZyb20gXCIuL2FwcF9yZWR1Y2VyXCI7XHJcbi8vIGltcG9ydCBtZW51IGZyb20gXCIuL21lbnVcIjtcclxuaW1wb3J0IHsgY29tYmluZVJlZHVjZXJzIH0gZnJvbSBcInJlZHV4XCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjb21iaW5lUmVkdWNlcnMoe1xyXG4gIGFwcF9yZWR1Y2VyLFxyXG59KTtcclxuIiwiaW1wb3J0IEV2ZW50RW1pdHRlciBmcm9tICdldmVudGVtaXR0ZXIzJztcbmV4cG9ydCB7IEV2ZW50RW1pdHRlciB9O1xuZXhwb3J0IGNsYXNzIEJhc2VXYWxsZXRBZGFwdGVyIGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbn1cbmV4cG9ydCB2YXIgV2FsbGV0QWRhcHRlck5ldHdvcms7XG4oZnVuY3Rpb24gKFdhbGxldEFkYXB0ZXJOZXR3b3JrKSB7XG4gICAgV2FsbGV0QWRhcHRlck5ldHdvcmtbXCJNYWlubmV0XCJdID0gXCJtYWlubmV0LWJldGFcIjtcbiAgICBXYWxsZXRBZGFwdGVyTmV0d29ya1tcIlRlc3RuZXRcIl0gPSBcInRlc3RuZXRcIjtcbiAgICBXYWxsZXRBZGFwdGVyTmV0d29ya1tcIkRldm5ldFwiXSA9IFwiZGV2bmV0XCI7XG59KShXYWxsZXRBZGFwdGVyTmV0d29yayB8fCAoV2FsbGV0QWRhcHRlck5ldHdvcmsgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YWRhcHRlci5qcy5tYXAiLCJleHBvcnQgY2xhc3MgV2FsbGV0RXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9leHBsaWNpdC1tb2R1bGUtYm91bmRhcnktdHlwZXNcbiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlLCBlcnJvcikge1xuICAgICAgICBzdXBlcihtZXNzYWdlKTtcbiAgICAgICAgdGhpcy5lcnJvciA9IGVycm9yO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXROb3RGb3VuZEVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0Tm90Rm91bmRFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldE5vdEluc3RhbGxlZEVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0Tm90SW5zdGFsbGVkRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXROb3RSZWFkeUVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0Tm90UmVhZHlFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldENvbm5lY3Rpb25FcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldENvbm5lY3Rpb25FcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldERpc2Nvbm5lY3RlZEVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0RGlzY29ubmVjdGVkRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXREaXNjb25uZWN0aW9uRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXREaXNjb25uZWN0aW9uRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRBY2NvdW50RXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXRBY2NvdW50RXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRQdWJsaWNLZXlFcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldFB1YmxpY0tleUVycm9yJztcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgV2FsbGV0S2V5cGFpckVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0S2V5cGFpckVycm9yJztcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgV2FsbGV0Tm90Q29ubmVjdGVkRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXROb3RDb25uZWN0ZWRFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldFNlbmRUcmFuc2FjdGlvbkVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0U2VuZFRyYW5zYWN0aW9uRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRTaWduTWVzc2FnZUVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0U2lnbk1lc3NhZ2VFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldFNpZ25UcmFuc2FjdGlvbkVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0U2lnblRyYW5zYWN0aW9uRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRUaW1lb3V0RXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXRUaW1lb3V0RXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRXaW5kb3dCbG9ja2VkRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXRXaW5kb3dCbG9ja2VkRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRXaW5kb3dDbG9zZWRFcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldFdpbmRvd0Nsb3NlZEVycm9yJztcbiAgICB9XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1lcnJvcnMuanMubWFwIiwiZXhwb3J0ICogZnJvbSAnLi9hZGFwdGVyJztcbmV4cG9ydCAqIGZyb20gJy4vZXJyb3JzJztcbmV4cG9ydCAqIGZyb20gJy4vcG9sbCc7XG5leHBvcnQgKiBmcm9tICcuL3NpZ25lcic7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJ2YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICAgIH0pO1xufTtcbmV4cG9ydCBmdW5jdGlvbiBwb2xsKGNhbGxiYWNrLCBpbnRlcnZhbCwgY291bnQpIHtcbiAgICBpZiAoY291bnQgPiAwKSB7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICAgICAgY29uc3QgZG9uZSA9IHlpZWxkIGNhbGxiYWNrKCk7XG4gICAgICAgICAgICBpZiAoIWRvbmUpXG4gICAgICAgICAgICAgICAgcG9sbChjYWxsYmFjaywgaW50ZXJ2YWwsIGNvdW50IC0gMSk7XG4gICAgICAgIH0pLCBpbnRlcnZhbCk7XG4gICAgfVxufVxuZXhwb3J0IGZ1bmN0aW9uIHBvbGxVbnRpbFJlYWR5KGFkYXB0ZXIsIHBvbGxJbnRlcnZhbCwgcG9sbENvdW50KSB7XG4gICAgcG9sbCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IHsgcmVhZHkgfSA9IGFkYXB0ZXI7XG4gICAgICAgIGlmIChyZWFkeSkge1xuICAgICAgICAgICAgaWYgKCFhZGFwdGVyLmVtaXQoJ3JlYWR5JykpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYCR7YWRhcHRlci5jb25zdHJ1Y3Rvci5uYW1lfSBpcyByZWFkeSBidXQgbm8gbGlzdGVuZXIgd2FzIHJlZ2lzdGVyZWRgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVhZHk7XG4gICAgfSwgcG9sbEludGVydmFsLCBwb2xsQ291bnQpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cG9sbC5qcy5tYXAiLCJ2YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICAgIH0pO1xufTtcbnZhciBfX3Jlc3QgPSAodGhpcyAmJiB0aGlzLl9fcmVzdCkgfHwgZnVuY3Rpb24gKHMsIGUpIHtcbiAgICB2YXIgdCA9IHt9O1xuICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxuICAgICAgICB0W3BdID0gc1twXTtcbiAgICBpZiAocyAhPSBudWxsICYmIHR5cGVvZiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzID09PSBcImZ1bmN0aW9uXCIpXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChlLmluZGV4T2YocFtpXSkgPCAwICYmIE9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChzLCBwW2ldKSlcbiAgICAgICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcbiAgICAgICAgfVxuICAgIHJldHVybiB0O1xufTtcbmltcG9ydCB7IEJhc2VXYWxsZXRBZGFwdGVyIH0gZnJvbSAnLi9hZGFwdGVyJztcbmltcG9ydCB7IFdhbGxldEVycm9yLCBXYWxsZXRTZW5kVHJhbnNhY3Rpb25FcnJvciB9IGZyb20gJy4vZXJyb3JzJztcbmV4cG9ydCBjbGFzcyBCYXNlU2lnbmVyV2FsbGV0QWRhcHRlciBleHRlbmRzIEJhc2VXYWxsZXRBZGFwdGVyIHtcbiAgICBzZW5kVHJhbnNhY3Rpb24odHJhbnNhY3Rpb24sIGNvbm5lY3Rpb24sIG9wdGlvbnMgPSB7fSkge1xuICAgICAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICAgICAgbGV0IGVtaXQgPSB0cnVlO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbi5mZWVQYXllciB8fCAodHJhbnNhY3Rpb24uZmVlUGF5ZXIgPSB0aGlzLnB1YmxpY0tleSB8fCB1bmRlZmluZWQpO1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbi5yZWNlbnRCbG9ja2hhc2ggfHwgKHRyYW5zYWN0aW9uLnJlY2VudEJsb2NraGFzaCA9ICh5aWVsZCBjb25uZWN0aW9uLmdldFJlY2VudEJsb2NraGFzaCgnZmluYWxpemVkJykpLmJsb2NraGFzaCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHsgc2lnbmVycyB9ID0gb3B0aW9ucywgc2VuZE9wdGlvbnMgPSBfX3Jlc3Qob3B0aW9ucywgW1wic2lnbmVyc1wiXSk7XG4gICAgICAgICAgICAgICAgICAgIChzaWduZXJzID09PSBudWxsIHx8IHNpZ25lcnMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNpZ25lcnMubGVuZ3RoKSAmJiB0cmFuc2FjdGlvbi5wYXJ0aWFsU2lnbiguLi5zaWduZXJzKTtcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNhY3Rpb24gPSB5aWVsZCB0aGlzLnNpZ25UcmFuc2FjdGlvbih0cmFuc2FjdGlvbik7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJhd1RyYW5zYWN0aW9uID0gdHJhbnNhY3Rpb24uc2VyaWFsaXplKCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB5aWVsZCBjb25uZWN0aW9uLnNlbmRSYXdUcmFuc2FjdGlvbihyYXdUcmFuc2FjdGlvbiwgc2VuZE9wdGlvbnMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gSWYgdGhlIGVycm9yIHdhcyB0aHJvd24gYnkgYHNpZ25UcmFuc2FjdGlvbmAsIHJldGhyb3cgaXQgYW5kIGRvbid0IGVtaXQgYSBkdXBsaWNhdGUgZXZlbnRcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgV2FsbGV0RXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtaXQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBXYWxsZXRTZW5kVHJhbnNhY3Rpb25FcnJvcihlcnJvciA9PT0gbnVsbCB8fCBlcnJvciA9PT0gdm9pZCAwID8gdm9pZCAwIDogZXJyb3IubWVzc2FnZSwgZXJyb3IpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGlmIChlbWl0KSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnJvcik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgQmFzZU1lc3NhZ2VTaWduZXJXYWxsZXRBZGFwdGVyIGV4dGVuZHMgQmFzZVNpZ25lcldhbGxldEFkYXB0ZXIge1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2lnbmVyLmpzLm1hcCIsImltcG9ydCB7IENvbm5lY3Rpb24gfSBmcm9tICdAc29sYW5hL3dlYjMuanMnO1xuaW1wb3J0IFJlYWN0LCB7IHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBDb25uZWN0aW9uQ29udGV4dCB9IGZyb20gJy4vdXNlQ29ubmVjdGlvbic7XG5leHBvcnQgY29uc3QgQ29ubmVjdGlvblByb3ZpZGVyID0gKHsgY2hpbGRyZW4sIGVuZHBvaW50LCBjb25maWcgPSB7IGNvbW1pdG1lbnQ6ICdjb25maXJtZWQnIH0sIH0pID0+IHtcbiAgICBjb25zdCBjb25uZWN0aW9uID0gdXNlTWVtbygoKSA9PiBuZXcgQ29ubmVjdGlvbihlbmRwb2ludCwgY29uZmlnKSwgW2VuZHBvaW50LCBjb25maWddKTtcbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChDb25uZWN0aW9uQ29udGV4dC5Qcm92aWRlciwgeyB2YWx1ZTogeyBjb25uZWN0aW9uIH0gfSwgY2hpbGRyZW4pO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUNvbm5lY3Rpb25Qcm92aWRlci5qcy5tYXAiLCJ2YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICAgIH0pO1xufTtcbmltcG9ydCB7IFdhbGxldE5vdENvbm5lY3RlZEVycm9yLCBXYWxsZXROb3RSZWFkeUVycm9yLCB9IGZyb20gJ0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItYmFzZSc7XG5pbXBvcnQgUmVhY3QsIHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFdhbGxldE5vdFNlbGVjdGVkRXJyb3IgfSBmcm9tICcuL2Vycm9ycyc7XG5pbXBvcnQgeyB1c2VMb2NhbFN0b3JhZ2UgfSBmcm9tICcuL3VzZUxvY2FsU3RvcmFnZSc7XG5pbXBvcnQgeyBXYWxsZXRDb250ZXh0IH0gZnJvbSAnLi91c2VXYWxsZXQnO1xuY29uc3QgaW5pdGlhbFN0YXRlID0ge1xuICAgIHdhbGxldDogbnVsbCxcbiAgICBhZGFwdGVyOiBudWxsLFxuICAgIHJlYWR5OiBmYWxzZSxcbiAgICBwdWJsaWNLZXk6IG51bGwsXG4gICAgY29ubmVjdGVkOiBmYWxzZSxcbn07XG5leHBvcnQgY29uc3QgV2FsbGV0UHJvdmlkZXIgPSAoeyBjaGlsZHJlbiwgd2FsbGV0cywgYXV0b0Nvbm5lY3QgPSBmYWxzZSwgb25FcnJvcjogX29uRXJyb3IgPSAoZXJyb3IpID0+IGNvbnNvbGUuZXJyb3IoZXJyb3IpLCBsb2NhbFN0b3JhZ2VLZXkgPSAnd2FsbGV0TmFtZScsIH0pID0+IHtcbiAgICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VMb2NhbFN0b3JhZ2UobG9jYWxTdG9yYWdlS2V5LCBudWxsKTtcbiAgICBjb25zdCBbeyB3YWxsZXQsIGFkYXB0ZXIsIHJlYWR5LCBwdWJsaWNLZXksIGNvbm5lY3RlZCB9LCBzZXRTdGF0ZV0gPSB1c2VTdGF0ZShpbml0aWFsU3RhdGUpO1xuICAgIGNvbnN0IFtjb25uZWN0aW5nLCBzZXRDb25uZWN0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbZGlzY29ubmVjdGluZywgc2V0RGlzY29ubmVjdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgaXNDb25uZWN0aW5nID0gdXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCBpc0Rpc2Nvbm5lY3RpbmcgPSB1c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IGlzVW5sb2FkaW5nID0gdXNlUmVmKGZhbHNlKTtcbiAgICAvLyBNYXAgb2Ygd2FsbGV0IG5hbWVzIHRvIHdhbGxldHNcbiAgICBjb25zdCB3YWxsZXRzQnlOYW1lID0gdXNlTWVtbygoKSA9PiB3YWxsZXRzLnJlZHVjZSgod2FsbGV0c0J5TmFtZSwgd2FsbGV0KSA9PiB7XG4gICAgICAgIHdhbGxldHNCeU5hbWVbd2FsbGV0Lm5hbWVdID0gd2FsbGV0O1xuICAgICAgICByZXR1cm4gd2FsbGV0c0J5TmFtZTtcbiAgICB9LCB7fSksIFt3YWxsZXRzXSk7XG4gICAgLy8gV2hlbiB0aGUgc2VsZWN0ZWQgd2FsbGV0IGNoYW5nZXMsIGluaXRpYWxpemUgdGhlIHN0YXRlXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3Qgd2FsbGV0ID0gKG5hbWUgJiYgd2FsbGV0c0J5TmFtZVtuYW1lXSkgfHwgbnVsbDtcbiAgICAgICAgY29uc3QgYWRhcHRlciA9IHdhbGxldCAmJiB3YWxsZXQuYWRhcHRlcigpO1xuICAgICAgICBpZiAoYWRhcHRlcikge1xuICAgICAgICAgICAgY29uc3QgeyByZWFkeSwgcHVibGljS2V5LCBjb25uZWN0ZWQgfSA9IGFkYXB0ZXI7XG4gICAgICAgICAgICBzZXRTdGF0ZSh7IHdhbGxldCwgYWRhcHRlciwgY29ubmVjdGVkLCBwdWJsaWNLZXksIHJlYWR5IH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgc2V0U3RhdGUoaW5pdGlhbFN0YXRlKTtcbiAgICAgICAgfVxuICAgIH0sIFtuYW1lLCB3YWxsZXRzQnlOYW1lLCBzZXRTdGF0ZV0pO1xuICAgIC8vIElmIGF1dG9Db25uZWN0IGlzIGVuYWJsZWQsIHRyeSB0byBjb25uZWN0IHdoZW4gdGhlIGFkYXB0ZXIgY2hhbmdlcyBhbmQgaXMgcmVhZHlcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoaXNDb25uZWN0aW5nLmN1cnJlbnQgfHwgY29ubmVjdGluZyB8fCBjb25uZWN0ZWQgfHwgIWF1dG9Db25uZWN0IHx8ICFhZGFwdGVyIHx8ICFyZWFkeSlcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgICAgICAgICAgaXNDb25uZWN0aW5nLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHNldENvbm5lY3RpbmcodHJ1ZSk7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgeWllbGQgYWRhcHRlci5jb25uZWN0KCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAvLyBDbGVhciB0aGUgc2VsZWN0ZWQgd2FsbGV0XG4gICAgICAgICAgICAgICAgICAgIHNldE5hbWUobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIC8vIERvbid0IHRocm93IGVycm9yLCBidXQgb25FcnJvciB3aWxsIHN0aWxsIGJlIGNhbGxlZFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q29ubmVjdGluZyhmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIGlzQ29ubmVjdGluZy5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pKCk7XG4gICAgfSwgW2lzQ29ubmVjdGluZywgY29ubmVjdGluZywgY29ubmVjdGVkLCBhdXRvQ29ubmVjdCwgYWRhcHRlciwgcmVhZHksIHNldENvbm5lY3RpbmcsIHNldE5hbWVdKTtcbiAgICAvLyBJZiB0aGUgd2luZG93IGlzIGNsb3Npbmcgb3IgcmVsb2FkaW5nLCBpZ25vcmUgZGlzY29ubmVjdCBhbmQgZXJyb3IgZXZlbnRzIGZyb20gdGhlIGFkYXB0ZXJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBmdW5jdGlvbiBsaXN0ZW5lcigpIHtcbiAgICAgICAgICAgIGlzVW5sb2FkaW5nLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdiZWZvcmV1bmxvYWQnLCBsaXN0ZW5lcik7XG4gICAgICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignYmVmb3JldW5sb2FkJywgbGlzdGVuZXIpO1xuICAgIH0sIFtpc1VubG9hZGluZ10pO1xuICAgIC8vIFNlbGVjdCBhIHdhbGxldCBieSBuYW1lXG4gICAgY29uc3Qgc2VsZWN0ID0gdXNlQ2FsbGJhY2soKG5ld05hbWUpID0+IF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICBpZiAobmFtZSA9PT0gbmV3TmFtZSlcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgaWYgKGFkYXB0ZXIpXG4gICAgICAgICAgICB5aWVsZCBhZGFwdGVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgc2V0TmFtZShuZXdOYW1lKTtcbiAgICB9KSwgW25hbWUsIGFkYXB0ZXIsIHNldE5hbWVdKTtcbiAgICAvLyBIYW5kbGUgdGhlIGFkYXB0ZXIncyByZWFkeSBldmVudFxuICAgIGNvbnN0IG9uUmVhZHkgPSB1c2VDYWxsYmFjaygoKSA9PiBzZXRTdGF0ZSgoc3RhdGUpID0+IChPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHN0YXRlKSwgeyByZWFkeTogdHJ1ZSB9KSkpLCBbc2V0U3RhdGVdKTtcbiAgICAvLyBIYW5kbGUgdGhlIGFkYXB0ZXIncyBjb25uZWN0IGV2ZW50XG4gICAgY29uc3Qgb25Db25uZWN0ID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgICAgICBpZiAoIWFkYXB0ZXIpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIGNvbnN0IHsgY29ubmVjdGVkLCBwdWJsaWNLZXksIHJlYWR5IH0gPSBhZGFwdGVyO1xuICAgICAgICBzZXRTdGF0ZSgoc3RhdGUpID0+IChPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHN0YXRlKSwgeyBjb25uZWN0ZWQsXG4gICAgICAgICAgICBwdWJsaWNLZXksXG4gICAgICAgICAgICByZWFkeSB9KSkpO1xuICAgIH0sIFthZGFwdGVyLCBzZXRTdGF0ZV0pO1xuICAgIC8vIEhhbmRsZSB0aGUgYWRhcHRlcidzIGRpc2Nvbm5lY3QgZXZlbnRcbiAgICBjb25zdCBvbkRpc2Nvbm5lY3QgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICAgIC8vIENsZWFyIHRoZSBzZWxlY3RlZCB3YWxsZXQgdW5sZXNzIHRoZSB3aW5kb3cgaXMgdW5sb2FkaW5nXG4gICAgICAgIGlmICghaXNVbmxvYWRpbmcuY3VycmVudClcbiAgICAgICAgICAgIHNldE5hbWUobnVsbCk7XG4gICAgfSwgW2lzVW5sb2FkaW5nLCBzZXROYW1lXSk7XG4gICAgLy8gSGFuZGxlIHRoZSBhZGFwdGVyJ3MgZXJyb3IgZXZlbnQsIGFuZCBsb2NhbCBlcnJvcnNcbiAgICBjb25zdCBvbkVycm9yID0gdXNlQ2FsbGJhY2soKGVycm9yKSA9PiB7XG4gICAgICAgIC8vIENhbGwgdGhlIHByb3ZpZGVkIGVycm9yIGhhbmRsZXIgdW5sZXNzIHRoZSB3aW5kb3cgaXMgdW5sb2FkaW5nXG4gICAgICAgIGlmICghaXNVbmxvYWRpbmcuY3VycmVudClcbiAgICAgICAgICAgIF9vbkVycm9yKGVycm9yKTtcbiAgICAgICAgcmV0dXJuIGVycm9yO1xuICAgIH0sIFtpc1VubG9hZGluZywgX29uRXJyb3JdKTtcbiAgICAvLyBDb25uZWN0IHRoZSBhZGFwdGVyIHRvIHRoZSB3YWxsZXRcbiAgICBjb25zdCBjb25uZWN0ID0gdXNlQ2FsbGJhY2soKCkgPT4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgIGlmIChpc0Nvbm5lY3RpbmcuY3VycmVudCB8fCBjb25uZWN0aW5nIHx8IGRpc2Nvbm5lY3RpbmcgfHwgY29ubmVjdGVkKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBpZiAoIXdhbGxldCB8fCAhYWRhcHRlcilcbiAgICAgICAgICAgIHRocm93IG9uRXJyb3IobmV3IFdhbGxldE5vdFNlbGVjdGVkRXJyb3IoKSk7XG4gICAgICAgIGlmICghcmVhZHkpIHtcbiAgICAgICAgICAgIC8vIENsZWFyIHRoZSBzZWxlY3RlZCB3YWxsZXRcbiAgICAgICAgICAgIHNldE5hbWUobnVsbCk7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICB3aW5kb3cub3Blbih3YWxsZXQudXJsLCAnX2JsYW5rJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBvbkVycm9yKG5ldyBXYWxsZXROb3RSZWFkeUVycm9yKCkpO1xuICAgICAgICB9XG4gICAgICAgIGlzQ29ubmVjdGluZy5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgc2V0Q29ubmVjdGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHlpZWxkIGFkYXB0ZXIuY29ubmVjdCgpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgLy8gQ2xlYXIgdGhlIHNlbGVjdGVkIHdhbGxldFxuICAgICAgICAgICAgc2V0TmFtZShudWxsKTtcbiAgICAgICAgICAgIC8vIFJldGhyb3cgdGhlIGVycm9yLCBhbmQgb25FcnJvciB3aWxsIGFsc28gYmUgY2FsbGVkXG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldENvbm5lY3RpbmcoZmFsc2UpO1xuICAgICAgICAgICAgaXNDb25uZWN0aW5nLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0pLCBbaXNDb25uZWN0aW5nLCBjb25uZWN0aW5nLCBkaXNjb25uZWN0aW5nLCBjb25uZWN0ZWQsIHdhbGxldCwgYWRhcHRlciwgb25FcnJvciwgcmVhZHksIHNldENvbm5lY3RpbmcsIHNldE5hbWVdKTtcbiAgICAvLyBEaXNjb25uZWN0IHRoZSBhZGFwdGVyIGZyb20gdGhlIHdhbGxldFxuICAgIGNvbnN0IGRpc2Nvbm5lY3QgPSB1c2VDYWxsYmFjaygoKSA9PiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgaWYgKGlzRGlzY29ubmVjdGluZy5jdXJyZW50IHx8IGRpc2Nvbm5lY3RpbmcpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIGlmICghYWRhcHRlcilcbiAgICAgICAgICAgIHJldHVybiBzZXROYW1lKG51bGwpO1xuICAgICAgICBpc0Rpc2Nvbm5lY3RpbmcuY3VycmVudCA9IHRydWU7XG4gICAgICAgIHNldERpc2Nvbm5lY3RpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB5aWVsZCBhZGFwdGVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIC8vIENsZWFyIHRoZSBzZWxlY3RlZCB3YWxsZXRcbiAgICAgICAgICAgIHNldE5hbWUobnVsbCk7XG4gICAgICAgICAgICAvLyBSZXRocm93IHRoZSBlcnJvciwgYW5kIG9uRXJyb3Igd2lsbCBhbHNvIGJlIGNhbGxlZFxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICBzZXREaXNjb25uZWN0aW5nKGZhbHNlKTtcbiAgICAgICAgICAgIGlzRGlzY29ubmVjdGluZy5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9KSwgW2lzRGlzY29ubmVjdGluZywgZGlzY29ubmVjdGluZywgYWRhcHRlciwgc2V0RGlzY29ubmVjdGluZywgc2V0TmFtZV0pO1xuICAgIC8vIFNlbmQgYSB0cmFuc2FjdGlvbiB1c2luZyB0aGUgcHJvdmlkZWQgY29ubmVjdGlvblxuICAgIGNvbnN0IHNlbmRUcmFuc2FjdGlvbiA9IHVzZUNhbGxiYWNrKCh0cmFuc2FjdGlvbiwgY29ubmVjdGlvbiwgb3B0aW9ucykgPT4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgIGlmICghYWRhcHRlcilcbiAgICAgICAgICAgIHRocm93IG9uRXJyb3IobmV3IFdhbGxldE5vdFNlbGVjdGVkRXJyb3IoKSk7XG4gICAgICAgIGlmICghY29ubmVjdGVkKVxuICAgICAgICAgICAgdGhyb3cgb25FcnJvcihuZXcgV2FsbGV0Tm90Q29ubmVjdGVkRXJyb3IoKSk7XG4gICAgICAgIHJldHVybiB5aWVsZCBhZGFwdGVyLnNlbmRUcmFuc2FjdGlvbih0cmFuc2FjdGlvbiwgY29ubmVjdGlvbiwgb3B0aW9ucyk7XG4gICAgfSksIFthZGFwdGVyLCBvbkVycm9yLCBjb25uZWN0ZWRdKTtcbiAgICAvLyBTaWduIGEgdHJhbnNhY3Rpb24gaWYgdGhlIHdhbGxldCBzdXBwb3J0cyBpdFxuICAgIGNvbnN0IHNpZ25UcmFuc2FjdGlvbiA9IHVzZU1lbW8oKCkgPT4gYWRhcHRlciAmJiAnc2lnblRyYW5zYWN0aW9uJyBpbiBhZGFwdGVyXG4gICAgICAgID8gKHRyYW5zYWN0aW9uKSA9PiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgICAgIGlmICghY29ubmVjdGVkKVxuICAgICAgICAgICAgICAgIHRocm93IG9uRXJyb3IobmV3IFdhbGxldE5vdENvbm5lY3RlZEVycm9yKCkpO1xuICAgICAgICAgICAgcmV0dXJuIHlpZWxkIGFkYXB0ZXIuc2lnblRyYW5zYWN0aW9uKHRyYW5zYWN0aW9uKTtcbiAgICAgICAgfSlcbiAgICAgICAgOiB1bmRlZmluZWQsIFthZGFwdGVyLCBvbkVycm9yLCBjb25uZWN0ZWRdKTtcbiAgICAvLyBTaWduIG11bHRpcGxlIHRyYW5zYWN0aW9ucyBpZiB0aGUgd2FsbGV0IHN1cHBvcnRzIGl0XG4gICAgY29uc3Qgc2lnbkFsbFRyYW5zYWN0aW9ucyA9IHVzZU1lbW8oKCkgPT4gYWRhcHRlciAmJiAnc2lnbkFsbFRyYW5zYWN0aW9ucycgaW4gYWRhcHRlclxuICAgICAgICA/ICh0cmFuc2FjdGlvbnMpID0+IF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICAgICAgaWYgKCFjb25uZWN0ZWQpXG4gICAgICAgICAgICAgICAgdGhyb3cgb25FcnJvcihuZXcgV2FsbGV0Tm90Q29ubmVjdGVkRXJyb3IoKSk7XG4gICAgICAgICAgICByZXR1cm4geWllbGQgYWRhcHRlci5zaWduQWxsVHJhbnNhY3Rpb25zKHRyYW5zYWN0aW9ucyk7XG4gICAgICAgIH0pXG4gICAgICAgIDogdW5kZWZpbmVkLCBbYWRhcHRlciwgb25FcnJvciwgY29ubmVjdGVkXSk7XG4gICAgLy8gU2lnbiBhbiBhcmJpdHJhcnkgbWVzc2FnZSBpZiB0aGUgd2FsbGV0IHN1cHBvcnRzIGl0XG4gICAgY29uc3Qgc2lnbk1lc3NhZ2UgPSB1c2VNZW1vKCgpID0+IGFkYXB0ZXIgJiYgJ3NpZ25NZXNzYWdlJyBpbiBhZGFwdGVyXG4gICAgICAgID8gKG1lc3NhZ2UpID0+IF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICAgICAgaWYgKCFjb25uZWN0ZWQpXG4gICAgICAgICAgICAgICAgdGhyb3cgb25FcnJvcihuZXcgV2FsbGV0Tm90Q29ubmVjdGVkRXJyb3IoKSk7XG4gICAgICAgICAgICByZXR1cm4geWllbGQgYWRhcHRlci5zaWduTWVzc2FnZShtZXNzYWdlKTtcbiAgICAgICAgfSlcbiAgICAgICAgOiB1bmRlZmluZWQsIFthZGFwdGVyLCBvbkVycm9yLCBjb25uZWN0ZWRdKTtcbiAgICAvLyBTZXR1cCBhbmQgdGVhcmRvd24gZXZlbnQgbGlzdGVuZXJzIHdoZW4gdGhlIGFkYXB0ZXIgY2hhbmdlc1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChhZGFwdGVyKSB7XG4gICAgICAgICAgICBhZGFwdGVyLm9uKCdyZWFkeScsIG9uUmVhZHkpO1xuICAgICAgICAgICAgYWRhcHRlci5vbignY29ubmVjdCcsIG9uQ29ubmVjdCk7XG4gICAgICAgICAgICBhZGFwdGVyLm9uKCdkaXNjb25uZWN0Jywgb25EaXNjb25uZWN0KTtcbiAgICAgICAgICAgIGFkYXB0ZXIub24oJ2Vycm9yJywgb25FcnJvcik7XG4gICAgICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgICAgIGFkYXB0ZXIub2ZmKCdyZWFkeScsIG9uUmVhZHkpO1xuICAgICAgICAgICAgICAgIGFkYXB0ZXIub2ZmKCdjb25uZWN0Jywgb25Db25uZWN0KTtcbiAgICAgICAgICAgICAgICBhZGFwdGVyLm9mZignZGlzY29ubmVjdCcsIG9uRGlzY29ubmVjdCk7XG4gICAgICAgICAgICAgICAgYWRhcHRlci5vZmYoJ2Vycm9yJywgb25FcnJvcik7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgfSwgW2FkYXB0ZXIsIG9uUmVhZHksIG9uQ29ubmVjdCwgb25EaXNjb25uZWN0LCBvbkVycm9yXSk7XG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KFdhbGxldENvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWU6IHtcbiAgICAgICAgICAgIHdhbGxldHMsXG4gICAgICAgICAgICBhdXRvQ29ubmVjdCxcbiAgICAgICAgICAgIHdhbGxldCxcbiAgICAgICAgICAgIGFkYXB0ZXIsXG4gICAgICAgICAgICBwdWJsaWNLZXksXG4gICAgICAgICAgICByZWFkeSxcbiAgICAgICAgICAgIGNvbm5lY3RlZCxcbiAgICAgICAgICAgIGNvbm5lY3RpbmcsXG4gICAgICAgICAgICBkaXNjb25uZWN0aW5nLFxuICAgICAgICAgICAgc2VsZWN0LFxuICAgICAgICAgICAgY29ubmVjdCxcbiAgICAgICAgICAgIGRpc2Nvbm5lY3QsXG4gICAgICAgICAgICBzZW5kVHJhbnNhY3Rpb24sXG4gICAgICAgICAgICBzaWduVHJhbnNhY3Rpb24sXG4gICAgICAgICAgICBzaWduQWxsVHJhbnNhY3Rpb25zLFxuICAgICAgICAgICAgc2lnbk1lc3NhZ2UsXG4gICAgICAgIH0gfSwgY2hpbGRyZW4pKTtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1XYWxsZXRQcm92aWRlci5qcy5tYXAiLCJpbXBvcnQgeyBXYWxsZXRFcnJvciB9IGZyb20gJ0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItYmFzZSc7XG5leHBvcnQgY2xhc3MgV2FsbGV0Tm90U2VsZWN0ZWRFcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldE5vdFNlbGVjdGVkRXJyb3InO1xuICAgIH1cbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVycm9ycy5qcy5tYXAiLCJleHBvcnQgKiBmcm9tICcuL0Nvbm5lY3Rpb25Qcm92aWRlcic7XG5leHBvcnQgKiBmcm9tICcuL2Vycm9ycyc7XG5leHBvcnQgKiBmcm9tICcuL3VzZUFuY2hvcldhbGxldCc7XG5leHBvcnQgKiBmcm9tICcuL3VzZUNvbm5lY3Rpb24nO1xuZXhwb3J0ICogZnJvbSAnLi91c2VMb2NhbFN0b3JhZ2UnO1xuZXhwb3J0ICogZnJvbSAnLi91c2VXYWxsZXQnO1xuZXhwb3J0ICogZnJvbSAnLi9XYWxsZXRQcm92aWRlcic7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJpbXBvcnQgeyB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlV2FsbGV0IH0gZnJvbSAnLi91c2VXYWxsZXQnO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUFuY2hvcldhbGxldCgpIHtcbiAgICBjb25zdCB7IHB1YmxpY0tleSwgc2lnblRyYW5zYWN0aW9uLCBzaWduQWxsVHJhbnNhY3Rpb25zIH0gPSB1c2VXYWxsZXQoKTtcbiAgICByZXR1cm4gdXNlTWVtbygoKSA9PiBwdWJsaWNLZXkgJiYgc2lnblRyYW5zYWN0aW9uICYmIHNpZ25BbGxUcmFuc2FjdGlvbnNcbiAgICAgICAgPyB7IHB1YmxpY0tleSwgc2lnblRyYW5zYWN0aW9uLCBzaWduQWxsVHJhbnNhY3Rpb25zIH1cbiAgICAgICAgOiB1bmRlZmluZWQsIFtwdWJsaWNLZXksIHNpZ25UcmFuc2FjdGlvbiwgc2lnbkFsbFRyYW5zYWN0aW9uc10pO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlQW5jaG9yV2FsbGV0LmpzLm1hcCIsImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNvbnRleHQgfSBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgQ29ubmVjdGlvbkNvbnRleHQgPSBjcmVhdGVDb250ZXh0KHt9KTtcbmV4cG9ydCBmdW5jdGlvbiB1c2VDb25uZWN0aW9uKCkge1xuICAgIHJldHVybiB1c2VDb250ZXh0KENvbm5lY3Rpb25Db250ZXh0KTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUNvbm5lY3Rpb24uanMubWFwIiwiaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUxvY2FsU3RvcmFnZShrZXksIGRlZmF1bHRTdGF0ZSkge1xuICAgIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gdXNlU3RhdGUoKCkgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIGxvY2FsU3RvcmFnZSA9PT0gJ3VuZGVmaW5lZCcpXG4gICAgICAgICAgICByZXR1cm4gZGVmYXVsdFN0YXRlO1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWUgPyBKU09OLnBhcnNlKHZhbHVlKSA6IGRlZmF1bHRTdGF0ZTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihlcnJvcik7XG4gICAgICAgICAgICByZXR1cm4gZGVmYXVsdFN0YXRlO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgY29uc3Qgc2V0TG9jYWxTdG9yYWdlID0gdXNlQ2FsbGJhY2soKG5ld1ZhbHVlKSA9PiB7XG4gICAgICAgIGlmIChuZXdWYWx1ZSA9PT0gdmFsdWUpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIHNldFZhbHVlKG5ld1ZhbHVlKTtcbiAgICAgICAgaWYgKG5ld1ZhbHVlID09PSBudWxsKSB7XG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShrZXkpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShrZXksIEpTT04uc3RyaW5naWZ5KG5ld1ZhbHVlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sIFt2YWx1ZSwgc2V0VmFsdWUsIGtleV0pO1xuICAgIHJldHVybiBbdmFsdWUsIHNldExvY2FsU3RvcmFnZV07XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VMb2NhbFN0b3JhZ2UuanMubWFwIiwiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCB9IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBXYWxsZXRDb250ZXh0ID0gY3JlYXRlQ29udGV4dCh7fSk7XG5leHBvcnQgZnVuY3Rpb24gdXNlV2FsbGV0KCkge1xuICAgIHJldHVybiB1c2VDb250ZXh0KFdhbGxldENvbnRleHQpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlV2FsbGV0LmpzLm1hcCIsIiIsIiIsIiIsIiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9kaXN0L3NoYXJlZC9saWIvZHluYW1pYycpXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbGVkZ2VyaHEvaHctdHJhbnNwb3J0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBsZWRnZXJocS9ody10cmFuc3BvcnQtd2ViaGlkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBwcm9qZWN0LXNlcnVtL2FuY2hvclwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IGltcG9ydChcIkBzb2xhbmEvd2FsbGV0LWFkYXB0ZXItYml0a2VlcFwiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSBpbXBvcnQoXCJAc29sYW5hL3dhbGxldC1hZGFwdGVyLWNsb3ZlclwiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSBpbXBvcnQoXCJAc29sYW5hL3dhbGxldC1hZGFwdGVyLWNvaW5odWJcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBzb2xhbmEvd2ViMy5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAdG9ydXNsYWJzL29wZW5sb2dpblwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAdG9ydXNsYWJzL29wZW5sb2dpbi1lZDI1NTE5XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImJzNThcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZXZlbnRlbWl0dGVyM1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9sb2FkYWJsZS5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2hlYWRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtZG9tXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LXJlZHV4XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWR1eFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWR1eC1wZXJzaXN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlZHV4LXBlcnNpc3QvaW50ZWdyYXRpb24vcmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVkdXgtcGVyc2lzdC9saWIvc3RvcmFnZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWR1eC10aHVua1wiKTsiXSwibmFtZXMiOlsidXNlV2FsbGV0IiwiTEFNUE9SVFNfUEVSX1NPTCIsImNyZWF0ZUNvbnRleHQiLCJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJhbmNob3IiLCJCYWxhbmNlQ29udGV4dCIsInJwY0hvc3QiLCJwcm9jZXNzIiwiZW52IiwiTkVYVF9QVUJMSUNfU09MQU5BX1JQQ19IT1NUIiwiY29ubmVjdGlvbiIsIndlYjMiLCJDb25uZWN0aW9uIiwidXNlV2FsbGV0QmFsYW5jZSIsImJhbGFuY2UiLCJzZXRCYWxhbmNlIiwiV2FsbGV0QmFsYW5jZVByb3ZpZGVyIiwiY2hpbGRyZW4iLCJ3YWxsZXQiLCJwdWJsaWNLZXkiLCJnZXRCYWxhbmNlIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJleHBvcnRzIiwidmFsdWUiLCJub1NTUiIsImRlZmF1bHQiLCJkeW5hbWljIiwiX3JlYWN0IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsInJlcXVpcmUiLCJfbG9hZGFibGUiLCJvYmoiLCJfX2VzTW9kdWxlIiwiaXNTZXJ2ZXJTaWRlIiwiTG9hZGFibGVJbml0aWFsaXplciIsImxvYWRhYmxlT3B0aW9ucyIsIndlYnBhY2siLCJtb2R1bGVzIiwiTG9hZGluZyIsImxvYWRpbmciLCJjcmVhdGVFbGVtZW50IiwiZXJyb3IiLCJpc0xvYWRpbmciLCJwYXN0RGVsYXkiLCJ0aW1lZE91dCIsImR5bmFtaWNPcHRpb25zIiwib3B0aW9ucyIsImxvYWRhYmxlRm4iLCJtZXNzYWdlIiwic3RhY2siLCJQcm9taXNlIiwibG9hZGVyIiwic3VzcGVuc2VPcHRpb25zIiwiX19ORVhUX0NPTkNVUlJFTlRfRkVBVFVSRVMiLCJfX05FWFRfUkVBQ1RfUk9PVCIsInN1c3BlbnNlIiwiRXJyb3IiLCJsb2FkYWJsZUdlbmVyYXRlZCIsInNzciIsIkhlYWQiLCJQZXJzaXN0R2F0ZSIsInN0b3JlIiwicGVyc2lzdG9yIiwiUHJvdmlkZXIiLCJXYWxsZXRDb25uZWN0aW9uUHJvdmlkZXIiLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsInJvb3RSZWR1Y2VyIiwiY3JlYXRlU3RvcmUiLCJhcHBseU1pZGRsZXdhcmUiLCJjb21wb3NlIiwidGh1bmsiLCJwZXJzaXN0U3RvcmUiLCJwZXJzaXN0UmVkdWNlciIsInN0b3JhZ2UiLCJwZXJzaXN0Q29uZmlnIiwia2V5IiwidGltZW91dCIsInBlcnNpc3RlZFJlZHVjZXIiLCJjb21wb3NlRW5oYW5jZXJzIiwiZmluYWwiLCJJTklUSUFMX1NUQVRFIiwid2FsbGV0X2lkIiwibmZ0X2xpc3QiLCJhcHBfcmVkdWNlciIsInN0YXRlIiwiYWN0aW9uIiwidHlwZSIsInBheWxvYWQiLCJjb21iaW5lUmVkdWNlcnMiLCJFdmVudEVtaXR0ZXIiLCJCYXNlV2FsbGV0QWRhcHRlciIsIldhbGxldEFkYXB0ZXJOZXR3b3JrIiwiV2FsbGV0RXJyb3IiLCJjb25zdHJ1Y3RvciIsIldhbGxldE5vdEZvdW5kRXJyb3IiLCJhcmd1bWVudHMiLCJuYW1lIiwiV2FsbGV0Tm90SW5zdGFsbGVkRXJyb3IiLCJXYWxsZXROb3RSZWFkeUVycm9yIiwiV2FsbGV0Q29ubmVjdGlvbkVycm9yIiwiV2FsbGV0RGlzY29ubmVjdGVkRXJyb3IiLCJXYWxsZXREaXNjb25uZWN0aW9uRXJyb3IiLCJXYWxsZXRBY2NvdW50RXJyb3IiLCJXYWxsZXRQdWJsaWNLZXlFcnJvciIsIldhbGxldEtleXBhaXJFcnJvciIsIldhbGxldE5vdENvbm5lY3RlZEVycm9yIiwiV2FsbGV0U2VuZFRyYW5zYWN0aW9uRXJyb3IiLCJXYWxsZXRTaWduTWVzc2FnZUVycm9yIiwiV2FsbGV0U2lnblRyYW5zYWN0aW9uRXJyb3IiLCJXYWxsZXRUaW1lb3V0RXJyb3IiLCJXYWxsZXRXaW5kb3dCbG9ja2VkRXJyb3IiLCJXYWxsZXRXaW5kb3dDbG9zZWRFcnJvciIsIl9fYXdhaXRlciIsInRoaXNBcmciLCJfYXJndW1lbnRzIiwiUCIsImdlbmVyYXRvciIsImFkb3B0IiwicmVzb2x2ZSIsInJlamVjdCIsImZ1bGZpbGxlZCIsInN0ZXAiLCJuZXh0IiwiZSIsInJlamVjdGVkIiwicmVzdWx0IiwiZG9uZSIsInRoZW4iLCJhcHBseSIsInBvbGwiLCJjYWxsYmFjayIsImludGVydmFsIiwiY291bnQiLCJzZXRUaW1lb3V0IiwicG9sbFVudGlsUmVhZHkiLCJhZGFwdGVyIiwicG9sbEludGVydmFsIiwicG9sbENvdW50IiwicmVhZHkiLCJlbWl0IiwiY29uc29sZSIsIndhcm4iLCJfX3Jlc3QiLCJzIiwidCIsInAiLCJwcm90b3R5cGUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJpbmRleE9mIiwiZ2V0T3duUHJvcGVydHlTeW1ib2xzIiwiaSIsImxlbmd0aCIsInByb3BlcnR5SXNFbnVtZXJhYmxlIiwiQmFzZVNpZ25lcldhbGxldEFkYXB0ZXIiLCJzZW5kVHJhbnNhY3Rpb24iLCJ0cmFuc2FjdGlvbiIsImZlZVBheWVyIiwidW5kZWZpbmVkIiwicmVjZW50QmxvY2toYXNoIiwiZ2V0UmVjZW50QmxvY2toYXNoIiwiYmxvY2toYXNoIiwic2lnbmVycyIsInNlbmRPcHRpb25zIiwicGFydGlhbFNpZ24iLCJzaWduVHJhbnNhY3Rpb24iLCJyYXdUcmFuc2FjdGlvbiIsInNlcmlhbGl6ZSIsInNlbmRSYXdUcmFuc2FjdGlvbiIsIkJhc2VNZXNzYWdlU2lnbmVyV2FsbGV0QWRhcHRlciIsIlJlYWN0IiwidXNlTWVtbyIsIkNvbm5lY3Rpb25Db250ZXh0IiwiQ29ubmVjdGlvblByb3ZpZGVyIiwiZW5kcG9pbnQiLCJjb25maWciLCJjb21taXRtZW50IiwidXNlQ2FsbGJhY2siLCJ1c2VSZWYiLCJXYWxsZXROb3RTZWxlY3RlZEVycm9yIiwidXNlTG9jYWxTdG9yYWdlIiwiV2FsbGV0Q29udGV4dCIsImluaXRpYWxTdGF0ZSIsImNvbm5lY3RlZCIsIldhbGxldFByb3ZpZGVyIiwid2FsbGV0cyIsImF1dG9Db25uZWN0Iiwib25FcnJvciIsIl9vbkVycm9yIiwibG9jYWxTdG9yYWdlS2V5Iiwic2V0TmFtZSIsInNldFN0YXRlIiwiY29ubmVjdGluZyIsInNldENvbm5lY3RpbmciLCJkaXNjb25uZWN0aW5nIiwic2V0RGlzY29ubmVjdGluZyIsImlzQ29ubmVjdGluZyIsImlzRGlzY29ubmVjdGluZyIsImlzVW5sb2FkaW5nIiwid2FsbGV0c0J5TmFtZSIsInJlZHVjZSIsImN1cnJlbnQiLCJjb25uZWN0IiwibGlzdGVuZXIiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsInNlbGVjdCIsIm5ld05hbWUiLCJkaXNjb25uZWN0Iiwib25SZWFkeSIsImFzc2lnbiIsIm9uQ29ubmVjdCIsIm9uRGlzY29ubmVjdCIsIm9wZW4iLCJ1cmwiLCJzaWduQWxsVHJhbnNhY3Rpb25zIiwidHJhbnNhY3Rpb25zIiwic2lnbk1lc3NhZ2UiLCJvbiIsIm9mZiIsInVzZUFuY2hvcldhbGxldCIsInVzZUNvbm5lY3Rpb24iLCJkZWZhdWx0U3RhdGUiLCJzZXRWYWx1ZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJzZXRMb2NhbFN0b3JhZ2UiLCJuZXdWYWx1ZSIsInJlbW92ZUl0ZW0iLCJzZXRJdGVtIiwic3RyaW5naWZ5Il0sInNvdXJjZVJvb3QiOiIifQ==