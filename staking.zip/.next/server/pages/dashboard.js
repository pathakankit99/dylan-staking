(() => {
var exports = {};
exports.id = "pages/dashboard";
exports.ids = ["pages/dashboard"];
exports.modules = {

/***/ "./components/ConnectToWallet.tsx":
/*!****************************************!*\
  !*** ./components/ConnectToWallet.tsx ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_candyMachine__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/candyMachine */ "./utils/candyMachine.ts");
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var _hooks_useWalletNFTs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../hooks/useWalletNFTs */ "./hooks/useWalletNFTs.ts");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);


// import useWalletBalance from "../hooks/useWalletBalance";






function ConnectToWallet(props) {
  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
  const rpcUrl = props.rpcHost;
  const wallet = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_5__.useWallet)();
  const [isLoading, nfts, isSPLExists] = (0,_hooks_useWalletNFTs__WEBPACK_IMPORTED_MODULE_2__.default)(props);
  const anchorWallet = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    if (!wallet || !wallet.publicKey || !wallet.signAllTransactions || !wallet.signTransaction) {
      return;
    }

    return {
      publicKey: wallet.publicKey,
      signAllTransactions: wallet.signAllTransactions,
      signTransaction: wallet.signTransaction
    };
  }, [wallet]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    (async () => {
      if (!anchorWallet) {
        console.log("disconnected");
        dispatch({
          type: "WALLET_ID",
          payload: null
        });
        dispatch({
          type: "SETNFT",
          payload: null
        });
        return;
      } //  console.log(anchorWallet, "anchorWallet");


      if (anchorWallet !== null && anchorWallet !== void 0 && anchorWallet.publicKey) {
        var _anchorWallet$publicK;

        dispatch({
          type: "WALLET_ID",
          payload: anchorWallet === null || anchorWallet === void 0 ? void 0 : (_anchorWallet$publicK = anchorWallet.publicKey) === null || _anchorWallet$publicK === void 0 ? void 0 : _anchorWallet$publicK.toString()
        });
      }

      if (props !== null && props !== void 0 && props.connection && anchorWallet !== null && anchorWallet !== void 0 && anchorWallet.publicKey) {
        const nftsForOwner = await (0,_utils_candyMachine__WEBPACK_IMPORTED_MODULE_1__.getNFTsForOwner)(props.connection, anchorWallet === null || anchorWallet === void 0 ? void 0 : anchorWallet.publicKey);
        console.log(nftsForOwner, "NFTsForOwner");
      } //setNfts(nftsForOwner as any);

    })();
  }, [anchorWallet, props.candyMachineId, props.connection]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (nfts) {
      dispatch({
        type: "SETNFT",
        payload: nfts
      }); // console.log(nfts,'nfts added')
    }
  }, [nfts]);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {}, void 0, false);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConnectToWallet);

/***/ }),

/***/ "./components/Dashboard/LineChart.js":
/*!*******************************************!*\
  !*** ./components/Dashboard/LineChart.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recharts */ "recharts");
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(recharts__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\components\\Dashboard\\LineChart.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const data = [{
  name: "1 Jan",
  average: 4000,
  floor: 2400
}, {
  name: "2 Jan",
  average: 3000,
  floor: 1398
}, {
  name: "3 Jan",
  average: 2000,
  floor: 9800
}, {
  name: "4 Jan",
  average: 2780,
  floor: 3908
}, {
  name: "5 Jan",
  average: 1890,
  floor: 4800
}, {
  name: "6 Jan",
  average: 2390,
  floor: 3800
}, {
  name: "7 Jan",
  average: 3490,
  floor: 4300
}, {
  name: "8 Jan",
  average: 4000,
  floor: 2400
}, {
  name: "9 Jan",
  average: 3000,
  floor: 1398
}, {
  name: "10 Jan",
  average: 2000,
  floor: 9800
}, {
  name: "11 Jan",
  average: 2780,
  floor: 3908
}, {
  name: "12 Jan",
  average: 1890,
  floor: 4800
}, {
  name: "13 Jan",
  average: 2390,
  floor: 3800
}, {
  name: "14 Jan",
  average: 3490,
  floor: 4300
}, {
  name: "15 Jan",
  average: 4000,
  floor: 2400
}, {
  name: "16 Jan",
  average: 3000,
  floor: 1398
}, {
  name: "17 Jan",
  average: 2000,
  floor: 9800
}, {
  name: "18 Jan",
  average: 2780,
  floor: 3908
}, {
  name: "19 Jan",
  average: 1890,
  floor: 4800
}, {
  name: "20 Jan",
  average: 2390,
  floor: 3800
}, {
  name: "21 Jan",
  average: 3490,
  floor: 4300
}, {
  name: "22 Jan",
  average: 4000,
  floor: 2400
}, {
  name: "23 Jan",
  average: 3000,
  floor: 1398
}, {
  name: "24 Jan",
  average: 2000,
  floor: 9800
}, {
  name: "25 Jan",
  average: 2780,
  floor: 3908
}, {
  name: "26 Jan",
  average: 1890,
  floor: 4800
}, {
  name: "27 Jan",
  average: 2390,
  floor: 3800
}, {
  name: "28 Jan",
  average: 3490,
  floor: 4300
}];
const darkTheme = {
  backgroundColor: "#2e2c34",
  color: "#dddddd"
};

const getTooltipStyles = () => {
  const {
    backgroundColor,
    color
  } = darkTheme;
  return {
    contentStyle: {
      backgroundColor
    },
    itemStyle: {
      color
    }
  };
};

function LineChartx() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
    className: "py-12 text-white",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.ResponsiveContainer, {
      height: 350,
      className: "dashboard__area",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.AreaChart, {
        data: data,
        margin: {
          top: 20,
          left: -15,
          bottom: 20
        },
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("defs", {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("linearGradient", {
            id: "colorUv",
            x1: "0",
            y1: "0",
            x2: "0",
            y2: "1",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("stop", {
              offset: "5%",
              stopColor: "#8884d8",
              stopOpacity: 0.8
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 175,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("stop", {
              offset: "95%",
              stopColor: "#8884d8",
              stopOpacity: 0
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 176,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 174,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("linearGradient", {
            id: "colorPv",
            x1: "0",
            y1: "0",
            x2: "0",
            y2: "1",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("stop", {
              offset: "5%",
              stopColor: "#82ca9d",
              stopOpacity: 0.8
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 179,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("stop", {
              offset: "95%",
              stopColor: "#82ca9d",
              stopOpacity: 0
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 180,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 178,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 173,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.XAxis, {
          dataKey: "name",
          tickLine: false
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 183,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.YAxis, {
          tickLine: false
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 184,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.Tooltip, _objectSpread({}, getTooltipStyles()), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 185,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.Legend, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 186,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.CartesianGrid, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 187,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.Area, {
          name: "Floor",
          type: "monotone",
          dataKey: "floor",
          stroke: "#8884d8",
          fillOpacity: 1,
          fill: "url(#colorUv)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 188,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.Area, {
          name: "Average",
          type: "monotone",
          dataKey: "average",
          stroke: "#82ca9d",
          fillOpacity: 1,
          fill: "url(#colorPv)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 196,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 172,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 171,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 170,
    columnNumber: 5
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LineChartx);

/***/ }),

/***/ "./components/Dashboard/NotConnected.js":
/*!**********************************************!*\
  !*** ./components/Dashboard/NotConnected.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _solana_wallet_adapter_react_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @solana/wallet-adapter-react-ui */ "./node_modules/@solana/wallet-adapter-react-ui/lib/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\components\\Dashboard\\NotConnected.js";




function NotConnected() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
    className: "center p-6",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h1", {
        className: "text-3xl lg:text-5xl font-bold text-center py-6 ",
        children: ["Staking ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("span", {
          className: "text-brand_accent",
          children: "Project"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 9,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 8,
        columnNumber: 11
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
        className: "pb-4 text-2xl",
        children: "Log in with your web3 provider to continue"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 11
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
        className: "center",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_solana_wallet_adapter_react_ui__WEBPACK_IMPORTED_MODULE_1__.WalletMultiButton, {
          children: "Connect Wallet"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 9
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 7
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotConnected);

/***/ }),

/***/ "./components/Dashboard/StakingCard.js":
/*!*********************************************!*\
  !*** ./components/Dashboard/StakingCard.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recharts */ "recharts");
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(recharts__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\components\\Dashboard\\StakingCard.js";



const data01 = [{
  value: 50,
  fill: "#118f15"
}, {
  value: 50,
  fill: "#eeeeee"
}];
const data02 = [{
  value: 60,
  fill: "#ff4861"
}, {
  value: 40,
  fill: "#eeeeee"
}];

const StakingCard = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
    className: "w-full lg:w-6/12 lg:pl-3 relative mt-3 lg:m-0",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
      className: "bg-brand_accent p-6  lg:min-h-50vh rounded",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h5", {
        className: " pb-6 uppercase font-medium text-sm tracking-wider",
        children: "Staking"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
        className: "flex flex-wrap",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          className: "pb-6 lg:pb-0 chart-1 w-full md:w-6/12 p-2 text-center",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
            className: "center relative",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.PieChart, {
              height: 120,
              width: 120,
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.Pie, {
                data: data01,
                dataKey: "value",
                cx: 55,
                cy: 55,
                innerRadius: 55,
                outerRadius: 60
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 27,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 26,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 25,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
            className: "info pt-4 text-gray-100",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
              className: "text-3xl text-indigo-100",
              children: "0%"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 44,
              columnNumber: 15
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
              className: "text-gray-100",
              children: "My NFTs Staked"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 45,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          className: "chart-2 w-full md:w-6/12 p-2 text-center",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
            className: "center relative",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.PieChart, {
              height: 120,
              width: 120,
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(recharts__WEBPACK_IMPORTED_MODULE_1__.Pie, {
                data: data02,
                dataKey: "value",
                cx: 55,
                cy: 55,
                innerRadius: 55,
                outerRadius: 60
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 51,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 50,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 49,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
            className: "info pt-4 text-gray-100",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
              className: "text-3xl",
              style: {
                color: "#ff4861"
              },
              children: "60%"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 68,
              columnNumber: 15
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
              className: "text-gray-100",
              children: "Overall NFTs Staked"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 71,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 67,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 48,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
        className: "center",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          className: "text-center",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
            className: "uppercase text-white font-medium tracking-wider pt-6 text-xl",
            children: "0 Sol /Day"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 77,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
            className: "text-gray-100",
            children: "Rewards"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 80,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 76,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StakingCard);

/***/ }),

/***/ "./components/Dashboard/Stats.js":
/*!***************************************!*\
  !*** ./components/Dashboard/Stats.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\components\\Dashboard\\Stats.js";



function Stats() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
    className: "border border-brand_tertiary rounded shadow-2xl",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
      className: "flex flex-wrap stats rounded text-brand_black",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "w-full border-r border-brand_tertiary p-6 md:w-6/12 lg:w-3/12 ",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          className: "text-center text-white",
          children: "Average Value"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 8,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
          className: "center py-2",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("img", {
            width: 40,
            src: "/sol.png"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 10,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("span", {
            className: "pl-4 text-brand_tertiary text-2xl font-bold ",
            children: "236.28"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 11,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 9,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 7,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "w-full border-r border-brand_tertiary p-6 md:w-6/12 lg:w-3/12 ",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          className: "text-center text-white",
          children: "Floor Value"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 15,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
          className: "center py-2",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("img", {
            width: 40,
            src: "/sol.png"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 17,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("span", {
            className: "pl-4 text-brand_tertiary text-2xl font-bold ",
            children: "227.06"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 18,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "w-full border-r border-brand_tertiary p-6 md:w-6/12 lg:w-3/12 ",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          className: "text-center text-white",
          children: "NFTs in Vault"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 22,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
          className: "center py-2",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("span", {
            className: "pl-4 text-brand_tertiary text-2xl font-bold ",
            children: "81"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 24,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 23,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "w-full p-6 md:w-6/12 lg:w-3/12 ",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          className: "text-center text-white",
          children: "Launch Date"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
          className: "center py-2",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("span", {
            className: "pl-4 text-brand_tertiary text-2xl font-bold ",
            children: "Nov 21, 2021"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 30,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 5,
    columnNumber: 5
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Stats);

/***/ }),

/***/ "./components/Dashboard/TokenCard.js":
/*!*******************************************!*\
  !*** ./components/Dashboard/TokenCard.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "reactstrap");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\components\\Dashboard\\TokenCard.js";




function TokenCard() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
    className: "w-full lg:w-6/12 lg:pr-3 mb-3 lg:m-0",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
      className: "bg-brand_accent p-6  lg:h-50vh rounded",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h5", {
        className: " pb-6 uppercase font-medium text-sm tracking-wider",
        children: "Token Balance"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 11,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
        className: "text-center text-white text-sm pb-1 tracking-wider",
        children: "Total"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
        className: "text-center text-3xl lg:text-5xl text-green-300",
        children: "15.00"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
        className: "py-16 lg:py-16",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          className: "",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Progress, {
            color: "success",
            className: "bg-green-500",
            value: "50",
            children: "50%"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 20,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          className: "flex justify-evenly py-2 text-center",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
              className: "text-white text-xl",
              children: "5.00"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 26,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
              className: "text-sm  text-green-300 pt-1",
              children: "Wallet"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 27,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 25,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
              className: "text-brand_white text-xl",
              children: "10.00"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 30,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
              className: "text-sm pt-1 text-white",
              children: "Unclaimed"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 31,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 29,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, this);
}

;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TokenCard);

/***/ }),

/***/ "./components/Dashboard/index.js":
/*!***************************************!*\
  !*** ./components/Dashboard/index.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _NotConnected__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NotConnected */ "./components/Dashboard/NotConnected.js");
/* harmony import */ var _TokenCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TokenCard */ "./components/Dashboard/TokenCard.js");
/* harmony import */ var _StakingCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./StakingCard */ "./components/Dashboard/StakingCard.js");
/* harmony import */ var _Stats__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Stats */ "./components/Dashboard/Stats.js");
/* harmony import */ var _LineChart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./LineChart */ "./components/Dashboard/LineChart.js");
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Navbar */ "./components/Navbar/index.js");
/* harmony import */ var _NFTCarousel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../NFTCarousel */ "./components/NFTCarousel.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\components\\Dashboard\\index.js";











function Dashboard(props) {
  const {
    publicKey,
    sendTransaction
  } = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_9__.useWallet)();

  if (!publicKey) {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_NotConnected__WEBPACK_IMPORTED_MODULE_1__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 13
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 11
    }, this);
  } else {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("section", {
      className: "text-black",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_Navbar__WEBPACK_IMPORTED_MODULE_6__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 13
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
        className: "mt-6 bg-brand_accent rounded my-6 p-6",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("h5", {
          className: " pb-6 uppercase font-medium text-sm tracking-wider",
          children: "My NFTs"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 15
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_NFTCarousel__WEBPACK_IMPORTED_MODULE_7__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 15
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 13
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
        className: "item-center flex justify-between flex-wrap my-6",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_TokenCard__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 15
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_StakingCard__WEBPACK_IMPORTED_MODULE_3__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 33,
          columnNumber: 15
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 13
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
        className: "mt-6 bg-brand_accent rounded my-6 p-6",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("h5", {
          className: " pb-6 uppercase font-medium text-sm tracking-wider",
          children: "Community Vault"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 15
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_Stats__WEBPACK_IMPORTED_MODULE_4__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 15
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_LineChart__WEBPACK_IMPORTED_MODULE_5__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 15
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 13
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 11
    }, this);
  }
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dashboard);

/***/ }),

/***/ "./components/NFT.js":
/*!***************************!*\
  !*** ./components/NFT.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\components\\NFT.js";



function NFT(props) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
    className: "w-full p-4 bg-red-500  md:w-3/12 lg:w-1/3",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
      className: "bg-gray-200",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "center",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("img", {
          src: props.img
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 8,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 7,
        columnNumber: 11
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "p-3",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h5", {
          className: "text-md font-bold",
          children: props.name
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 11,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 9
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 5,
    columnNumber: 7
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NFT);

/***/ }),

/***/ "./components/NFTCarousel.js":
/*!***********************************!*\
  !*** ./components/NFTCarousel.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _NFT__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NFT */ "./components/NFT.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-slick */ "react-slick");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\components\\NFTCarousel.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







function NFTCarousel() {
  const {
    user,
    wallet_id,
    nft_list
  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)(state => ({
    wallet_id: state.app_reducer.wallet_id,
    nft_list: state.app_reducer.nft_list
  }));
  const settings = {
    dots: true,
    infinite: false,
    speed: 500,
    autoplay: true,
    swipeToSlide: true,
    slidesToScroll: 1,
    responsive: [{
      breakpoint: 768,
      settings: {
        slidesToShow: 1
      }
    }, {
      breakpoint: 992,
      settings: {
        slidesToShow: 2
      }
    }, {
      breakpoint: 1200,
      settings: {
        slidesToShow: 3
      }
    }, {
      breakpoint: 100000,
      settings: {
        slidesToShow: 4
      }
    }]
  };
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
    className: "",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), _objectSpread(_objectSpread({}, settings), {}, {
      children: nft_list === null || nft_list === void 0 ? void 0 : nft_list.map(item => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "p-6",
        style: {
          width: 200
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
          className: "",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
            className: "center",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("img", {
              src: item.image,
              alt: "NFT"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 32,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 31,
            columnNumber: 15
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
            className: "py-3 bg-brand_black px-2",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h5", {
              className: "text-md font-bold",
              children: item.name
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 35,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 34,
            columnNumber: 15
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 13
        }, this)
      }, item.image, false, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 11
      }, this))
    }), void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 26,
    columnNumber: 5
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NFTCarousel);

/***/ }),

/***/ "./components/Navbar/index.js":
/*!************************************!*\
  !*** ./components/Navbar/index.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _solana_wallet_adapter_react_ui__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @solana/wallet-adapter-react-ui */ "./node_modules/@solana/wallet-adapter-react-ui/lib/index.js");
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var _ConnectToWallet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../ConnectToWallet */ "./components/ConnectToWallet.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\components\\Navbar\\index.js";







function Navbar(props) {
  const {
    publicKey,
    sendTransaction
  } = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_5__.useWallet)();
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("nav", {
    className: "text-brand_white pb-3 mb-3 w-full flex flex-wrap justify-between border-b border-brand_accent",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_ConnectToWallet__WEBPACK_IMPORTED_MODULE_3__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("ul", {
      className: "flex items-center w-full w-full md:w-8/12 justify-center md:justify-start",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("li", {
        className: "md:mr-4 cursor-pointer p-3 font-bold uppercase ",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/dashboard",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
            children: "Dashboard"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 14,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("li", {
        className: "md:mr-4 cursor-pointer p-3 font-bold uppercase ",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/staking",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
            children: "Staking"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 19,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 18,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, this), publicKey && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("li", {
      className: "pl-4 py-1 font-bold uppercase w-full md:w-4/12 flex justify-center md:justify-end my-3 md:m-0",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_solana_wallet_adapter_react_ui__WEBPACK_IMPORTED_MODULE_2__.WalletMultiButton, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 9
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);

/***/ }),

/***/ "./hooks/useWalletNFTs.ts":
/*!********************************!*\
  !*** ./hooks/useWalletNFTs.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _project_serum_anchor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @project-serum/anchor */ "@project-serum/anchor");
/* harmony import */ var _project_serum_anchor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_project_serum_anchor__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_candyMachine__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/candyMachine */ "./utils/candyMachine.ts");




const rpcHost = "https://api.devnet.solana.com";
const connection = new _project_serum_anchor__WEBPACK_IMPORTED_MODULE_1__.web3.Connection(rpcHost);

const useWalletNfts = props => {
  const wallet = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_3__.useWallet)();
  const {
    0: isLoading,
    1: setIsLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: isSPLExists,
    1: setSPLExists
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: nfts,
    1: setNfts
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    (async () => {
      if (!wallet || !wallet.publicKey || !wallet.signAllTransactions || !wallet.signTransaction) {
        return;
      }

      setIsLoading(true);
      const isExistSPLToken = await (0,_utils_candyMachine__WEBPACK_IMPORTED_MODULE_2__.existsOwnerSPLToken)(connection, wallet.publicKey);
      console.log("isSPLExists " + isSPLExists);
      setSPLExists(isExistSPLToken);
      const nftsForOwner = await (0,_utils_candyMachine__WEBPACK_IMPORTED_MODULE_2__.getNFTsForOwner)(connection, wallet.publicKey);
      setNfts(nftsForOwner); // console.log(nftsForOwner);

      setIsLoading(false);
    })();
  }, [wallet]);
  return [isLoading, nfts, isSPLExists];
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useWalletNfts);

/***/ }),

/***/ "./node_modules/next/dist/client/link.js":
/*!***********************************************!*\
  !*** ./node_modules/next/dist/client/link.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ../shared/lib/router/router */ "./node_modules/next/dist/shared/lib/router/router.js");

var _router1 = __webpack_require__(/*! ./router */ "./node_modules/next/dist/client/router.js");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "./node_modules/next/dist/client/use-intersection.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

const prefetched = {};

function prefetch(router, href, as, options) {
  if (true) return;
  if (!(0, _router).isLocalURL(href)) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (true) {
      // rethrow to show invalid URL errors
      throw err;
    }
  });
  const curLocale = options && typeof options.locale !== 'undefined' ? options.locale : router && router.locale; // Join on an invalid URI character

  prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')] = true;
}

function isModifiedEvent(event) {
  const {
    target
  } = event.currentTarget;
  return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.nativeEvent && event.nativeEvent.which === 2;
}

function linkClicked(e, router, href, as, replace, shallow, scroll, locale) {
  const {
    nodeName
  } = e.currentTarget;

  if (nodeName === 'A' && (isModifiedEvent(e) || !(0, _router).isLocalURL(href))) {
    // ignore click for browser’s default behavior
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null && as.indexOf('#') >= 0) {
    scroll = false;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow,
    locale,
    scroll
  });
}

function Link(props) {
  if (true) {
    function createPropError(args) {
      return new Error(`Failed prop type: The prop \`${args.key}\` expects a ${args.expected} in \`<Link>\`, but got \`${args.actual}\` instead.` + ( false ? 0 : ''));
    } // TypeScript trick for type-guarding:


    const requiredPropsGuard = {
      href: true
    };
    const requiredProps = Object.keys(requiredPropsGuard);
    requiredProps.forEach(key => {
      if (key === 'href') {
        if (props[key] == null || typeof props[key] !== 'string' && typeof props[key] !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: props[key] === null ? 'null' : typeof props[key]
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // TypeScript trick for type-guarding:

    const optionalPropsGuard = {
      as: true,
      replace: true,
      scroll: true,
      shallow: true,
      passHref: true,
      prefetch: true,
      locale: true
    };
    const optionalProps = Object.keys(optionalPropsGuard);
    optionalProps.forEach(key => {
      const valType = typeof props[key];

      if (key === 'as') {
        if (props[key] && valType !== 'string' && valType !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: valType
          });
        }
      } else if (key === 'locale') {
        if (props[key] && valType !== 'string') {
          throw createPropError({
            key,
            expected: '`string`',
            actual: valType
          });
        }
      } else if (key === 'replace' || key === 'scroll' || key === 'shallow' || key === 'passHref' || key === 'prefetch') {
        if (props[key] != null && valType !== 'boolean') {
          throw createPropError({
            key,
            expected: '`boolean`',
            actual: valType
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // This hook is in a conditional but that is ok because `process.env.NODE_ENV` never changes
    // eslint-disable-next-line react-hooks/rules-of-hooks

    const hasWarned = _react.default.useRef(false);

    if (props.prefetch && !hasWarned.current) {
      hasWarned.current = true;
      console.warn('Next.js auto-prefetches automatically based on viewport. The prefetch attribute is no longer needed. More: https://nextjs.org/docs/messages/prefetch-true-deprecated');
    }
  }

  const p = props.prefetch !== false;
  const router = (0, _router1).useRouter();

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const [resolvedHref, resolvedAs] = (0, _router).resolveHref(router, props.href, true);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router).resolveHref(router, props.as) : resolvedAs || resolvedHref
    };
  }, [router, props.href, props.as]);

  let {
    children,
    replace,
    shallow,
    scroll,
    locale
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  let child;

  if (true) {
    try {
      child = _react.default.Children.only(children);
    } catch (err) {
      throw new Error(`Multiple children were passed to <Link> with \`href\` of \`${props.href}\` but only one child is supported https://nextjs.org/docs/messages/link-multiple-children` + ( false ? 0 : ''));
    }
  } else {}

  const childRef = child && typeof child === 'object' && child.ref;
  const [setIntersectionRef, isVisible] = (0, _useIntersection).useIntersection({
    rootMargin: '200px'
  });

  const setRef = _react.default.useCallback(el => {
    setIntersectionRef(el);

    if (childRef) {
      if (typeof childRef === 'function') childRef(el);else if (typeof childRef === 'object') {
        childRef.current = el;
      }
    }
  }, [childRef, setIntersectionRef]);

  _react.default.useEffect(() => {
    const shouldPrefetch = isVisible && p && (0, _router).isLocalURL(href);
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale;
    const isPrefetched = prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')];

    if (shouldPrefetch && !isPrefetched) {
      prefetch(router, href, as, {
        locale: curLocale
      });
    }
  }, [as, href, isVisible, locale, p, router]);

  const childProps = {
    ref: setRef,
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll, locale);
      }
    }
  };

  childProps.onMouseEnter = e => {
    if (!(0, _router).isLocalURL(href)) return;

    if (child.props && typeof child.props.onMouseEnter === 'function') {
      child.props.onMouseEnter(e);
    }

    prefetch(router, href, as, {
      priority: true
    });
  }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale; // we only render domain locales if we are currently on a domain locale
    // so that locale links are still visitable in development/preview envs

    const localeDomain = router && router.isLocaleDomain && (0, _router).getDomainLocale(as, curLocale, router && router.locales, router && router.domainLocales);
    childProps.href = localeDomain || (0, _router).addBasePath((0, _router).addLocale(as, curLocale, router && router.defaultLocale));
  }

  return /*#__PURE__*/_react.default.cloneElement(child, childProps);
}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "./node_modules/next/dist/client/normalize-trailing-slash.js":
/*!*******************************************************************!*\
  !*** ./node_modules/next/dist/client/normalize-trailing-slash.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}

const normalizePathTrailingSlash =  false ? 0 : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "./node_modules/next/dist/client/request-idle-callback.js":
/*!****************************************************************!*\
  !*** ./node_modules/next/dist/client/request-idle-callback.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.requestIdleCallback = exports.cancelIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback && self.requestIdleCallback.bind(window) || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback && self.cancelIdleCallback.bind(window) || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "./node_modules/next/dist/client/route-loader.js":
/*!*******************************************************!*\
  !*** ./node_modules/next/dist/client/route-loader.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.markAssetError = markAssetError;
exports.isAssetError = isAssetError;
exports.getClientBuildManifest = getClientBuildManifest;
exports.createRouteLoader = createRouteLoader;

var _getAssetPathFromRoute = _interopRequireDefault(__webpack_require__(/*! ../shared/lib/router/utils/get-asset-path-from-route */ "../shared/lib/router/utils/get-asset-path-from-route"));

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
} // 3.8s was arbitrarily chosen as it's what https://web.dev/interactive
// considers as "Good" time-to-interactive. We must assume something went
// wrong beyond this point, and then fall-back to a full page transition to
// show the user something of value.


const MS_MAX_IDLE_DELAY = 3800;

function withFuture(key, map, generator) {
  let entry = map.get(key);

  if (entry) {
    if ('future' in entry) {
      return entry.future;
    }

    return Promise.resolve(entry);
  }

  let resolver;
  const prom = new Promise(resolve => {
    resolver = resolve;
  });
  map.set(key, entry = {
    resolve: resolver,
    future: prom
  });
  return generator ? generator().then(value => (resolver(value), value)) : prom;
}

function hasPrefetch(link) {
  try {
    link = document.createElement('link');
    return (// detect IE11 since it supports prefetch but isn't detected
      // with relList.support
      !!window.MSInputMethodContext && !!document.documentMode || link.relList.supports('prefetch')
    );
  } catch (e) {
    return false;
  }
}

const canPrefetch = hasPrefetch();

function prefetchViaDom(href, as, link) {
  return new Promise((res, rej) => {
    if (document.querySelector(`link[rel="prefetch"][href^="${href}"]`)) {
      return res();
    }

    link = document.createElement('link'); // The order of property assignment here is intentional:

    if (as) link.as = as;
    link.rel = `prefetch`;
    link.crossOrigin = undefined;
    link.onload = res;
    link.onerror = rej; // `href` should always be last:

    link.href = href;
    document.head.appendChild(link);
  });
}

const ASSET_LOAD_ERROR = Symbol('ASSET_LOAD_ERROR');

function markAssetError(err) {
  return Object.defineProperty(err, ASSET_LOAD_ERROR, {});
}

function isAssetError(err) {
  return err && ASSET_LOAD_ERROR in err;
}

function appendScript(src, script) {
  return new Promise((resolve, reject) => {
    script = document.createElement('script'); // The order of property assignment here is intentional.
    // 1. Setup success/failure hooks in case the browser synchronously
    //    executes when `src` is set.

    script.onload = resolve;

    script.onerror = () => reject(markAssetError(new Error(`Failed to load script: ${src}`))); // 2. Configure the cross-origin attribute before setting `src` in case the
    //    browser begins to fetch.


    script.crossOrigin = undefined; // 3. Finally, set the source and inject into the DOM in case the child
    //    must be appended for fetching to start.

    script.src = src;
    document.body.appendChild(script);
  });
} // We wait for pages to be built in dev before we start the route transition
// timeout to prevent an un-necessary hard navigation in development.


let devBuildPromise; // Resolve a promise that times out after given amount of milliseconds.

function resolvePromiseWithTimeout(p, ms, err) {
  return new Promise((resolve, reject) => {
    let cancelled = false;
    p.then(r => {
      // Resolved, cancel the timeout
      cancelled = true;
      resolve(r);
    }).catch(reject); // We wrap these checks separately for better dead-code elimination in
    // production bundles.

    if (true) {
      (devBuildPromise || Promise.resolve()).then(() => {
        (0, _requestIdleCallback).requestIdleCallback(() => setTimeout(() => {
          if (!cancelled) {
            reject(err);
          }
        }, ms));
      });
    }

    if (false) {}
  });
}

function getClientBuildManifest() {
  if (self.__BUILD_MANIFEST) {
    return Promise.resolve(self.__BUILD_MANIFEST);
  }

  const onBuildManifest = new Promise(resolve => {
    // Mandatory because this is not concurrent safe:
    const cb = self.__BUILD_MANIFEST_CB;

    self.__BUILD_MANIFEST_CB = () => {
      resolve(self.__BUILD_MANIFEST);
      cb && cb();
    };
  });
  return resolvePromiseWithTimeout(onBuildManifest, MS_MAX_IDLE_DELAY, markAssetError(new Error('Failed to load client build manifest')));
}

function getFilesForRoute(assetPrefix, route) {
  if (true) {
    return Promise.resolve({
      scripts: [assetPrefix + '/_next/static/chunks/pages' + encodeURI((0, _getAssetPathFromRoute).default(route, '.js'))],
      // Styles are handled by `style-loader` in development:
      css: []
    });
  }

  return getClientBuildManifest().then(manifest => {
    if (!(route in manifest)) {
      throw markAssetError(new Error(`Failed to lookup route: ${route}`));
    }

    const allFiles = manifest[route].map(entry => assetPrefix + '/_next/' + encodeURI(entry));
    return {
      scripts: allFiles.filter(v => v.endsWith('.js')),
      css: allFiles.filter(v => v.endsWith('.css'))
    };
  });
}

function createRouteLoader(assetPrefix) {
  const entrypoints = new Map();
  const loadedScripts = new Map();
  const styleSheets = new Map();
  const routes = new Map();

  function maybeExecuteScript(src) {
    let prom = loadedScripts.get(src);

    if (prom) {
      return prom;
    } // Skip executing script if it's already in the DOM:


    if (document.querySelector(`script[src^="${src}"]`)) {
      return Promise.resolve();
    }

    loadedScripts.set(src, prom = appendScript(src));
    return prom;
  }

  function fetchStyleSheet(href) {
    let prom = styleSheets.get(href);

    if (prom) {
      return prom;
    }

    styleSheets.set(href, prom = fetch(href).then(res => {
      if (!res.ok) {
        throw new Error(`Failed to load stylesheet: ${href}`);
      }

      return res.text().then(text => ({
        href: href,
        content: text
      }));
    }).catch(err => {
      throw markAssetError(err);
    }));
    return prom;
  }

  return {
    whenEntrypoint(route) {
      return withFuture(route, entrypoints);
    },

    onEntrypoint(route, execute) {
      Promise.resolve(execute).then(fn => fn()).then(exports => ({
        component: exports && exports.default || exports,
        exports: exports
      }), err => ({
        error: err
      })).then(input => {
        const old = entrypoints.get(route);
        entrypoints.set(route, input);
        if (old && 'resolve' in old) old.resolve(input);
      });
    },

    loadRoute(route, prefetch) {
      return withFuture(route, routes, () => {
        const routeFilesPromise = getFilesForRoute(assetPrefix, route).then(({
          scripts,
          css
        }) => {
          return Promise.all([entrypoints.has(route) ? [] : Promise.all(scripts.map(maybeExecuteScript)), Promise.all(css.map(fetchStyleSheet))]);
        }).then(res => {
          return this.whenEntrypoint(route).then(entrypoint => ({
            entrypoint,
            styles: res[1]
          }));
        });

        if (true) {
          devBuildPromise = new Promise(resolve => {
            if (routeFilesPromise) {
              return routeFilesPromise.finally(() => {
                resolve();
              });
            }
          });
        }

        return resolvePromiseWithTimeout(routeFilesPromise, MS_MAX_IDLE_DELAY, markAssetError(new Error(`Route did not complete loading: ${route}`))).then(({
          entrypoint,
          styles
        }) => {
          const res = Object.assign({
            styles: styles
          }, entrypoint);
          return 'error' in entrypoint ? entrypoint : res;
        }).catch(err => {
          if (prefetch) {
            // we don't want to cache errors during prefetch
            throw err;
          }

          return {
            error: err
          };
        });
      });
    },

    prefetch(route) {
      // https://github.com/GoogleChromeLabs/quicklink/blob/453a661fa1fa940e2d2e044452398e38c67a98fb/src/index.mjs#L115-L118
      // License: Apache 2.0
      let cn;

      if (cn = navigator.connection) {
        // Don't prefetch if using 2G or if Save-Data is enabled.
        if (cn.saveData || /2g/.test(cn.effectiveType)) return Promise.resolve();
      }

      return getFilesForRoute(assetPrefix, route).then(output => Promise.all(canPrefetch ? output.scripts.map(script => prefetchViaDom(script, 'script')) : [])).then(() => {
        (0, _requestIdleCallback).requestIdleCallback(() => this.loadRoute(route, true).catch(() => {}));
      }).catch( // swallow prefetch errors
      () => {});
    }

  };
}

/***/ }),

/***/ "./node_modules/next/dist/client/router.js":
/*!*************************************************!*\
  !*** ./node_modules/next/dist/client/router.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
Object.defineProperty(exports, "Router", ({
  enumerable: true,
  get: function () {
    return _router.default;
  }
}));
Object.defineProperty(exports, "withRouter", ({
  enumerable: true,
  get: function () {
    return _withRouter.default;
  }
}));
exports.useRouter = useRouter;
exports.createRouter = createRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = _interopRequireDefault(__webpack_require__(/*! ../shared/lib/router/router */ "./node_modules/next/dist/shared/lib/router/router.js"));

var _routerContext = __webpack_require__(/*! ../shared/lib/router-context */ "../shared/lib/router-context");

var _withRouter = _interopRequireDefault(__webpack_require__(/*! ./with-router */ "./node_modules/next/dist/client/with-router.js"));

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

const singletonRouter = {
  router: null,
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath', 'locale', 'locales', 'defaultLocale', 'isReady', 'isPreview', 'isLocaleDomain', 'domainLocales'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          console.error(`Error when running the Router event: ${eventField}`);
          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" on the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
}

var _default = singletonRouter;
exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
}

function createRouter(...args) {
  singletonRouter.router = new _router.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}

function makePublicRouterInstance(router) {
  const _router1 = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router1[property] === 'object') {
      instance[property] = Object.assign(Array.isArray(_router1[property]) ? [] : {}, _router1[property]) // makes sure query is not stateful
      ;
      continue;
    }

    instance[property] = _router1[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router1[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/dist/client/use-intersection.js":
/*!***********************************************************!*\
  !*** ./node_modules/next/dist/client/use-intersection.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.useIntersection = useIntersection;

var _react = __webpack_require__(/*! react */ "react");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react).useRef();
  const [visible, setVisible] = (0, _react).useState(false);
  const setRef = (0, _react).useCallback(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react).useEffect(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback).requestIdleCallback(() => setVisible(true));
        return () => (0, _requestIdleCallback).cancelIdleCallback(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/dist/client/with-router.js":
/*!******************************************************!*\
  !*** ./node_modules/next/dist/client/with-router.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ./router */ "./node_modules/next/dist/client/router.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router).useRouter()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (true) {
    const name = ComposedComponent.displayName || ComposedComponent.name || 'Unknown';
    WithRouterWrapper.displayName = `withRouter(${name})`;
  }

  return WithRouterWrapper;
}

/***/ }),

/***/ "./node_modules/next/dist/shared/lib/router/router.js":
/*!************************************************************!*\
  !*** ./node_modules/next/dist/shared/lib/router/router.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.getDomainLocale = getDomainLocale;
exports.addLocale = addLocale;
exports.delLocale = delLocale;
exports.hasBasePath = hasBasePath;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.isLocalURL = isLocalURL;
exports.interpolateAs = interpolateAs;
exports.resolveHref = resolveHref;
exports.default = void 0;

var _normalizeTrailingSlash = __webpack_require__(/*! ../../../client/normalize-trailing-slash */ "./node_modules/next/dist/client/normalize-trailing-slash.js");

var _routeLoader = __webpack_require__(/*! ../../../client/route-loader */ "./node_modules/next/dist/client/route-loader.js");

var _denormalizePagePath = __webpack_require__(/*! ../../../server/denormalize-page-path */ "../../../server/denormalize-page-path");

var _normalizeLocalePath = __webpack_require__(/*! ../i18n/normalize-locale-path */ "../i18n/normalize-locale-path");

var _mitt = _interopRequireDefault(__webpack_require__(/*! ../mitt */ "../mitt"));

var _utils = __webpack_require__(/*! ../utils */ "../shared/lib/utils");

var _isDynamic = __webpack_require__(/*! ./utils/is-dynamic */ "./utils/is-dynamic");

var _parseRelativeUrl = __webpack_require__(/*! ./utils/parse-relative-url */ "./utils/parse-relative-url");

var _querystring = __webpack_require__(/*! ./utils/querystring */ "./utils/querystring");

var _resolveRewrites = _interopRequireDefault(__webpack_require__(/*! ./utils/resolve-rewrites */ "?5c99"));

var _routeMatcher = __webpack_require__(/*! ./utils/route-matcher */ "./utils/route-matcher");

var _routeRegex = __webpack_require__(/*! ./utils/route-regex */ "./utils/route-regex");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

let detectDomainLocale;

if (false) {}

const basePath =  false || '';

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addPathPrefix(path, prefix) {
  return prefix && path.startsWith('/') ? path === '/' ? (0, _normalizeTrailingSlash).normalizePathTrailingSlash(prefix) : `${prefix}${pathNoQueryHash(path) === '/' ? path.substring(1) : path}` : path;
}

function getDomainLocale(path, locale, locales, domainLocales) {
  if (false) {} else {
    return false;
  }
}

function addLocale(path, locale, defaultLocale) {
  if (false) {}

  return path;
}

function delLocale(path, locale) {
  if (false) {}

  return path;
}

function pathNoQueryHash(path) {
  const queryIndex = path.indexOf('?');
  const hashIndex = path.indexOf('#');

  if (queryIndex > -1 || hashIndex > -1) {
    path = path.substring(0, queryIndex > -1 ? queryIndex : hashIndex);
  }

  return path;
}

function hasBasePath(path) {
  path = pathNoQueryHash(path);
  return path === basePath || path.startsWith(basePath + '/');
}

function addBasePath(path) {
  // we only add the basepath on relative urls
  return addPathPrefix(path, basePath);
}

function delBasePath(path) {
  path = path.slice(basePath.length);
  if (!path.startsWith('/')) path = `/${path}`;
  return path;
}

function isLocalURL(url) {
  // prevent a hydration mismatch on href for url with anchor refs
  if (url.startsWith('/') || url.startsWith('#') || url.startsWith('?')) return true;

  try {
    // absolute urls can be local if they are on the same origin
    const locationOrigin = (0, _utils).getLocationOrigin();
    const resolved = new URL(url, locationOrigin);
    return resolved.origin === locationOrigin && hasBasePath(resolved.pathname);
  } catch (_) {
    return false;
  }
}

function interpolateAs(route, asPathname, query) {
  let interpolatedRoute = '';
  const dynamicRegex = (0, _routeRegex).getRouteRegex(route);
  const dynamicGroups = dynamicRegex.groups;
  const dynamicMatches = // Try to match the dynamic route against the asPath
  (asPathname !== route ? (0, _routeMatcher).getRouteMatcher(dynamicRegex)(asPathname) : '') || // Fall back to reading the values from the href
  // TODO: should this take priority; also need to change in the router.
  query;
  interpolatedRoute = route;
  const params = Object.keys(dynamicGroups);

  if (!params.every(param => {
    let value = dynamicMatches[param] || '';
    const {
      repeat,
      optional
    } = dynamicGroups[param]; // support single-level catch-all
    // TODO: more robust handling for user-error (passing `/`)

    let replaced = `[${repeat ? '...' : ''}${param}]`;

    if (optional) {
      replaced = `${!value ? '/' : ''}[${replaced}]`;
    }

    if (repeat && !Array.isArray(value)) value = [value];
    return (optional || param in dynamicMatches) && (interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map( // these values should be fully encoded instead of just
    // path delimiter escaped since they are being inserted
    // into the URL and we expect URL encoded segments
    // when parsing dynamic route params
    segment => encodeURIComponent(segment)).join('/') : encodeURIComponent(value)) || '/');
  })) {
    interpolatedRoute = '' // did not satisfy all requirements
    ; // n.b. We ignore this error because we handle warning for this case in
    // development in the `<Link>` component directly.
  }

  return {
    params,
    result: interpolatedRoute
  };
}

function omitParmsFromQuery(query, params) {
  const filteredQuery = {};
  Object.keys(query).forEach(key => {
    if (!params.includes(key)) {
      filteredQuery[key] = query[key];
    }
  });
  return filteredQuery;
}

function resolveHref(router, href, resolveAs) {
  // we use a dummy base url for relative urls
  let base;
  let urlAsString = typeof href === 'string' ? href : (0, _utils).formatWithValidation(href); // repeated slashes and backslashes in the URL are considered
  // invalid and will never match a Next.js page/file

  const urlProtoMatch = urlAsString.match(/^[a-zA-Z]{1,}:\/\//);
  const urlAsStringNoProto = urlProtoMatch ? urlAsString.substr(urlProtoMatch[0].length) : urlAsString;
  const urlParts = urlAsStringNoProto.split('?');

  if ((urlParts[0] || '').match(/(\/\/|\\)/)) {
    console.error(`Invalid href passed to next/router: ${urlAsString}, repeated forward-slashes (//) or backslashes \\ are not valid in the href`);
    const normalizedUrl = (0, _utils).normalizeRepeatedSlashes(urlAsStringNoProto);
    urlAsString = (urlProtoMatch ? urlProtoMatch[0] : '') + normalizedUrl;
  } // Return because it cannot be routed by the Next.js router


  if (!isLocalURL(urlAsString)) {
    return resolveAs ? [urlAsString] : urlAsString;
  }

  try {
    base = new URL(urlAsString.startsWith('#') ? router.asPath : router.pathname, 'http://n');
  } catch (_) {
    // fallback to / for invalid asPath values e.g. //
    base = new URL('/', 'http://n');
  }

  try {
    const finalUrl = new URL(urlAsString, base);
    finalUrl.pathname = (0, _normalizeTrailingSlash).normalizePathTrailingSlash(finalUrl.pathname);
    let interpolatedAs = '';

    if ((0, _isDynamic).isDynamicRoute(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
      const query = (0, _querystring).searchParamsToUrlQuery(finalUrl.searchParams);
      const {
        result,
        params
      } = interpolateAs(finalUrl.pathname, finalUrl.pathname, query);

      if (result) {
        interpolatedAs = (0, _utils).formatWithValidation({
          pathname: result,
          hash: finalUrl.hash,
          query: omitParmsFromQuery(query, params)
        });
      }
    } // if the origin didn't change, it means we received a relative href


    const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
    return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
  } catch (_) {
    return resolveAs ? [urlAsString] : urlAsString;
  }
}

function stripOrigin(url) {
  const origin = (0, _utils).getLocationOrigin();
  return url.startsWith(origin) ? url.substring(origin.length) : url;
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  let [resolvedHref, resolvedAs] = resolveHref(router, url, true);
  const origin = (0, _utils).getLocationOrigin();
  const hrefHadOrigin = resolvedHref.startsWith(origin);
  const asHadOrigin = resolvedAs && resolvedAs.startsWith(origin);
  resolvedHref = stripOrigin(resolvedHref);
  resolvedAs = resolvedAs ? stripOrigin(resolvedAs) : resolvedAs;
  const preparedUrl = hrefHadOrigin ? resolvedHref : addBasePath(resolvedHref);
  const preparedAs = as ? stripOrigin(resolveHref(router, as)) : resolvedAs || resolvedHref;
  return {
    url: preparedUrl,
    as: asHadOrigin ? preparedAs : addBasePath(preparedAs)
  };
}

function resolveDynamicRoute(pathname, pages) {
  const cleanPathname = (0, _normalizeTrailingSlash).removePathTrailingSlash((0, _denormalizePagePath).denormalizePagePath(pathname));

  if (cleanPathname === '/404' || cleanPathname === '/_error') {
    return pathname;
  } // handle resolving href for dynamic routes


  if (!pages.includes(cleanPathname)) {
    // eslint-disable-next-line array-callback-return
    pages.some(page => {
      if ((0, _isDynamic).isDynamicRoute(page) && (0, _routeRegex).getRouteRegex(page).re.test(cleanPathname)) {
        pathname = page;
        return true;
      }
    });
  }

  return (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname);
}

const manualScrollRestoration =  false && 0;
const SSG_DATA_NOT_FOUND = Symbol('SSG_DATA_NOT_FOUND');

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      if (res.status === 404) {
        return res.json().then(data => {
          if (data.notFound) {
            return {
              notFound: SSG_DATA_NOT_FOUND
            };
          }

          throw new Error(`Failed to load static props`);
        });
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      (0, _routeLoader).markAssetError(err);
    }

    throw err;
  });
}

class Router {
  constructor(pathname1, query1, as1, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component: Component1,
    err: err1,
    subscription,
    isFallback,
    locale,
    locales,
    defaultLocale,
    domainLocales,
    isPreview
  }) {
    // Static Data Cache
    this.sdc = {}; // In-flight Server Data Requests, for deduping

    this.sdr = {};
    this._idx = 0;

    this.onPopState = e => {
      const state = e.state;

      if (!state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname: pathname1,
          query: query1
        } = this;
        this.changeState('replaceState', (0, _utils).formatWithValidation({
          pathname: addBasePath(pathname1),
          query: query1
        }), (0, _utils).getURL());
        return;
      }

      if (!state.__N) {
        return;
      }

      let forcedScroll;
      const {
        url,
        as: as1,
        options,
        idx
      } = state;

      if (false) {}

      this._idx = idx;
      const {
        pathname: pathname1
      } = (0, _parseRelativeUrl).parseRelativeUrl(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as1 === this.asPath && pathname1 === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(state)) {
        return;
      }

      this.change('replaceState', url, as1, Object.assign({}, options, {
        shallow: options.shallow && this._shallow,
        locale: options.locale || this.defaultLocale
      }), forcedScroll);
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname1); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (pathname1 !== '/_error') {
      this.components[this.route] = {
        Component: Component1,
        initial: true,
        props: initialProps,
        err: err1,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App,
      styleSheets: []
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = pathname1;
    this.query = query1; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    const autoExportDynamic = (0, _isDynamic).isDynamicRoute(pathname1) && self.__NEXT_DATA__.autoExport;

    this.asPath = autoExportDynamic ? pathname1 : as1;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;
    this.isReady = !!(self.__NEXT_DATA__.gssp || self.__NEXT_DATA__.gip || self.__NEXT_DATA__.appGip && !self.__NEXT_DATA__.gsp || !autoExportDynamic && !self.location.search && !false);
    this.isPreview = !!isPreview;
    this.isLocaleDomain = false;

    if (false) {}

    if (false) {}
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as, options = {}) {
    if (false) {}

    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as, options = {}) {
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options, forcedScroll) {
    if (!isLocalURL(url)) {
      window.location.href = url;
      return false;
    }

    const shouldResolveHref = url === as || options._h || options._shouldResolveHref; // for static pages with query params in the URL we delay
    // marking the router ready until after the query is updated

    if (options._h) {
      this.isReady = true;
    }

    const prevLocale = this.locale;

    if (false) { var ref; }

    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    }

    const {
      shallow = false
    } = options;
    const routeProps = {
      shallow
    };

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute, routeProps);
    }

    as = addBasePath(addLocale(hasBasePath(as) ? delBasePath(as) : as, options.locale, this.defaultLocale));
    const cleanedAs = delLocale(hasBasePath(as) ? delBasePath(as) : as, this.locale);
    this._inFlightRoute = as;
    let localeChange = prevLocale !== this.locale; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs) && !localeChange) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as, routeProps); // TODO: do we need the resolved href when only a hash change?

      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      this.notify(this.components[this.route], null);
      Router.events.emit('hashChangeComplete', as, routeProps);
      return true;
    }

    let parsed = (0, _parseRelativeUrl).parseRelativeUrl(url);
    let {
      pathname: pathname1,
      query: query1
    } = parsed; // The build manifest needs to be loaded before auto-static dynamic pages
    // get their query parameters to allow ensuring they can be parsed properly
    // when rewritten to

    let pages, rewrites;

    try {
      pages = await this.pageLoader.getPageList();
      ({
        __rewrites: rewrites
      } = await (0, _routeLoader).getClientBuildManifest());
    } catch (err1) {
      // If we fail to resolve the page list or client-build manifest, we must
      // do a server-side transition:
      window.location.href = as;
      return false;
    } // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url


    if (!this.urlIsNew(cleanedAs) && !localeChange) {
      method = 'replaceState';
    } // we need to resolve the as value using rewrites for dynamic SSG
    // pages to allow building the data URL correctly


    let resolvedAs = as; // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1

    pathname1 = pathname1 ? (0, _normalizeTrailingSlash).removePathTrailingSlash(delBasePath(pathname1)) : pathname1;

    if (shouldResolveHref && pathname1 !== '/_error') {
      options._shouldResolveHref = true;

      if (false) {} else {
        parsed.pathname = resolveDynamicRoute(pathname1, pages);

        if (parsed.pathname !== pathname1) {
          pathname1 = parsed.pathname;
          parsed.pathname = addBasePath(pathname1);
          url = (0, _utils).formatWithValidation(parsed);
        }
      }
    }

    const route = (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname1);

    if (!isLocalURL(as)) {
      if (true) {
        throw new Error(`Invalid href: "${url}" and as: "${as}", received relative href and external as` + `\nSee more info: https://nextjs.org/docs/messages/invalid-relative-url-external-as`);
      }

      window.location.href = as;
      return false;
    }

    resolvedAs = delLocale(delBasePath(resolvedAs), this.locale);

    if ((0, _isDynamic).isDynamicRoute(route)) {
      const parsedAs = (0, _parseRelativeUrl).parseRelativeUrl(resolvedAs);
      const asPathname = parsedAs.pathname;
      const routeRegex = (0, _routeRegex).getRouteRegex(route);
      const routeMatch = (0, _routeMatcher).getRouteMatcher(routeRegex)(asPathname);
      const shouldInterpolate = route === asPathname;
      const interpolatedAs = shouldInterpolate ? interpolateAs(route, asPathname, query1) : {};

      if (!routeMatch || shouldInterpolate && !interpolatedAs.result) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query1[param]);

        if (missingParams.length > 0) {
          if (true) {
            console.warn(`${shouldInterpolate ? `Interpolating href` : `Mismatching \`as\` and \`href\``} failed to manually provide ` + `the params: ${missingParams.join(', ')} in the \`href\`'s \`query\``);
          }

          throw new Error((shouldInterpolate ? `The provided \`href\` (${url}) value is missing query values (${missingParams.join(', ')}) to be interpolated properly. ` : `The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). `) + `Read more: https://nextjs.org/docs/messages/${shouldInterpolate ? 'href-interpolation-failed' : 'incompatible-href-as'}`);
        }
      } else if (shouldInterpolate) {
        as = (0, _utils).formatWithValidation(Object.assign({}, parsedAs, {
          pathname: interpolatedAs.result,
          query: omitParmsFromQuery(query1, interpolatedAs.params)
        }));
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query1, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as, routeProps);

    try {
      var ref, ref1;
      let routeInfo = await this.getRouteInfo(route, pathname1, query1, as, resolvedAs, routeProps);
      let {
        error,
        props,
        __N_SSG,
        __N_SSP
      } = routeInfo; // handle redirect on client-transition

      if ((__N_SSG || __N_SSP) && props) {
        if (props.pageProps && props.pageProps.__N_REDIRECT) {
          const destination = props.pageProps.__N_REDIRECT; // check if destination is internal (resolves to a page) and attempt
          // client-navigation if it is falling back to hard navigation if
          // it's not

          if (destination.startsWith('/')) {
            const parsedHref = (0, _parseRelativeUrl).parseRelativeUrl(destination);
            parsedHref.pathname = resolveDynamicRoute(parsedHref.pathname, pages);
            const {
              url: newUrl,
              as: newAs
            } = prepareUrlAs(this, destination, destination);
            return this.change(method, newUrl, newAs, options);
          }

          window.location.href = destination;
          return new Promise(() => {});
        }

        this.isPreview = !!props.__N_PREVIEW; // handle SSG data 404

        if (props.notFound === SSG_DATA_NOT_FOUND) {
          let notFoundRoute;

          try {
            await this.fetchComponent('/404');
            notFoundRoute = '/404';
          } catch (_) {
            notFoundRoute = '/_error';
          }

          routeInfo = await this.getRouteInfo(notFoundRoute, notFoundRoute, query1, as, resolvedAs, {
            shallow: false
          });
        }
      }

      Router.events.emit('beforeHistoryChange', as, routeProps);
      this.changeState(method, url, as, options);

      if (true) {
        const appComp = this.components['/_app'].Component;
        window.next.isPrerendered = appComp.getInitialProps === appComp.origGetInitialProps && !routeInfo.Component.getInitialProps;
      }

      if (options._h && pathname1 === '/_error' && ((ref = self.__NEXT_DATA__.props) === null || ref === void 0 ? void 0 : (ref1 = ref.pageProps) === null || ref1 === void 0 ? void 0 : ref1.statusCode) === 500 && (props === null || props === void 0 ? void 0 : props.pageProps)) {
        // ensure statusCode is still correct for static 500 page
        // when updating query information
        props.pageProps.statusCode = 500;
      } // shallow routing is only allowed for same page URL changes.


      const isValidShallowRoute = options.shallow && this.route === route;

      var _scroll;

      const shouldScroll = (_scroll = options.scroll) !== null && _scroll !== void 0 ? _scroll : !isValidShallowRoute;
      const resetScroll = shouldScroll ? {
        x: 0,
        y: 0
      } : null;
      await this.set(route, pathname1, query1, cleanedAs, routeInfo, forcedScroll !== null && forcedScroll !== void 0 ? forcedScroll : resetScroll).catch(e => {
        if (e.cancelled) error = error || e;else throw e;
      });

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs, routeProps);
        throw error;
      }

      if (false) {}

      Router.events.emit('routeChangeComplete', as, routeProps);
      return true;
    } catch (err1) {
      if (err1.cancelled) {
        return false;
      }

      throw err1;
    }
  }

  changeState(method, url, as, options = {}) {
    if (true) {
      if (typeof window.history === 'undefined') {
        console.error(`Warning: window.history is not available.`);
        return;
      }

      if (typeof window.history[method] === 'undefined') {
        console.error(`Warning: window.history.${method} is not available`);
        return;
      }
    }

    if (method !== 'pushState' || (0, _utils).getURL() !== as) {
      this._shallow = options.shallow;
      window.history[method]({
        url,
        as,
        options,
        __N: true,
        idx: this._idx = method !== 'pushState' ? this._idx : this._idx + 1
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, routeProps, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if ((0, _routeLoader).isAssetError(err) || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as, routeProps); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      let Component1;
      let styleSheets;
      let props;

      if (typeof Component1 === 'undefined' || typeof styleSheets === 'undefined') {
        ({
          page: Component1,
          styleSheets
        } = await this.fetchComponent('/_error'));
      }

      const routeInfo = {
        props,
        Component: Component1,
        styleSheets,
        err,
        error: err
      };

      if (!routeInfo.props) {
        try {
          routeInfo.props = await this.getInitialProps(Component1, {
            err,
            pathname,
            query
          });
        } catch (gipErr) {
          console.error('Error in error page `getInitialProps`: ', gipErr);
          routeInfo.props = {};
        }
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, routeProps, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, resolvedAs, routeProps) {
    try {
      const existingRouteInfo = this.components[route];

      if (routeProps.shallow && existingRouteInfo && this.route === route) {
        return existingRouteInfo;
      }

      const cachedRouteInfo = existingRouteInfo && 'initial' in existingRouteInfo ? undefined : existingRouteInfo;
      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        styleSheets: res.styleSheets,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component: Component1,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (true) {
        const {
          isValidElementType
        } = __webpack_require__(/*! react-is */ "react-is");

        if (!isValidElementType(Component1)) {
          throw new Error(`The default export is not a React Component in page: "${pathname}"`);
        }
      }

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils).formatWithValidation({
          pathname,
          query
        }), resolvedAs, __N_SSG, this.locale);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component1, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as,
        locale: this.locale,
        locales: this.locales,
        defaultLocale: this.defaultLocale
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err2) {
      return this.handleRouteInfoError(err2, pathname, query, as, routeProps);
    }
  }

  set(route, pathname, query, as, data, resetScroll) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data, resetScroll);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value or `#top`
    // To mirror browsers

    if (hash === '' || hash === 'top') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    let parsed = (0, _parseRelativeUrl).parseRelativeUrl(url);
    let {
      pathname: pathname2
    } = parsed;

    if (false) {}

    const pages = await this.pageLoader.getPageList();
    let resolvedAs = asPath;

    if (false) {} else {
      parsed.pathname = resolveDynamicRoute(parsed.pathname, pages);

      if (parsed.pathname !== pathname2) {
        pathname2 = parsed.pathname;
        parsed.pathname = pathname2;
        url = (0, _utils).formatWithValidation(parsed);
      }
    }

    const route = (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname2); // Prefetch is not supported in development mode because it would trigger on-demand-entries

    if (true) {
      return;
    }

    await Promise.all([this.pageLoader._isSsg(route).then(isSsg => {
      return isSsg ? this._getStaticData(this.pageLoader.getDataHref(url, resolvedAs, true, typeof options.locale !== 'undefined' ? options.locale : this.locale)) : false;
    }), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err2 = new Error('Loading initial props cancelled');
        err2.cancelled = true;
        throw err2;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if (false) {}

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    const {
      href: resourceKey
    } = new URL(dataHref, window.location.href);

    if (this.sdr[resourceKey]) {
      return this.sdr[resourceKey];
    }

    return this.sdr[resourceKey] = fetchNextData(dataHref, this.isSsr).then(data => {
      delete this.sdr[resourceKey];
      return data;
    }).catch(err2 => {
      delete this.sdr[resourceKey];
      throw err2;
    });
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App1
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App1);

    ctx.AppTree = AppTree;
    return (0, _utils).loadGetInitialProps(App1, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as, routeProps) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as, routeProps);
      this.clc();
      this.clc = null;
    }
  }

  notify(data, resetScroll) {
    return this.sub(data, this.components['/_app'].Component, resetScroll);
  }

}

Router.events = (0, _mitt).default();
exports.default = Router;

/***/ }),

/***/ "./pages/dashboard.js":
/*!****************************!*\
  !*** ./pages/dashboard.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Dashboard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Dashboard */ "./components/Dashboard/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\pages\\dashboard.js";




function dashboard() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_components_Dashboard__WEBPACK_IMPORTED_MODULE_1__.default, {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 12
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dashboard);

/***/ }),

/***/ "./utils/candyMachine.ts":
/*!*******************************!*\
  !*** ./utils/candyMachine.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CANDY_MACHINE_PROGRAM": () => (/* binding */ CANDY_MACHINE_PROGRAM),
/* harmony export */   "existsOwnerSPLToken": () => (/* binding */ existsOwnerSPLToken),
/* harmony export */   "awaitTransactionSignatureConfirmation": () => (/* binding */ awaitTransactionSignatureConfirmation),
/* harmony export */   "getCandyMachineState": () => (/* binding */ getCandyMachineState),
/* harmony export */   "getNFTsForOwner": () => (/* binding */ getNFTsForOwner),
/* harmony export */   "mintOneToken": () => (/* binding */ mintOneToken),
/* harmony export */   "mintMultipleToken": () => (/* binding */ mintMultipleToken),
/* harmony export */   "shortenAddress": () => (/* binding */ shortenAddress)
/* harmony export */ });
/* harmony import */ var _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @project-serum/anchor */ "@project-serum/anchor");
/* harmony import */ var _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _metaplex_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @metaplex/js */ "@metaplex/js");
/* harmony import */ var _metaplex_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_metaplex_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @solana/spl-token */ "@solana/spl-token");
/* harmony import */ var _solana_spl_token__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_solana_spl_token__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! . */ "./utils/index.ts");




const CANDY_MACHINE_PROGRAM = new _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.PublicKey("cndyAnrLdpjq1Ssp1z8xxDsB8dxe7u4HL5Nxi2K5WXZ");
const SPL_ASSOCIATED_TOKEN_ACCOUNT_PROGRAM_ID = new _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL");
const TOKEN_METADATA_PROGRAM_ID = new _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.PublicKey("metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s");
async function existsOwnerSPLToken(connection, ownerAddress) {
  // console.log("As TOKEN ");
  const tokenAccounts = await connection.getParsedTokenAccountsByOwner(ownerAddress, {
    programId: _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.TOKEN_PROGRAM_ID
  });
  console.log(tokenAccounts); // let multipleAccounts = [];
  // while (tokenAccounts.length > 0) {
  //   const lookups = mintPubkeys.splice(0, 100);
  //   const lookupAccts = await conn.getMultipleAccountsInfo(lookups);
  //   multipleAccounts.push(...lookupAccts);
  // }

  for (let index = 0; index < tokenAccounts.value.length; index++) {
    const tokenAccount = tokenAccounts.value[index];
    const tokenAmount = tokenAccount.account.data.parsed.info.tokenAmount;
    const mint = tokenAccount.account.data.parsed.info.mint;

    if (mint === process.env.NEXT_PUBLIC_AIRDROP_TOKEN && tokenAmount.uiAmount > 0) {
      console.log("Found", mint === process.env.NEXT_PUBLIC_AIRDROP_TOKEN);
      return true;
    }
  }

  return false;
}
const awaitTransactionSignatureConfirmation = async (txid, timeout, connection, commitment = "recent", queryStatus = false) => {
  let done = false;
  let status = {
    slot: 0,
    confirmations: 0,
    err: null
  };
  let subId = 0;
  status = await new Promise(async (resolve, reject) => {
    setTimeout(() => {
      if (done) {
        return;
      }

      done = true;
      console.log("Rejecting for timeout...");
      reject({
        timeout: true
      });
    }, timeout);

    try {
      subId = connection.onSignature(txid, (result, context) => {
        done = true;
        status = {
          err: result.err,
          slot: context.slot,
          confirmations: 0
        };

        if (result.err) {
          console.log("Rejected via websocket", result.err);
          reject(status);
        } else {
          console.log("Resolved via websocket", result);
          resolve(status);
        }
      }, commitment);
    } catch (e) {
      done = true;
      console.error("WS error in setup", txid, e);
    }

    while (!done && queryStatus) {
      (async () => {
        try {
          const signatureStatuses = await connection.getSignatureStatuses([txid]);
          status = signatureStatuses && signatureStatuses.value[0];

          if (!done) {
            if (!status) {
              console.log("REST null result for", txid, status);
            } else if (status.err) {
              console.log("REST error for", txid, status);
              done = true;
              reject(status.err);
            } else if (!status.confirmations) {
              console.log("REST no confirmations for", txid, status);
            } else {
              console.log("REST confirmation for", txid, status);
              done = true;
              resolve(status);
            }
          }
        } catch (e) {
          if (!done) {
            console.log("REST connection error: txid", txid, e);
          }
        }
      })();

      await (0,___WEBPACK_IMPORTED_MODULE_3__.sleep)(2000);
    }
  }); //@ts-ignore

  if (connection._signatureSubscriptions[subId]) {
    connection.removeSignatureListener(subId);
  }

  done = true;
  console.log("Returning status", status);
  return status;
};

const createAssociatedTokenAccountInstruction = (associatedTokenAddress, payer, walletAddress, splTokenMintAddress) => {
  const keys = [{
    pubkey: payer,
    isSigner: true,
    isWritable: true
  }, {
    pubkey: associatedTokenAddress,
    isSigner: false,
    isWritable: true
  }, {
    pubkey: walletAddress,
    isSigner: false,
    isWritable: false
  }, {
    pubkey: splTokenMintAddress,
    isSigner: false,
    isWritable: false
  }, {
    pubkey: _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.SystemProgram.programId,
    isSigner: false,
    isWritable: false
  }, {
    pubkey: _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.TOKEN_PROGRAM_ID,
    isSigner: false,
    isWritable: false
  }, {
    pubkey: _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.SYSVAR_RENT_PUBKEY,
    isSigner: false,
    isWritable: false
  }];
  return new _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.TransactionInstruction({
    keys,
    programId: SPL_ASSOCIATED_TOKEN_ACCOUNT_PROGRAM_ID,
    data: Buffer.from([])
  });
};

const getCandyMachineState = async (anchorWallet, candyMachineId, connection) => {
  const provider = new _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.Provider(connection, anchorWallet, {
    preflightCommitment: "recent"
  });
  const idl = await _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.Program.fetchIdl(CANDY_MACHINE_PROGRAM, provider);

  if (idl) {
    const program = new _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.Program(idl, CANDY_MACHINE_PROGRAM, provider);
    const candyMachine = {
      id: candyMachineId,
      connection,
      program
    };
    const state = await program.account.candyMachine.fetch(candyMachineId);
    const itemsAvailable = state.data.itemsAvailable.toNumber();
    const itemsRedeemed = state.itemsRedeemed.toNumber();
    const itemsRemaining = itemsAvailable - itemsRedeemed;
    let goLiveDate = state.data.goLiveDate.toNumber();
    goLiveDate = new Date(goLiveDate * 1000);
    return {
      candyMachine,
      itemsAvailable,
      itemsRedeemed,
      itemsRemaining,
      goLiveDate
    };
  } else {
    throw new Error(`Fetching idl returned null: check CANDY_MACHINE_PROGRAM`);
  }
};

const getMasterEdition = async mint => {
  return (await _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.PublicKey.findProgramAddress([Buffer.from("metadata"), TOKEN_METADATA_PROGRAM_ID.toBuffer(), mint.toBuffer(), Buffer.from("edition")], TOKEN_METADATA_PROGRAM_ID))[0];
};

const getMetadata = async mint => {
  return (await _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.PublicKey.findProgramAddress([Buffer.from("metadata"), TOKEN_METADATA_PROGRAM_ID.toBuffer(), mint.toBuffer()], TOKEN_METADATA_PROGRAM_ID))[0];
};

const getTokenWallet = async (wallet, mint) => {
  return (await _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.PublicKey.findProgramAddress([wallet.toBuffer(), _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.TOKEN_PROGRAM_ID.toBuffer(), mint.toBuffer()], SPL_ASSOCIATED_TOKEN_ACCOUNT_PROGRAM_ID))[0];
};

async function getNFTsForOwner(connection, ownerAddress) {
  const allTokens = [];
  const tokenAccounts = await connection.getParsedTokenAccountsByOwner(ownerAddress, {
    programId: _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.TOKEN_PROGRAM_ID
  });

  for (let index = 0; index < tokenAccounts.value.length; index++) {
    const tokenAccount = tokenAccounts.value[index];
    const tokenAmount = tokenAccount.account.data.parsed.info.tokenAmount;

    if (tokenAmount.amount == "1" && tokenAmount.decimals == "0") {
      let [pda] = await _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.PublicKey.findProgramAddress([Buffer.from("metadata"), TOKEN_METADATA_PROGRAM_ID.toBuffer(), new _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.PublicKey(tokenAccount.account.data.parsed.info.mint).toBuffer()], TOKEN_METADATA_PROGRAM_ID);
      const accountInfo = await connection.getParsedAccountInfo(pda);
      const metadata = new _metaplex_js__WEBPACK_IMPORTED_MODULE_1__.Metadata(ownerAddress.toString(), accountInfo.value);
      const dataRes = await fetch(metadata.data.data.uri);

      if (dataRes.status === 200) {
        allTokens.push(await dataRes.json());
      }
    }
  }

  return allTokens;
}
const mintOneToken = async (candyMachine, config, payer, treasury) => {
  const mint = _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.Keypair.generate();
  const token = await getTokenWallet(payer, mint.publicKey);
  const {
    connection,
    program
  } = candyMachine;
  const metadata = await getMetadata(mint.publicKey);
  const masterEdition = await getMasterEdition(mint.publicKey);
  const rent = await connection.getMinimumBalanceForRentExemption(_solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.MintLayout.span);
  return await program.rpc.mintNft({
    accounts: {
      config,
      candyMachine: candyMachine.id,
      payer: payer,
      wallet: treasury,
      mint: mint.publicKey,
      metadata,
      masterEdition,
      mintAuthority: payer,
      updateAuthority: payer,
      tokenMetadataProgram: TOKEN_METADATA_PROGRAM_ID,
      tokenProgram: _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.TOKEN_PROGRAM_ID,
      systemProgram: _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.SystemProgram.programId,
      rent: _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.SYSVAR_RENT_PUBKEY,
      clock: _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.SYSVAR_CLOCK_PUBKEY
    },
    signers: [mint],
    instructions: [_project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.SystemProgram.createAccount({
      fromPubkey: payer,
      newAccountPubkey: mint.publicKey,
      space: _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.MintLayout.span,
      lamports: rent,
      programId: _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.TOKEN_PROGRAM_ID
    }), _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.Token.createInitMintInstruction(_solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.TOKEN_PROGRAM_ID, mint.publicKey, 0, payer, payer), createAssociatedTokenAccountInstruction(token, payer, payer, mint.publicKey), _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.Token.createMintToInstruction(_solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.TOKEN_PROGRAM_ID, mint.publicKey, token, payer, [], 1)]
  });
};
const mintMultipleToken = async (candyMachine, config, payer, treasury, quantity = 2) => {
  const signersMatrix = [];
  const instructionsMatrix = [];

  for (let index = 0; index < quantity; index++) {
    const mint = _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.Keypair.generate();
    const token = await getTokenWallet(payer, mint.publicKey);
    const {
      connection
    } = candyMachine;
    const rent = await connection.getMinimumBalanceForRentExemption(_solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.MintLayout.span);
    const instructions = [_project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.SystemProgram.createAccount({
      fromPubkey: payer,
      newAccountPubkey: mint.publicKey,
      space: _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.MintLayout.span,
      lamports: rent,
      programId: _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.TOKEN_PROGRAM_ID
    }), _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.Token.createInitMintInstruction(_solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.TOKEN_PROGRAM_ID, mint.publicKey, 0, payer, payer), createAssociatedTokenAccountInstruction(token, payer, payer, mint.publicKey), _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.Token.createMintToInstruction(_solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.TOKEN_PROGRAM_ID, mint.publicKey, token, payer, [], 1)];
    const masterEdition = await getMasterEdition(mint.publicKey);
    const metadata = await getMetadata(mint.publicKey);
    instructions.push(await candyMachine.program.instruction.mintNft({
      accounts: {
        config,
        candyMachine: candyMachine.id,
        payer: payer,
        wallet: treasury,
        mint: mint.publicKey,
        metadata,
        masterEdition,
        mintAuthority: payer,
        updateAuthority: payer,
        tokenMetadataProgram: TOKEN_METADATA_PROGRAM_ID,
        tokenProgram: _solana_spl_token__WEBPACK_IMPORTED_MODULE_2__.TOKEN_PROGRAM_ID,
        systemProgram: _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.SystemProgram.programId,
        rent: _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.SYSVAR_RENT_PUBKEY,
        clock: _project_serum_anchor__WEBPACK_IMPORTED_MODULE_0__.web3.SYSVAR_CLOCK_PUBKEY
      }
    }));
    const signers = [mint];
    signersMatrix.push(signers);
    instructionsMatrix.push(instructions);
  }

  return await (0,___WEBPACK_IMPORTED_MODULE_3__.sendTransactions)(candyMachine.program.provider.connection, candyMachine.program.provider.wallet, instructionsMatrix, signersMatrix);
};
const shortenAddress = (address, chars = 4) => {
  return `${address.slice(0, chars)}...${address.slice(-chars)}`;
};

/***/ }),

/***/ "./utils/index.ts":
/*!************************!*\
  !*** ./utils/index.ts ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getErrorForTransaction": () => (/* binding */ getErrorForTransaction),
/* harmony export */   "SequenceType": () => (/* binding */ SequenceType),
/* harmony export */   "sendTransactions": () => (/* binding */ sendTransactions),
/* harmony export */   "sendTransaction": () => (/* binding */ sendTransaction),
/* harmony export */   "sendTransactionWithRetry": () => (/* binding */ sendTransactionWithRetry),
/* harmony export */   "getUnixTs": () => (/* binding */ getUnixTs),
/* harmony export */   "sendSignedTransaction": () => (/* binding */ sendSignedTransaction),
/* harmony export */   "sleep": () => (/* binding */ sleep)
/* harmony export */ });
/* harmony import */ var _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @solana/web3.js */ "@solana/web3.js");
/* harmony import */ var _solana_web3_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_solana_web3_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @solana/wallet-adapter-base */ "./node_modules/@solana/wallet-adapter-base/lib/index.js");


const getErrorForTransaction = async (connection, txid) => {
  // wait for all confirmation before geting transaction
  await connection.confirmTransaction(txid, "max");
  const tx = await connection.getParsedConfirmedTransaction(txid);
  const errors = [];

  if (tx !== null && tx !== void 0 && tx.meta && tx.meta.logMessages) {
    tx.meta.logMessages.forEach(log => {
      const regex = /Error: (.*)/gm;
      let m;

      while ((m = regex.exec(log)) !== null) {
        // This is necessary to avoid infinite loops with zero-width matches
        if (m.index === regex.lastIndex) {
          regex.lastIndex++;
        }

        if (m.length > 1) {
          errors.push(m[1]);
        }
      }
    });
  }

  return errors;
};
let SequenceType;

(function (SequenceType) {
  SequenceType[SequenceType["Sequential"] = 0] = "Sequential";
  SequenceType[SequenceType["Parallel"] = 1] = "Parallel";
  SequenceType[SequenceType["StopOnFailure"] = 2] = "StopOnFailure";
})(SequenceType || (SequenceType = {}));

const sendTransactions = async (connection, wallet, instructionSet, signersSet, sequenceType = SequenceType.Parallel, commitment = "singleGossip", block) => {
  if (!wallet.publicKey) throw new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_1__.WalletNotConnectedError();
  const unsignedTxns = [];

  if (!block) {
    block = await connection.getRecentBlockhash(commitment);
  }

  for (let i = 0; i < instructionSet.length; i++) {
    const instructions = instructionSet[i];
    const signers = signersSet[i];

    if (instructions.length === 0) {
      continue;
    }

    let transaction = new _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__.Transaction();
    instructions.forEach(instruction => transaction.add(instruction));
    transaction.recentBlockhash = block.blockhash;
    transaction.setSigners( // fee payed by the wallet owner
    wallet.publicKey, ...signers.map(s => s.publicKey));

    if (signers.length > 0) {
      transaction.partialSign(...signers);
    }

    unsignedTxns.push(transaction);
  }

  const signedTxns = await wallet.signAllTransactions(unsignedTxns);
  const pendingTxns = [];
  let breakEarlyObject = {
    breakEarly: false,
    i: 0
  };
  console.log("Signed txns length", signedTxns.length, "vs handed in length", instructionSet.length);
  const txIds = [];

  for (let i = 0; i < signedTxns.length; i++) {
    const signedTxnPromise = sendSignedTransaction({
      connection,
      signedTransaction: signedTxns[i]
    });

    try {
      const {
        txid
      } = await signedTxnPromise;
      txIds.push(txid);
    } catch (error) {
      console.error(error); // @ts-ignore

      failCallback(signedTxns[i], i);

      if (sequenceType === SequenceType.StopOnFailure) {
        breakEarlyObject.breakEarly = true;
        breakEarlyObject.i = i;
      }
    }

    if (sequenceType !== SequenceType.Parallel) {
      try {
        await signedTxnPromise;
      } catch (e) {
        console.log("Caught failure", e);

        if (breakEarlyObject.breakEarly) {
          console.log("Died on ", breakEarlyObject.i);
          return breakEarlyObject.i; // Return the txn we failed on by index
        }
      }
    } else {
      pendingTxns.push(signedTxnPromise);
    }
  }

  if (sequenceType !== SequenceType.Parallel) {
    await Promise.all(pendingTxns);
  }

  return txIds;
};
const sendTransaction = async (connection, wallet, instructions, signers, awaitConfirmation = true, commitment = "singleGossip", includesFeePayer = false, block) => {
  if (!wallet.publicKey) throw new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_1__.WalletNotConnectedError();
  let transaction = new _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__.Transaction();
  instructions.forEach(instruction => transaction.add(instruction));
  transaction.recentBlockhash = (block || (await connection.getRecentBlockhash(commitment))).blockhash;

  if (includesFeePayer) {
    transaction.setSigners(...signers.map(s => s.publicKey));
  } else {
    transaction.setSigners( // fee payed by the wallet owner
    wallet.publicKey, ...signers.map(s => s.publicKey));
  }

  if (signers.length > 0) {
    transaction.partialSign(...signers);
  }

  if (!includesFeePayer) {
    transaction = await wallet.signTransaction(transaction);
  }

  const rawTransaction = transaction.serialize();
  let options = {
    skipPreflight: true,
    commitment
  };
  const txid = await connection.sendRawTransaction(rawTransaction, options);
  let slot = 0;

  if (awaitConfirmation) {
    const confirmation = await awaitTransactionSignatureConfirmation(txid, DEFAULT_TIMEOUT, connection, commitment);
    if (!confirmation) throw new Error("Timed out awaiting confirmation on transaction");
    slot = (confirmation === null || confirmation === void 0 ? void 0 : confirmation.slot) || 0;

    if (confirmation !== null && confirmation !== void 0 && confirmation.err) {
      const errors = await getErrorForTransaction(connection, txid);
      console.log(errors);
      throw new Error(`Raw transaction ${txid} failed`);
    }
  }

  return {
    txid,
    slot
  };
};
const sendTransactionWithRetry = async (connection, wallet, instructions, signers, commitment = "singleGossip", includesFeePayer = false, block, beforeSend) => {
  if (!wallet.publicKey) throw new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_1__.WalletNotConnectedError();
  let transaction = new _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__.Transaction();
  instructions.forEach(instruction => transaction.add(instruction));
  transaction.recentBlockhash = (block || (await connection.getRecentBlockhash(commitment))).blockhash;

  if (includesFeePayer) {
    transaction.setSigners(...signers.map(s => s.publicKey));
  } else {
    transaction.setSigners( // fee payed by the wallet owner
    wallet.publicKey, ...signers.map(s => s.publicKey));
  }

  if (signers.length > 0) {
    transaction.partialSign(...signers);
  }

  if (!includesFeePayer) {
    transaction = await wallet.signTransaction(transaction);
  }

  if (beforeSend) {
    beforeSend();
  }

  const {
    txid,
    slot
  } = await sendSignedTransaction({
    connection,
    signedTransaction: transaction
  });
  return {
    txid,
    slot
  };
};
const getUnixTs = () => {
  return new Date().getTime() / 1000;
};
const DEFAULT_TIMEOUT = 15000;
async function sendSignedTransaction({
  signedTransaction,
  connection,
  timeout = DEFAULT_TIMEOUT
}) {
  const rawTransaction = signedTransaction.serialize();
  const startTime = getUnixTs();
  let slot = 0;
  const txid = await connection.sendRawTransaction(rawTransaction, {
    skipPreflight: true
  });
  console.log("Started awaiting confirmation for", txid);
  let done = false;

  (async () => {
    while (!done && getUnixTs() - startTime < timeout) {
      connection.sendRawTransaction(rawTransaction, {
        skipPreflight: true
      });
      await sleep(500);
    }
  })();

  try {
    const confirmation = await awaitTransactionSignatureConfirmation(txid, timeout, connection, "recent", true);
    if (!confirmation) throw new Error("Timed out awaiting confirmation on transaction");

    if (confirmation.err) {
      console.error(confirmation.err);
      throw new Error("Transaction failed: Custom instruction error");
    }

    slot = (confirmation === null || confirmation === void 0 ? void 0 : confirmation.slot) || 0;
  } catch (err) {
    console.error("Timeout Error caught", err);

    if (err.timeout) {
      throw new Error("Timed out awaiting confirmation on transaction");
    }

    let simulateResult = null;

    try {
      simulateResult = (await simulateTransaction(connection, signedTransaction, "single")).value;
    } catch (e) {}

    if (simulateResult && simulateResult.err) {
      if (simulateResult.logs) {
        for (let i = simulateResult.logs.length - 1; i >= 0; --i) {
          const line = simulateResult.logs[i];

          if (line.startsWith("Program log: ")) {
            throw new Error("Transaction failed: " + line.slice("Program log: ".length));
          }
        }
      }

      throw new Error(JSON.stringify(simulateResult.err));
    } // throw new Error('Transaction failed');

  } finally {
    done = true;
  }

  console.log("Latency", txid, getUnixTs() - startTime);
  return {
    txid,
    slot
  };
}

async function simulateTransaction(connection, transaction, commitment) {
  // @ts-ignore
  transaction.recentBlockhash = await connection._recentBlockhash( // @ts-ignore
  connection._disableBlockhashCaching);
  const signData = transaction.serializeMessage(); // @ts-ignore

  const wireTransaction = transaction._serialize(signData);

  const encodedTransaction = wireTransaction.toString("base64");
  const config = {
    encoding: "base64",
    commitment
  };
  const args = [encodedTransaction, config]; // @ts-ignore

  const res = await connection._rpcRequest("simulateTransaction", args);

  if (res.error) {
    throw new Error("failed to simulate transaction: " + res.error.message);
  }

  return res.result;
}

async function awaitTransactionSignatureConfirmation(txid, timeout, connection, commitment = "recent", queryStatus = false) {
  let done = false;
  let status = {
    slot: 0,
    confirmations: 0,
    err: null
  };
  let subId = 0;
  status = await new Promise(async (resolve, reject) => {
    setTimeout(() => {
      if (done) {
        return;
      }

      done = true;
      console.log("Rejecting for timeout...");
      reject({
        timeout: true
      });
    }, timeout);

    try {
      subId = connection.onSignature(txid, (result, context) => {
        done = true;
        status = {
          err: result.err,
          slot: context.slot,
          confirmations: 0
        };

        if (result.err) {
          console.log("Rejected via websocket", result.err);
          reject(status);
        } else {
          console.log("Resolved via websocket", result);
          resolve(status);
        }
      }, commitment);
    } catch (e) {
      done = true;
      console.error("WS error in setup", txid, e);
    }

    while (!done && queryStatus) {
      // eslint-disable-next-line no-loop-func
      (async () => {
        try {
          const signatureStatuses = await connection.getSignatureStatuses([txid]);
          status = signatureStatuses && signatureStatuses.value[0];

          if (!done) {
            if (!status) {
              console.log("REST null result for", txid, status);
            } else if (status.err) {
              console.log("REST error for", txid, status);
              done = true;
              reject(status.err);
            } else if (!status.confirmations) {
              console.log("REST no confirmations for", txid, status);
            } else {
              console.log("REST confirmation for", txid, status);
              done = true;
              resolve(status);
            }
          }
        } catch (e) {
          if (!done) {
            console.log("REST connection error: txid", txid, e);
          }
        }
      })();

      await sleep(2000);
    }
  }); //@ts-ignore

  if (connection._signatureSubscriptions[subId]) connection.removeSignatureListener(subId);
  done = true;
  console.log("Returning status", status);
  return status;
}

const sleep = ms => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/adapter.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/adapter.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventEmitter": () => (/* reexport default from dynamic */ eventemitter3__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "BaseWalletAdapter": () => (/* binding */ BaseWalletAdapter),
/* harmony export */   "WalletAdapterNetwork": () => (/* binding */ WalletAdapterNetwork)
/* harmony export */ });
/* harmony import */ var eventemitter3__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! eventemitter3 */ "eventemitter3");
/* harmony import */ var eventemitter3__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(eventemitter3__WEBPACK_IMPORTED_MODULE_0__);


class BaseWalletAdapter extends (eventemitter3__WEBPACK_IMPORTED_MODULE_0___default()) {}
var WalletAdapterNetwork;

(function (WalletAdapterNetwork) {
  WalletAdapterNetwork["Mainnet"] = "mainnet-beta";
  WalletAdapterNetwork["Testnet"] = "testnet";
  WalletAdapterNetwork["Devnet"] = "devnet";
})(WalletAdapterNetwork || (WalletAdapterNetwork = {}));

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/errors.js":
/*!****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/errors.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletError": () => (/* binding */ WalletError),
/* harmony export */   "WalletNotFoundError": () => (/* binding */ WalletNotFoundError),
/* harmony export */   "WalletNotInstalledError": () => (/* binding */ WalletNotInstalledError),
/* harmony export */   "WalletNotReadyError": () => (/* binding */ WalletNotReadyError),
/* harmony export */   "WalletConnectionError": () => (/* binding */ WalletConnectionError),
/* harmony export */   "WalletDisconnectedError": () => (/* binding */ WalletDisconnectedError),
/* harmony export */   "WalletDisconnectionError": () => (/* binding */ WalletDisconnectionError),
/* harmony export */   "WalletAccountError": () => (/* binding */ WalletAccountError),
/* harmony export */   "WalletPublicKeyError": () => (/* binding */ WalletPublicKeyError),
/* harmony export */   "WalletKeypairError": () => (/* binding */ WalletKeypairError),
/* harmony export */   "WalletNotConnectedError": () => (/* binding */ WalletNotConnectedError),
/* harmony export */   "WalletSendTransactionError": () => (/* binding */ WalletSendTransactionError),
/* harmony export */   "WalletSignMessageError": () => (/* binding */ WalletSignMessageError),
/* harmony export */   "WalletSignTransactionError": () => (/* binding */ WalletSignTransactionError),
/* harmony export */   "WalletTimeoutError": () => (/* binding */ WalletTimeoutError),
/* harmony export */   "WalletWindowBlockedError": () => (/* binding */ WalletWindowBlockedError),
/* harmony export */   "WalletWindowClosedError": () => (/* binding */ WalletWindowClosedError)
/* harmony export */ });
class WalletError extends Error {
  // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
  constructor(message, error) {
    super(message);
    this.error = error;
  }

}
class WalletNotFoundError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotFoundError';
  }

}
class WalletNotInstalledError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotInstalledError';
  }

}
class WalletNotReadyError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotReadyError';
  }

}
class WalletConnectionError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletConnectionError';
  }

}
class WalletDisconnectedError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletDisconnectedError';
  }

}
class WalletDisconnectionError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletDisconnectionError';
  }

}
class WalletAccountError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletAccountError';
  }

}
class WalletPublicKeyError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletPublicKeyError';
  }

}
class WalletKeypairError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletKeypairError';
  }

}
class WalletNotConnectedError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotConnectedError';
  }

}
class WalletSendTransactionError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletSendTransactionError';
  }

}
class WalletSignMessageError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletSignMessageError';
  }

}
class WalletSignTransactionError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletSignTransactionError';
  }

}
class WalletTimeoutError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletTimeoutError';
  }

}
class WalletWindowBlockedError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletWindowBlockedError';
  }

}
class WalletWindowClosedError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletWindowClosedError';
  }

}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/index.js":
/*!***************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _adapter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./adapter */ "./node_modules/@solana/wallet-adapter-base/lib/adapter.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _adapter__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _adapter__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors */ "./node_modules/@solana/wallet-adapter-base/lib/errors.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _errors__WEBPACK_IMPORTED_MODULE_1__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _errors__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _poll__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./poll */ "./node_modules/@solana/wallet-adapter-base/lib/poll.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _poll__WEBPACK_IMPORTED_MODULE_2__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _poll__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _signer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./signer */ "./node_modules/@solana/wallet-adapter-base/lib/signer.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _signer__WEBPACK_IMPORTED_MODULE_3__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _signer__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);





/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/poll.js":
/*!**************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/poll.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "poll": () => (/* binding */ poll),
/* harmony export */   "pollUntilReady": () => (/* binding */ pollUntilReady)
/* harmony export */ });
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

function poll(callback, interval, count) {
  if (count > 0) {
    setTimeout(() => __awaiter(this, void 0, void 0, function* () {
      const done = yield callback();
      if (!done) poll(callback, interval, count - 1);
    }), interval);
  }
}
function pollUntilReady(adapter, pollInterval, pollCount) {
  poll(() => {
    const {
      ready
    } = adapter;

    if (ready) {
      if (!adapter.emit('ready')) {
        console.warn(`${adapter.constructor.name} is ready but no listener was registered`);
      }
    }

    return ready;
  }, pollInterval, pollCount);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/signer.js":
/*!****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/signer.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BaseSignerWalletAdapter": () => (/* binding */ BaseSignerWalletAdapter),
/* harmony export */   "BaseMessageSignerWalletAdapter": () => (/* binding */ BaseMessageSignerWalletAdapter)
/* harmony export */ });
/* harmony import */ var _adapter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./adapter */ "./node_modules/@solana/wallet-adapter-base/lib/adapter.js");
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors */ "./node_modules/@solana/wallet-adapter-base/lib/errors.js");
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};



class BaseSignerWalletAdapter extends _adapter__WEBPACK_IMPORTED_MODULE_0__.BaseWalletAdapter {
  sendTransaction(transaction, connection, options = {}) {
    return __awaiter(this, void 0, void 0, function* () {
      let emit = true;

      try {
        try {
          transaction.feePayer || (transaction.feePayer = this.publicKey || undefined);
          transaction.recentBlockhash || (transaction.recentBlockhash = (yield connection.getRecentBlockhash('finalized')).blockhash);

          const {
            signers
          } = options,
                sendOptions = __rest(options, ["signers"]);

          (signers === null || signers === void 0 ? void 0 : signers.length) && transaction.partialSign(...signers);
          transaction = yield this.signTransaction(transaction);
          const rawTransaction = transaction.serialize();
          return yield connection.sendRawTransaction(rawTransaction, sendOptions);
        } catch (error) {
          // If the error was thrown by `signTransaction`, rethrow it and don't emit a duplicate event
          if (error instanceof _errors__WEBPACK_IMPORTED_MODULE_1__.WalletError) {
            emit = false;
            throw error;
          }

          throw new _errors__WEBPACK_IMPORTED_MODULE_1__.WalletSendTransactionError(error === null || error === void 0 ? void 0 : error.message, error);
        }
      } catch (error) {
        if (emit) {
          this.emit('error', error);
        }

        throw error;
      }
    });
  }

}
class BaseMessageSignerWalletAdapter extends BaseSignerWalletAdapter {}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js":
/*!********************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Button": () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const Button = props => {
  const justifyContent = props.endIcon || props.startIcon ? 'space-between' : 'center';
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", {
    className: `wallet-adapter-button ${props.className || ''}`,
    disabled: props.disabled,
    onClick: props.onClick,
    style: Object.assign({
      justifyContent
    }, props.style),
    tabIndex: props.tabIndex || 0,
    type: "button"
  }, props.startIcon && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", {
    className: "wallet-adapter-button-start-icon"
  }, props.startIcon), props.children, props.endIcon && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", {
    className: "wallet-adapter-button-end-icon"
  }, props.endIcon));
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/Collapse.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/Collapse.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Collapse": () => (/* binding */ Collapse)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const Collapse = ({
  id,
  children,
  expanded = false
}) => {
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const instant = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(true);
  const transition = 'height 250ms ease-out';

  const openCollapse = () => {
    const node = ref.current;
    if (!node) return;
    requestAnimationFrame(() => {
      node.style.height = node.scrollHeight + 'px';
    });
  };

  const closeCollapse = () => {
    const node = ref.current;
    if (!node) return;
    requestAnimationFrame(() => {
      node.style.height = node.offsetHeight + 'px';
      node.style.overflow = 'hidden';
      requestAnimationFrame(() => {
        node.style.height = '0';
      });
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    if (expanded) {
      openCollapse();
    } else {
      closeCollapse();
    }
  }, [expanded]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    const node = ref.current;
    if (!node) return;

    function handleComplete() {
      if (!node) return;
      node.style.overflow = expanded ? 'initial' : 'hidden';

      if (expanded) {
        node.style.height = 'auto';
      }
    }

    function handleTransitionEnd(event) {
      if (node && event.target === node && event.propertyName === 'height') {
        handleComplete();
      }
    }

    if (instant.current) {
      handleComplete();
      instant.current = false;
    }

    node.addEventListener('transitionend', handleTransitionEnd);
    return () => node.removeEventListener('transitionend', handleTransitionEnd);
  }, [expanded]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    children: children,
    className: "wallet-adapter-collapse",
    id: id,
    ref: ref,
    role: "region",
    style: {
      height: 0,
      transition: instant.current ? undefined : transition
    }
  });
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletConnectButton.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletConnectButton.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletConnectButton": () => (/* binding */ WalletConnectButton)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js");
/* harmony import */ var _WalletIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WalletIcon */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js");
var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};





const WalletConnectButton = _a => {
  var {
    children,
    disabled,
    onClick
  } = _a,
      props = __rest(_a, ["children", "disabled", "onClick"]);

  const {
    wallet,
    connect,
    connecting,
    connected
  } = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_3__.useWallet)();
  const handleClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    if (onClick) onClick(event); // eslint-disable-next-line @typescript-eslint/no-empty-function

    if (!event.defaultPrevented) connect().catch(() => {});
  }, [onClick, connect]);
  const content = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    if (children) return children;
    if (connecting) return 'Connecting ...';
    if (connected) return 'Connected';
    if (wallet) return 'Connect';
    return 'Connect Wallet';
  }, [children, connecting, connected, wallet]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, Object.assign({
    className: "wallet-adapter-button-trigger",
    disabled: disabled || !wallet || connecting || connected,
    startIcon: wallet ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletIcon__WEBPACK_IMPORTED_MODULE_2__.WalletIcon, {
      wallet: wallet
    }) : undefined,
    onClick: handleClick
  }, props), content);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletDisconnectButton.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletDisconnectButton.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletDisconnectButton": () => (/* binding */ WalletDisconnectButton)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js");
/* harmony import */ var _WalletIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WalletIcon */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js");
var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};





const WalletDisconnectButton = _a => {
  var {
    children,
    disabled,
    onClick
  } = _a,
      props = __rest(_a, ["children", "disabled", "onClick"]);

  const {
    wallet,
    disconnect,
    disconnecting
  } = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_3__.useWallet)();
  const handleClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    if (onClick) onClick(event); // eslint-disable-next-line @typescript-eslint/no-empty-function

    if (!event.defaultPrevented) disconnect().catch(() => {});
  }, [onClick, disconnect]);
  const content = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    if (children) return children;
    if (disconnecting) return 'Disconnecting ...';
    if (wallet) return 'Disconnect';
    return 'Disconnect Wallet';
  }, [children, disconnecting, wallet]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, Object.assign({
    className: "wallet-adapter-button-trigger",
    disabled: disabled || !wallet,
    startIcon: wallet ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletIcon__WEBPACK_IMPORTED_MODULE_2__.WalletIcon, {
      wallet: wallet
    }) : undefined,
    onClick: handleClick
  }, props), content);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js":
/*!************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletIcon": () => (/* binding */ WalletIcon)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};


const WalletIcon = _a => {
  var {
    wallet
  } = _a,
      props = __rest(_a, ["wallet"]);

  return wallet && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", Object.assign({
    src: wallet.icon,
    alt: `${wallet.name} icon`
  }, props));
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletListItem.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletListItem.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletListItem": () => (/* binding */ WalletListItem)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js");
/* harmony import */ var _WalletIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WalletIcon */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js");



const WalletListItem = ({
  handleClick,
  tabIndex,
  wallet
}) => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, {
    onClick: handleClick,
    endIcon: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletIcon__WEBPACK_IMPORTED_MODULE_2__.WalletIcon, {
      wallet: wallet
    }),
    tabIndex: tabIndex
  }, wallet.name));
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModal.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModal.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletModal": () => (/* binding */ WalletModal)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Button */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js");
/* harmony import */ var _Collapse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Collapse */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Collapse.js");
/* harmony import */ var _useWalletModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./useWalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js");
/* harmony import */ var _WalletListItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./WalletListItem */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletListItem.js");







const WalletModal = ({
  className = '',
  logo,
  featuredWallets = 3,
  container = 'body'
}) => {
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const {
    wallets,
    select
  } = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_6__.useWallet)();
  const {
    setVisible
  } = (0,_useWalletModal__WEBPACK_IMPORTED_MODULE_4__.useWalletModal)();
  const {
    0: expanded,
    1: setExpanded
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: fadeIn,
    1: setFadeIn
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: portal,
    1: setPortal
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const {
    0: featured,
    1: more
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => [wallets.slice(0, featuredWallets), wallets.slice(featuredWallets)], [wallets, featuredWallets]);
  const hideModal = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    setFadeIn(false);
    setTimeout(() => setVisible(false), 150);
  }, [setFadeIn, setVisible]);
  const handleClose = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    event.preventDefault();
    hideModal();
  }, [hideModal]);
  const handleWalletClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((event, walletName) => {
    select(walletName);
    handleClose(event);
  }, [select, handleClose]);
  const handleCollapseClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => setExpanded(!expanded), [setExpanded, expanded]);
  const handleTabKey = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    const node = ref.current;
    if (!node) return; // here we query all focusable elements

    const focusableElements = node.querySelectorAll('button');
    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];

    if (event.shiftKey) {
      // if going backward by pressing tab and firstElement is active, shift focus to last focusable element
      if (document.activeElement === firstElement) {
        lastElement.focus();
        event.preventDefault();
      }
    } else {
      // if going forward by pressing tab and lastElement is active, shift focus to first focusable element
      if (document.activeElement === lastElement) {
        firstElement.focus();
        event.preventDefault();
      }
    }
  }, [ref]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    const handleKeyDown = event => {
      if (event.key === 'Escape') {
        hideModal();
      } else if (event.key === 'Tab') {
        handleTabKey(event);
      }
    }; // Get original overflow


    const {
      overflow
    } = window.getComputedStyle(document.body); // Hack to enable fade in animation after mount

    setTimeout(() => setFadeIn(true), 0); // Prevent scrolling on mount

    document.body.style.overflow = 'hidden'; // Listen for keydown events

    window.addEventListener('keydown', handleKeyDown, false);
    return () => {
      // Re-enable scrolling when component unmounts
      document.body.style.overflow = overflow;
      window.removeEventListener('keydown', handleKeyDown, false);
    };
  }, [hideModal, handleTabKey]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => setPortal(document.querySelector(container)), [setPortal, container]);
  return portal && /*#__PURE__*/(0,react_dom__WEBPACK_IMPORTED_MODULE_1__.createPortal)( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    "aria-labelledby": "wallet-adapter-modal-title",
    "aria-modal": "true",
    className: `wallet-adapter-modal ${fadeIn && 'wallet-adapter-modal-fade-in'} ${className}`,
    ref: ref,
    role: "dialog"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    className: "wallet-adapter-modal-container"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    className: `wallet-adapter-modal-wrapper ${!logo && 'wallet-adapter-modal-wrapper-no-logo'}`
  }, logo && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    className: "wallet-adapter-modal-logo-wrapper"
  }, typeof logo === 'string' ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", {
    alt: "logo",
    className: "wallet-adapter-modal-logo",
    src: logo
  }) : logo), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", {
    className: "wallet-adapter-modal-title",
    id: "wallet-adapter-modal-title"
  }, "Connect Wallet"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", {
    onClick: handleClose,
    className: "wallet-adapter-modal-button-close"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", {
    width: "14",
    height: "14"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", {
    d: "M14 12.461 8.3 6.772l5.234-5.233L12.006 0 6.772 5.234 1.54 0 0 1.539l5.234 5.233L0 12.006l1.539 1.528L6.772 8.3l5.69 5.7L14 12.461z"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", {
    className: "wallet-adapter-modal-list"
  }, featured.map(wallet => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletListItem__WEBPACK_IMPORTED_MODULE_5__.WalletListItem, {
    key: wallet.name,
    handleClick: event => handleWalletClick(event, wallet.name),
    wallet: wallet
  }))), more.length ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Collapse__WEBPACK_IMPORTED_MODULE_3__.Collapse, {
    expanded: expanded,
    id: "wallet-adapter-modal-collapse"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", {
    className: "wallet-adapter-modal-list"
  }, more.map(wallet => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletListItem__WEBPACK_IMPORTED_MODULE_5__.WalletListItem, {
    key: wallet.name,
    handleClick: event => handleWalletClick(event, wallet.name),
    tabIndex: expanded ? 0 : -1,
    wallet: wallet
  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_2__.Button, {
    "aria-controls": "wallet-adapter-modal-collapse",
    "aria-expanded": expanded,
    className: `wallet-adapter-modal-collapse-button ${expanded && 'wallet-adapter-modal-collapse-button-active'}`,
    endIcon: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", {
      width: "11",
      height: "6",
      xmlns: "http://www.w3.org/2000/svg"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", {
      d: "m5.938 5.73 4.28-4.126a.915.915 0 0 0 0-1.322 1 1 0 0 0-1.371 0L5.253 3.736 1.659.272a1 1 0 0 0-1.371 0A.93.93 0 0 0 0 .932c0 .246.1.48.288.662l4.28 4.125a.99.99 0 0 0 1.37.01z"
    })),
    onClick: handleCollapseClick
  }, expanded ? 'Less' : 'More', " options")) : null)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    className: "wallet-adapter-modal-overlay",
    onMouseDown: handleClose
  })), portal);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalButton.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalButton.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletModalButton": () => (/* binding */ WalletModalButton)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js");
/* harmony import */ var _useWalletModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useWalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js");
var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};




const WalletModalButton = _a => {
  var {
    children = 'Select Wallet',
    onClick
  } = _a,
      props = __rest(_a, ["children", "onClick"]);

  const {
    visible,
    setVisible
  } = (0,_useWalletModal__WEBPACK_IMPORTED_MODULE_2__.useWalletModal)();
  const handleClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    if (onClick) onClick(event);
    if (!event.defaultPrevented) setVisible(!visible);
  }, [onClick, setVisible, visible]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, Object.assign({
    className: "wallet-adapter-button-trigger",
    onClick: handleClick
  }, props), children);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalProvider.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalProvider.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletModalProvider": () => (/* binding */ WalletModalProvider)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _useWalletModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./useWalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js");
/* harmony import */ var _WalletModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModal.js");
var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};




const WalletModalProvider = _a => {
  var {
    children
  } = _a,
      props = __rest(_a, ["children"]);

  const {
    0: visible,
    1: setVisible
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_useWalletModal__WEBPACK_IMPORTED_MODULE_1__.WalletModalContext.Provider, {
    value: {
      visible,
      setVisible
    }
  }, children, visible && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletModal__WEBPACK_IMPORTED_MODULE_2__.WalletModal, Object.assign({}, props)));
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletMultiButton.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletMultiButton.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletMultiButton": () => (/* binding */ WalletMultiButton)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js");
/* harmony import */ var _useWalletModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useWalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js");
/* harmony import */ var _WalletConnectButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./WalletConnectButton */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletConnectButton.js");
/* harmony import */ var _WalletIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./WalletIcon */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js");
/* harmony import */ var _WalletModalButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./WalletModalButton */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalButton.js");
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};








const WalletMultiButton = _a => {
  var {
    children
  } = _a,
      props = __rest(_a, ["children"]);

  const {
    publicKey,
    wallet,
    disconnect
  } = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_6__.useWallet)();
  const {
    setVisible
  } = (0,_useWalletModal__WEBPACK_IMPORTED_MODULE_2__.useWalletModal)();
  const {
    0: copied,
    1: setCopied
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: active,
    1: setActive
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const base58 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => publicKey === null || publicKey === void 0 ? void 0 : publicKey.toBase58(), [publicKey]);
  const content = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    if (children) return children;
    if (!wallet || !base58) return null;
    return base58.slice(0, 4) + '..' + base58.slice(-4);
  }, [children, wallet, base58]);
  const copyAddress = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => __awaiter(void 0, void 0, void 0, function* () {
    if (base58) {
      yield navigator.clipboard.writeText(base58);
      setCopied(true);
      setTimeout(() => setCopied(false), 400);
    }
  }), [base58]);
  const openDropdown = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => setActive(true), [setActive]);
  const closeDropdown = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => setActive(false), [setActive]);
  const openModal = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    setVisible(true);
    closeDropdown();
  }, [setVisible, closeDropdown]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const listener = event => {
      const node = ref.current; // Do nothing if clicking dropdown or its descendants

      if (!node || node.contains(event.target)) return;
      closeDropdown();
    };

    document.addEventListener('mousedown', listener);
    document.addEventListener('touchstart', listener);
    return () => {
      document.removeEventListener('mousedown', listener);
      document.removeEventListener('touchstart', listener);
    };
  }, [ref, closeDropdown]);
  if (!wallet) return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletModalButton__WEBPACK_IMPORTED_MODULE_5__.WalletModalButton, Object.assign({}, props), children);
  if (!base58) return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletConnectButton__WEBPACK_IMPORTED_MODULE_3__.WalletConnectButton, Object.assign({}, props), children);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    className: "wallet-adapter-dropdown"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, Object.assign({
    "aria-expanded": active,
    className: "wallet-adapter-button-trigger",
    style: Object.assign({
      pointerEvents: active ? 'none' : 'auto'
    }, props.style),
    onClick: openDropdown,
    startIcon: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletIcon__WEBPACK_IMPORTED_MODULE_4__.WalletIcon, {
      wallet: wallet
    })
  }, props), content), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", {
    "aria-label": "dropdown-list",
    className: `wallet-adapter-dropdown-list ${active && 'wallet-adapter-dropdown-list-active'}`,
    ref: ref,
    role: "menu"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", {
    onClick: copyAddress,
    className: "wallet-adapter-dropdown-list-item",
    role: "menuitem"
  }, copied ? 'Copied' : 'Copy address'), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", {
    onClick: openModal,
    className: "wallet-adapter-dropdown-list-item",
    role: "menuitem"
  }, "Connect a different wallet"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", {
    onClick: disconnect,
    className: "wallet-adapter-dropdown-list-item",
    role: "menuitem"
  }, "Disconnect")));
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/index.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/index.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _useWalletModal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./useWalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useWalletModal__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useWalletModal__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletConnectButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WalletConnectButton */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletConnectButton.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletConnectButton__WEBPACK_IMPORTED_MODULE_1__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletConnectButton__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModal.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletModal__WEBPACK_IMPORTED_MODULE_2__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletModal__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletModalButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./WalletModalButton */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalButton.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletModalButton__WEBPACK_IMPORTED_MODULE_3__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletModalButton__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletModalProvider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./WalletModalProvider */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalProvider.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletModalProvider__WEBPACK_IMPORTED_MODULE_4__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletModalProvider__WEBPACK_IMPORTED_MODULE_4__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletDisconnectButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./WalletDisconnectButton */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletDisconnectButton.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletDisconnectButton__WEBPACK_IMPORTED_MODULE_5__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletDisconnectButton__WEBPACK_IMPORTED_MODULE_5__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./WalletIcon */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletIcon__WEBPACK_IMPORTED_MODULE_6__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletIcon__WEBPACK_IMPORTED_MODULE_6__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletMultiButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./WalletMultiButton */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletMultiButton.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletMultiButton__WEBPACK_IMPORTED_MODULE_7__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletMultiButton__WEBPACK_IMPORTED_MODULE_7__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);









/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletModalContext": () => (/* binding */ WalletModalContext),
/* harmony export */   "useWalletModal": () => (/* binding */ useWalletModal)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const WalletModalContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
function useWalletModal() {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(WalletModalContext);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/ConnectionProvider.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/ConnectionProvider.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConnectionProvider": () => (/* binding */ ConnectionProvider)
/* harmony export */ });
/* harmony import */ var _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @solana/web3.js */ "@solana/web3.js");
/* harmony import */ var _solana_web3_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_solana_web3_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _useConnection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useConnection */ "./node_modules/@solana/wallet-adapter-react/lib/useConnection.js");



const ConnectionProvider = ({
  children,
  endpoint,
  config = {
    commitment: 'confirmed'
  }
}) => {
  const connection = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => new _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__.Connection(endpoint, config), [endpoint, config]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_useConnection__WEBPACK_IMPORTED_MODULE_2__.ConnectionContext.Provider, {
    value: {
      connection
    }
  }, children);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/WalletProvider.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/WalletProvider.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletProvider": () => (/* binding */ WalletProvider)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @solana/wallet-adapter-base */ "./node_modules/@solana/wallet-adapter-base/lib/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./errors */ "./node_modules/@solana/wallet-adapter-react/lib/errors.js");
/* harmony import */ var _useLocalStorage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./useLocalStorage */ "./node_modules/@solana/wallet-adapter-react/lib/useLocalStorage.js");
/* harmony import */ var _useWallet__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./useWallet */ "./node_modules/@solana/wallet-adapter-react/lib/useWallet.js");
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};






const initialState = {
  wallet: null,
  adapter: null,
  ready: false,
  publicKey: null,
  connected: false
};
const WalletProvider = ({
  children,
  wallets,
  autoConnect = false,
  onError: _onError = error => console.error(error),
  localStorageKey = 'walletName'
}) => {
  const [name, setName] = (0,_useLocalStorage__WEBPACK_IMPORTED_MODULE_1__.useLocalStorage)(localStorageKey, null);
  const {
    0: {
      wallet,
      adapter,
      ready,
      publicKey,
      connected
    },
    1: setState
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialState);
  const {
    0: connecting,
    1: setConnecting
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: disconnecting,
    1: setDisconnecting
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const isConnecting = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
  const isDisconnecting = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
  const isUnloading = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false); // Map of wallet names to wallets

  const walletsByName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => wallets.reduce((walletsByName, wallet) => {
    walletsByName[wallet.name] = wallet;
    return walletsByName;
  }, {}), [wallets]); // When the selected wallet changes, initialize the state

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const wallet = name && walletsByName[name] || null;
    const adapter = wallet && wallet.adapter();

    if (adapter) {
      const {
        ready,
        publicKey,
        connected
      } = adapter;
      setState({
        wallet,
        adapter,
        connected,
        publicKey,
        ready
      });
    } else {
      setState(initialState);
    }
  }, [name, walletsByName, setState]); // If autoConnect is enabled, try to connect when the adapter changes and is ready

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (isConnecting.current || connecting || connected || !autoConnect || !adapter || !ready) return;

    (function () {
      return __awaiter(this, void 0, void 0, function* () {
        isConnecting.current = true;
        setConnecting(true);

        try {
          yield adapter.connect();
        } catch (error) {
          // Clear the selected wallet
          setName(null); // Don't throw error, but onError will still be called
        } finally {
          setConnecting(false);
          isConnecting.current = false;
        }
      });
    })();
  }, [isConnecting, connecting, connected, autoConnect, adapter, ready, setConnecting, setName]); // If the window is closing or reloading, ignore disconnect and error events from the adapter

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    function listener() {
      isUnloading.current = true;
    }

    window.addEventListener('beforeunload', listener);
    return () => window.removeEventListener('beforeunload', listener);
  }, [isUnloading]); // Select a wallet by name

  const select = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(newName => __awaiter(void 0, void 0, void 0, function* () {
    if (name === newName) return;
    if (adapter) yield adapter.disconnect();
    setName(newName);
  }), [name, adapter, setName]); // Handle the adapter's ready event

  const onReady = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => setState(state => Object.assign(Object.assign({}, state), {
    ready: true
  })), [setState]); // Handle the adapter's connect event

  const onConnect = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    if (!adapter) return;
    const {
      connected,
      publicKey,
      ready
    } = adapter;
    setState(state => Object.assign(Object.assign({}, state), {
      connected,
      publicKey,
      ready
    }));
  }, [adapter, setState]); // Handle the adapter's disconnect event

  const onDisconnect = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    // Clear the selected wallet unless the window is unloading
    if (!isUnloading.current) setName(null);
  }, [isUnloading, setName]); // Handle the adapter's error event, and local errors

  const onError = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(error => {
    // Call the provided error handler unless the window is unloading
    if (!isUnloading.current) _onError(error);
    return error;
  }, [isUnloading, _onError]); // Connect the adapter to the wallet

  const connect = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => __awaiter(void 0, void 0, void 0, function* () {
    if (isConnecting.current || connecting || disconnecting || connected) return;
    if (!wallet || !adapter) throw onError(new _errors__WEBPACK_IMPORTED_MODULE_2__.WalletNotSelectedError());

    if (!ready) {
      // Clear the selected wallet
      setName(null);

      if (false) {}

      throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotReadyError());
    }

    isConnecting.current = true;
    setConnecting(true);

    try {
      yield adapter.connect();
    } catch (error) {
      // Clear the selected wallet
      setName(null); // Rethrow the error, and onError will also be called

      throw error;
    } finally {
      setConnecting(false);
      isConnecting.current = false;
    }
  }), [isConnecting, connecting, disconnecting, connected, wallet, adapter, onError, ready, setConnecting, setName]); // Disconnect the adapter from the wallet

  const disconnect = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => __awaiter(void 0, void 0, void 0, function* () {
    if (isDisconnecting.current || disconnecting) return;
    if (!adapter) return setName(null);
    isDisconnecting.current = true;
    setDisconnecting(true);

    try {
      yield adapter.disconnect();
    } catch (error) {
      // Clear the selected wallet
      setName(null); // Rethrow the error, and onError will also be called

      throw error;
    } finally {
      setDisconnecting(false);
      isDisconnecting.current = false;
    }
  }), [isDisconnecting, disconnecting, adapter, setDisconnecting, setName]); // Send a transaction using the provided connection

  const sendTransaction = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((transaction, connection, options) => __awaiter(void 0, void 0, void 0, function* () {
    if (!adapter) throw onError(new _errors__WEBPACK_IMPORTED_MODULE_2__.WalletNotSelectedError());
    if (!connected) throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotConnectedError());
    return yield adapter.sendTransaction(transaction, connection, options);
  }), [adapter, onError, connected]); // Sign a transaction if the wallet supports it

  const signTransaction = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => adapter && 'signTransaction' in adapter ? transaction => __awaiter(void 0, void 0, void 0, function* () {
    if (!connected) throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotConnectedError());
    return yield adapter.signTransaction(transaction);
  }) : undefined, [adapter, onError, connected]); // Sign multiple transactions if the wallet supports it

  const signAllTransactions = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => adapter && 'signAllTransactions' in adapter ? transactions => __awaiter(void 0, void 0, void 0, function* () {
    if (!connected) throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotConnectedError());
    return yield adapter.signAllTransactions(transactions);
  }) : undefined, [adapter, onError, connected]); // Sign an arbitrary message if the wallet supports it

  const signMessage = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => adapter && 'signMessage' in adapter ? message => __awaiter(void 0, void 0, void 0, function* () {
    if (!connected) throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotConnectedError());
    return yield adapter.signMessage(message);
  }) : undefined, [adapter, onError, connected]); // Setup and teardown event listeners when the adapter changes

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (adapter) {
      adapter.on('ready', onReady);
      adapter.on('connect', onConnect);
      adapter.on('disconnect', onDisconnect);
      adapter.on('error', onError);
      return () => {
        adapter.off('ready', onReady);
        adapter.off('connect', onConnect);
        adapter.off('disconnect', onDisconnect);
        adapter.off('error', onError);
      };
    }
  }, [adapter, onReady, onConnect, onDisconnect, onError]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_useWallet__WEBPACK_IMPORTED_MODULE_4__.WalletContext.Provider, {
    value: {
      wallets,
      autoConnect,
      wallet,
      adapter,
      publicKey,
      ready,
      connected,
      connecting,
      disconnecting,
      select,
      connect,
      disconnect,
      sendTransaction,
      signTransaction,
      signAllTransactions,
      signMessage
    }
  }, children);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/errors.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/errors.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletNotSelectedError": () => (/* binding */ WalletNotSelectedError)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @solana/wallet-adapter-base */ "./node_modules/@solana/wallet-adapter-base/lib/index.js");

class WalletNotSelectedError extends _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_0__.WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotSelectedError';
  }

}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/index.js":
/*!****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/index.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ConnectionProvider__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ConnectionProvider */ "./node_modules/@solana/wallet-adapter-react/lib/ConnectionProvider.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _ConnectionProvider__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _ConnectionProvider__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors */ "./node_modules/@solana/wallet-adapter-react/lib/errors.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _errors__WEBPACK_IMPORTED_MODULE_1__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _errors__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _useAnchorWallet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useAnchorWallet */ "./node_modules/@solana/wallet-adapter-react/lib/useAnchorWallet.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useAnchorWallet__WEBPACK_IMPORTED_MODULE_2__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useAnchorWallet__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _useConnection__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./useConnection */ "./node_modules/@solana/wallet-adapter-react/lib/useConnection.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useConnection__WEBPACK_IMPORTED_MODULE_3__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useConnection__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _useLocalStorage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./useLocalStorage */ "./node_modules/@solana/wallet-adapter-react/lib/useLocalStorage.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useLocalStorage__WEBPACK_IMPORTED_MODULE_4__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useLocalStorage__WEBPACK_IMPORTED_MODULE_4__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _useWallet__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./useWallet */ "./node_modules/@solana/wallet-adapter-react/lib/useWallet.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useWallet__WEBPACK_IMPORTED_MODULE_5__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useWallet__WEBPACK_IMPORTED_MODULE_5__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletProvider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./WalletProvider */ "./node_modules/@solana/wallet-adapter-react/lib/WalletProvider.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletProvider__WEBPACK_IMPORTED_MODULE_6__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletProvider__WEBPACK_IMPORTED_MODULE_6__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);








/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/useAnchorWallet.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/useAnchorWallet.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useAnchorWallet": () => (/* binding */ useAnchorWallet)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _useWallet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./useWallet */ "./node_modules/@solana/wallet-adapter-react/lib/useWallet.js");


function useAnchorWallet() {
  const {
    publicKey,
    signTransaction,
    signAllTransactions
  } = (0,_useWallet__WEBPACK_IMPORTED_MODULE_1__.useWallet)();
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => publicKey && signTransaction && signAllTransactions ? {
    publicKey,
    signTransaction,
    signAllTransactions
  } : undefined, [publicKey, signTransaction, signAllTransactions]);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/useConnection.js":
/*!************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/useConnection.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConnectionContext": () => (/* binding */ ConnectionContext),
/* harmony export */   "useConnection": () => (/* binding */ useConnection)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const ConnectionContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
function useConnection() {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(ConnectionContext);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/useLocalStorage.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/useLocalStorage.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useLocalStorage": () => (/* binding */ useLocalStorage)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useLocalStorage(key, defaultState) {
  const {
    0: value,
    1: setValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => {
    if (typeof localStorage === 'undefined') return defaultState;
    const value = localStorage.getItem(key);

    try {
      return value ? JSON.parse(value) : defaultState;
    } catch (error) {
      console.warn(error);
      return defaultState;
    }
  });
  const setLocalStorage = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(newValue => {
    if (newValue === value) return;
    setValue(newValue);

    if (newValue === null) {
      localStorage.removeItem(key);
    } else {
      try {
        localStorage.setItem(key, JSON.stringify(newValue));
      } catch (error) {
        console.error(error);
      }
    }
  }, [value, setValue, key]);
  return [value, setLocalStorage];
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/useWallet.js":
/*!********************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/useWallet.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletContext": () => (/* binding */ WalletContext),
/* harmony export */   "useWallet": () => (/* binding */ useWallet)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const WalletContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
function useWallet() {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(WalletContext);
}

/***/ }),

/***/ "./node_modules/next/link.js":
/*!***********************************!*\
  !*** ./node_modules/next/link.js ***!
  \***********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(/*! ./dist/client/link */ "./node_modules/next/dist/client/link.js")


/***/ }),

/***/ "@metaplex/js":
/*!*******************************!*\
  !*** external "@metaplex/js" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = require("@metaplex/js");

/***/ }),

/***/ "@project-serum/anchor":
/*!****************************************!*\
  !*** external "@project-serum/anchor" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@project-serum/anchor");

/***/ }),

/***/ "@solana/spl-token":
/*!************************************!*\
  !*** external "@solana/spl-token" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@solana/spl-token");

/***/ }),

/***/ "@solana/web3.js":
/*!**********************************!*\
  !*** external "@solana/web3.js" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@solana/web3.js");

/***/ }),

/***/ "eventemitter3":
/*!********************************!*\
  !*** external "eventemitter3" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("eventemitter3");

/***/ }),

/***/ "../../../server/denormalize-page-path":
/*!************************************************************!*\
  !*** external "next/dist/server/denormalize-page-path.js" ***!
  \************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ "../i18n/normalize-locale-path":
/*!*********************************************************************!*\
  !*** external "next/dist/shared/lib/i18n/normalize-locale-path.js" ***!
  \*********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ "../mitt":
/*!***********************************************!*\
  !*** external "next/dist/shared/lib/mitt.js" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ "../shared/lib/router-context":
/*!*********************************************************!*\
  !*** external "next/dist/shared/lib/router-context.js" ***!
  \*********************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ "../shared/lib/router/utils/get-asset-path-from-route":
/*!*********************************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/get-asset-path-from-route.js" ***!
  \*********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ "./utils/is-dynamic":
/*!******************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/is-dynamic.js" ***!
  \******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ "./utils/parse-relative-url":
/*!**************************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/parse-relative-url.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ "./utils/querystring":
/*!*******************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/querystring.js" ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ "./utils/route-matcher":
/*!*********************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/route-matcher.js" ***!
  \*********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ "./utils/route-regex":
/*!*******************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/route-regex.js" ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ "../shared/lib/utils":
/*!************************************************!*\
  !*** external "next/dist/shared/lib/utils.js" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-is":
/*!***************************!*\
  !*** external "react-is" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-is");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ "react-slick":
/*!******************************!*\
  !*** external "react-slick" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-slick");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "reactstrap":
/*!*****************************!*\
  !*** external "reactstrap" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("reactstrap");

/***/ }),

/***/ "recharts":
/*!***************************!*\
  !*** external "recharts" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("recharts");

/***/ }),

/***/ "?5c99":
/*!******************************************!*\
  !*** ./utils/resolve-rewrites (ignored) ***!
  \******************************************/
/***/ (() => {

/* (ignored) */

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/dashboard.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvZGFzaGJvYXJkLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFJQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOzs7O0FBUUEsU0FBU00sZUFBVCxDQUF5QkMsS0FBekIsRUFBMkM7QUFDdkMsUUFBTUMsUUFBUSxHQUFHSCx3REFBVyxFQUE1QjtBQUNBLFFBQU1JLE1BQU0sR0FBR0YsS0FBSyxDQUFDRyxPQUFyQjtBQUNGLFFBQU1DLE1BQU0sR0FBR1IsdUVBQVMsRUFBeEI7QUFDQSxRQUFNLENBQUNTLFNBQUQsRUFBV0MsSUFBWCxFQUFpQkMsV0FBakIsSUFBZ0NWLDZEQUFhLENBQUNHLEtBQUQsQ0FBbkQ7QUFDRSxRQUFNUSxZQUFZLEdBQUdkLDhDQUFPLENBQUMsTUFBTTtBQUNqQyxRQUNFLENBQUNVLE1BQUQsSUFDQSxDQUFDQSxNQUFNLENBQUNLLFNBRFIsSUFFQSxDQUFDTCxNQUFNLENBQUNNLG1CQUZSLElBR0EsQ0FBQ04sTUFBTSxDQUFDTyxlQUpWLEVBS0U7QUFDQTtBQUNEOztBQUVELFdBQU87QUFDTEYsTUFBQUEsU0FBUyxFQUFFTCxNQUFNLENBQUNLLFNBRGI7QUFFTEMsTUFBQUEsbUJBQW1CLEVBQUVOLE1BQU0sQ0FBQ00sbUJBRnZCO0FBR0xDLE1BQUFBLGVBQWUsRUFBRVAsTUFBTSxDQUFDTztBQUhuQixLQUFQO0FBS0QsR0FmMkIsRUFlekIsQ0FBQ1AsTUFBRCxDQWZ5QixDQUE1QjtBQWlCRlgsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ2QsS0FBQyxZQUFZO0FBR1gsVUFBSSxDQUFDZSxZQUFMLEVBQW1CO0FBQ2pCSSxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaO0FBQ0FaLFFBQUFBLFFBQVEsQ0FBQztBQUNQYSxVQUFBQSxJQUFJLEVBQUUsV0FEQztBQUVQQyxVQUFBQSxPQUFPLEVBQUU7QUFGRixTQUFELENBQVI7QUFJQWQsUUFBQUEsUUFBUSxDQUFDO0FBQ1BhLFVBQUFBLElBQUksRUFBRSxRQURDO0FBRVBDLFVBQUFBLE9BQU8sRUFBRTtBQUZGLFNBQUQsQ0FBUjtBQUtHO0FBQ0QsT0FmTyxDQWdCVDs7O0FBQ0MsVUFBSVAsWUFBSixhQUFJQSxZQUFKLGVBQUlBLFlBQVksQ0FBRUMsU0FBbEIsRUFBNkI7QUFBQTs7QUFDM0JSLFFBQUFBLFFBQVEsQ0FBQztBQUNQYSxVQUFBQSxJQUFJLEVBQUUsV0FEQztBQUVQQyxVQUFBQSxPQUFPLEVBQUVQLFlBQUYsYUFBRUEsWUFBRixnREFBRUEsWUFBWSxDQUFFQyxTQUFoQiwwREFBRSxzQkFBeUJPLFFBQXpCO0FBRkYsU0FBRCxDQUFSO0FBSUQ7O0FBR0QsVUFBSWhCLEtBQUssU0FBTCxJQUFBQSxLQUFLLFdBQUwsSUFBQUEsS0FBSyxDQUFFaUIsVUFBUCxJQUFxQlQsWUFBckIsYUFBcUJBLFlBQXJCLGVBQXFCQSxZQUFZLENBQUVDLFNBQXZDLEVBQWtEO0FBQ2hELGNBQU1TLFlBQVksR0FBRyxNQUFNdkIsb0VBQWUsQ0FDeENLLEtBQUssQ0FBQ2lCLFVBRGtDLEVBRXhDVCxZQUZ3QyxhQUV4Q0EsWUFGd0MsdUJBRXhDQSxZQUFZLENBQUVDLFNBRjBCLENBQTFDO0FBS0FHLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSyxZQUFaLEVBQTBCLGNBQTFCO0FBQ0QsT0FoQ08sQ0FrQ1I7O0FBR0QsS0FyQ0o7QUFzQ0UsR0F2Q0ssRUF1Q0gsQ0FBQ1YsWUFBRCxFQUFlUixLQUFLLENBQUNtQixjQUFyQixFQUFxQ25CLEtBQUssQ0FBQ2lCLFVBQTNDLENBdkNHLENBQVQ7QUF5Q0F4QixFQUFBQSxnREFBUyxDQUFDLE1BQU07QUFDZCxRQUFJYSxJQUFKLEVBQVU7QUFDUkwsTUFBQUEsUUFBUSxDQUFDO0FBQ1BhLFFBQUFBLElBQUksRUFBRSxRQURDO0FBRVBDLFFBQUFBLE9BQU8sRUFBRVQ7QUFGRixPQUFELENBQVIsQ0FEUSxDQUtSO0FBQ0Q7QUFDRixHQVJRLEVBUVAsQ0FBQ0EsSUFBRCxDQVJPLENBQVQ7QUFZQSxzQkFBTyw2SUFBUDtBQUNEOztBQUVELGlFQUFlUCxlQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9GQTtBQUNBOztBQWFBLE1BQU1nQyxJQUFJLEdBQUcsQ0FDWDtBQUNFQyxFQUFBQSxJQUFJLEVBQUUsT0FEUjtBQUVFQyxFQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFQyxFQUFBQSxLQUFLLEVBQUU7QUFIVCxDQURXLEVBTVg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLE9BRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0FOVyxFQVdYO0FBQ0VGLEVBQUFBLElBQUksRUFBRSxPQURSO0FBRUVDLEVBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0VDLEVBQUFBLEtBQUssRUFBRTtBQUhULENBWFcsRUFnQlg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLE9BRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0FoQlcsRUFxQlg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLE9BRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0FyQlcsRUEwQlg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLE9BRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0ExQlcsRUErQlg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLE9BRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0EvQlcsRUFvQ1g7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLE9BRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0FwQ1csRUF5Q1g7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLE9BRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0F6Q1csRUE4Q1g7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0E5Q1csRUFtRFg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0FuRFcsRUF3RFg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0F4RFcsRUE2RFg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0E3RFcsRUFrRVg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0FsRVcsRUF1RVg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0F2RVcsRUE0RVg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0E1RVcsRUFpRlg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0FqRlcsRUFzRlg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0F0RlcsRUEyRlg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0EzRlcsRUFnR1g7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0FoR1csRUFxR1g7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0FyR1csRUEwR1g7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0ExR1csRUErR1g7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0EvR1csRUFvSFg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0FwSFcsRUF5SFg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0F6SFcsRUE4SFg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0E5SFcsRUFtSVg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0FuSVcsRUF3SVg7QUFDRUYsRUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRUMsRUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUMsRUFBQUEsS0FBSyxFQUFFO0FBSFQsQ0F4SVcsQ0FBYjtBQThJQSxNQUFNQyxTQUFTLEdBQUc7QUFDaEJDLEVBQUFBLGVBQWUsRUFBRSxTQUREO0FBRWhCQyxFQUFBQSxLQUFLLEVBQUU7QUFGUyxDQUFsQjs7QUFJQSxNQUFNQyxnQkFBZ0IsR0FBRyxNQUFNO0FBQzdCLFFBQU07QUFBRUYsSUFBQUEsZUFBRjtBQUFtQkMsSUFBQUE7QUFBbkIsTUFBNkJGLFNBQW5DO0FBQ0EsU0FBTztBQUNMSSxJQUFBQSxZQUFZLEVBQUU7QUFBRUgsTUFBQUE7QUFBRixLQURUO0FBRUxJLElBQUFBLFNBQVMsRUFBRTtBQUFFSCxNQUFBQTtBQUFGO0FBRk4sR0FBUDtBQUlELENBTkQ7O0FBT0EsU0FBU0ksVUFBVCxHQUFzQjtBQUNwQixzQkFDRTtBQUFLLGFBQVMsRUFBQyxrQkFBZjtBQUFBLDJCQUNFLDhEQUFDLHlEQUFEO0FBQXFCLFlBQU0sRUFBRSxHQUE3QjtBQUFrQyxlQUFTLEVBQUMsaUJBQTVDO0FBQUEsNkJBQ0UsOERBQUMsK0NBQUQ7QUFBVyxZQUFJLEVBQUVWLElBQWpCO0FBQXVCLGNBQU0sRUFBRTtBQUFFVyxVQUFBQSxHQUFHLEVBQUUsRUFBUDtBQUFXQyxVQUFBQSxJQUFJLEVBQUUsQ0FBQyxFQUFsQjtBQUFzQkMsVUFBQUEsTUFBTSxFQUFFO0FBQTlCLFNBQS9CO0FBQUEsZ0NBQ0U7QUFBQSxrQ0FDRTtBQUFnQixjQUFFLEVBQUMsU0FBbkI7QUFBNkIsY0FBRSxFQUFDLEdBQWhDO0FBQW9DLGNBQUUsRUFBQyxHQUF2QztBQUEyQyxjQUFFLEVBQUMsR0FBOUM7QUFBa0QsY0FBRSxFQUFDLEdBQXJEO0FBQUEsb0NBQ0U7QUFBTSxvQkFBTSxFQUFDLElBQWI7QUFBa0IsdUJBQVMsRUFBQyxTQUE1QjtBQUFzQyx5QkFBVyxFQUFFO0FBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFFRTtBQUFNLG9CQUFNLEVBQUMsS0FBYjtBQUFtQix1QkFBUyxFQUFDLFNBQTdCO0FBQXVDLHlCQUFXLEVBQUU7QUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFLRTtBQUFnQixjQUFFLEVBQUMsU0FBbkI7QUFBNkIsY0FBRSxFQUFDLEdBQWhDO0FBQW9DLGNBQUUsRUFBQyxHQUF2QztBQUEyQyxjQUFFLEVBQUMsR0FBOUM7QUFBa0QsY0FBRSxFQUFDLEdBQXJEO0FBQUEsb0NBQ0U7QUFBTSxvQkFBTSxFQUFDLElBQWI7QUFBa0IsdUJBQVMsRUFBQyxTQUE1QjtBQUFzQyx5QkFBVyxFQUFFO0FBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFFRTtBQUFNLG9CQUFNLEVBQUMsS0FBYjtBQUFtQix1QkFBUyxFQUFDLFNBQTdCO0FBQXVDLHlCQUFXLEVBQUU7QUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBV0UsOERBQUMsMkNBQUQ7QUFBTyxpQkFBTyxFQUFDLE1BQWY7QUFBc0Isa0JBQVEsRUFBRTtBQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVhGLGVBWUUsOERBQUMsMkNBQUQ7QUFBTyxrQkFBUSxFQUFFO0FBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWkYsZUFhRSw4REFBQyw2Q0FBRCxvQkFBYU4sZ0JBQWdCLEVBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBYkYsZUFjRSw4REFBQyw0Q0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWRGLGVBZUUsOERBQUMsbURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFmRixlQWdCRSw4REFBQywwQ0FBRDtBQUNFLGNBQUksRUFBQyxPQURQO0FBRUUsY0FBSSxFQUFDLFVBRlA7QUFHRSxpQkFBTyxFQUFDLE9BSFY7QUFJRSxnQkFBTSxFQUFDLFNBSlQ7QUFLRSxxQkFBVyxFQUFFLENBTGY7QUFNRSxjQUFJLEVBQUM7QUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWhCRixlQXdCRSw4REFBQywwQ0FBRDtBQUNFLGNBQUksRUFBQyxTQURQO0FBRUUsY0FBSSxFQUFDLFVBRlA7QUFHRSxpQkFBTyxFQUFDLFNBSFY7QUFJRSxnQkFBTSxFQUFDLFNBSlQ7QUFLRSxxQkFBVyxFQUFFLENBTGY7QUFNRSxjQUFJLEVBQUM7QUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBdUNEOztBQUVELGlFQUFlRyxVQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqTkE7QUFFQTs7O0FBQ0EsU0FBU0ssWUFBVCxHQUF3QjtBQUNwQixzQkFDRTtBQUFLLGFBQVMsRUFBQyxZQUFmO0FBQUEsMkJBQ0U7QUFBQSw4QkFDRTtBQUFJLGlCQUFTLEVBQUMsa0RBQWQ7QUFBQSw0Q0FDVTtBQUFNLG1CQUFTLEVBQUMsbUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBS0U7QUFBRyxpQkFBUyxFQUFDLGVBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FMRixlQVFFO0FBQUssaUJBQVMsRUFBQyxRQUFmO0FBQUEsK0JBQ0UsOERBQUMsOEVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBZ0JIOztBQUVELGlFQUFlQSxZQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEJBO0FBQ0E7O0FBR0EsTUFBTUcsTUFBTSxHQUFHLENBQ2I7QUFBRUMsRUFBQUEsS0FBSyxFQUFFLEVBQVQ7QUFBYUMsRUFBQUEsSUFBSSxFQUFFO0FBQW5CLENBRGEsRUFFYjtBQUFFRCxFQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxFQUFBQSxJQUFJLEVBQUU7QUFBbkIsQ0FGYSxDQUFmO0FBS0EsTUFBTUMsTUFBTSxHQUFHLENBQ2I7QUFBRUYsRUFBQUEsS0FBSyxFQUFFLEVBQVQ7QUFBYUMsRUFBQUEsSUFBSSxFQUFFO0FBQW5CLENBRGEsRUFFYjtBQUFFRCxFQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxFQUFBQSxJQUFJLEVBQUU7QUFBbkIsQ0FGYSxDQUFmOztBQUtBLE1BQU1FLFdBQVcsR0FBRyxNQUFNO0FBRXhCLHNCQUNFO0FBQUssYUFBUyxFQUFDLCtDQUFmO0FBQUEsMkJBQ0U7QUFBSyxlQUFTLEVBQUMsNENBQWY7QUFBQSw4QkFDRTtBQUFJLGlCQUFTLEVBQUMsb0RBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFJRTtBQUFLLGlCQUFTLEVBQUMsZ0JBQWY7QUFBQSxnQ0FDRTtBQUFLLG1CQUFTLEVBQUMsdURBQWY7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMsaUJBQWY7QUFBQSxtQ0FDRSw4REFBQyw4Q0FBRDtBQUFVLG9CQUFNLEVBQUUsR0FBbEI7QUFBdUIsbUJBQUssRUFBRSxHQUE5QjtBQUFBLHFDQUNFLDhEQUFDLHlDQUFEO0FBQ0Usb0JBQUksRUFBRUosTUFEUjtBQUVFLHVCQUFPLEVBQUMsT0FGVjtBQUdFLGtCQUFFLEVBQUUsRUFITjtBQUlFLGtCQUFFLEVBQUUsRUFKTjtBQUtFLDJCQUFXLEVBQUUsRUFMZjtBQU1FLDJCQUFXLEVBQUU7QUFOZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFtQkU7QUFBSyxxQkFBUyxFQUFDLHlCQUFmO0FBQUEsb0NBQ0U7QUFBRyx1QkFBUyxFQUFDLDBCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBRUU7QUFBRyx1QkFBUyxFQUFDLGVBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUF5QkU7QUFBSyxtQkFBUyxFQUFDLDBDQUFmO0FBQUEsa0NBQ0U7QUFBSyxxQkFBUyxFQUFDLGlCQUFmO0FBQUEsbUNBQ0UsOERBQUMsOENBQUQ7QUFBVSxvQkFBTSxFQUFFLEdBQWxCO0FBQXVCLG1CQUFLLEVBQUUsR0FBOUI7QUFBQSxxQ0FDRSw4REFBQyx5Q0FBRDtBQUNFLG9CQUFJLEVBQUVHLE1BRFI7QUFFRSx1QkFBTyxFQUFDLE9BRlY7QUFHRSxrQkFBRSxFQUFFLEVBSE47QUFJRSxrQkFBRSxFQUFFLEVBSk47QUFLRSwyQkFBVyxFQUFFLEVBTGY7QUFNRSwyQkFBVyxFQUFFO0FBTmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBbUJFO0FBQUsscUJBQVMsRUFBQyx5QkFBZjtBQUFBLG9DQUNFO0FBQUcsdUJBQVMsRUFBQyxVQUFiO0FBQXdCLG1CQUFLLEVBQUU7QUFBRWYsZ0JBQUFBLEtBQUssRUFBRTtBQUFULGVBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBSUU7QUFBRyx1QkFBUyxFQUFDLGVBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKRixlQXdERTtBQUFLLGlCQUFTLEVBQUMsUUFBZjtBQUFBLCtCQUNFO0FBQUssbUJBQVMsRUFBQyxhQUFmO0FBQUEsa0NBQ0U7QUFBRyxxQkFBUyxFQUFDLDhEQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBSUU7QUFBRyxxQkFBUyxFQUFDLGVBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF4REY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBcUVELENBdkVEOztBQXlFQSxpRUFBZWdCLFdBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkZBOzs7QUFFQSxTQUFTQyxLQUFULEdBQWlCO0FBQ2Ysc0JBQ0U7QUFBSyxhQUFTLEVBQUMsaURBQWY7QUFBQSwyQkFDRTtBQUFLLGVBQVMsRUFBQywrQ0FBZjtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQyxnRUFBZjtBQUFBLGdDQUNFO0FBQUcsbUJBQVMsRUFBQyx3QkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFO0FBQUssbUJBQVMsRUFBQyxhQUFmO0FBQUEsa0NBQ0U7QUFBSyxpQkFBSyxFQUFFLEVBQVo7QUFBZ0IsZUFBRyxFQUFDO0FBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFFRTtBQUFNLHFCQUFTLEVBQUMsOENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQVFFO0FBQUssaUJBQVMsRUFBQyxnRUFBZjtBQUFBLGdDQUNFO0FBQUcsbUJBQVMsRUFBQyx3QkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFO0FBQUssbUJBQVMsRUFBQyxhQUFmO0FBQUEsa0NBQ0U7QUFBSyxpQkFBSyxFQUFFLEVBQVo7QUFBZ0IsZUFBRyxFQUFDO0FBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFFRTtBQUFNLHFCQUFTLEVBQUMsOENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FSRixlQWVFO0FBQUssaUJBQVMsRUFBQyxnRUFBZjtBQUFBLGdDQUNFO0FBQUcsbUJBQVMsRUFBQyx3QkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFO0FBQUssbUJBQVMsRUFBQyxhQUFmO0FBQUEsaUNBQ0U7QUFBTSxxQkFBUyxFQUFDLDhDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZkYsZUFxQkU7QUFBSyxpQkFBUyxFQUFDLGlDQUFmO0FBQUEsZ0NBQ0U7QUFBRyxtQkFBUyxFQUFDLHdCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUU7QUFBSyxtQkFBUyxFQUFDLGFBQWY7QUFBQSxpQ0FDRTtBQUFNLHFCQUFTLEVBQUMsOENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBZ0NEOztBQUVELGlFQUFlQSxLQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDckNBO0FBQ0E7OztBQUlBLFNBQVNFLFNBQVQsR0FBcUI7QUFFbkIsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsc0NBQWY7QUFBQSwyQkFDRTtBQUFLLGVBQVMsRUFBQyx3Q0FBZjtBQUFBLDhCQUNFO0FBQUksaUJBQVMsRUFBQyxvREFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBSUU7QUFBRyxpQkFBUyxFQUFDLG9EQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSkYsZUFPRTtBQUFHLGlCQUFTLEVBQUMsaURBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FQRixlQVFFO0FBQUssaUJBQVMsRUFBQyxnQkFBZjtBQUFBLGdDQUNFO0FBQUssbUJBQVMsRUFBQyxFQUFmO0FBQUEsaUNBQ0UsOERBQUMsZ0RBQUQ7QUFBVSxpQkFBSyxFQUFDLFNBQWhCO0FBQTBCLHFCQUFTLEVBQUMsY0FBcEM7QUFBbUQsaUJBQUssRUFBQyxJQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFNRTtBQUFLLG1CQUFTLEVBQUMsc0NBQWY7QUFBQSxrQ0FDRTtBQUFBLG9DQUNFO0FBQUcsdUJBQVMsRUFBQyxvQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQUVFO0FBQUcsdUJBQVMsRUFBQyw4QkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFLRTtBQUFBLG9DQUNFO0FBQUcsdUJBQVMsRUFBQywwQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQUVFO0FBQUcsdUJBQVMsRUFBQyx5QkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQThCRDs7QUFBQTtBQUNELGlFQUFlQSxTQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU0csU0FBVCxDQUFtQjNELEtBQW5CLEVBQTBCO0FBRXhCLFFBQU07QUFBRVMsSUFBQUEsU0FBRjtBQUFhbUQsSUFBQUE7QUFBYixNQUFpQ2hFLHVFQUFTLEVBQWhEOztBQUNFLE1BQUksQ0FBQ2EsU0FBTCxFQUFnQjtBQUNaLHdCQUNFO0FBQUEsNkJBQ0UsOERBQUMsa0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQUtILEdBTkQsTUFPSztBQUNELHdCQUNFO0FBQVMsZUFBUyxFQUFDLFlBQW5CO0FBQUEsOEJBQ0UsOERBQUMsNENBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBR0U7QUFBSyxpQkFBUyxFQUFDLHVDQUFmO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLG9EQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBSUUsOERBQUMsaURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FIRixlQVNFO0FBQUssaUJBQVMsRUFBQyxpREFBZjtBQUFBLGdDQUNFLDhEQUFDLCtDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFFRSw4REFBQyxpREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVRGLGVBYUU7QUFBSyxpQkFBUyxFQUFDLHVDQUFmO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLG9EQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBSUUsOERBQUMsMkNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKRixlQUtFLDhEQUFDLCtDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUF1Qkg7QUFDSjs7QUFFRCxpRUFBZWtELFNBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOUNBOzs7QUFFQSxTQUFTRSxHQUFULENBQWE3RCxLQUFiLEVBQW9CO0FBQ2hCLHNCQUNFO0FBQUssYUFBUyxFQUFDLDJDQUFmO0FBQUEsMkJBQ0U7QUFBSyxlQUFTLEVBQUMsYUFBZjtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQyxRQUFmO0FBQUEsK0JBQ0U7QUFBSyxhQUFHLEVBQUVBLEtBQUssQ0FBQzhEO0FBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFJRTtBQUFLLGlCQUFTLEVBQUMsS0FBZjtBQUFBLCtCQUNFO0FBQUksbUJBQVMsRUFBQyxtQkFBZDtBQUFBLG9CQUFtQzlELEtBQUssQ0FBQ2dDO0FBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBYUg7O0FBRUQsaUVBQWU2QixHQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xCQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU0gsV0FBVCxHQUF1QjtBQUNyQixRQUFNO0FBQUVPLElBQUFBLElBQUY7QUFBUUMsSUFBQUEsU0FBUjtBQUFtQkMsSUFBQUE7QUFBbkIsTUFBZ0NKLHdEQUFXLENBQUVLLEtBQUQsS0FBWTtBQUM1REYsSUFBQUEsU0FBUyxFQUFFRSxLQUFLLENBQUNDLFdBQU4sQ0FBa0JILFNBRCtCO0FBRTVEQyxJQUFBQSxRQUFRLEVBQUVDLEtBQUssQ0FBQ0MsV0FBTixDQUFrQkY7QUFGZ0MsR0FBWixDQUFELENBQWpEO0FBSUUsUUFBTUcsUUFBUSxHQUFHO0FBQ2ZDLElBQUFBLElBQUksRUFBRSxJQURTO0FBRWZDLElBQUFBLFFBQVEsRUFBRSxLQUZLO0FBR2ZDLElBQUFBLEtBQUssRUFBRSxHQUhRO0FBSWZDLElBQUFBLFFBQVEsRUFBRSxJQUpLO0FBS2ZDLElBQUFBLFlBQVksRUFBRSxJQUxDO0FBTWZDLElBQUFBLGNBQWMsRUFBRSxDQU5EO0FBUWZDLElBQUFBLFVBQVUsRUFBRSxDQUNWO0FBQUVDLE1BQUFBLFVBQVUsRUFBRSxHQUFkO0FBQW1CUixNQUFBQSxRQUFRLEVBQUU7QUFBRVMsUUFBQUEsWUFBWSxFQUFFO0FBQWhCO0FBQTdCLEtBRFUsRUFFVjtBQUFFRCxNQUFBQSxVQUFVLEVBQUUsR0FBZDtBQUFtQlIsTUFBQUEsUUFBUSxFQUFFO0FBQUVTLFFBQUFBLFlBQVksRUFBRTtBQUFoQjtBQUE3QixLQUZVLEVBR1Y7QUFBRUQsTUFBQUEsVUFBVSxFQUFFLElBQWQ7QUFBb0JSLE1BQUFBLFFBQVEsRUFBRTtBQUFFUyxRQUFBQSxZQUFZLEVBQUU7QUFBaEI7QUFBOUIsS0FIVSxFQUlWO0FBQUVELE1BQUFBLFVBQVUsRUFBRSxNQUFkO0FBQXNCUixNQUFBQSxRQUFRLEVBQUU7QUFBRVMsUUFBQUEsWUFBWSxFQUFFO0FBQWhCO0FBQWhDLEtBSlU7QUFSRyxHQUFqQjtBQWVGLHNCQUNFO0FBQUssYUFBUyxFQUFDLEVBQWY7QUFBQSwyQkFDRSw4REFBQyxvREFBRCxrQ0FBWVQsUUFBWjtBQUFBLGdCQUNHSCxRQURILGFBQ0dBLFFBREgsdUJBQ0dBLFFBQVEsQ0FBRWEsR0FBVixDQUFlQyxJQUFELGlCQUNiO0FBQXNCLGlCQUFTLEVBQUMsS0FBaEM7QUFBc0MsYUFBSyxFQUFFO0FBQUNDLFVBQUFBLEtBQUssRUFBRTtBQUFSLFNBQTdDO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLEVBQWY7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMsUUFBZjtBQUFBLG1DQUNFO0FBQUssaUJBQUcsRUFBRUQsSUFBSSxDQUFDRSxLQUFmO0FBQXNCLGlCQUFHLEVBQUM7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFJRTtBQUFLLHFCQUFTLEVBQUMsMEJBQWY7QUFBQSxtQ0FDRTtBQUFJLHVCQUFTLEVBQUMsbUJBQWQ7QUFBQSx3QkFBbUNGLElBQUksQ0FBQ2pEO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFNBQVVpRCxJQUFJLENBQUNFLEtBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUREO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQWtCRDs7QUFFRCxpRUFBZXpCLFdBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU0QsTUFBVCxDQUFnQnpELEtBQWhCLEVBQXVCO0FBQ3JCLFFBQU07QUFBRVMsSUFBQUEsU0FBRjtBQUFhbUQsSUFBQUE7QUFBYixNQUFpQ2hFLHVFQUFTLEVBQWhEO0FBQ0Esc0JBQ0U7QUFBSyxhQUFTLEVBQUMsK0ZBQWY7QUFBQSw0QkFDRSw4REFBQyxxREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFFRTtBQUFJLGVBQVMsRUFBQywyRUFBZDtBQUFBLDhCQUNFO0FBQUksaUJBQVMsRUFBQyxpREFBZDtBQUFBLCtCQUNFLDhEQUFDLGtEQUFEO0FBQU0sY0FBSSxFQUFDLFlBQVg7QUFBQSxpQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFNRTtBQUFJLGlCQUFTLEVBQUMsaURBQWQ7QUFBQSwrQkFDRSw4REFBQyxrREFBRDtBQUFNLGNBQUksRUFBQyxVQUFYO0FBQUEsaUNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLEVBZUdhLFNBQVMsaUJBQ1I7QUFBSSxlQUFTLEVBQUMsK0ZBQWQ7QUFBQSw2QkFDRSw4REFBQyw4RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXVCRDs7QUFFRCxpRUFBZWdELE1BQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLE1BQU10RCxPQUFPLEdBQUdzRiwrQkFBaEI7QUFDQSxNQUFNeEUsVUFBVSxHQUFHLElBQUlzRSxrRUFBSixDQUEyQnBGLE9BQTNCLENBQW5COztBQUVBLE1BQU1OLGFBQWEsR0FBSUcsS0FBRCxJQUFnQjtBQUNwQyxRQUFNSSxNQUFNLEdBQUdSLHVFQUFTLEVBQXhCO0FBQ0EsUUFBTTtBQUFBLE9BQUNTLFNBQUQ7QUFBQSxPQUFZeUY7QUFBWixNQUE0QlIsK0NBQVEsQ0FBQyxLQUFELENBQTFDO0FBQ0EsUUFBTTtBQUFBLE9BQUMvRSxXQUFEO0FBQUEsT0FBY3dGO0FBQWQsTUFBOEJULCtDQUFRLENBQUMsS0FBRCxDQUE1QztBQUVBLFFBQU07QUFBQSxPQUFDaEYsSUFBRDtBQUFBLE9BQU8wRjtBQUFQLE1BQWtCViwrQ0FBUSxDQUFhLEVBQWIsQ0FBaEM7QUFFQTdGLEVBQUFBLGdEQUFTLENBQUMsTUFBTTtBQUNkLEtBQUMsWUFBWTtBQUNYLFVBQ0UsQ0FBQ1csTUFBRCxJQUNBLENBQUNBLE1BQU0sQ0FBQ0ssU0FEUixJQUVBLENBQUNMLE1BQU0sQ0FBQ00sbUJBRlIsSUFHQSxDQUFDTixNQUFNLENBQUNPLGVBSlYsRUFLRTtBQUNBO0FBQ0Q7O0FBRURtRixNQUFBQSxZQUFZLENBQUMsSUFBRCxDQUFaO0FBRUEsWUFBTUcsZUFBZSxHQUFHLE1BQU1ULHdFQUFtQixDQUMvQ3ZFLFVBRCtDLEVBRS9DYixNQUFNLENBQUNLLFNBRndDLENBQWpEO0FBSUFHLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFpQk4sV0FBN0I7QUFDQXdGLE1BQUFBLFlBQVksQ0FBQ0UsZUFBRCxDQUFaO0FBRUEsWUFBTS9FLFlBQVksR0FBRyxNQUFNdkIsb0VBQWUsQ0FBQ3NCLFVBQUQsRUFBYWIsTUFBTSxDQUFDSyxTQUFwQixDQUExQztBQUVBdUYsTUFBQUEsT0FBTyxDQUFDOUUsWUFBRCxDQUFQLENBckJXLENBc0JYOztBQUNBNEUsTUFBQUEsWUFBWSxDQUFDLEtBQUQsQ0FBWjtBQUNELEtBeEJEO0FBeUJELEdBMUJRLEVBMEJOLENBQUMxRixNQUFELENBMUJNLENBQVQ7QUE0QkEsU0FBTyxDQUFDQyxTQUFELEVBQVlDLElBQVosRUFBa0JDLFdBQWxCLENBQVA7QUFDRCxDQXBDRDs7QUFzQ0EsaUVBQWVWLGFBQWY7Ozs7Ozs7Ozs7O0FDOUNhOztBQUNicUcsOENBQTZDO0FBQ3pDaEQsRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0FrRCxlQUFBLEdBQWtCLEtBQUssQ0FBdkI7O0FBQ0EsSUFBSUUsTUFBTSxHQUFHQyxzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyxvQkFBRCxDQUFSLENBQW5DOztBQUNBLElBQUlDLE9BQU8sR0FBR0QsbUJBQU8sQ0FBQyx5RkFBRCxDQUFyQjs7QUFDQSxJQUFJRSxRQUFRLEdBQUdGLG1CQUFPLENBQUMsMkRBQUQsQ0FBdEI7O0FBQ0EsSUFBSUcsZ0JBQWdCLEdBQUdILG1CQUFPLENBQUMsK0VBQUQsQ0FBOUI7O0FBQ0EsU0FBU0Qsc0JBQVQsQ0FBZ0NLLEdBQWhDLEVBQXFDO0FBQ2pDLFNBQU9BLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxVQUFYLEdBQXdCRCxHQUF4QixHQUE4QjtBQUNqQ1AsSUFBQUEsT0FBTyxFQUFFTztBQUR3QixHQUFyQztBQUdIOztBQUNELE1BQU1FLFVBQVUsR0FBRyxFQUFuQjs7QUFFQSxTQUFTQyxRQUFULENBQWtCQyxNQUFsQixFQUEwQkMsSUFBMUIsRUFBZ0NDLEVBQWhDLEVBQW9DQyxPQUFwQyxFQUE2QztBQUN6QyxNQUFJLElBQUosRUFBOEM7QUFDOUMsTUFBSSxDQUFDLENBQUMsR0FBR1YsT0FBSixFQUFhVyxVQUFiLENBQXdCSCxJQUF4QixDQUFMLEVBQW9DLE9BRkssQ0FHekM7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FELEVBQUFBLE1BQU0sQ0FBQ0QsUUFBUCxDQUFnQkUsSUFBaEIsRUFBc0JDLEVBQXRCLEVBQTBCQyxPQUExQixFQUFtQ0UsS0FBbkMsQ0FBMENDLEdBQUQsSUFBTztBQUM1QyxjQUEyQztBQUN2QztBQUNBLFlBQU1BLEdBQU47QUFDSDtBQUNKLEdBTEQ7QUFNQSxRQUFNQyxTQUFTLEdBQUdKLE9BQU8sSUFBSSxPQUFPQSxPQUFPLENBQUNLLE1BQWYsS0FBMEIsV0FBckMsR0FBbURMLE9BQU8sQ0FBQ0ssTUFBM0QsR0FBb0VSLE1BQU0sSUFBSUEsTUFBTSxDQUFDUSxNQUF2RyxDQWJ5QyxDQWN6Qzs7QUFDQVYsRUFBQUEsVUFBVSxDQUFDRyxJQUFJLEdBQUcsR0FBUCxHQUFhQyxFQUFiLElBQW1CSyxTQUFTLEdBQUcsTUFBTUEsU0FBVCxHQUFxQixFQUFqRCxDQUFELENBQVYsR0FBbUUsSUFBbkU7QUFDSDs7QUFDRCxTQUFTRSxlQUFULENBQXlCQyxLQUF6QixFQUFnQztBQUM1QixRQUFNO0FBQUVDLElBQUFBO0FBQUYsTUFBY0QsS0FBSyxDQUFDRSxhQUExQjtBQUNBLFNBQU9ELE1BQU0sSUFBSUEsTUFBTSxLQUFLLE9BQXJCLElBQWdDRCxLQUFLLENBQUNHLE9BQXRDLElBQWlESCxLQUFLLENBQUNJLE9BQXZELElBQWtFSixLQUFLLENBQUNLLFFBQXhFLElBQW9GTCxLQUFLLENBQUNNLE1BQTFGLElBQW9HTixLQUFLLENBQUNPLFdBQU4sSUFBcUJQLEtBQUssQ0FBQ08sV0FBTixDQUFrQkMsS0FBbEIsS0FBNEIsQ0FBNUo7QUFDSDs7QUFDRCxTQUFTQyxXQUFULENBQXFCQyxDQUFyQixFQUF3QnBCLE1BQXhCLEVBQWdDQyxJQUFoQyxFQUFzQ0MsRUFBdEMsRUFBMENtQixPQUExQyxFQUFtREMsT0FBbkQsRUFBNERDLE1BQTVELEVBQW9FZixNQUFwRSxFQUE0RTtBQUN4RSxRQUFNO0FBQUVnQixJQUFBQTtBQUFGLE1BQWdCSixDQUFDLENBQUNSLGFBQXhCOztBQUNBLE1BQUlZLFFBQVEsS0FBSyxHQUFiLEtBQXFCZixlQUFlLENBQUNXLENBQUQsQ0FBZixJQUFzQixDQUFDLENBQUMsR0FBRzNCLE9BQUosRUFBYVcsVUFBYixDQUF3QkgsSUFBeEIsQ0FBNUMsQ0FBSixFQUFnRjtBQUM1RTtBQUNBO0FBQ0g7O0FBQ0RtQixFQUFBQSxDQUFDLENBQUNLLGNBQUYsR0FOd0UsQ0FPeEU7O0FBQ0EsTUFBSUYsTUFBTSxJQUFJLElBQVYsSUFBa0JyQixFQUFFLENBQUN3QixPQUFILENBQVcsR0FBWCxLQUFtQixDQUF6QyxFQUE0QztBQUN4Q0gsSUFBQUEsTUFBTSxHQUFHLEtBQVQ7QUFDSCxHQVZ1RSxDQVd4RTs7O0FBQ0F2QixFQUFBQSxNQUFNLENBQUNxQixPQUFPLEdBQUcsU0FBSCxHQUFlLE1BQXZCLENBQU4sQ0FBcUNwQixJQUFyQyxFQUEyQ0MsRUFBM0MsRUFBK0M7QUFDM0NvQixJQUFBQSxPQUQyQztBQUUzQ2QsSUFBQUEsTUFGMkM7QUFHM0NlLElBQUFBO0FBSDJDLEdBQS9DO0FBS0g7O0FBQ0QsU0FBU25ELElBQVQsQ0FBY3BGLEtBQWQsRUFBcUI7QUFDakIsWUFBMkM7QUFDdkMsYUFBUzJJLGVBQVQsQ0FBeUJDLElBQXpCLEVBQStCO0FBQzNCLGFBQU8sSUFBSUMsS0FBSixDQUFXLGdDQUErQkQsSUFBSSxDQUFDRSxHQUFJLGdCQUFlRixJQUFJLENBQUNHLFFBQVMsNkJBQTRCSCxJQUFJLENBQUNJLE1BQU8sYUFBOUcsSUFBOEgsU0FBZ0MsQ0FBaEMsR0FBcUcsRUFBbk8sQ0FBVixDQUFQO0FBQ0gsS0FIc0MsQ0FJdkM7OztBQUNBLFVBQU1DLGtCQUFrQixHQUFHO0FBQ3ZCaEMsTUFBQUEsSUFBSSxFQUFFO0FBRGlCLEtBQTNCO0FBR0EsVUFBTWlDLGFBQWEsR0FBR2hELE1BQU0sQ0FBQ2lELElBQVAsQ0FBWUYsa0JBQVosQ0FBdEI7QUFDQUMsSUFBQUEsYUFBYSxDQUFDRSxPQUFkLENBQXVCTixHQUFELElBQU87QUFDekIsVUFBSUEsR0FBRyxLQUFLLE1BQVosRUFBb0I7QUFDaEIsWUFBSTlJLEtBQUssQ0FBQzhJLEdBQUQsQ0FBTCxJQUFjLElBQWQsSUFBc0IsT0FBTzlJLEtBQUssQ0FBQzhJLEdBQUQsQ0FBWixLQUFzQixRQUF0QixJQUFrQyxPQUFPOUksS0FBSyxDQUFDOEksR0FBRCxDQUFaLEtBQXNCLFFBQWxGLEVBQTRGO0FBQ3hGLGdCQUFNSCxlQUFlLENBQUM7QUFDbEJHLFlBQUFBLEdBRGtCO0FBRWxCQyxZQUFBQSxRQUFRLEVBQUUsc0JBRlE7QUFHbEJDLFlBQUFBLE1BQU0sRUFBRWhKLEtBQUssQ0FBQzhJLEdBQUQsQ0FBTCxLQUFlLElBQWYsR0FBc0IsTUFBdEIsR0FBK0IsT0FBTzlJLEtBQUssQ0FBQzhJLEdBQUQ7QUFIakMsV0FBRCxDQUFyQjtBQUtIO0FBQ0osT0FSRCxNQVFPO0FBQ0g7QUFDQTtBQUNBLGNBQU1PLENBQUMsR0FBR1AsR0FBVjtBQUNIO0FBQ0osS0FkRCxFQVR1QyxDQXdCdkM7O0FBQ0EsVUFBTVEsa0JBQWtCLEdBQUc7QUFDdkJwQyxNQUFBQSxFQUFFLEVBQUUsSUFEbUI7QUFFdkJtQixNQUFBQSxPQUFPLEVBQUUsSUFGYztBQUd2QkUsTUFBQUEsTUFBTSxFQUFFLElBSGU7QUFJdkJELE1BQUFBLE9BQU8sRUFBRSxJQUpjO0FBS3ZCaUIsTUFBQUEsUUFBUSxFQUFFLElBTGE7QUFNdkJ4QyxNQUFBQSxRQUFRLEVBQUUsSUFOYTtBQU92QlMsTUFBQUEsTUFBTSxFQUFFO0FBUGUsS0FBM0I7QUFTQSxVQUFNZ0MsYUFBYSxHQUFHdEQsTUFBTSxDQUFDaUQsSUFBUCxDQUFZRyxrQkFBWixDQUF0QjtBQUNBRSxJQUFBQSxhQUFhLENBQUNKLE9BQWQsQ0FBdUJOLEdBQUQsSUFBTztBQUN6QixZQUFNVyxPQUFPLEdBQUcsT0FBT3pKLEtBQUssQ0FBQzhJLEdBQUQsQ0FBNUI7O0FBQ0EsVUFBSUEsR0FBRyxLQUFLLElBQVosRUFBa0I7QUFDZCxZQUFJOUksS0FBSyxDQUFDOEksR0FBRCxDQUFMLElBQWNXLE9BQU8sS0FBSyxRQUExQixJQUFzQ0EsT0FBTyxLQUFLLFFBQXRELEVBQWdFO0FBQzVELGdCQUFNZCxlQUFlLENBQUM7QUFDbEJHLFlBQUFBLEdBRGtCO0FBRWxCQyxZQUFBQSxRQUFRLEVBQUUsc0JBRlE7QUFHbEJDLFlBQUFBLE1BQU0sRUFBRVM7QUFIVSxXQUFELENBQXJCO0FBS0g7QUFDSixPQVJELE1BUU8sSUFBSVgsR0FBRyxLQUFLLFFBQVosRUFBc0I7QUFDekIsWUFBSTlJLEtBQUssQ0FBQzhJLEdBQUQsQ0FBTCxJQUFjVyxPQUFPLEtBQUssUUFBOUIsRUFBd0M7QUFDcEMsZ0JBQU1kLGVBQWUsQ0FBQztBQUNsQkcsWUFBQUEsR0FEa0I7QUFFbEJDLFlBQUFBLFFBQVEsRUFBRSxVQUZRO0FBR2xCQyxZQUFBQSxNQUFNLEVBQUVTO0FBSFUsV0FBRCxDQUFyQjtBQUtIO0FBQ0osT0FSTSxNQVFBLElBQUlYLEdBQUcsS0FBSyxTQUFSLElBQXFCQSxHQUFHLEtBQUssUUFBN0IsSUFBeUNBLEdBQUcsS0FBSyxTQUFqRCxJQUE4REEsR0FBRyxLQUFLLFVBQXRFLElBQW9GQSxHQUFHLEtBQUssVUFBaEcsRUFBNEc7QUFDL0csWUFBSTlJLEtBQUssQ0FBQzhJLEdBQUQsQ0FBTCxJQUFjLElBQWQsSUFBc0JXLE9BQU8sS0FBSyxTQUF0QyxFQUFpRDtBQUM3QyxnQkFBTWQsZUFBZSxDQUFDO0FBQ2xCRyxZQUFBQSxHQURrQjtBQUVsQkMsWUFBQUEsUUFBUSxFQUFFLFdBRlE7QUFHbEJDLFlBQUFBLE1BQU0sRUFBRVM7QUFIVSxXQUFELENBQXJCO0FBS0g7QUFDSixPQVJNLE1BUUE7QUFDSDtBQUNBO0FBQ0EsY0FBTUosQ0FBQyxHQUFHUCxHQUFWO0FBQ0g7QUFDSixLQS9CRCxFQW5DdUMsQ0FtRXZDO0FBQ0E7O0FBQ0EsVUFBTVksU0FBUyxHQUFHcEQsTUFBTSxDQUFDRCxPQUFQLENBQWVzRCxNQUFmLENBQXNCLEtBQXRCLENBQWxCOztBQUNBLFFBQUkzSixLQUFLLENBQUMrRyxRQUFOLElBQWtCLENBQUMyQyxTQUFTLENBQUNFLE9BQWpDLEVBQTBDO0FBQ3RDRixNQUFBQSxTQUFTLENBQUNFLE9BQVYsR0FBb0IsSUFBcEI7QUFDQWhKLE1BQUFBLE9BQU8sQ0FBQ2lKLElBQVIsQ0FBYSxzS0FBYjtBQUNIO0FBQ0o7O0FBQ0QsUUFBTUMsQ0FBQyxHQUFHOUosS0FBSyxDQUFDK0csUUFBTixLQUFtQixLQUE3QjtBQUNBLFFBQU1DLE1BQU0sR0FBRyxDQUFDLEdBQUdOLFFBQUosRUFBY3FELFNBQWQsRUFBZjs7QUFDQSxRQUFNO0FBQUU5QyxJQUFBQSxJQUFGO0FBQVNDLElBQUFBO0FBQVQsTUFBaUJaLE1BQU0sQ0FBQ0QsT0FBUCxDQUFlM0csT0FBZixDQUF1QixNQUFJO0FBQzlDLFVBQU0sQ0FBQ3NLLFlBQUQsRUFBZUMsVUFBZixJQUE2QixDQUFDLEdBQUd4RCxPQUFKLEVBQWF5RCxXQUFiLENBQXlCbEQsTUFBekIsRUFBaUNoSCxLQUFLLENBQUNpSCxJQUF2QyxFQUE2QyxJQUE3QyxDQUFuQztBQUNBLFdBQU87QUFDSEEsTUFBQUEsSUFBSSxFQUFFK0MsWUFESDtBQUVIOUMsTUFBQUEsRUFBRSxFQUFFbEgsS0FBSyxDQUFDa0gsRUFBTixHQUFXLENBQUMsR0FBR1QsT0FBSixFQUFheUQsV0FBYixDQUF5QmxELE1BQXpCLEVBQWlDaEgsS0FBSyxDQUFDa0gsRUFBdkMsQ0FBWCxHQUF3RCtDLFVBQVUsSUFBSUQ7QUFGdkUsS0FBUDtBQUlILEdBTnNCLEVBTXBCLENBQ0NoRCxNQURELEVBRUNoSCxLQUFLLENBQUNpSCxJQUZQLEVBR0NqSCxLQUFLLENBQUNrSCxFQUhQLENBTm9CLENBQXZCOztBQVdBLE1BQUk7QUFBRWlELElBQUFBLFFBQUY7QUFBYTlCLElBQUFBLE9BQWI7QUFBdUJDLElBQUFBLE9BQXZCO0FBQWlDQyxJQUFBQSxNQUFqQztBQUEwQ2YsSUFBQUE7QUFBMUMsTUFBc0R4SCxLQUExRCxDQXpGaUIsQ0EwRmpCOztBQUNBLE1BQUksT0FBT21LLFFBQVAsS0FBb0IsUUFBeEIsRUFBa0M7QUFDOUJBLElBQUFBLFFBQVEsR0FBRyxhQUFjN0QsTUFBTSxDQUFDRCxPQUFQLENBQWUrRCxhQUFmLENBQTZCLEdBQTdCLEVBQWtDLElBQWxDLEVBQXdDRCxRQUF4QyxDQUF6QjtBQUNILEdBN0ZnQixDQThGakI7OztBQUNBLE1BQUlFLEtBQUo7O0FBQ0EsWUFBNEM7QUFDeEMsUUFBSTtBQUNBQSxNQUFBQSxLQUFLLEdBQUcvRCxNQUFNLENBQUNELE9BQVAsQ0FBZWlFLFFBQWYsQ0FBd0JDLElBQXhCLENBQTZCSixRQUE3QixDQUFSO0FBQ0gsS0FGRCxDQUVFLE9BQU83QyxHQUFQLEVBQVk7QUFDVixZQUFNLElBQUl1QixLQUFKLENBQVcsOERBQTZEN0ksS0FBSyxDQUFDaUgsSUFBSyw0RkFBekUsSUFBd0ssU0FBZ0MsQ0FBaEMsR0FBc0csRUFBOVEsQ0FBVixDQUFOO0FBQ0g7QUFDSixHQU5ELE1BTU8sRUFFTjs7QUFDRCxRQUFNdUQsUUFBUSxHQUFHSCxLQUFLLElBQUksT0FBT0EsS0FBUCxLQUFpQixRQUExQixJQUFzQ0EsS0FBSyxDQUFDSSxHQUE3RDtBQUNBLFFBQU0sQ0FBQ0Msa0JBQUQsRUFBcUJDLFNBQXJCLElBQWtDLENBQUMsR0FBR2hFLGdCQUFKLEVBQXNCaUUsZUFBdEIsQ0FBc0M7QUFDMUVDLElBQUFBLFVBQVUsRUFBRTtBQUQ4RCxHQUF0QyxDQUF4Qzs7QUFHQSxRQUFNQyxNQUFNLEdBQUd4RSxNQUFNLENBQUNELE9BQVAsQ0FBZTBFLFdBQWYsQ0FBNEJDLEVBQUQsSUFBTTtBQUM1Q04sSUFBQUEsa0JBQWtCLENBQUNNLEVBQUQsQ0FBbEI7O0FBQ0EsUUFBSVIsUUFBSixFQUFjO0FBQ1YsVUFBSSxPQUFPQSxRQUFQLEtBQW9CLFVBQXhCLEVBQW9DQSxRQUFRLENBQUNRLEVBQUQsQ0FBUixDQUFwQyxLQUNLLElBQUksT0FBT1IsUUFBUCxLQUFvQixRQUF4QixFQUFrQztBQUNuQ0EsUUFBQUEsUUFBUSxDQUFDWixPQUFULEdBQW1Cb0IsRUFBbkI7QUFDSDtBQUNKO0FBQ0osR0FSYyxFQVFaLENBQ0NSLFFBREQsRUFFQ0Usa0JBRkQsQ0FSWSxDQUFmOztBQVlBcEUsRUFBQUEsTUFBTSxDQUFDRCxPQUFQLENBQWU1RyxTQUFmLENBQXlCLE1BQUk7QUFDekIsVUFBTXdMLGNBQWMsR0FBR04sU0FBUyxJQUFJYixDQUFiLElBQWtCLENBQUMsR0FBR3JELE9BQUosRUFBYVcsVUFBYixDQUF3QkgsSUFBeEIsQ0FBekM7QUFDQSxVQUFNTSxTQUFTLEdBQUcsT0FBT0MsTUFBUCxLQUFrQixXQUFsQixHQUFnQ0EsTUFBaEMsR0FBeUNSLE1BQU0sSUFBSUEsTUFBTSxDQUFDUSxNQUE1RTtBQUNBLFVBQU0wRCxZQUFZLEdBQUdwRSxVQUFVLENBQUNHLElBQUksR0FBRyxHQUFQLEdBQWFDLEVBQWIsSUFBbUJLLFNBQVMsR0FBRyxNQUFNQSxTQUFULEdBQXFCLEVBQWpELENBQUQsQ0FBL0I7O0FBQ0EsUUFBSTBELGNBQWMsSUFBSSxDQUFDQyxZQUF2QixFQUFxQztBQUNqQ25FLE1BQUFBLFFBQVEsQ0FBQ0MsTUFBRCxFQUFTQyxJQUFULEVBQWVDLEVBQWYsRUFBbUI7QUFDdkJNLFFBQUFBLE1BQU0sRUFBRUQ7QUFEZSxPQUFuQixDQUFSO0FBR0g7QUFDSixHQVRELEVBU0csQ0FDQ0wsRUFERCxFQUVDRCxJQUZELEVBR0MwRCxTQUhELEVBSUNuRCxNQUpELEVBS0NzQyxDQUxELEVBTUM5QyxNQU5ELENBVEg7O0FBaUJBLFFBQU1tRSxVQUFVLEdBQUc7QUFDZlYsSUFBQUEsR0FBRyxFQUFFSyxNQURVO0FBRWZNLElBQUFBLE9BQU8sRUFBR2hELENBQUQsSUFBSztBQUNWLFVBQUlpQyxLQUFLLENBQUNySyxLQUFOLElBQWUsT0FBT3FLLEtBQUssQ0FBQ3JLLEtBQU4sQ0FBWW9MLE9BQW5CLEtBQStCLFVBQWxELEVBQThEO0FBQzFEZixRQUFBQSxLQUFLLENBQUNySyxLQUFOLENBQVlvTCxPQUFaLENBQW9CaEQsQ0FBcEI7QUFDSDs7QUFDRCxVQUFJLENBQUNBLENBQUMsQ0FBQ2lELGdCQUFQLEVBQXlCO0FBQ3JCbEQsUUFBQUEsV0FBVyxDQUFDQyxDQUFELEVBQUlwQixNQUFKLEVBQVlDLElBQVosRUFBa0JDLEVBQWxCLEVBQXNCbUIsT0FBdEIsRUFBK0JDLE9BQS9CLEVBQXdDQyxNQUF4QyxFQUFnRGYsTUFBaEQsQ0FBWDtBQUNIO0FBQ0o7QUFUYyxHQUFuQjs7QUFXQTJELEVBQUFBLFVBQVUsQ0FBQ0csWUFBWCxHQUEyQmxELENBQUQsSUFBSztBQUMzQixRQUFJLENBQUMsQ0FBQyxHQUFHM0IsT0FBSixFQUFhVyxVQUFiLENBQXdCSCxJQUF4QixDQUFMLEVBQW9DOztBQUNwQyxRQUFJb0QsS0FBSyxDQUFDckssS0FBTixJQUFlLE9BQU9xSyxLQUFLLENBQUNySyxLQUFOLENBQVlzTCxZQUFuQixLQUFvQyxVQUF2RCxFQUFtRTtBQUMvRGpCLE1BQUFBLEtBQUssQ0FBQ3JLLEtBQU4sQ0FBWXNMLFlBQVosQ0FBeUJsRCxDQUF6QjtBQUNIOztBQUNEckIsSUFBQUEsUUFBUSxDQUFDQyxNQUFELEVBQVNDLElBQVQsRUFBZUMsRUFBZixFQUFtQjtBQUN2QnFFLE1BQUFBLFFBQVEsRUFBRTtBQURhLEtBQW5CLENBQVI7QUFHSCxHQVJELENBckppQixDQThKakI7QUFDQTs7O0FBQ0EsTUFBSXZMLEtBQUssQ0FBQ3VKLFFBQU4sSUFBa0JjLEtBQUssQ0FBQ3ZKLElBQU4sS0FBZSxHQUFmLElBQXNCLEVBQUUsVUFBVXVKLEtBQUssQ0FBQ3JLLEtBQWxCLENBQTVDLEVBQXNFO0FBQ2xFLFVBQU11SCxTQUFTLEdBQUcsT0FBT0MsTUFBUCxLQUFrQixXQUFsQixHQUFnQ0EsTUFBaEMsR0FBeUNSLE1BQU0sSUFBSUEsTUFBTSxDQUFDUSxNQUE1RSxDQURrRSxDQUVsRTtBQUNBOztBQUNBLFVBQU1nRSxZQUFZLEdBQUd4RSxNQUFNLElBQUlBLE1BQU0sQ0FBQ3lFLGNBQWpCLElBQW1DLENBQUMsR0FBR2hGLE9BQUosRUFBYWlGLGVBQWIsQ0FBNkJ4RSxFQUE3QixFQUFpQ0ssU0FBakMsRUFBNENQLE1BQU0sSUFBSUEsTUFBTSxDQUFDMkUsT0FBN0QsRUFBc0UzRSxNQUFNLElBQUlBLE1BQU0sQ0FBQzRFLGFBQXZGLENBQXhEO0FBQ0FULElBQUFBLFVBQVUsQ0FBQ2xFLElBQVgsR0FBa0J1RSxZQUFZLElBQUksQ0FBQyxHQUFHL0UsT0FBSixFQUFhb0YsV0FBYixDQUF5QixDQUFDLEdBQUdwRixPQUFKLEVBQWFxRixTQUFiLENBQXVCNUUsRUFBdkIsRUFBMkJLLFNBQTNCLEVBQXNDUCxNQUFNLElBQUlBLE1BQU0sQ0FBQytFLGFBQXZELENBQXpCLENBQWxDO0FBQ0g7O0FBQ0QsU0FBTyxhQUFjekYsTUFBTSxDQUFDRCxPQUFQLENBQWUyRixZQUFmLENBQTRCM0IsS0FBNUIsRUFBbUNjLFVBQW5DLENBQXJCO0FBQ0g7O0FBQ0QsSUFBSWMsUUFBUSxHQUFHN0csSUFBZjtBQUNBZ0IsZUFBQSxHQUFrQjZGLFFBQWxCOzs7Ozs7Ozs7OztBQ2pPYTs7QUFDYi9GLDhDQUE2QztBQUN6Q2hELEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBa0QsK0JBQUEsR0FBa0M4Rix1QkFBbEM7QUFDQTlGLGtDQUFBLEdBQXFDLEtBQUssQ0FBMUM7O0FBQ0EsU0FBUzhGLHVCQUFULENBQWlDRSxJQUFqQyxFQUF1QztBQUNuQyxTQUFPQSxJQUFJLENBQUNDLFFBQUwsQ0FBYyxHQUFkLEtBQXNCRCxJQUFJLEtBQUssR0FBL0IsR0FBcUNBLElBQUksQ0FBQ0UsS0FBTCxDQUFXLENBQVgsRUFBYyxDQUFDLENBQWYsQ0FBckMsR0FBeURGLElBQWhFO0FBQ0g7O0FBQ0QsTUFBTUQsMEJBQTBCLEdBQUcxRyxNQUFBLEdBQXFDMkcsQ0FBckMsR0FRL0JGLHVCQVJKO0FBU0E5RixrQ0FBQSxHQUFxQytGLDBCQUFyQzs7Ozs7Ozs7Ozs7QUNsQmE7O0FBQ2JqRyw4Q0FBNkM7QUFDekNoRCxFQUFBQSxLQUFLLEVBQUU7QUFEa0MsQ0FBN0M7QUFHQWtELDJCQUFBLEdBQThCQSwwQkFBQSxHQUE2QixLQUFLLENBQWhFOztBQUNBLE1BQU1xRyxtQkFBbUIsR0FBRyxPQUFPRSxJQUFQLEtBQWdCLFdBQWhCLElBQStCQSxJQUFJLENBQUNGLG1CQUFwQyxJQUEyREUsSUFBSSxDQUFDRixtQkFBTCxDQUF5QkcsSUFBekIsQ0FBOEJDLE1BQTlCLENBQTNELElBQW9HLFVBQVNDLEVBQVQsRUFBYTtBQUN6SSxNQUFJQyxLQUFLLEdBQUdDLElBQUksQ0FBQ0MsR0FBTCxFQUFaO0FBQ0EsU0FBT0MsVUFBVSxDQUFDLFlBQVc7QUFDekJKLElBQUFBLEVBQUUsQ0FBQztBQUNDSyxNQUFBQSxVQUFVLEVBQUUsS0FEYjtBQUVDQyxNQUFBQSxhQUFhLEVBQUUsWUFBVztBQUN0QixlQUFPQyxJQUFJLENBQUNDLEdBQUwsQ0FBUyxDQUFULEVBQVksTUFBTU4sSUFBSSxDQUFDQyxHQUFMLEtBQWFGLEtBQW5CLENBQVosQ0FBUDtBQUNIO0FBSkYsS0FBRCxDQUFGO0FBTUgsR0FQZ0IsRUFPZCxDQVBjLENBQWpCO0FBUUgsQ0FWRDs7QUFXQTNHLDJCQUFBLEdBQThCcUcsbUJBQTlCOztBQUNBLE1BQU1DLGtCQUFrQixHQUFHLE9BQU9DLElBQVAsS0FBZ0IsV0FBaEIsSUFBK0JBLElBQUksQ0FBQ0Qsa0JBQXBDLElBQTBEQyxJQUFJLENBQUNELGtCQUFMLENBQXdCRSxJQUF4QixDQUE2QkMsTUFBN0IsQ0FBMUQsSUFBa0csVUFBU1UsRUFBVCxFQUFhO0FBQ3RJLFNBQU9DLFlBQVksQ0FBQ0QsRUFBRCxDQUFuQjtBQUNILENBRkQ7O0FBR0FuSCwwQkFBQSxHQUE2QnNHLGtCQUE3Qjs7Ozs7Ozs7Ozs7QUNwQmE7O0FBQ2J4Ryw4Q0FBNkM7QUFDekNoRCxFQUFBQSxLQUFLLEVBQUU7QUFEa0MsQ0FBN0M7QUFHQWtELHNCQUFBLEdBQXlCcUgsY0FBekI7QUFDQXJILG9CQUFBLEdBQXVCc0gsWUFBdkI7QUFDQXRILDhCQUFBLEdBQWlDdUgsc0JBQWpDO0FBQ0F2SCx5QkFBQSxHQUE0QndILGlCQUE1Qjs7QUFDQSxJQUFJQyxzQkFBc0IsR0FBR3RILHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLGtIQUFELENBQVIsQ0FBbkQ7O0FBQ0EsSUFBSXNILG9CQUFvQixHQUFHdEgsbUJBQU8sQ0FBQyx5RkFBRCxDQUFsQzs7QUFDQSxTQUFTRCxzQkFBVCxDQUFnQ0ssR0FBaEMsRUFBcUM7QUFDakMsU0FBT0EsR0FBRyxJQUFJQSxHQUFHLENBQUNDLFVBQVgsR0FBd0JELEdBQXhCLEdBQThCO0FBQ2pDUCxJQUFBQSxPQUFPLEVBQUVPO0FBRHdCLEdBQXJDO0FBR0gsRUFDRDtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTW1ILGlCQUFpQixHQUFHLElBQTFCOztBQUNBLFNBQVNDLFVBQVQsQ0FBb0JsRixHQUFwQixFQUF5QjlELEdBQXpCLEVBQThCaUosU0FBOUIsRUFBeUM7QUFDckMsTUFBSUMsS0FBSyxHQUFHbEosR0FBRyxDQUFDbUosR0FBSixDQUFRckYsR0FBUixDQUFaOztBQUNBLE1BQUlvRixLQUFKLEVBQVc7QUFDUCxRQUFJLFlBQVlBLEtBQWhCLEVBQXVCO0FBQ25CLGFBQU9BLEtBQUssQ0FBQ0UsTUFBYjtBQUNIOztBQUNELFdBQU9DLE9BQU8sQ0FBQ0MsT0FBUixDQUFnQkosS0FBaEIsQ0FBUDtBQUNIOztBQUNELE1BQUlLLFFBQUo7QUFDQSxRQUFNQyxJQUFJLEdBQUcsSUFBSUgsT0FBSixDQUFhQyxPQUFELElBQVc7QUFDaENDLElBQUFBLFFBQVEsR0FBR0QsT0FBWDtBQUNILEdBRlksQ0FBYjtBQUdBdEosRUFBQUEsR0FBRyxDQUFDeUosR0FBSixDQUFRM0YsR0FBUixFQUFhb0YsS0FBSyxHQUFHO0FBQ2pCSSxJQUFBQSxPQUFPLEVBQUVDLFFBRFE7QUFFakJILElBQUFBLE1BQU0sRUFBRUk7QUFGUyxHQUFyQjtBQUlBLFNBQU9QLFNBQVMsR0FBR0EsU0FBUyxHQUFHUyxJQUFaLENBQWtCeEwsS0FBRCxLQUFVcUwsUUFBUSxDQUFDckwsS0FBRCxDQUFSLEVBQWlCQSxLQUEzQixDQUFqQixDQUFILEdBQ1pzTCxJQURKO0FBRUg7O0FBQ0QsU0FBU0csV0FBVCxDQUFxQkMsSUFBckIsRUFBMkI7QUFDdkIsTUFBSTtBQUNBQSxJQUFBQSxJQUFJLEdBQUdDLFFBQVEsQ0FBQ3pFLGFBQVQsQ0FBdUIsTUFBdkIsQ0FBUDtBQUNBLFdBQU87QUFDUDtBQUNDLE9BQUMsQ0FBQ3lDLE1BQU0sQ0FBQ2lDLG9CQUFULElBQWlDLENBQUMsQ0FBQ0QsUUFBUSxDQUFDRSxZQUE3QyxJQUE4REgsSUFBSSxDQUFDSSxPQUFMLENBQWFDLFFBQWIsQ0FBc0IsVUFBdEI7QUFGOUQ7QUFHSCxHQUxELENBS0UsT0FBTzdHLENBQVAsRUFBVTtBQUNSLFdBQU8sS0FBUDtBQUNIO0FBQ0o7O0FBQ0QsTUFBTThHLFdBQVcsR0FBR1AsV0FBVyxFQUEvQjs7QUFDQSxTQUFTUSxjQUFULENBQXdCbEksSUFBeEIsRUFBOEJDLEVBQTlCLEVBQWtDMEgsSUFBbEMsRUFBd0M7QUFDcEMsU0FBTyxJQUFJUCxPQUFKLENBQVksQ0FBQ2UsR0FBRCxFQUFNQyxHQUFOLEtBQVk7QUFDM0IsUUFBSVIsUUFBUSxDQUFDUyxhQUFULENBQXdCLCtCQUE4QnJJLElBQUssSUFBM0QsQ0FBSixFQUFxRTtBQUNqRSxhQUFPbUksR0FBRyxFQUFWO0FBQ0g7O0FBQ0RSLElBQUFBLElBQUksR0FBR0MsUUFBUSxDQUFDekUsYUFBVCxDQUF1QixNQUF2QixDQUFQLENBSjJCLENBSzNCOztBQUNBLFFBQUlsRCxFQUFKLEVBQVEwSCxJQUFJLENBQUMxSCxFQUFMLEdBQVVBLEVBQVY7QUFDUjBILElBQUFBLElBQUksQ0FBQ1csR0FBTCxHQUFZLFVBQVo7QUFDQVgsSUFBQUEsSUFBSSxDQUFDWSxXQUFMLEdBQW1CL0osU0FBbkI7QUFDQW1KLElBQUFBLElBQUksQ0FBQ2MsTUFBTCxHQUFjTixHQUFkO0FBQ0FSLElBQUFBLElBQUksQ0FBQ2UsT0FBTCxHQUFlTixHQUFmLENBVjJCLENBVzNCOztBQUNBVCxJQUFBQSxJQUFJLENBQUMzSCxJQUFMLEdBQVlBLElBQVo7QUFDQTRILElBQUFBLFFBQVEsQ0FBQ2UsSUFBVCxDQUFjQyxXQUFkLENBQTBCakIsSUFBMUI7QUFDSCxHQWRNLENBQVA7QUFlSDs7QUFDRCxNQUFNa0IsZ0JBQWdCLEdBQUdDLE1BQU0sQ0FBQyxrQkFBRCxDQUEvQjs7QUFDQSxTQUFTdEMsY0FBVCxDQUF3Qm5HLEdBQXhCLEVBQTZCO0FBQ3pCLFNBQU9wQixNQUFNLENBQUNDLGNBQVAsQ0FBc0JtQixHQUF0QixFQUEyQndJLGdCQUEzQixFQUE2QyxFQUE3QyxDQUFQO0FBRUg7O0FBQ0QsU0FBU3BDLFlBQVQsQ0FBc0JwRyxHQUF0QixFQUEyQjtBQUN2QixTQUFPQSxHQUFHLElBQUl3SSxnQkFBZ0IsSUFBSXhJLEdBQWxDO0FBQ0g7O0FBQ0QsU0FBUzBJLFlBQVQsQ0FBc0JDLEdBQXRCLEVBQTJCQyxNQUEzQixFQUFtQztBQUMvQixTQUFPLElBQUk3QixPQUFKLENBQVksQ0FBQ0MsT0FBRCxFQUFVNkIsTUFBVixLQUFtQjtBQUNsQ0QsSUFBQUEsTUFBTSxHQUFHckIsUUFBUSxDQUFDekUsYUFBVCxDQUF1QixRQUF2QixDQUFULENBRGtDLENBRWxDO0FBQ0E7QUFDQTs7QUFDQThGLElBQUFBLE1BQU0sQ0FBQ1IsTUFBUCxHQUFnQnBCLE9BQWhCOztBQUNBNEIsSUFBQUEsTUFBTSxDQUFDUCxPQUFQLEdBQWlCLE1BQUlRLE1BQU0sQ0FBQzFDLGNBQWMsQ0FBQyxJQUFJNUUsS0FBSixDQUFXLDBCQUF5Qm9ILEdBQUksRUFBeEMsQ0FBRCxDQUFmLENBQTNCLENBTmtDLENBUWxDO0FBQ0E7OztBQUNBQyxJQUFBQSxNQUFNLENBQUNWLFdBQVAsR0FBcUIvSixTQUFyQixDQVZrQyxDQVdsQztBQUNBOztBQUNBeUssSUFBQUEsTUFBTSxDQUFDRCxHQUFQLEdBQWFBLEdBQWI7QUFDQXBCLElBQUFBLFFBQVEsQ0FBQ3VCLElBQVQsQ0FBY1AsV0FBZCxDQUEwQkssTUFBMUI7QUFDSCxHQWZNLENBQVA7QUFnQkgsRUFDRDtBQUNBOzs7QUFDQSxJQUFJRyxlQUFKLEVBQ0E7O0FBQ0EsU0FBU0MseUJBQVQsQ0FBbUN4RyxDQUFuQyxFQUFzQ3lHLEVBQXRDLEVBQTBDakosR0FBMUMsRUFBK0M7QUFDM0MsU0FBTyxJQUFJK0csT0FBSixDQUFZLENBQUNDLE9BQUQsRUFBVTZCLE1BQVYsS0FBbUI7QUFDbEMsUUFBSUssU0FBUyxHQUFHLEtBQWhCO0FBQ0ExRyxJQUFBQSxDQUFDLENBQUM0RSxJQUFGLENBQVErQixDQUFELElBQUs7QUFDUjtBQUNBRCxNQUFBQSxTQUFTLEdBQUcsSUFBWjtBQUNBbEMsTUFBQUEsT0FBTyxDQUFDbUMsQ0FBRCxDQUFQO0FBQ0gsS0FKRCxFQUlHcEosS0FKSCxDQUlTOEksTUFKVCxFQUZrQyxDQU9sQztBQUNBOztBQUNBLGNBQTRDO0FBQ3hDLE9BQUNFLGVBQWUsSUFBSWhDLE9BQU8sQ0FBQ0MsT0FBUixFQUFwQixFQUF1Q0ksSUFBdkMsQ0FBNEMsTUFBSTtBQUM1QyxTQUFDLEdBQUdaLG9CQUFKLEVBQTBCckIsbUJBQTFCLENBQThDLE1BQUlTLFVBQVUsQ0FBQyxNQUFJO0FBQ3pELGNBQUksQ0FBQ3NELFNBQUwsRUFBZ0I7QUFDWkwsWUFBQUEsTUFBTSxDQUFDN0ksR0FBRCxDQUFOO0FBQ0g7QUFDSixTQUp1RCxFQUlyRGlKLEVBSnFELENBQTVEO0FBTUgsT0FQRDtBQVFIOztBQUNELGVBQTRDLEVBTzNDO0FBQ0osR0EzQk0sQ0FBUDtBQTRCSDs7QUFDRCxTQUFTNUMsc0JBQVQsR0FBa0M7QUFDOUIsTUFBSWhCLElBQUksQ0FBQytELGdCQUFULEVBQTJCO0FBQ3ZCLFdBQU9yQyxPQUFPLENBQUNDLE9BQVIsQ0FBZ0IzQixJQUFJLENBQUMrRCxnQkFBckIsQ0FBUDtBQUNIOztBQUNELFFBQU1DLGVBQWUsR0FBRyxJQUFJdEMsT0FBSixDQUFhQyxPQUFELElBQVc7QUFDM0M7QUFDQSxVQUFNeEIsRUFBRSxHQUFHSCxJQUFJLENBQUNpRSxtQkFBaEI7O0FBQ0FqRSxJQUFBQSxJQUFJLENBQUNpRSxtQkFBTCxHQUEyQixNQUFJO0FBQzNCdEMsTUFBQUEsT0FBTyxDQUFDM0IsSUFBSSxDQUFDK0QsZ0JBQU4sQ0FBUDtBQUNBNUQsTUFBQUEsRUFBRSxJQUFJQSxFQUFFLEVBQVI7QUFDSCxLQUhEO0FBSUgsR0FQdUIsQ0FBeEI7QUFRQSxTQUFPd0QseUJBQXlCLENBQUNLLGVBQUQsRUFBa0I1QyxpQkFBbEIsRUFBcUNOLGNBQWMsQ0FBQyxJQUFJNUUsS0FBSixDQUFVLHNDQUFWLENBQUQsQ0FBbkQsQ0FBaEM7QUFDSDs7QUFDRCxTQUFTZ0ksZ0JBQVQsQ0FBMEJDLFdBQTFCLEVBQXVDQyxLQUF2QyxFQUE4QztBQUMxQyxZQUE0QztBQUN4QyxXQUFPMUMsT0FBTyxDQUFDQyxPQUFSLENBQWdCO0FBQ25CMEMsTUFBQUEsT0FBTyxFQUFFLENBQ0xGLFdBQVcsR0FBRyw0QkFBZCxHQUE2Q0csU0FBUyxDQUFDLENBQUMsR0FBR3BELHNCQUFKLEVBQTRCeEgsT0FBNUIsQ0FBb0MwSyxLQUFwQyxFQUEyQyxLQUEzQyxDQUFELENBRGpELENBRFU7QUFJbkI7QUFDQUcsTUFBQUEsR0FBRyxFQUFFO0FBTGMsS0FBaEIsQ0FBUDtBQU9IOztBQUNELFNBQU92RCxzQkFBc0IsR0FBR2UsSUFBekIsQ0FBK0J5QyxRQUFELElBQVk7QUFDN0MsUUFBSSxFQUFFSixLQUFLLElBQUlJLFFBQVgsQ0FBSixFQUEwQjtBQUN0QixZQUFNMUQsY0FBYyxDQUFDLElBQUk1RSxLQUFKLENBQVcsMkJBQTBCa0ksS0FBTSxFQUEzQyxDQUFELENBQXBCO0FBQ0g7O0FBQ0QsVUFBTUssUUFBUSxHQUFHRCxRQUFRLENBQUNKLEtBQUQsQ0FBUixDQUFnQi9MLEdBQWhCLENBQXFCa0osS0FBRCxJQUFTNEMsV0FBVyxHQUFHLFNBQWQsR0FBMEJHLFNBQVMsQ0FBQy9DLEtBQUQsQ0FBaEUsQ0FBakI7QUFFQSxXQUFPO0FBQ0g4QyxNQUFBQSxPQUFPLEVBQUVJLFFBQVEsQ0FBQ0MsTUFBVCxDQUFpQkMsQ0FBRCxJQUFLQSxDQUFDLENBQUNqRixRQUFGLENBQVcsS0FBWCxDQUFyQixDQUROO0FBR0g2RSxNQUFBQSxHQUFHLEVBQUVFLFFBQVEsQ0FBQ0MsTUFBVCxDQUFpQkMsQ0FBRCxJQUFLQSxDQUFDLENBQUNqRixRQUFGLENBQVcsTUFBWCxDQUFyQjtBQUhGLEtBQVA7QUFNSCxHQVpNLENBQVA7QUFhSDs7QUFDRCxTQUFTdUIsaUJBQVQsQ0FBMkJrRCxXQUEzQixFQUF3QztBQUNwQyxRQUFNUyxXQUFXLEdBQUcsSUFBSUMsR0FBSixFQUFwQjtBQUNBLFFBQU1DLGFBQWEsR0FBRyxJQUFJRCxHQUFKLEVBQXRCO0FBQ0EsUUFBTUUsV0FBVyxHQUFHLElBQUlGLEdBQUosRUFBcEI7QUFDQSxRQUFNRyxNQUFNLEdBQUcsSUFBSUgsR0FBSixFQUFmOztBQUNBLFdBQVNJLGtCQUFULENBQTRCM0IsR0FBNUIsRUFBaUM7QUFDN0IsUUFBSXpCLElBQUksR0FBR2lELGFBQWEsQ0FBQ3RELEdBQWQsQ0FBa0I4QixHQUFsQixDQUFYOztBQUNBLFFBQUl6QixJQUFKLEVBQVU7QUFDTixhQUFPQSxJQUFQO0FBQ0gsS0FKNEIsQ0FLN0I7OztBQUNBLFFBQUlLLFFBQVEsQ0FBQ1MsYUFBVCxDQUF3QixnQkFBZVcsR0FBSSxJQUEzQyxDQUFKLEVBQXFEO0FBQ2pELGFBQU81QixPQUFPLENBQUNDLE9BQVIsRUFBUDtBQUNIOztBQUNEbUQsSUFBQUEsYUFBYSxDQUFDaEQsR0FBZCxDQUFrQndCLEdBQWxCLEVBQXVCekIsSUFBSSxHQUFHd0IsWUFBWSxDQUFDQyxHQUFELENBQTFDO0FBQ0EsV0FBT3pCLElBQVA7QUFDSDs7QUFDRCxXQUFTcUQsZUFBVCxDQUF5QjVLLElBQXpCLEVBQStCO0FBQzNCLFFBQUl1SCxJQUFJLEdBQUdrRCxXQUFXLENBQUN2RCxHQUFaLENBQWdCbEgsSUFBaEIsQ0FBWDs7QUFDQSxRQUFJdUgsSUFBSixFQUFVO0FBQ04sYUFBT0EsSUFBUDtBQUNIOztBQUNEa0QsSUFBQUEsV0FBVyxDQUFDakQsR0FBWixDQUFnQnhILElBQWhCLEVBQXNCdUgsSUFBSSxHQUFHc0QsS0FBSyxDQUFDN0ssSUFBRCxDQUFMLENBQVl5SCxJQUFaLENBQWtCVSxHQUFELElBQU87QUFDakQsVUFBSSxDQUFDQSxHQUFHLENBQUMyQyxFQUFULEVBQWE7QUFDVCxjQUFNLElBQUlsSixLQUFKLENBQVcsOEJBQTZCNUIsSUFBSyxFQUE3QyxDQUFOO0FBQ0g7O0FBQ0QsYUFBT21JLEdBQUcsQ0FBQzRDLElBQUosR0FBV3RELElBQVgsQ0FBaUJzRCxJQUFELEtBQVM7QUFDeEIvSyxRQUFBQSxJQUFJLEVBQUVBLElBRGtCO0FBRXhCZ0wsUUFBQUEsT0FBTyxFQUFFRDtBQUZlLE9BQVQsQ0FBaEIsQ0FBUDtBQUtILEtBVDRCLEVBUzFCM0ssS0FUMEIsQ0FTbkJDLEdBQUQsSUFBTztBQUNaLFlBQU1tRyxjQUFjLENBQUNuRyxHQUFELENBQXBCO0FBQ0gsS0FYNEIsQ0FBN0I7QUFZQSxXQUFPa0gsSUFBUDtBQUNIOztBQUNELFNBQU87QUFDSDBELElBQUFBLGNBQWMsQ0FBRW5CLEtBQUYsRUFBUztBQUNuQixhQUFPL0MsVUFBVSxDQUFDK0MsS0FBRCxFQUFRUSxXQUFSLENBQWpCO0FBQ0gsS0FIRTs7QUFJSFksSUFBQUEsWUFBWSxDQUFFcEIsS0FBRixFQUFTcUIsT0FBVCxFQUFrQjtBQUMxQi9ELE1BQUFBLE9BQU8sQ0FBQ0MsT0FBUixDQUFnQjhELE9BQWhCLEVBQXlCMUQsSUFBekIsQ0FBK0IyRCxFQUFELElBQU1BLEVBQUUsRUFBdEMsRUFDRTNELElBREYsQ0FDUXRJLE9BQUQsS0FBWTtBQUNYa00sUUFBQUEsU0FBUyxFQUFFbE0sT0FBTyxJQUFJQSxPQUFPLENBQUNDLE9BQW5CLElBQThCRCxPQUQ5QjtBQUVYQSxRQUFBQSxPQUFPLEVBQUVBO0FBRkUsT0FBWixDQURQLEVBS0drQixHQUFELEtBQVE7QUFDRmlMLFFBQUFBLEtBQUssRUFBRWpMO0FBREwsT0FBUixDQUxGLEVBUUVvSCxJQVJGLENBUVE4RCxLQUFELElBQVM7QUFDWixjQUFNQyxHQUFHLEdBQUdsQixXQUFXLENBQUNwRCxHQUFaLENBQWdCNEMsS0FBaEIsQ0FBWjtBQUNBUSxRQUFBQSxXQUFXLENBQUM5QyxHQUFaLENBQWdCc0MsS0FBaEIsRUFBdUJ5QixLQUF2QjtBQUNBLFlBQUlDLEdBQUcsSUFBSSxhQUFhQSxHQUF4QixFQUE2QkEsR0FBRyxDQUFDbkUsT0FBSixDQUFZa0UsS0FBWjtBQUNoQyxPQVpEO0FBYUgsS0FsQkU7O0FBbUJIRSxJQUFBQSxTQUFTLENBQUUzQixLQUFGLEVBQVNoSyxRQUFULEVBQW1CO0FBQ3hCLGFBQU9pSCxVQUFVLENBQUMrQyxLQUFELEVBQVFZLE1BQVIsRUFBZ0IsTUFBSTtBQUNqQyxjQUFNZ0IsaUJBQWlCLEdBQUc5QixnQkFBZ0IsQ0FBQ0MsV0FBRCxFQUFjQyxLQUFkLENBQWhCLENBQXFDckMsSUFBckMsQ0FBMEMsQ0FBQztBQUFFc0MsVUFBQUEsT0FBRjtBQUFZRSxVQUFBQTtBQUFaLFNBQUQsS0FBc0I7QUFDdEYsaUJBQU83QyxPQUFPLENBQUN1RSxHQUFSLENBQVksQ0FDZnJCLFdBQVcsQ0FBQ3NCLEdBQVosQ0FBZ0I5QixLQUFoQixJQUF5QixFQUF6QixHQUE4QjFDLE9BQU8sQ0FBQ3VFLEdBQVIsQ0FBWTVCLE9BQU8sQ0FBQ2hNLEdBQVIsQ0FBWTRNLGtCQUFaLENBQVosQ0FEZixFQUVmdkQsT0FBTyxDQUFDdUUsR0FBUixDQUFZMUIsR0FBRyxDQUFDbE0sR0FBSixDQUFRNk0sZUFBUixDQUFaLENBRmUsQ0FBWixDQUFQO0FBSUgsU0FMeUIsRUFLdkJuRCxJQUx1QixDQUtqQlUsR0FBRCxJQUFPO0FBQ1gsaUJBQU8sS0FBSzhDLGNBQUwsQ0FBb0JuQixLQUFwQixFQUEyQnJDLElBQTNCLENBQWlDb0UsVUFBRCxLQUFlO0FBQzlDQSxZQUFBQSxVQUQ4QztBQUU5Q0MsWUFBQUEsTUFBTSxFQUFFM0QsR0FBRyxDQUFDLENBQUQ7QUFGbUMsV0FBZixDQUFoQyxDQUFQO0FBS0gsU0FYeUIsQ0FBMUI7O0FBWUEsa0JBQTRDO0FBQ3hDaUIsVUFBQUEsZUFBZSxHQUFHLElBQUloQyxPQUFKLENBQWFDLE9BQUQsSUFBVztBQUNyQyxnQkFBSXFFLGlCQUFKLEVBQXVCO0FBQ25CLHFCQUFPQSxpQkFBaUIsQ0FBQ0ssT0FBbEIsQ0FBMEIsTUFBSTtBQUNqQzFFLGdCQUFBQSxPQUFPO0FBQ1YsZUFGTSxDQUFQO0FBR0g7QUFDSixXQU5pQixDQUFsQjtBQU9IOztBQUNELGVBQU9nQyx5QkFBeUIsQ0FBQ3FDLGlCQUFELEVBQW9CNUUsaUJBQXBCLEVBQXVDTixjQUFjLENBQUMsSUFBSTVFLEtBQUosQ0FBVyxtQ0FBa0NrSSxLQUFNLEVBQW5ELENBQUQsQ0FBckQsQ0FBekIsQ0FBdUlyQyxJQUF2SSxDQUE0SSxDQUFDO0FBQUVvRSxVQUFBQSxVQUFGO0FBQWVDLFVBQUFBO0FBQWYsU0FBRCxLQUE0QjtBQUMzSyxnQkFBTTNELEdBQUcsR0FBR2xKLE1BQU0sQ0FBQytNLE1BQVAsQ0FBYztBQUN0QkYsWUFBQUEsTUFBTSxFQUFFQTtBQURjLFdBQWQsRUFFVEQsVUFGUyxDQUFaO0FBR0EsaUJBQU8sV0FBV0EsVUFBWCxHQUF3QkEsVUFBeEIsR0FBcUMxRCxHQUE1QztBQUNILFNBTE0sRUFLSi9ILEtBTEksQ0FLR0MsR0FBRCxJQUFPO0FBQ1osY0FBSVAsUUFBSixFQUFjO0FBQ1Y7QUFDQSxrQkFBTU8sR0FBTjtBQUNIOztBQUNELGlCQUFPO0FBQ0hpTCxZQUFBQSxLQUFLLEVBQUVqTDtBQURKLFdBQVA7QUFHSCxTQWJNLENBQVA7QUFjSCxPQXBDZ0IsQ0FBakI7QUFxQ0gsS0F6REU7O0FBMERIUCxJQUFBQSxRQUFRLENBQUVnSyxLQUFGLEVBQVM7QUFDYjtBQUNBO0FBQ0EsVUFBSW1DLEVBQUo7O0FBQ0EsVUFBSUEsRUFBRSxHQUFHQyxTQUFTLENBQUNsUyxVQUFuQixFQUErQjtBQUMzQjtBQUNBLFlBQUlpUyxFQUFFLENBQUNFLFFBQUgsSUFBZSxLQUFLNUcsSUFBTCxDQUFVMEcsRUFBRSxDQUFDRyxhQUFiLENBQW5CLEVBQWdELE9BQU9oRixPQUFPLENBQUNDLE9BQVIsRUFBUDtBQUNuRDs7QUFDRCxhQUFPdUMsZ0JBQWdCLENBQUNDLFdBQUQsRUFBY0MsS0FBZCxDQUFoQixDQUFxQ3JDLElBQXJDLENBQTJDNEUsTUFBRCxJQUFVakYsT0FBTyxDQUFDdUUsR0FBUixDQUFZMUQsV0FBVyxHQUFHb0UsTUFBTSxDQUFDdEMsT0FBUCxDQUFlaE0sR0FBZixDQUFvQmtMLE1BQUQsSUFBVWYsY0FBYyxDQUFDZSxNQUFELEVBQVMsUUFBVCxDQUEzQyxDQUFILEdBQzFFLEVBRG1ELENBQXBELEVBRUx4QixJQUZLLENBRUEsTUFBSTtBQUNQLFNBQUMsR0FBR1osb0JBQUosRUFBMEJyQixtQkFBMUIsQ0FBOEMsTUFBSSxLQUFLaUcsU0FBTCxDQUFlM0IsS0FBZixFQUFzQixJQUF0QixFQUE0QjFKLEtBQTVCLENBQWtDLE1BQUksQ0FDbkYsQ0FENkMsQ0FBbEQ7QUFHSCxPQU5NLEVBTUpBLEtBTkksRUFNRTtBQUNULFlBQUksQ0FDSCxDQVJNLENBQVA7QUFTSDs7QUEzRUUsR0FBUDtBQTZFSDs7Ozs7Ozs7Ozs7QUN0Ulk7O0FBQ2JuQiw4Q0FBNkM7QUFDekNoRCxFQUFBQSxLQUFLLEVBQUU7QUFEa0MsQ0FBN0M7QUFHQWdELDBDQUF5QztBQUNyQ3FOLEVBQUFBLFVBQVUsRUFBRSxJQUR5QjtBQUVyQ3BGLEVBQUFBLEdBQUcsRUFBRSxZQUFXO0FBQ1osV0FBTzFILE9BQU8sQ0FBQ0osT0FBZjtBQUNIO0FBSm9DLENBQXpDO0FBTUFILDhDQUE2QztBQUN6Q3FOLEVBQUFBLFVBQVUsRUFBRSxJQUQ2QjtBQUV6Q3BGLEVBQUFBLEdBQUcsRUFBRSxZQUFXO0FBQ1osV0FBT3FGLFdBQVcsQ0FBQ25OLE9BQW5CO0FBQ0g7QUFKd0MsQ0FBN0M7QUFNQUQsaUJBQUEsR0FBb0IyRCxTQUFwQjtBQUNBM0Qsb0JBQUEsR0FBdUJxTixZQUF2QjtBQUNBck4sZ0NBQUEsR0FBbUNzTix3QkFBbkM7QUFDQXROLGVBQUEsR0FBa0IsS0FBSyxDQUF2Qjs7QUFDQSxJQUFJRSxNQUFNLEdBQUdDLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLG9CQUFELENBQVIsQ0FBbkM7O0FBQ0EsSUFBSUMsT0FBTyxHQUFHRixzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyx5RkFBRCxDQUFSLENBQXBDOztBQUNBLElBQUltTixjQUFjLEdBQUduTixtQkFBTyxDQUFDLGtFQUFELENBQTVCOztBQUNBLElBQUlnTixXQUFXLEdBQUdqTixzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyxxRUFBRCxDQUFSLENBQXhDOztBQUNBLFNBQVNELHNCQUFULENBQWdDSyxHQUFoQyxFQUFxQztBQUNqQyxTQUFPQSxHQUFHLElBQUlBLEdBQUcsQ0FBQ0MsVUFBWCxHQUF3QkQsR0FBeEIsR0FBOEI7QUFDakNQLElBQUFBLE9BQU8sRUFBRU87QUFEd0IsR0FBckM7QUFHSDs7QUFDRCxNQUFNZ04sZUFBZSxHQUFHO0FBQ3BCNU0sRUFBQUEsTUFBTSxFQUFFLElBRFk7QUFFcEI2TSxFQUFBQSxjQUFjLEVBQUUsRUFGSTs7QUFHcEJDLEVBQUFBLEtBQUssQ0FBRWhILEVBQUYsRUFBTTtBQUNQLFFBQUksS0FBSzlGLE1BQVQsRUFBaUIsT0FBTzhGLEVBQUUsRUFBVDs7QUFDakIsZUFBbUMsRUFFbEM7QUFDSjs7QUFSbUIsQ0FBeEIsRUFVQTs7QUFDQSxNQUFNa0gsaUJBQWlCLEdBQUcsQ0FDdEIsVUFEc0IsRUFFdEIsT0FGc0IsRUFHdEIsT0FIc0IsRUFJdEIsUUFKc0IsRUFLdEIsWUFMc0IsRUFNdEIsWUFOc0IsRUFPdEIsVUFQc0IsRUFRdEIsUUFSc0IsRUFTdEIsU0FUc0IsRUFVdEIsZUFWc0IsRUFXdEIsU0FYc0IsRUFZdEIsV0Fac0IsRUFhdEIsZ0JBYnNCLEVBY3RCLGVBZHNCLENBQTFCO0FBZ0JBLE1BQU1DLFlBQVksR0FBRyxDQUNqQixrQkFEaUIsRUFFakIscUJBRmlCLEVBR2pCLHFCQUhpQixFQUlqQixrQkFKaUIsRUFLakIsaUJBTGlCLEVBTWpCLG9CQU5pQixDQUFyQjtBQVFBLE1BQU1DLGdCQUFnQixHQUFHLENBQ3JCLE1BRHFCLEVBRXJCLFNBRnFCLEVBR3JCLFFBSHFCLEVBSXJCLE1BSnFCLEVBS3JCLFVBTHFCLEVBTXJCLGdCQU5xQixDQUF6QixFQVFBOztBQUNBaE8sTUFBTSxDQUFDQyxjQUFQLENBQXNCeU4sZUFBdEIsRUFBdUMsUUFBdkMsRUFBaUQ7QUFDN0N6RixFQUFBQSxHQUFHLEdBQUk7QUFDSCxXQUFPMUgsT0FBTyxDQUFDSixPQUFSLENBQWdCOE4sTUFBdkI7QUFDSDs7QUFINEMsQ0FBakQ7QUFLQUgsaUJBQWlCLENBQUM1SyxPQUFsQixDQUEyQmdMLEtBQUQsSUFBUztBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBbE8sRUFBQUEsTUFBTSxDQUFDQyxjQUFQLENBQXNCeU4sZUFBdEIsRUFBdUNRLEtBQXZDLEVBQThDO0FBQzFDakcsSUFBQUEsR0FBRyxHQUFJO0FBQ0gsWUFBTW5ILE1BQU0sR0FBR3FOLFNBQVMsRUFBeEI7QUFDQSxhQUFPck4sTUFBTSxDQUFDb04sS0FBRCxDQUFiO0FBQ0g7O0FBSnlDLEdBQTlDO0FBTUgsQ0FYRDtBQVlBRixnQkFBZ0IsQ0FBQzlLLE9BQWpCLENBQTBCZ0wsS0FBRCxJQUFTO0FBQzlCUixFQUFBQSxlQUFlLENBQUNRLEtBQUQsQ0FBZixHQUF5QixDQUFDLEdBQUd4TCxJQUFKLEtBQVc7QUFDaEMsVUFBTTVCLE1BQU0sR0FBR3FOLFNBQVMsRUFBeEI7QUFDQSxXQUFPck4sTUFBTSxDQUFDb04sS0FBRCxDQUFOLENBQWMsR0FBR3hMLElBQWpCLENBQVA7QUFDSCxHQUhEO0FBSUgsQ0FMRDtBQU1BcUwsWUFBWSxDQUFDN0ssT0FBYixDQUFzQjFCLEtBQUQsSUFBUztBQUMxQmtNLEVBQUFBLGVBQWUsQ0FBQ0UsS0FBaEIsQ0FBc0IsTUFBSTtBQUN0QnJOLElBQUFBLE9BQU8sQ0FBQ0osT0FBUixDQUFnQjhOLE1BQWhCLENBQXVCRyxFQUF2QixDQUEwQjVNLEtBQTFCLEVBQWlDLENBQUMsR0FBR2tCLElBQUosS0FBVztBQUN4QyxZQUFNMkwsVUFBVSxHQUFJLEtBQUk3TSxLQUFLLENBQUM4TSxNQUFOLENBQWEsQ0FBYixFQUFnQkMsV0FBaEIsRUFBOEIsR0FBRS9NLEtBQUssQ0FBQ2dOLFNBQU4sQ0FBZ0IsQ0FBaEIsQ0FBbUIsRUFBM0U7QUFDQSxZQUFNQyxnQkFBZ0IsR0FBR2YsZUFBekI7O0FBQ0EsVUFBSWUsZ0JBQWdCLENBQUNKLFVBQUQsQ0FBcEIsRUFBa0M7QUFDOUIsWUFBSTtBQUNBSSxVQUFBQSxnQkFBZ0IsQ0FBQ0osVUFBRCxDQUFoQixDQUE2QixHQUFHM0wsSUFBaEM7QUFDSCxTQUZELENBRUUsT0FBT3RCLEdBQVAsRUFBWTtBQUNWMUcsVUFBQUEsT0FBTyxDQUFDMlIsS0FBUixDQUFlLHdDQUF1Q2dDLFVBQVcsRUFBakU7QUFDQTNULFVBQUFBLE9BQU8sQ0FBQzJSLEtBQVIsQ0FBZSxHQUFFakwsR0FBRyxDQUFDc04sT0FBUSxLQUFJdE4sR0FBRyxDQUFDdU4sS0FBTSxFQUEzQztBQUNIO0FBQ0o7QUFDSixLQVhEO0FBWUgsR0FiRDtBQWNILENBZkQ7O0FBZ0JBLFNBQVNSLFNBQVQsR0FBcUI7QUFDakIsTUFBSSxDQUFDVCxlQUFlLENBQUM1TSxNQUFyQixFQUE2QjtBQUN6QixVQUFNNE4sT0FBTyxHQUFHLGdDQUFnQyxxRUFBaEQ7QUFDQSxVQUFNLElBQUkvTCxLQUFKLENBQVUrTCxPQUFWLENBQU47QUFDSDs7QUFDRCxTQUFPaEIsZUFBZSxDQUFDNU0sTUFBdkI7QUFDSDs7QUFDRCxJQUFJaUYsUUFBUSxHQUFHMkgsZUFBZjtBQUNBeE4sZUFBQSxHQUFrQjZGLFFBQWxCOztBQUNBLFNBQVNsQyxTQUFULEdBQXFCO0FBQ2pCLFNBQU96RCxNQUFNLENBQUNELE9BQVAsQ0FBZXlPLFVBQWYsQ0FBMEJuQixjQUFjLENBQUNvQixhQUF6QyxDQUFQO0FBQ0g7O0FBQ0QsU0FBU3RCLFlBQVQsQ0FBc0IsR0FBRzdLLElBQXpCLEVBQStCO0FBQzNCZ0wsRUFBQUEsZUFBZSxDQUFDNU0sTUFBaEIsR0FBeUIsSUFBSVAsT0FBTyxDQUFDSixPQUFaLENBQW9CLEdBQUd1QyxJQUF2QixDQUF6QjtBQUNBZ0wsRUFBQUEsZUFBZSxDQUFDQyxjQUFoQixDQUErQnpLLE9BQS9CLENBQXdDMEQsRUFBRCxJQUFNQSxFQUFFLEVBQS9DO0FBRUE4RyxFQUFBQSxlQUFlLENBQUNDLGNBQWhCLEdBQWlDLEVBQWpDO0FBQ0EsU0FBT0QsZUFBZSxDQUFDNU0sTUFBdkI7QUFDSDs7QUFDRCxTQUFTME0sd0JBQVQsQ0FBa0MxTSxNQUFsQyxFQUEwQztBQUN0QyxRQUFNTixRQUFRLEdBQUdNLE1BQWpCO0FBQ0EsUUFBTWdPLFFBQVEsR0FBRyxFQUFqQjs7QUFFQSxPQUFLLE1BQU1DLFFBQVgsSUFBdUJqQixpQkFBdkIsRUFBeUM7QUFDckMsUUFBSSxPQUFPdE4sUUFBUSxDQUFDdU8sUUFBRCxDQUFmLEtBQThCLFFBQWxDLEVBQTRDO0FBQ3hDRCxNQUFBQSxRQUFRLENBQUNDLFFBQUQsQ0FBUixHQUFxQi9PLE1BQU0sQ0FBQytNLE1BQVAsQ0FBY2lDLEtBQUssQ0FBQ0MsT0FBTixDQUFjek8sUUFBUSxDQUFDdU8sUUFBRCxDQUF0QixJQUFvQyxFQUFwQyxHQUF5QyxFQUF2RCxFQUNsQnZPLFFBQVEsQ0FBQ3VPLFFBQUQsQ0FEVSxDQUFyQixDQUN1QjtBQUR2QjtBQUdBO0FBQ0g7O0FBQ0RELElBQUFBLFFBQVEsQ0FBQ0MsUUFBRCxDQUFSLEdBQXFCdk8sUUFBUSxDQUFDdU8sUUFBRCxDQUE3QjtBQUNILEdBWnFDLENBYXRDOzs7QUFDQUQsRUFBQUEsUUFBUSxDQUFDYixNQUFULEdBQWtCMU4sT0FBTyxDQUFDSixPQUFSLENBQWdCOE4sTUFBbEM7QUFDQUQsRUFBQUEsZ0JBQWdCLENBQUM5SyxPQUFqQixDQUEwQmdMLEtBQUQsSUFBUztBQUM5QlksSUFBQUEsUUFBUSxDQUFDWixLQUFELENBQVIsR0FBa0IsQ0FBQyxHQUFHeEwsSUFBSixLQUFXO0FBQ3pCLGFBQU9sQyxRQUFRLENBQUMwTixLQUFELENBQVIsQ0FBZ0IsR0FBR3hMLElBQW5CLENBQVA7QUFDSCxLQUZEO0FBR0gsR0FKRDtBQUtBLFNBQU9vTSxRQUFQO0FBQ0g7Ozs7Ozs7Ozs7O0FDeEpZOztBQUNiOU8sOENBQTZDO0FBQ3pDaEQsRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0FrRCx1QkFBQSxHQUEwQndFLGVBQTFCOztBQUNBLElBQUl0RSxNQUFNLEdBQUdFLG1CQUFPLENBQUMsb0JBQUQsQ0FBcEI7O0FBQ0EsSUFBSXNILG9CQUFvQixHQUFHdEgsbUJBQU8sQ0FBQyx5RkFBRCxDQUFsQzs7QUFDQSxNQUFNNE8sdUJBQXVCLEdBQUcsT0FBT0Msb0JBQVAsS0FBZ0MsV0FBaEU7O0FBQ0EsU0FBU3pLLGVBQVQsQ0FBeUI7QUFBRUMsRUFBQUEsVUFBRjtBQUFleUssRUFBQUE7QUFBZixDQUF6QixFQUFxRDtBQUNqRCxRQUFNQyxVQUFVLEdBQUdELFFBQVEsSUFBSSxDQUFDRix1QkFBaEM7QUFDQSxRQUFNSSxTQUFTLEdBQUcsQ0FBQyxHQUFHbFAsTUFBSixFQUFZcUQsTUFBWixFQUFsQjtBQUNBLFFBQU0sQ0FBQzhMLE9BQUQsRUFBVUMsVUFBVixJQUF3QixDQUFDLEdBQUdwUCxNQUFKLEVBQVloQixRQUFaLENBQXFCLEtBQXJCLENBQTlCO0FBQ0EsUUFBTXdGLE1BQU0sR0FBRyxDQUFDLEdBQUd4RSxNQUFKLEVBQVl5RSxXQUFaLENBQXlCQyxFQUFELElBQU07QUFDekMsUUFBSXdLLFNBQVMsQ0FBQzVMLE9BQWQsRUFBdUI7QUFDbkI0TCxNQUFBQSxTQUFTLENBQUM1TCxPQUFWO0FBQ0E0TCxNQUFBQSxTQUFTLENBQUM1TCxPQUFWLEdBQW9CK0wsU0FBcEI7QUFDSDs7QUFDRCxRQUFJSixVQUFVLElBQUlFLE9BQWxCLEVBQTJCOztBQUMzQixRQUFJekssRUFBRSxJQUFJQSxFQUFFLENBQUM0SyxPQUFiLEVBQXNCO0FBQ2xCSixNQUFBQSxTQUFTLENBQUM1TCxPQUFWLEdBQW9CaU0sT0FBTyxDQUFDN0ssRUFBRCxFQUFNTCxTQUFELElBQWFBLFNBQVMsSUFBSStLLFVBQVUsQ0FBQy9LLFNBQUQsQ0FBekMsRUFDekI7QUFDRUUsUUFBQUE7QUFERixPQUR5QixDQUEzQjtBQUlIO0FBQ0osR0FaYyxFQVlaLENBQ0MwSyxVQURELEVBRUMxSyxVQUZELEVBR0M0SyxPQUhELENBWlksQ0FBZjtBQWlCQSxHQUFDLEdBQUduUCxNQUFKLEVBQVk3RyxTQUFaLENBQXNCLE1BQUk7QUFDdEIsUUFBSSxDQUFDMlYsdUJBQUwsRUFBOEI7QUFDMUIsVUFBSSxDQUFDSyxPQUFMLEVBQWM7QUFDVixjQUFNSyxZQUFZLEdBQUcsQ0FBQyxHQUFHaEksb0JBQUosRUFBMEJyQixtQkFBMUIsQ0FBOEMsTUFBSWlKLFVBQVUsQ0FBQyxJQUFELENBQTVELENBQXJCO0FBRUEsZUFBTyxNQUFJLENBQUMsR0FBRzVILG9CQUFKLEVBQTBCcEIsa0JBQTFCLENBQTZDb0osWUFBN0MsQ0FBWDtBQUVIO0FBQ0o7QUFDSixHQVRELEVBU0csQ0FDQ0wsT0FERCxDQVRIO0FBWUEsU0FBTyxDQUNIM0ssTUFERyxFQUVIMkssT0FGRyxDQUFQO0FBSUg7O0FBQ0QsU0FBU0ksT0FBVCxDQUFpQkUsT0FBakIsRUFBMEJDLFFBQTFCLEVBQW9DN08sT0FBcEMsRUFBNkM7QUFDekMsUUFBTTtBQUFFb0csSUFBQUEsRUFBRjtBQUFPMEksSUFBQUEsUUFBUDtBQUFrQkMsSUFBQUE7QUFBbEIsTUFBZ0NDLGNBQWMsQ0FBQ2hQLE9BQUQsQ0FBcEQ7QUFDQStPLEVBQUFBLFFBQVEsQ0FBQ3pILEdBQVQsQ0FBYXNILE9BQWIsRUFBc0JDLFFBQXRCO0FBQ0FDLEVBQUFBLFFBQVEsQ0FBQ0osT0FBVCxDQUFpQkUsT0FBakI7QUFDQSxTQUFPLFNBQVNQLFNBQVQsR0FBcUI7QUFDeEJVLElBQUFBLFFBQVEsQ0FBQ0UsTUFBVCxDQUFnQkwsT0FBaEI7QUFDQUUsSUFBQUEsUUFBUSxDQUFDVCxTQUFULENBQW1CTyxPQUFuQixFQUZ3QixDQUd4Qjs7QUFDQSxRQUFJRyxRQUFRLENBQUNHLElBQVQsS0FBa0IsQ0FBdEIsRUFBeUI7QUFDckJKLE1BQUFBLFFBQVEsQ0FBQ0ssVUFBVDtBQUNBQyxNQUFBQSxTQUFTLENBQUNILE1BQVYsQ0FBaUI3SSxFQUFqQjtBQUNIO0FBQ0osR0FSRDtBQVNIOztBQUNELE1BQU1nSixTQUFTLEdBQUcsSUFBSS9FLEdBQUosRUFBbEI7O0FBQ0EsU0FBUzJFLGNBQVQsQ0FBd0JoUCxPQUF4QixFQUFpQztBQUM3QixRQUFNb0csRUFBRSxHQUFHcEcsT0FBTyxDQUFDMEQsVUFBUixJQUFzQixFQUFqQztBQUNBLE1BQUltSyxRQUFRLEdBQUd1QixTQUFTLENBQUNwSSxHQUFWLENBQWNaLEVBQWQsQ0FBZjs7QUFDQSxNQUFJeUgsUUFBSixFQUFjO0FBQ1YsV0FBT0EsUUFBUDtBQUNIOztBQUNELFFBQU1rQixRQUFRLEdBQUcsSUFBSTFFLEdBQUosRUFBakI7QUFDQSxRQUFNeUUsUUFBUSxHQUFHLElBQUlaLG9CQUFKLENBQTBCbUIsT0FBRCxJQUFXO0FBQ2pEQSxJQUFBQSxPQUFPLENBQUNwTixPQUFSLENBQWlCOEUsS0FBRCxJQUFTO0FBQ3JCLFlBQU04SCxRQUFRLEdBQUdFLFFBQVEsQ0FBQy9ILEdBQVQsQ0FBYUQsS0FBSyxDQUFDdkcsTUFBbkIsQ0FBakI7QUFDQSxZQUFNZ0QsU0FBUyxHQUFHdUQsS0FBSyxDQUFDdUksY0FBTixJQUF3QnZJLEtBQUssQ0FBQ3dJLGlCQUFOLEdBQTBCLENBQXBFOztBQUNBLFVBQUlWLFFBQVEsSUFBSXJMLFNBQWhCLEVBQTJCO0FBQ3ZCcUwsUUFBQUEsUUFBUSxDQUFDckwsU0FBRCxDQUFSO0FBQ0g7QUFDSixLQU5EO0FBT0gsR0FSZ0IsRUFRZHhELE9BUmMsQ0FBakI7QUFTQW9QLEVBQUFBLFNBQVMsQ0FBQzlILEdBQVYsQ0FBY2xCLEVBQWQsRUFBa0J5SCxRQUFRLEdBQUc7QUFDekJ6SCxJQUFBQSxFQUR5QjtBQUV6QjBJLElBQUFBLFFBRnlCO0FBR3pCQyxJQUFBQTtBQUh5QixHQUE3QjtBQUtBLFNBQU9sQixRQUFQO0FBQ0g7Ozs7Ozs7Ozs7O0FDbkZZOztBQUNiOU8sOENBQTZDO0FBQ3pDaEQsRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0FrRCxlQUFBLEdBQWtCdVEsVUFBbEI7O0FBQ0EsSUFBSXJRLE1BQU0sR0FBR0Msc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsb0JBQUQsQ0FBUixDQUFuQzs7QUFDQSxJQUFJQyxPQUFPLEdBQUdELG1CQUFPLENBQUMsMkRBQUQsQ0FBckI7O0FBQ0EsU0FBU0Qsc0JBQVQsQ0FBZ0NLLEdBQWhDLEVBQXFDO0FBQ2pDLFNBQU9BLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxVQUFYLEdBQXdCRCxHQUF4QixHQUE4QjtBQUNqQ1AsSUFBQUEsT0FBTyxFQUFFTztBQUR3QixHQUFyQztBQUdIOztBQUNELFNBQVMrUCxVQUFULENBQW9CQyxpQkFBcEIsRUFBdUM7QUFDbkMsV0FBU0MsaUJBQVQsQ0FBMkI3VyxLQUEzQixFQUFrQztBQUM5QixXQUFPLGFBQWNzRyxNQUFNLENBQUNELE9BQVAsQ0FBZStELGFBQWYsQ0FBNkJ3TSxpQkFBN0IsRUFBZ0QxUSxNQUFNLENBQUMrTSxNQUFQLENBQWM7QUFDL0VqTSxNQUFBQSxNQUFNLEVBQUUsQ0FBQyxHQUFHUCxPQUFKLEVBQWFzRCxTQUFiO0FBRHVFLEtBQWQsRUFFbEUvSixLQUZrRSxDQUFoRCxDQUFyQjtBQUdIOztBQUNENlcsRUFBQUEsaUJBQWlCLENBQUNDLGVBQWxCLEdBQW9DRixpQkFBaUIsQ0FBQ0UsZUFBdEQ7QUFDQUQsRUFBQUEsaUJBQWlCLENBQUNFLG1CQUFsQixHQUF3Q0gsaUJBQWlCLENBQUNHLG1CQUExRDs7QUFDQSxZQUEyQztBQUN2QyxVQUFNL1UsSUFBSSxHQUFHNFUsaUJBQWlCLENBQUNJLFdBQWxCLElBQWlDSixpQkFBaUIsQ0FBQzVVLElBQW5ELElBQTJELFNBQXhFO0FBQ0E2VSxJQUFBQSxpQkFBaUIsQ0FBQ0csV0FBbEIsR0FBaUMsY0FBYWhWLElBQUssR0FBbkQ7QUFDSDs7QUFDRCxTQUFPNlUsaUJBQVA7QUFDSDs7Ozs7Ozs7Ozs7QUN6Qlk7O0FBQ2IzUSw4Q0FBNkM7QUFDekNoRCxFQUFBQSxLQUFLLEVBQUU7QUFEa0MsQ0FBN0M7QUFHQWtELHVCQUFBLEdBQTBCc0YsZUFBMUI7QUFDQXRGLGlCQUFBLEdBQW9CMEYsU0FBcEI7QUFDQTFGLGlCQUFBLEdBQW9CNlEsU0FBcEI7QUFDQTdRLG1CQUFBLEdBQXNCOFEsV0FBdEI7QUFDQTlRLG1CQUFBLEdBQXNCeUYsV0FBdEI7QUFDQXpGLG1CQUFBLEdBQXNCK1EsV0FBdEI7QUFDQS9RLGtCQUFBLEdBQXFCZ0IsVUFBckI7QUFDQWhCLHFCQUFBLEdBQXdCZ1IsYUFBeEI7QUFDQWhSLG1CQUFBLEdBQXNCOEQsV0FBdEI7QUFDQTlELGVBQUEsR0FBa0IsS0FBSyxDQUF2Qjs7QUFDQSxJQUFJaVIsdUJBQXVCLEdBQUc3USxtQkFBTyxDQUFDLDZHQUFELENBQXJDOztBQUNBLElBQUk4USxZQUFZLEdBQUc5USxtQkFBTyxDQUFDLHFGQUFELENBQTFCOztBQUNBLElBQUkrUSxvQkFBb0IsR0FBRy9RLG1CQUFPLENBQUMsb0ZBQUQsQ0FBbEM7O0FBQ0EsSUFBSWdSLG9CQUFvQixHQUFHaFIsbUJBQU8sQ0FBQyxvRUFBRCxDQUFsQzs7QUFDQSxJQUFJaVIsS0FBSyxHQUFHbFIsc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsd0JBQUQsQ0FBUixDQUFsQzs7QUFDQSxJQUFJa1IsTUFBTSxHQUFHbFIsbUJBQU8sQ0FBQyxxQ0FBRCxDQUFwQjs7QUFDQSxJQUFJbVIsVUFBVSxHQUFHblIsbUJBQU8sQ0FBQyw4Q0FBRCxDQUF4Qjs7QUFDQSxJQUFJb1IsaUJBQWlCLEdBQUdwUixtQkFBTyxDQUFDLDhEQUFELENBQS9COztBQUNBLElBQUlxUixZQUFZLEdBQUdyUixtQkFBTyxDQUFDLGdEQUFELENBQTFCOztBQUNBLElBQUlzUixnQkFBZ0IsR0FBR3ZSLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLHVDQUFELENBQVIsQ0FBN0M7O0FBQ0EsSUFBSXVSLGFBQWEsR0FBR3ZSLG1CQUFPLENBQUMsb0RBQUQsQ0FBM0I7O0FBQ0EsSUFBSXdSLFdBQVcsR0FBR3hSLG1CQUFPLENBQUMsZ0RBQUQsQ0FBekI7O0FBQ0EsU0FBU0Qsc0JBQVQsQ0FBZ0NLLEdBQWhDLEVBQXFDO0FBQ2pDLFNBQU9BLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxVQUFYLEdBQXdCRCxHQUF4QixHQUE4QjtBQUNqQ1AsSUFBQUEsT0FBTyxFQUFFTztBQUR3QixHQUFyQztBQUdIOztBQUNELElBQUlxUixrQkFBSjs7QUFDQSxJQUFJeFMsS0FBSixFQUFxQyxFQUVwQzs7QUFDRCxNQUFNMFMsUUFBUSxHQUFHMVMsTUFBQSxJQUFzQyxFQUF2RDs7QUFDQSxTQUFTNFMsc0JBQVQsR0FBa0M7QUFDOUIsU0FBT25TLE1BQU0sQ0FBQytNLE1BQVAsQ0FBYyxJQUFJcEssS0FBSixDQUFVLGlCQUFWLENBQWQsRUFBNEM7QUFDL0MySCxJQUFBQSxTQUFTLEVBQUU7QUFEb0MsR0FBNUMsQ0FBUDtBQUdIOztBQUNELFNBQVM4SCxhQUFULENBQXVCbE0sSUFBdkIsRUFBNkJtTSxNQUE3QixFQUFxQztBQUNqQyxTQUFPQSxNQUFNLElBQUluTSxJQUFJLENBQUNvTSxVQUFMLENBQWdCLEdBQWhCLENBQVYsR0FBaUNwTSxJQUFJLEtBQUssR0FBVCxHQUFlLENBQUMsR0FBR2lMLHVCQUFKLEVBQTZCbEwsMEJBQTdCLENBQXdEb00sTUFBeEQsQ0FBZixHQUFrRixHQUFFQSxNQUFPLEdBQUVFLGVBQWUsQ0FBQ3JNLElBQUQsQ0FBZixLQUEwQixHQUExQixHQUFnQ0EsSUFBSSxDQUFDc0ksU0FBTCxDQUFlLENBQWYsQ0FBaEMsR0FBb0R0SSxJQUFLLEVBQXZMLEdBQTJMQSxJQUFsTTtBQUNIOztBQUNELFNBQVNWLGVBQVQsQ0FBeUJVLElBQXpCLEVBQStCNUUsTUFBL0IsRUFBdUNtRSxPQUF2QyxFQUFnREMsYUFBaEQsRUFBK0Q7QUFDM0QsTUFBSW5HLEtBQUosRUFBcUMsRUFBckMsTUFPTztBQUNILFdBQU8sS0FBUDtBQUNIO0FBQ0o7O0FBQ0QsU0FBU3FHLFNBQVQsQ0FBbUJNLElBQW5CLEVBQXlCNUUsTUFBekIsRUFBaUN1RSxhQUFqQyxFQUFnRDtBQUM1QyxNQUFJdEcsS0FBSixFQUFxQyxFQUtwQzs7QUFDRCxTQUFPMkcsSUFBUDtBQUNIOztBQUNELFNBQVM2SyxTQUFULENBQW1CN0ssSUFBbkIsRUFBeUI1RSxNQUF6QixFQUFpQztBQUM3QixNQUFJL0IsS0FBSixFQUFxQyxFQUtwQzs7QUFDRCxTQUFPMkcsSUFBUDtBQUNIOztBQUNELFNBQVNxTSxlQUFULENBQXlCck0sSUFBekIsRUFBK0I7QUFDM0IsUUFBTWlOLFVBQVUsR0FBR2pOLElBQUksQ0FBQzFELE9BQUwsQ0FBYSxHQUFiLENBQW5CO0FBQ0EsUUFBTTRRLFNBQVMsR0FBR2xOLElBQUksQ0FBQzFELE9BQUwsQ0FBYSxHQUFiLENBQWxCOztBQUNBLE1BQUkyUSxVQUFVLEdBQUcsQ0FBQyxDQUFkLElBQW1CQyxTQUFTLEdBQUcsQ0FBQyxDQUFwQyxFQUF1QztBQUNuQ2xOLElBQUFBLElBQUksR0FBR0EsSUFBSSxDQUFDc0ksU0FBTCxDQUFlLENBQWYsRUFBa0IyRSxVQUFVLEdBQUcsQ0FBQyxDQUFkLEdBQWtCQSxVQUFsQixHQUErQkMsU0FBakQsQ0FBUDtBQUNIOztBQUNELFNBQU9sTixJQUFQO0FBQ0g7O0FBQ0QsU0FBUzhLLFdBQVQsQ0FBcUI5SyxJQUFyQixFQUEyQjtBQUN2QkEsRUFBQUEsSUFBSSxHQUFHcU0sZUFBZSxDQUFDck0sSUFBRCxDQUF0QjtBQUNBLFNBQU9BLElBQUksS0FBSytMLFFBQVQsSUFBcUIvTCxJQUFJLENBQUNvTSxVQUFMLENBQWdCTCxRQUFRLEdBQUcsR0FBM0IsQ0FBNUI7QUFDSDs7QUFDRCxTQUFTdE0sV0FBVCxDQUFxQk8sSUFBckIsRUFBMkI7QUFDdkI7QUFDQSxTQUFPa00sYUFBYSxDQUFDbE0sSUFBRCxFQUFPK0wsUUFBUCxDQUFwQjtBQUNIOztBQUNELFNBQVNoQixXQUFULENBQXFCL0ssSUFBckIsRUFBMkI7QUFDdkJBLEVBQUFBLElBQUksR0FBR0EsSUFBSSxDQUFDRSxLQUFMLENBQVc2TCxRQUFRLENBQUNnQixNQUFwQixDQUFQO0FBQ0EsTUFBSSxDQUFDL00sSUFBSSxDQUFDb00sVUFBTCxDQUFnQixHQUFoQixDQUFMLEVBQTJCcE0sSUFBSSxHQUFJLElBQUdBLElBQUssRUFBaEI7QUFDM0IsU0FBT0EsSUFBUDtBQUNIOztBQUNELFNBQVNoRixVQUFULENBQW9CbVMsR0FBcEIsRUFBeUI7QUFDckI7QUFDQSxNQUFJQSxHQUFHLENBQUNmLFVBQUosQ0FBZSxHQUFmLEtBQXVCZSxHQUFHLENBQUNmLFVBQUosQ0FBZSxHQUFmLENBQXZCLElBQThDZSxHQUFHLENBQUNmLFVBQUosQ0FBZSxHQUFmLENBQWxELEVBQXVFLE9BQU8sSUFBUDs7QUFDdkUsTUFBSTtBQUNBO0FBQ0EsVUFBTWdCLGNBQWMsR0FBRyxDQUFDLEdBQUc5QixNQUFKLEVBQVkrQixpQkFBWixFQUF2QjtBQUNBLFVBQU1DLFFBQVEsR0FBRyxJQUFJQyxHQUFKLENBQVFKLEdBQVIsRUFBYUMsY0FBYixDQUFqQjtBQUNBLFdBQU9FLFFBQVEsQ0FBQ0UsTUFBVCxLQUFvQkosY0FBcEIsSUFBc0N0QyxXQUFXLENBQUN3QyxRQUFRLENBQUNYLFFBQVYsQ0FBeEQ7QUFDSCxHQUxELENBS0UsT0FBTzFQLENBQVAsRUFBVTtBQUNSLFdBQU8sS0FBUDtBQUNIO0FBQ0o7O0FBQ0QsU0FBUytOLGFBQVQsQ0FBdUJyRyxLQUF2QixFQUE4QjhJLFVBQTlCLEVBQTBDQyxLQUExQyxFQUFpRDtBQUM3QyxNQUFJQyxpQkFBaUIsR0FBRyxFQUF4QjtBQUNBLFFBQU1DLFlBQVksR0FBRyxDQUFDLEdBQUdoQyxXQUFKLEVBQWlCaUMsYUFBakIsQ0FBK0JsSixLQUEvQixDQUFyQjtBQUNBLFFBQU1tSixhQUFhLEdBQUdGLFlBQVksQ0FBQ0csTUFBbkM7QUFDQSxRQUFNQyxjQUFjLEdBQUc7QUFDdkIsR0FBQ1AsVUFBVSxLQUFLOUksS0FBZixHQUF1QixDQUFDLEdBQUdnSCxhQUFKLEVBQW1Cc0MsZUFBbkIsQ0FBbUNMLFlBQW5DLEVBQWlESCxVQUFqRCxDQUF2QixHQUFzRixFQUF2RixLQUE4RjtBQUM5RjtBQUNBQyxFQUFBQSxLQUhBO0FBSUFDLEVBQUFBLGlCQUFpQixHQUFHaEosS0FBcEI7QUFDQSxRQUFNdUosTUFBTSxHQUFHcFUsTUFBTSxDQUFDaUQsSUFBUCxDQUFZK1EsYUFBWixDQUFmOztBQUNBLE1BQUksQ0FBQ0ksTUFBTSxDQUFDQyxLQUFQLENBQWNDLEtBQUQsSUFBUztBQUN2QixRQUFJdFgsS0FBSyxHQUFHa1gsY0FBYyxDQUFDSSxLQUFELENBQWQsSUFBeUIsRUFBckM7QUFDQSxVQUFNO0FBQUVDLE1BQUFBLE1BQUY7QUFBV0MsTUFBQUE7QUFBWCxRQUF5QlIsYUFBYSxDQUFDTSxLQUFELENBQTVDLENBRnVCLENBR3ZCO0FBQ0E7O0FBQ0EsUUFBSUcsUUFBUSxHQUFJLElBQUdGLE1BQU0sR0FBRyxLQUFILEdBQVcsRUFBRyxHQUFFRCxLQUFNLEdBQS9DOztBQUNBLFFBQUlFLFFBQUosRUFBYztBQUNWQyxNQUFBQSxRQUFRLEdBQUksR0FBRSxDQUFDelgsS0FBRCxHQUFTLEdBQVQsR0FBZSxFQUFHLElBQUd5WCxRQUFTLEdBQTVDO0FBQ0g7O0FBQ0QsUUFBSUYsTUFBTSxJQUFJLENBQUN2RixLQUFLLENBQUNDLE9BQU4sQ0FBY2pTLEtBQWQsQ0FBZixFQUFxQ0EsS0FBSyxHQUFHLENBQ3pDQSxLQUR5QyxDQUFSO0FBR3JDLFdBQU8sQ0FBQ3dYLFFBQVEsSUFBSUYsS0FBSyxJQUFJSixjQUF0QixNQUNOTCxpQkFBaUIsR0FBR0EsaUJBQWlCLENBQUMxUixPQUFsQixDQUEwQnNTLFFBQTFCLEVBQW9DRixNQUFNLEdBQUd2WCxLQUFLLENBQUM4QixHQUFOLEVBQVU7QUFDNUU7QUFDQTtBQUNBO0FBQ0M0VixJQUFBQSxPQUFELElBQVdDLGtCQUFrQixDQUFDRCxPQUFELENBSnFDLEVBS2hFRSxJQUxnRSxDQUszRCxHQUwyRCxDQUFILEdBS2pERCxrQkFBa0IsQ0FBQzNYLEtBQUQsQ0FMWCxLQUt1QixHQU5yQyxDQUFQO0FBT0gsR0FuQkksQ0FBTCxFQW1CSTtBQUNBNlcsSUFBQUEsaUJBQWlCLEdBQUcsRUFBcEIsQ0FBdUI7QUFBdkIsS0FEQSxDQUdKO0FBQ0E7QUFDQzs7QUFDRCxTQUFPO0FBQ0hPLElBQUFBLE1BREc7QUFFSFMsSUFBQUEsTUFBTSxFQUFFaEI7QUFGTCxHQUFQO0FBSUg7O0FBQ0QsU0FBU2lCLGtCQUFULENBQTRCbEIsS0FBNUIsRUFBbUNRLE1BQW5DLEVBQTJDO0FBQ3ZDLFFBQU1XLGFBQWEsR0FBRyxFQUF0QjtBQUVBL1UsRUFBQUEsTUFBTSxDQUFDaUQsSUFBUCxDQUFZMlEsS0FBWixFQUFtQjFRLE9BQW5CLENBQTRCTixHQUFELElBQU87QUFDOUIsUUFBSSxDQUFDd1IsTUFBTSxDQUFDWSxRQUFQLENBQWdCcFMsR0FBaEIsQ0FBTCxFQUEyQjtBQUN2Qm1TLE1BQUFBLGFBQWEsQ0FBQ25TLEdBQUQsQ0FBYixHQUFxQmdSLEtBQUssQ0FBQ2hSLEdBQUQsQ0FBMUI7QUFDSDtBQUNKLEdBSkQ7QUFLQSxTQUFPbVMsYUFBUDtBQUNIOztBQUNELFNBQVMvUSxXQUFULENBQXFCbEQsTUFBckIsRUFBNkJDLElBQTdCLEVBQW1Da1UsU0FBbkMsRUFBOEM7QUFDMUM7QUFDQSxNQUFJQyxJQUFKO0FBQ0EsTUFBSUMsV0FBVyxHQUFHLE9BQU9wVSxJQUFQLEtBQWdCLFFBQWhCLEdBQTJCQSxJQUEzQixHQUFrQyxDQUFDLEdBQUd5USxNQUFKLEVBQVk0RCxvQkFBWixDQUFpQ3JVLElBQWpDLENBQXBELENBSDBDLENBSTFDO0FBQ0E7O0FBQ0EsUUFBTXNVLGFBQWEsR0FBR0YsV0FBVyxDQUFDRyxLQUFaLENBQWtCLG9CQUFsQixDQUF0QjtBQUNBLFFBQU1DLGtCQUFrQixHQUFHRixhQUFhLEdBQUdGLFdBQVcsQ0FBQ2pDLE1BQVosQ0FBbUJtQyxhQUFhLENBQUMsQ0FBRCxDQUFiLENBQWlCcEMsTUFBcEMsQ0FBSCxHQUFpRGtDLFdBQXpGO0FBQ0EsUUFBTUssUUFBUSxHQUFHRCxrQkFBa0IsQ0FBQ0UsS0FBbkIsQ0FBeUIsR0FBekIsQ0FBakI7O0FBQ0EsTUFBSSxDQUFDRCxRQUFRLENBQUMsQ0FBRCxDQUFSLElBQWUsRUFBaEIsRUFBb0JGLEtBQXBCLENBQTBCLFdBQTFCLENBQUosRUFBNEM7QUFDeEM1YSxJQUFBQSxPQUFPLENBQUMyUixLQUFSLENBQWUsdUNBQXNDOEksV0FBWSw2RUFBakU7QUFDQSxVQUFNTyxhQUFhLEdBQUcsQ0FBQyxHQUFHbEUsTUFBSixFQUFZbUUsd0JBQVosQ0FBcUNKLGtCQUFyQyxDQUF0QjtBQUNBSixJQUFBQSxXQUFXLEdBQUcsQ0FBQ0UsYUFBYSxHQUFHQSxhQUFhLENBQUMsQ0FBRCxDQUFoQixHQUFzQixFQUFwQyxJQUEwQ0ssYUFBeEQ7QUFDSCxHQWJ5QyxDQWMxQzs7O0FBQ0EsTUFBSSxDQUFDeFUsVUFBVSxDQUFDaVUsV0FBRCxDQUFmLEVBQThCO0FBQzFCLFdBQU9GLFNBQVMsR0FBRyxDQUNmRSxXQURlLENBQUgsR0FFWkEsV0FGSjtBQUdIOztBQUNELE1BQUk7QUFDQUQsSUFBQUEsSUFBSSxHQUFHLElBQUl6QixHQUFKLENBQVEwQixXQUFXLENBQUM3QyxVQUFaLENBQXVCLEdBQXZCLElBQThCeFIsTUFBTSxDQUFDOFUsTUFBckMsR0FBOEM5VSxNQUFNLENBQUMrUixRQUE3RCxFQUF1RSxVQUF2RSxDQUFQO0FBQ0gsR0FGRCxDQUVFLE9BQU8xUCxDQUFQLEVBQVU7QUFDUjtBQUNBK1IsSUFBQUEsSUFBSSxHQUFHLElBQUl6QixHQUFKLENBQVEsR0FBUixFQUFhLFVBQWIsQ0FBUDtBQUNIOztBQUNELE1BQUk7QUFDQSxVQUFNb0MsUUFBUSxHQUFHLElBQUlwQyxHQUFKLENBQVEwQixXQUFSLEVBQXFCRCxJQUFyQixDQUFqQjtBQUNBVyxJQUFBQSxRQUFRLENBQUNoRCxRQUFULEdBQW9CLENBQUMsR0FBRzFCLHVCQUFKLEVBQTZCbEwsMEJBQTdCLENBQXdENFAsUUFBUSxDQUFDaEQsUUFBakUsQ0FBcEI7QUFDQSxRQUFJaUQsY0FBYyxHQUFHLEVBQXJCOztBQUNBLFFBQUksQ0FBQyxHQUFHckUsVUFBSixFQUFnQnNFLGNBQWhCLENBQStCRixRQUFRLENBQUNoRCxRQUF4QyxLQUFxRGdELFFBQVEsQ0FBQ0csWUFBOUQsSUFBOEVmLFNBQWxGLEVBQTZGO0FBQ3pGLFlBQU1yQixLQUFLLEdBQUcsQ0FBQyxHQUFHakMsWUFBSixFQUFrQnNFLHNCQUFsQixDQUF5Q0osUUFBUSxDQUFDRyxZQUFsRCxDQUFkO0FBQ0EsWUFBTTtBQUFFbkIsUUFBQUEsTUFBRjtBQUFXVCxRQUFBQTtBQUFYLFVBQXVCbEQsYUFBYSxDQUFDMkUsUUFBUSxDQUFDaEQsUUFBVixFQUFvQmdELFFBQVEsQ0FBQ2hELFFBQTdCLEVBQXVDZSxLQUF2QyxDQUExQzs7QUFDQSxVQUFJaUIsTUFBSixFQUFZO0FBQ1JpQixRQUFBQSxjQUFjLEdBQUcsQ0FBQyxHQUFHdEUsTUFBSixFQUFZNEQsb0JBQVosQ0FBaUM7QUFDOUN2QyxVQUFBQSxRQUFRLEVBQUVnQyxNQURvQztBQUU5Q3FCLFVBQUFBLElBQUksRUFBRUwsUUFBUSxDQUFDSyxJQUYrQjtBQUc5Q3RDLFVBQUFBLEtBQUssRUFBRWtCLGtCQUFrQixDQUFDbEIsS0FBRCxFQUFRUSxNQUFSO0FBSHFCLFNBQWpDLENBQWpCO0FBS0g7QUFDSixLQWRELENBZUE7OztBQUNBLFVBQU10USxZQUFZLEdBQUcrUixRQUFRLENBQUNuQyxNQUFULEtBQW9Cd0IsSUFBSSxDQUFDeEIsTUFBekIsR0FBa0NtQyxRQUFRLENBQUM5VSxJQUFULENBQWNxRixLQUFkLENBQW9CeVAsUUFBUSxDQUFDbkMsTUFBVCxDQUFnQlQsTUFBcEMsQ0FBbEMsR0FBZ0Y0QyxRQUFRLENBQUM5VSxJQUE5RztBQUNBLFdBQU9rVSxTQUFTLEdBQUcsQ0FDZm5SLFlBRGUsRUFFZmdTLGNBQWMsSUFBSWhTLFlBRkgsQ0FBSCxHQUdaQSxZQUhKO0FBSUgsR0FyQkQsQ0FxQkUsT0FBT1gsQ0FBUCxFQUFVO0FBQ1IsV0FBTzhSLFNBQVMsR0FBRyxDQUNmRSxXQURlLENBQUgsR0FFWkEsV0FGSjtBQUdIO0FBQ0o7O0FBQ0QsU0FBU2dCLFdBQVQsQ0FBcUI5QyxHQUFyQixFQUEwQjtBQUN0QixRQUFNSyxNQUFNLEdBQUcsQ0FBQyxHQUFHbEMsTUFBSixFQUFZK0IsaUJBQVosRUFBZjtBQUNBLFNBQU9GLEdBQUcsQ0FBQ2YsVUFBSixDQUFlb0IsTUFBZixJQUF5QkwsR0FBRyxDQUFDN0UsU0FBSixDQUFja0YsTUFBTSxDQUFDVCxNQUFyQixDQUF6QixHQUF3REksR0FBL0Q7QUFDSDs7QUFDRCxTQUFTK0MsWUFBVCxDQUFzQnRWLE1BQXRCLEVBQThCdVMsR0FBOUIsRUFBbUNyUyxFQUFuQyxFQUF1QztBQUNuQztBQUNBO0FBQ0EsTUFBSSxDQUFDOEMsWUFBRCxFQUFlQyxVQUFmLElBQTZCQyxXQUFXLENBQUNsRCxNQUFELEVBQVN1UyxHQUFULEVBQWMsSUFBZCxDQUE1QztBQUNBLFFBQU1LLE1BQU0sR0FBRyxDQUFDLEdBQUdsQyxNQUFKLEVBQVkrQixpQkFBWixFQUFmO0FBQ0EsUUFBTThDLGFBQWEsR0FBR3ZTLFlBQVksQ0FBQ3dPLFVBQWIsQ0FBd0JvQixNQUF4QixDQUF0QjtBQUNBLFFBQU00QyxXQUFXLEdBQUd2UyxVQUFVLElBQUlBLFVBQVUsQ0FBQ3VPLFVBQVgsQ0FBc0JvQixNQUF0QixDQUFsQztBQUNBNVAsRUFBQUEsWUFBWSxHQUFHcVMsV0FBVyxDQUFDclMsWUFBRCxDQUExQjtBQUNBQyxFQUFBQSxVQUFVLEdBQUdBLFVBQVUsR0FBR29TLFdBQVcsQ0FBQ3BTLFVBQUQsQ0FBZCxHQUE2QkEsVUFBcEQ7QUFDQSxRQUFNd1MsV0FBVyxHQUFHRixhQUFhLEdBQUd2UyxZQUFILEdBQWtCNkIsV0FBVyxDQUFDN0IsWUFBRCxDQUE5RDtBQUNBLFFBQU0wUyxVQUFVLEdBQUd4VixFQUFFLEdBQUdtVixXQUFXLENBQUNuUyxXQUFXLENBQUNsRCxNQUFELEVBQVNFLEVBQVQsQ0FBWixDQUFkLEdBQTBDK0MsVUFBVSxJQUFJRCxZQUE3RTtBQUNBLFNBQU87QUFDSHVQLElBQUFBLEdBQUcsRUFBRWtELFdBREY7QUFFSHZWLElBQUFBLEVBQUUsRUFBRXNWLFdBQVcsR0FBR0UsVUFBSCxHQUFnQjdRLFdBQVcsQ0FBQzZRLFVBQUQ7QUFGdkMsR0FBUDtBQUlIOztBQUNELFNBQVNDLG1CQUFULENBQTZCNUQsUUFBN0IsRUFBdUM2RCxLQUF2QyxFQUE4QztBQUMxQyxRQUFNQyxhQUFhLEdBQUcsQ0FBQyxHQUFHeEYsdUJBQUosRUFBNkJuTCx1QkFBN0IsQ0FBcUQsQ0FBQyxHQUFHcUwsb0JBQUosRUFBMEJ1RixtQkFBMUIsQ0FBOEMvRCxRQUE5QyxDQUFyRCxDQUF0Qjs7QUFDQSxNQUFJOEQsYUFBYSxLQUFLLE1BQWxCLElBQTRCQSxhQUFhLEtBQUssU0FBbEQsRUFBNkQ7QUFDekQsV0FBTzlELFFBQVA7QUFDSCxHQUp5QyxDQUsxQzs7O0FBQ0EsTUFBSSxDQUFDNkQsS0FBSyxDQUFDMUIsUUFBTixDQUFlMkIsYUFBZixDQUFMLEVBQW9DO0FBQ2hDO0FBQ0FELElBQUFBLEtBQUssQ0FBQ0csSUFBTixDQUFZQyxJQUFELElBQVE7QUFDZixVQUFJLENBQUMsR0FBR3JGLFVBQUosRUFBZ0JzRSxjQUFoQixDQUErQmUsSUFBL0IsS0FBd0MsQ0FBQyxHQUFHaEYsV0FBSixFQUFpQmlDLGFBQWpCLENBQStCK0MsSUFBL0IsRUFBcUNDLEVBQXJDLENBQXdDelEsSUFBeEMsQ0FBNkNxUSxhQUE3QyxDQUE1QyxFQUF5RztBQUNyRzlELFFBQUFBLFFBQVEsR0FBR2lFLElBQVg7QUFDQSxlQUFPLElBQVA7QUFDSDtBQUNKLEtBTEQ7QUFNSDs7QUFDRCxTQUFPLENBQUMsR0FBRzNGLHVCQUFKLEVBQTZCbkwsdUJBQTdCLENBQXFENk0sUUFBckQsQ0FBUDtBQUNIOztBQUNELE1BQU1tRSx1QkFBdUIsR0FBR3pYLE1BQUEsSUFBbUgsQ0FBbko7QUFRQSxNQUFNZ1ksa0JBQWtCLEdBQUcxTixNQUFNLENBQUMsb0JBQUQsQ0FBakM7O0FBQ0EsU0FBUzJOLFVBQVQsQ0FBb0JuRSxHQUFwQixFQUF5Qm9FLFFBQXpCLEVBQW1DO0FBQy9CLFNBQU83TCxLQUFLLENBQUN5SCxHQUFELEVBQU07QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FxRSxJQUFBQSxXQUFXLEVBQUU7QUFaQyxHQUFOLENBQUwsQ0FhSmxQLElBYkksQ0FhRVUsR0FBRCxJQUFPO0FBQ1gsUUFBSSxDQUFDQSxHQUFHLENBQUMyQyxFQUFULEVBQWE7QUFDVCxVQUFJNEwsUUFBUSxHQUFHLENBQVgsSUFBZ0J2TyxHQUFHLENBQUN5TyxNQUFKLElBQWMsR0FBbEMsRUFBdUM7QUFDbkMsZUFBT0gsVUFBVSxDQUFDbkUsR0FBRCxFQUFNb0UsUUFBUSxHQUFHLENBQWpCLENBQWpCO0FBQ0g7O0FBQ0QsVUFBSXZPLEdBQUcsQ0FBQ3lPLE1BQUosS0FBZSxHQUFuQixFQUF3QjtBQUNwQixlQUFPek8sR0FBRyxDQUFDME8sSUFBSixHQUFXcFAsSUFBWCxDQUFpQjNNLElBQUQsSUFBUTtBQUMzQixjQUFJQSxJQUFJLENBQUNnYyxRQUFULEVBQW1CO0FBQ2YsbUJBQU87QUFDSEEsY0FBQUEsUUFBUSxFQUFFTjtBQURQLGFBQVA7QUFHSDs7QUFDRCxnQkFBTSxJQUFJNVUsS0FBSixDQUFXLDZCQUFYLENBQU47QUFDSCxTQVBNLENBQVA7QUFRSDs7QUFDRCxZQUFNLElBQUlBLEtBQUosQ0FBVyw2QkFBWCxDQUFOO0FBQ0g7O0FBQ0QsV0FBT3VHLEdBQUcsQ0FBQzBPLElBQUosRUFBUDtBQUNILEdBL0JNLENBQVA7QUFnQ0g7O0FBQ0QsU0FBU0UsYUFBVCxDQUF1QkMsUUFBdkIsRUFBaUNDLGNBQWpDLEVBQWlEO0FBQzdDLFNBQU9SLFVBQVUsQ0FBQ08sUUFBRCxFQUFXQyxjQUFjLEdBQUcsQ0FBSCxHQUFPLENBQWhDLENBQVYsQ0FBNkM3VyxLQUE3QyxDQUFvREMsR0FBRCxJQUFPO0FBQzdEO0FBQ0E7QUFDQTtBQUNBLFFBQUksQ0FBQzRXLGNBQUwsRUFBcUI7QUFDakIsT0FBQyxHQUFHNUcsWUFBSixFQUFrQjdKLGNBQWxCLENBQWlDbkcsR0FBakM7QUFDSDs7QUFDRCxVQUFNQSxHQUFOO0FBQ0gsR0FSTSxDQUFQO0FBU0g7O0FBQ0QsTUFBTTZXLE1BQU4sQ0FBYTtBQUNUQyxFQUFBQSxXQUFXLENBQUNDLFNBQUQsRUFBWUMsTUFBWixFQUFvQkMsR0FBcEIsRUFBeUI7QUFBRUMsSUFBQUEsWUFBRjtBQUFpQkMsSUFBQUEsVUFBakI7QUFBOEJDLElBQUFBLEdBQTlCO0FBQW9DQyxJQUFBQSxPQUFwQztBQUE4Q0MsSUFBQUEsU0FBUyxFQUFFQyxVQUF6RDtBQUFzRXZYLElBQUFBLEdBQUcsRUFBRXdYLElBQTNFO0FBQWtGQyxJQUFBQSxZQUFsRjtBQUFpR0MsSUFBQUEsVUFBakc7QUFBOEd4WCxJQUFBQSxNQUE5RztBQUF1SG1FLElBQUFBLE9BQXZIO0FBQWlJSSxJQUFBQSxhQUFqSTtBQUFpSkgsSUFBQUEsYUFBako7QUFBaUtxVCxJQUFBQTtBQUFqSyxHQUF6QixFQUF1TTtBQUM5TTtBQUNBLFNBQUtDLEdBQUwsR0FBVyxFQUFYLENBRjhNLENBSTlNOztBQUNBLFNBQUtDLEdBQUwsR0FBVyxFQUFYO0FBRUEsU0FBS0MsSUFBTCxHQUFZLENBQVo7O0FBQ0EsU0FBS0MsVUFBTCxHQUFtQmpYLENBQUQsSUFBSztBQUNuQixZQUFNaEUsS0FBSyxHQUFHZ0UsQ0FBQyxDQUFDaEUsS0FBaEI7O0FBQ0EsVUFBSSxDQUFDQSxLQUFMLEVBQVk7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFNO0FBQUUyVSxVQUFBQSxRQUFRLEVBQUVzRixTQUFaO0FBQXdCdkUsVUFBQUEsS0FBSyxFQUFFd0U7QUFBL0IsWUFBMkMsSUFBakQ7QUFDQSxhQUFLZ0IsV0FBTCxDQUFpQixjQUFqQixFQUFpQyxDQUFDLEdBQUc1SCxNQUFKLEVBQVk0RCxvQkFBWixDQUFpQztBQUM5RHZDLFVBQUFBLFFBQVEsRUFBRWxOLFdBQVcsQ0FBQ3dTLFNBQUQsQ0FEeUM7QUFFOUR2RSxVQUFBQSxLQUFLLEVBQUV3RTtBQUZ1RCxTQUFqQyxDQUFqQyxFQUdJLENBQUMsR0FBRzVHLE1BQUosRUFBWTZILE1BQVosRUFISjtBQUlBO0FBQ0g7O0FBQ0QsVUFBSSxDQUFDbmIsS0FBSyxDQUFDb2IsR0FBWCxFQUFnQjtBQUNaO0FBQ0g7O0FBQ0QsVUFBSUMsWUFBSjtBQUNBLFlBQU07QUFBRWxHLFFBQUFBLEdBQUY7QUFBUXJTLFFBQUFBLEVBQUUsRUFBRXFYLEdBQVo7QUFBa0JwWCxRQUFBQSxPQUFsQjtBQUE0QnVZLFFBQUFBO0FBQTVCLFVBQXFDdGIsS0FBM0M7O0FBQ0EsVUFBSXFCLEtBQUosRUFBMkMsRUF1QjFDOztBQUNELFdBQUsyWixJQUFMLEdBQVlNLEdBQVo7QUFDQSxZQUFNO0FBQUUzRyxRQUFBQSxRQUFRLEVBQUVzRjtBQUFaLFVBQTJCLENBQUMsR0FBR3pHLGlCQUFKLEVBQXVCdUksZ0JBQXZCLENBQXdDNUcsR0FBeEMsQ0FBakMsQ0FqRG1CLENBa0RuQjtBQUNBOztBQUNBLFVBQUksS0FBSzZHLEtBQUwsSUFBYzdCLEdBQUcsS0FBSyxLQUFLekMsTUFBM0IsSUFBcUN1QyxTQUFTLEtBQUssS0FBS3RGLFFBQTVELEVBQXNFO0FBQ2xFO0FBQ0gsT0F0RGtCLENBdURuQjtBQUNBOzs7QUFDQSxVQUFJLEtBQUtzSCxJQUFMLElBQWEsQ0FBQyxLQUFLQSxJQUFMLENBQVVqYyxLQUFWLENBQWxCLEVBQW9DO0FBQ2hDO0FBQ0g7O0FBQ0QsV0FBS2tjLE1BQUwsQ0FBWSxjQUFaLEVBQTRCL0csR0FBNUIsRUFBaUNnRixHQUFqQyxFQUFzQ3JZLE1BQU0sQ0FBQytNLE1BQVAsQ0FBYyxFQUFkLEVBQ25DOUwsT0FEbUMsRUFDMUI7QUFDUm1CLFFBQUFBLE9BQU8sRUFBRW5CLE9BQU8sQ0FBQ21CLE9BQVIsSUFBbUIsS0FBS2lZLFFBRHpCO0FBRVIvWSxRQUFBQSxNQUFNLEVBQUVMLE9BQU8sQ0FBQ0ssTUFBUixJQUFrQixLQUFLdUU7QUFGdkIsT0FEMEIsQ0FBdEMsRUFJSTBULFlBSko7QUFLSCxLQWpFRCxDQVI4TSxDQTBFOU07OztBQUNBLFNBQUsxTyxLQUFMLEdBQWEsQ0FBQyxHQUFHc0csdUJBQUosRUFBNkJuTCx1QkFBN0IsQ0FBcURtUyxTQUFyRCxDQUFiLENBM0U4TSxDQTRFOU07O0FBQ0EsU0FBS21DLFVBQUwsR0FBa0IsRUFBbEIsQ0E3RThNLENBK0U5TTtBQUNBO0FBQ0E7O0FBQ0EsUUFBSW5DLFNBQVMsS0FBSyxTQUFsQixFQUE2QjtBQUN6QixXQUFLbUMsVUFBTCxDQUFnQixLQUFLelAsS0FBckIsSUFBOEI7QUFDMUI2TixRQUFBQSxTQUFTLEVBQUVDLFVBRGU7QUFFMUI0QixRQUFBQSxPQUFPLEVBQUUsSUFGaUI7QUFHMUJ6Z0IsUUFBQUEsS0FBSyxFQUFFd2UsWUFIbUI7QUFJMUJsWCxRQUFBQSxHQUFHLEVBQUV3WCxJQUpxQjtBQUsxQjRCLFFBQUFBLE9BQU8sRUFBRWxDLFlBQVksSUFBSUEsWUFBWSxDQUFDa0MsT0FMWjtBQU0xQkMsUUFBQUEsT0FBTyxFQUFFbkMsWUFBWSxJQUFJQSxZQUFZLENBQUNtQztBQU5aLE9BQTlCO0FBUUg7O0FBQ0QsU0FBS0gsVUFBTCxDQUFnQixPQUFoQixJQUEyQjtBQUN2QjVCLE1BQUFBLFNBQVMsRUFBRUYsR0FEWTtBQUV2QmhOLE1BQUFBLFdBQVcsRUFBRTtBQUZVLEtBQTNCLENBNUY4TSxDQWdHOU07QUFDQTs7QUFDQSxTQUFLeUMsTUFBTCxHQUFjZ0ssTUFBTSxDQUFDaEssTUFBckI7QUFDQSxTQUFLc0ssVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxTQUFLMUYsUUFBTCxHQUFnQnNGLFNBQWhCO0FBQ0EsU0FBS3ZFLEtBQUwsR0FBYXdFLE1BQWIsQ0FyRzhNLENBc0c5TTtBQUNBOztBQUNBLFVBQU1zQyxpQkFBaUIsR0FBRyxDQUFDLEdBQUdqSixVQUFKLEVBQWdCc0UsY0FBaEIsQ0FBK0JvQyxTQUEvQixLQUE2QzFSLElBQUksQ0FBQ2tVLGFBQUwsQ0FBbUJDLFVBQTFGOztBQUNBLFNBQUtoRixNQUFMLEdBQWM4RSxpQkFBaUIsR0FBR3ZDLFNBQUgsR0FBZUUsR0FBOUM7QUFDQSxTQUFLcEcsUUFBTCxHQUFnQkEsUUFBaEI7QUFDQSxTQUFLNEksR0FBTCxHQUFXaEMsWUFBWDtBQUNBLFNBQUtpQyxHQUFMLEdBQVcsSUFBWDtBQUNBLFNBQUtDLFFBQUwsR0FBZ0J0QyxPQUFoQixDQTdHOE0sQ0E4RzlNO0FBQ0E7O0FBQ0EsU0FBS3lCLEtBQUwsR0FBYSxJQUFiO0FBQ0EsU0FBS3BCLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EsU0FBS2tDLE9BQUwsR0FBZSxDQUFDLEVBQUV2VSxJQUFJLENBQUNrVSxhQUFMLENBQW1CTSxJQUFuQixJQUEyQnhVLElBQUksQ0FBQ2tVLGFBQUwsQ0FBbUJPLEdBQTlDLElBQXFEelUsSUFBSSxDQUFDa1UsYUFBTCxDQUFtQlEsTUFBbkIsSUFBNkIsQ0FBQzFVLElBQUksQ0FBQ2tVLGFBQUwsQ0FBbUJTLEdBQXRHLElBQTZHLENBQUNWLGlCQUFELElBQXNCLENBQUNqVSxJQUFJLENBQUM0VSxRQUFMLENBQWNDLE1BQXJDLElBQStDLENBQUMvYixLQUEvSixDQUFoQjtBQUNBLFNBQUt3WixTQUFMLEdBQWlCLENBQUMsQ0FBQ0EsU0FBbkI7QUFDQSxTQUFLeFQsY0FBTCxHQUFzQixLQUF0Qjs7QUFDQSxRQUFJaEcsS0FBSixFQUFxQyxFQU1wQzs7QUFDRCxlQUFtQyxFQXVCbEM7QUFDSjs7QUFDRHFjLEVBQUFBLE1BQU0sR0FBRztBQUNMalYsSUFBQUEsTUFBTSxDQUFDMFUsUUFBUCxDQUFnQk8sTUFBaEI7QUFDSDtBQUNEO0FBQ0o7QUFDQTs7O0FBQU1DLEVBQUFBLElBQUksR0FBRztBQUNMbFYsSUFBQUEsTUFBTSxDQUFDdVEsT0FBUCxDQUFlMkUsSUFBZjtBQUNIO0FBQ0Q7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFBTWhPLEVBQUFBLElBQUksQ0FBQ3dGLEdBQUQsRUFBTXJTLEVBQU4sRUFBVUMsT0FBTyxHQUFHLEVBQXBCLEVBQ0g7QUFDQyxRQUFJMUIsS0FBSixFQUEyQyxFQWExQzs7QUFDRCxLQUFDO0FBQUU4VCxNQUFBQSxHQUFGO0FBQVFyUyxNQUFBQTtBQUFSLFFBQWdCb1YsWUFBWSxDQUFDLElBQUQsRUFBTy9DLEdBQVAsRUFBWXJTLEVBQVosQ0FBN0I7QUFDQSxXQUFPLEtBQUtvWixNQUFMLENBQVksV0FBWixFQUF5Qi9HLEdBQXpCLEVBQThCclMsRUFBOUIsRUFBa0NDLE9BQWxDLENBQVA7QUFDSDtBQUNEO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQU1rQixFQUFBQSxPQUFPLENBQUNrUixHQUFELEVBQU1yUyxFQUFOLEVBQVVDLE9BQU8sR0FBRyxFQUFwQixFQUNOO0FBQ0MsS0FBQztBQUFFb1MsTUFBQUEsR0FBRjtBQUFRclMsTUFBQUE7QUFBUixRQUFnQm9WLFlBQVksQ0FBQyxJQUFELEVBQU8vQyxHQUFQLEVBQVlyUyxFQUFaLENBQTdCO0FBQ0EsV0FBTyxLQUFLb1osTUFBTCxDQUFZLGNBQVosRUFBNEIvRyxHQUE1QixFQUFpQ3JTLEVBQWpDLEVBQXFDQyxPQUFyQyxDQUFQO0FBQ0g7O0FBQ1csUUFBTm1aLE1BQU0sQ0FBQzBCLE1BQUQsRUFBU3pJLEdBQVQsRUFBY3JTLEVBQWQsRUFBa0JDLE9BQWxCLEVBQTJCc1ksWUFBM0IsRUFBeUM7QUFDakQsUUFBSSxDQUFDclksVUFBVSxDQUFDbVMsR0FBRCxDQUFmLEVBQXNCO0FBQ2xCMU0sTUFBQUEsTUFBTSxDQUFDMFUsUUFBUCxDQUFnQnRhLElBQWhCLEdBQXVCc1MsR0FBdkI7QUFDQSxhQUFPLEtBQVA7QUFDSDs7QUFDRCxVQUFNMEksaUJBQWlCLEdBQUcxSSxHQUFHLEtBQUtyUyxFQUFSLElBQWNDLE9BQU8sQ0FBQythLEVBQXRCLElBQTRCL2EsT0FBTyxDQUFDd2Esa0JBQTlELENBTGlELENBTWpEO0FBQ0E7O0FBQ0EsUUFBSXhhLE9BQU8sQ0FBQythLEVBQVosRUFBZ0I7QUFDWixXQUFLaEIsT0FBTCxHQUFlLElBQWY7QUFDSDs7QUFDRCxVQUFNaUIsVUFBVSxHQUFHLEtBQUszYSxNQUF4Qjs7QUFDQSxRQUFJL0IsS0FBSixFQUFxQyxZQTZDcEM7O0FBQ0QsUUFBSSxDQUFDMEIsT0FBTyxDQUFDK2EsRUFBYixFQUFpQjtBQUNiLFdBQUs5QixLQUFMLEdBQWEsS0FBYjtBQUNILEtBNURnRCxDQTZEakQ7OztBQUNBLFFBQUkxSSxNQUFNLENBQUM4SyxFQUFYLEVBQWU7QUFDWEMsTUFBQUEsV0FBVyxDQUFDQyxJQUFaLENBQWlCLGFBQWpCO0FBQ0g7O0FBQ0QsVUFBTTtBQUFFcGEsTUFBQUEsT0FBTyxHQUFFO0FBQVgsUUFBc0JuQixPQUE1QjtBQUNBLFVBQU13YixVQUFVLEdBQUc7QUFDZnJhLE1BQUFBO0FBRGUsS0FBbkI7O0FBR0EsUUFBSSxLQUFLc2EsY0FBVCxFQUF5QjtBQUNyQixXQUFLQyxrQkFBTCxDQUF3QixLQUFLRCxjQUE3QixFQUE2Q0QsVUFBN0M7QUFDSDs7QUFDRHpiLElBQUFBLEVBQUUsR0FBRzJFLFdBQVcsQ0FBQ0MsU0FBUyxDQUFDb0wsV0FBVyxDQUFDaFEsRUFBRCxDQUFYLEdBQWtCaVEsV0FBVyxDQUFDalEsRUFBRCxDQUE3QixHQUFvQ0EsRUFBckMsRUFBeUNDLE9BQU8sQ0FBQ0ssTUFBakQsRUFBeUQsS0FBS3VFLGFBQTlELENBQVYsQ0FBaEI7QUFDQSxVQUFNK1csU0FBUyxHQUFHN0wsU0FBUyxDQUFDQyxXQUFXLENBQUNoUSxFQUFELENBQVgsR0FBa0JpUSxXQUFXLENBQUNqUSxFQUFELENBQTdCLEdBQW9DQSxFQUFyQyxFQUF5QyxLQUFLTSxNQUE5QyxDQUEzQjtBQUNBLFNBQUtvYixjQUFMLEdBQXNCMWIsRUFBdEI7QUFDQSxRQUFJNmIsWUFBWSxHQUFHWixVQUFVLEtBQUssS0FBSzNhLE1BQXZDLENBM0VpRCxDQTRFakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxRQUFJLENBQUNMLE9BQU8sQ0FBQythLEVBQVQsSUFBZSxLQUFLYyxlQUFMLENBQXFCRixTQUFyQixDQUFmLElBQWtELENBQUNDLFlBQXZELEVBQXFFO0FBQ2pFLFdBQUtqSCxNQUFMLEdBQWNnSCxTQUFkO0FBQ0EzRSxNQUFBQSxNQUFNLENBQUNoSyxNQUFQLENBQWM4TyxJQUFkLENBQW1CLGlCQUFuQixFQUFzQy9iLEVBQXRDLEVBQTBDeWIsVUFBMUMsRUFGaUUsQ0FHakU7O0FBQ0EsV0FBS3JELFdBQUwsQ0FBaUIwQyxNQUFqQixFQUF5QnpJLEdBQXpCLEVBQThCclMsRUFBOUIsRUFBa0NDLE9BQWxDO0FBQ0EsV0FBSytiLFlBQUwsQ0FBa0JKLFNBQWxCO0FBQ0EsV0FBS0ssTUFBTCxDQUFZLEtBQUszQyxVQUFMLENBQWdCLEtBQUt6UCxLQUFyQixDQUFaLEVBQXlDLElBQXpDO0FBQ0FvTixNQUFBQSxNQUFNLENBQUNoSyxNQUFQLENBQWM4TyxJQUFkLENBQW1CLG9CQUFuQixFQUF5Qy9iLEVBQXpDLEVBQTZDeWIsVUFBN0M7QUFDQSxhQUFPLElBQVA7QUFDSDs7QUFDRCxRQUFJUyxNQUFNLEdBQUcsQ0FBQyxHQUFHeEwsaUJBQUosRUFBdUJ1SSxnQkFBdkIsQ0FBd0M1RyxHQUF4QyxDQUFiO0FBQ0EsUUFBSTtBQUFFUixNQUFBQSxRQUFRLEVBQUVzRixTQUFaO0FBQXdCdkUsTUFBQUEsS0FBSyxFQUFFd0U7QUFBL0IsUUFBMkM4RSxNQUEvQyxDQTVGaUQsQ0E2RmpEO0FBQ0E7QUFDQTs7QUFDQSxRQUFJeEcsS0FBSixFQUFXeUcsUUFBWDs7QUFDQSxRQUFJO0FBQ0F6RyxNQUFBQSxLQUFLLEdBQUcsTUFBTSxLQUFLNkIsVUFBTCxDQUFnQjZFLFdBQWhCLEVBQWQ7QUFDQSxPQUFDO0FBQUVDLFFBQUFBLFVBQVUsRUFBRUY7QUFBZCxVQUE0QixNQUFNLENBQUMsR0FBRy9MLFlBQUosRUFBa0IzSixzQkFBbEIsRUFBbkM7QUFDSCxLQUhELENBR0UsT0FBT21SLElBQVAsRUFBYTtBQUNYO0FBQ0E7QUFDQWpTLE1BQUFBLE1BQU0sQ0FBQzBVLFFBQVAsQ0FBZ0J0YSxJQUFoQixHQUF1QkMsRUFBdkI7QUFDQSxhQUFPLEtBQVA7QUFDSCxLQXpHZ0QsQ0EwR2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFFBQUksQ0FBQyxLQUFLc2MsUUFBTCxDQUFjVixTQUFkLENBQUQsSUFBNkIsQ0FBQ0MsWUFBbEMsRUFBZ0Q7QUFDNUNmLE1BQUFBLE1BQU0sR0FBRyxjQUFUO0FBQ0gsS0FqSGdELENBa0hqRDtBQUNBOzs7QUFDQSxRQUFJL1gsVUFBVSxHQUFHL0MsRUFBakIsQ0FwSGlELENBcUhqRDtBQUNBO0FBQ0E7O0FBQ0FtWCxJQUFBQSxTQUFTLEdBQUdBLFNBQVMsR0FBRyxDQUFDLEdBQUdoSCx1QkFBSixFQUE2Qm5MLHVCQUE3QixDQUFxRGlMLFdBQVcsQ0FBQ2tILFNBQUQsQ0FBaEUsQ0FBSCxHQUFrRkEsU0FBdkc7O0FBQ0EsUUFBSTRELGlCQUFpQixJQUFJNUQsU0FBUyxLQUFLLFNBQXZDLEVBQWtEO0FBQzlDbFgsTUFBQUEsT0FBTyxDQUFDd2Esa0JBQVIsR0FBNkIsSUFBN0I7O0FBQ0EsVUFBSWxjLEtBQUosRUFBMkQsRUFBM0QsTUFXTztBQUNIMmQsUUFBQUEsTUFBTSxDQUFDckssUUFBUCxHQUFrQjRELG1CQUFtQixDQUFDMEIsU0FBRCxFQUFZekIsS0FBWixDQUFyQzs7QUFDQSxZQUFJd0csTUFBTSxDQUFDckssUUFBUCxLQUFvQnNGLFNBQXhCLEVBQW1DO0FBQy9CQSxVQUFBQSxTQUFTLEdBQUcrRSxNQUFNLENBQUNySyxRQUFuQjtBQUNBcUssVUFBQUEsTUFBTSxDQUFDckssUUFBUCxHQUFrQmxOLFdBQVcsQ0FBQ3dTLFNBQUQsQ0FBN0I7QUFDQTlFLFVBQUFBLEdBQUcsR0FBRyxDQUFDLEdBQUc3QixNQUFKLEVBQVk0RCxvQkFBWixDQUFpQzhILE1BQWpDLENBQU47QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsVUFBTXJTLEtBQUssR0FBRyxDQUFDLEdBQUdzRyx1QkFBSixFQUE2Qm5MLHVCQUE3QixDQUFxRG1TLFNBQXJELENBQWQ7O0FBQ0EsUUFBSSxDQUFDalgsVUFBVSxDQUFDRixFQUFELENBQWYsRUFBcUI7QUFDakIsZ0JBQTJDO0FBQ3ZDLGNBQU0sSUFBSTJCLEtBQUosQ0FBVyxrQkFBaUIwUSxHQUFJLGNBQWFyUyxFQUFHLDJDQUF0QyxHQUFvRixvRkFBOUYsQ0FBTjtBQUNIOztBQUNEMkYsTUFBQUEsTUFBTSxDQUFDMFUsUUFBUCxDQUFnQnRhLElBQWhCLEdBQXVCQyxFQUF2QjtBQUNBLGFBQU8sS0FBUDtBQUNIOztBQUNEK0MsSUFBQUEsVUFBVSxHQUFHZ04sU0FBUyxDQUFDRSxXQUFXLENBQUNsTixVQUFELENBQVosRUFBMEIsS0FBS3pDLE1BQS9CLENBQXRCOztBQUNBLFFBQUksQ0FBQyxHQUFHbVEsVUFBSixFQUFnQnNFLGNBQWhCLENBQStCbEwsS0FBL0IsQ0FBSixFQUEyQztBQUN2QyxZQUFNcVIsUUFBUSxHQUFHLENBQUMsR0FBR3hLLGlCQUFKLEVBQXVCdUksZ0JBQXZCLENBQXdDbFcsVUFBeEMsQ0FBakI7QUFDQSxZQUFNNFAsVUFBVSxHQUFHdUksUUFBUSxDQUFDckosUUFBNUI7QUFDQSxZQUFNNEssVUFBVSxHQUFHLENBQUMsR0FBRzNMLFdBQUosRUFBaUJpQyxhQUFqQixDQUErQmxKLEtBQS9CLENBQW5CO0FBQ0EsWUFBTTZTLFVBQVUsR0FBRyxDQUFDLEdBQUc3TCxhQUFKLEVBQW1Cc0MsZUFBbkIsQ0FBbUNzSixVQUFuQyxFQUErQzlKLFVBQS9DLENBQW5CO0FBQ0EsWUFBTWdLLGlCQUFpQixHQUFHOVMsS0FBSyxLQUFLOEksVUFBcEM7QUFDQSxZQUFNbUMsY0FBYyxHQUFHNkgsaUJBQWlCLEdBQUd6TSxhQUFhLENBQUNyRyxLQUFELEVBQVE4SSxVQUFSLEVBQW9CeUUsTUFBcEIsQ0FBaEIsR0FBOEMsRUFBdEY7O0FBRUEsVUFBSSxDQUFDc0YsVUFBRCxJQUFlQyxpQkFBaUIsSUFBSSxDQUFDN0gsY0FBYyxDQUFDakIsTUFBeEQsRUFBZ0U7QUFDNUQsY0FBTStJLGFBQWEsR0FBRzVkLE1BQU0sQ0FBQ2lELElBQVAsQ0FBWXdhLFVBQVUsQ0FBQ3hKLE1BQXZCLEVBQStCOUksTUFBL0IsQ0FBdUNtSixLQUFELElBQVMsQ0FBQzhELE1BQU0sQ0FBQzlELEtBQUQsQ0FBdEQsQ0FBdEI7O0FBRUEsWUFBSXNKLGFBQWEsQ0FBQzNLLE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFDMUIsb0JBQTJDO0FBQ3ZDdlksWUFBQUEsT0FBTyxDQUFDaUosSUFBUixDQUFjLEdBQUVnYSxpQkFBaUIsR0FBSSxvQkFBSixHQUEyQixpQ0FBaUMsOEJBQWhGLEdBQWlILGVBQWNDLGFBQWEsQ0FBQ2hKLElBQWQsQ0FBbUIsSUFBbkIsQ0FBeUIsOEJBQXJLO0FBQ0g7O0FBQ0QsZ0JBQU0sSUFBSWpTLEtBQUosQ0FBVSxDQUFDZ2IsaUJBQWlCLEdBQUksMEJBQXlCdEssR0FBSSxvQ0FBbUN1SyxhQUFhLENBQUNoSixJQUFkLENBQW1CLElBQW5CLENBQXlCLGlDQUE3RixHQUFpSSw4QkFBNkJqQixVQUFXLDhDQUE2QzlJLEtBQU0sS0FBOU8sSUFBdVAsK0NBQThDOFMsaUJBQWlCLEdBQUcsMkJBQUgsR0FBaUMsc0JBQXVCLEVBQXhYLENBQU47QUFDSDtBQUNKLE9BVEQsTUFTTyxJQUFJQSxpQkFBSixFQUF1QjtBQUMxQjNjLFFBQUFBLEVBQUUsR0FBRyxDQUFDLEdBQUd3USxNQUFKLEVBQVk0RCxvQkFBWixDQUFpQ3BWLE1BQU0sQ0FBQytNLE1BQVAsQ0FBYyxFQUFkLEVBQ25DbVAsUUFEbUMsRUFDekI7QUFDVHJKLFVBQUFBLFFBQVEsRUFBRWlELGNBQWMsQ0FBQ2pCLE1BRGhCO0FBRVRqQixVQUFBQSxLQUFLLEVBQUVrQixrQkFBa0IsQ0FBQ3NELE1BQUQsRUFBU3RDLGNBQWMsQ0FBQzFCLE1BQXhCO0FBRmhCLFNBRHlCLENBQWpDLENBQUw7QUFLSCxPQU5NLE1BTUE7QUFDSDtBQUNBcFUsUUFBQUEsTUFBTSxDQUFDK00sTUFBUCxDQUFjcUwsTUFBZCxFQUFzQnNGLFVBQXRCO0FBQ0g7QUFDSjs7QUFDRHpGLElBQUFBLE1BQU0sQ0FBQ2hLLE1BQVAsQ0FBYzhPLElBQWQsQ0FBbUIsa0JBQW5CLEVBQXVDL2IsRUFBdkMsRUFBMkN5YixVQUEzQzs7QUFDQSxRQUFJO0FBQ0EsVUFBSWxZLEdBQUosRUFBU3NaLElBQVQ7QUFDQSxVQUFJQyxTQUFTLEdBQUcsTUFBTSxLQUFLQyxZQUFMLENBQWtCbFQsS0FBbEIsRUFBeUJzTixTQUF6QixFQUFvQ0MsTUFBcEMsRUFBNENwWCxFQUE1QyxFQUFnRCtDLFVBQWhELEVBQTREMFksVUFBNUQsQ0FBdEI7QUFDQSxVQUFJO0FBQUVwUSxRQUFBQSxLQUFGO0FBQVV2UyxRQUFBQSxLQUFWO0FBQWtCMGdCLFFBQUFBLE9BQWxCO0FBQTRCQyxRQUFBQTtBQUE1QixVQUF5Q3FELFNBQTdDLENBSEEsQ0FJQTs7QUFDQSxVQUFJLENBQUN0RCxPQUFPLElBQUlDLE9BQVosS0FBd0IzZ0IsS0FBNUIsRUFBbUM7QUFDL0IsWUFBSUEsS0FBSyxDQUFDa2tCLFNBQU4sSUFBbUJsa0IsS0FBSyxDQUFDa2tCLFNBQU4sQ0FBZ0JDLFlBQXZDLEVBQXFEO0FBQ2pELGdCQUFNQyxXQUFXLEdBQUdwa0IsS0FBSyxDQUFDa2tCLFNBQU4sQ0FBZ0JDLFlBQXBDLENBRGlELENBRWpEO0FBQ0E7QUFDQTs7QUFDQSxjQUFJQyxXQUFXLENBQUM1TCxVQUFaLENBQXVCLEdBQXZCLENBQUosRUFBaUM7QUFDN0Isa0JBQU02TCxVQUFVLEdBQUcsQ0FBQyxHQUFHek0saUJBQUosRUFBdUJ1SSxnQkFBdkIsQ0FBd0NpRSxXQUF4QyxDQUFuQjtBQUNBQyxZQUFBQSxVQUFVLENBQUN0TCxRQUFYLEdBQXNCNEQsbUJBQW1CLENBQUMwSCxVQUFVLENBQUN0TCxRQUFaLEVBQXNCNkQsS0FBdEIsQ0FBekM7QUFDQSxrQkFBTTtBQUFFckQsY0FBQUEsR0FBRyxFQUFFK0ssTUFBUDtBQUFnQnBkLGNBQUFBLEVBQUUsRUFBRXFkO0FBQXBCLGdCQUErQmpJLFlBQVksQ0FBQyxJQUFELEVBQU84SCxXQUFQLEVBQW9CQSxXQUFwQixDQUFqRDtBQUNBLG1CQUFPLEtBQUs5RCxNQUFMLENBQVkwQixNQUFaLEVBQW9Cc0MsTUFBcEIsRUFBNEJDLEtBQTVCLEVBQW1DcGQsT0FBbkMsQ0FBUDtBQUNIOztBQUNEMEYsVUFBQUEsTUFBTSxDQUFDMFUsUUFBUCxDQUFnQnRhLElBQWhCLEdBQXVCbWQsV0FBdkI7QUFDQSxpQkFBTyxJQUFJL1YsT0FBSixDQUFZLE1BQUksQ0FDdEIsQ0FETSxDQUFQO0FBRUg7O0FBQ0QsYUFBSzRRLFNBQUwsR0FBaUIsQ0FBQyxDQUFDamYsS0FBSyxDQUFDd2tCLFdBQXpCLENBaEIrQixDQWlCL0I7O0FBQ0EsWUFBSXhrQixLQUFLLENBQUMrZCxRQUFOLEtBQW1CTixrQkFBdkIsRUFBMkM7QUFDdkMsY0FBSWdILGFBQUo7O0FBQ0EsY0FBSTtBQUNBLGtCQUFNLEtBQUtDLGNBQUwsQ0FBb0IsTUFBcEIsQ0FBTjtBQUNBRCxZQUFBQSxhQUFhLEdBQUcsTUFBaEI7QUFDSCxXQUhELENBR0UsT0FBT3BiLENBQVAsRUFBVTtBQUNSb2IsWUFBQUEsYUFBYSxHQUFHLFNBQWhCO0FBQ0g7O0FBQ0RULFVBQUFBLFNBQVMsR0FBRyxNQUFNLEtBQUtDLFlBQUwsQ0FBa0JRLGFBQWxCLEVBQWlDQSxhQUFqQyxFQUFnRG5HLE1BQWhELEVBQXdEcFgsRUFBeEQsRUFBNEQrQyxVQUE1RCxFQUF3RTtBQUN0RjNCLFlBQUFBLE9BQU8sRUFBRTtBQUQ2RSxXQUF4RSxDQUFsQjtBQUdIO0FBQ0o7O0FBQ0Q2VixNQUFBQSxNQUFNLENBQUNoSyxNQUFQLENBQWM4TyxJQUFkLENBQW1CLHFCQUFuQixFQUEwQy9iLEVBQTFDLEVBQThDeWIsVUFBOUM7QUFDQSxXQUFLckQsV0FBTCxDQUFpQjBDLE1BQWpCLEVBQXlCekksR0FBekIsRUFBOEJyUyxFQUE5QixFQUFrQ0MsT0FBbEM7O0FBQ0EsZ0JBQTJDO0FBQ3ZDLGNBQU13ZCxPQUFPLEdBQUcsS0FBS25FLFVBQUwsQ0FBZ0IsT0FBaEIsRUFBeUI1QixTQUF6QztBQUNBL1IsUUFBQUEsTUFBTSxDQUFDK1gsSUFBUCxDQUFZQyxhQUFaLEdBQTRCRixPQUFPLENBQUM3TixlQUFSLEtBQTRCNk4sT0FBTyxDQUFDNU4sbUJBQXBDLElBQTJELENBQUNpTixTQUFTLENBQUNwRixTQUFWLENBQW9COUgsZUFBNUc7QUFDSDs7QUFDRCxVQUFJM1AsT0FBTyxDQUFDK2EsRUFBUixJQUFjN0QsU0FBUyxLQUFLLFNBQTVCLElBQXlDLENBQUMsQ0FBQzVULEdBQUcsR0FBR2tDLElBQUksQ0FBQ2tVLGFBQUwsQ0FBbUI3Z0IsS0FBMUIsTUFBcUMsSUFBckMsSUFBNkN5SyxHQUFHLEtBQUssS0FBSyxDQUExRCxHQUE4RCxLQUFLLENBQW5FLEdBQXVFLENBQUNzWixJQUFJLEdBQUd0WixHQUFHLENBQUN5WixTQUFaLE1BQTJCLElBQTNCLElBQW1DSCxJQUFJLEtBQUssS0FBSyxDQUFqRCxHQUFxRCxLQUFLLENBQTFELEdBQThEQSxJQUFJLENBQUNlLFVBQTNJLE1BQTJKLEdBQXBNLEtBQTRNOWtCLEtBQUssS0FBSyxJQUFWLElBQWtCQSxLQUFLLEtBQUssS0FBSyxDQUFqQyxHQUFxQyxLQUFLLENBQTFDLEdBQThDQSxLQUFLLENBQUNra0IsU0FBaFEsQ0FBSixFQUFnUjtBQUM1UTtBQUNBO0FBQ0Fsa0IsUUFBQUEsS0FBSyxDQUFDa2tCLFNBQU4sQ0FBZ0JZLFVBQWhCLEdBQTZCLEdBQTdCO0FBQ0gsT0E5Q0QsQ0ErQ0E7OztBQUNBLFlBQU1DLG1CQUFtQixHQUFHNWQsT0FBTyxDQUFDbUIsT0FBUixJQUFtQixLQUFLeUksS0FBTCxLQUFlQSxLQUE5RDs7QUFDQSxVQUFJaVUsT0FBSjs7QUFDQSxZQUFNQyxZQUFZLEdBQUcsQ0FBQ0QsT0FBTyxHQUFHN2QsT0FBTyxDQUFDb0IsTUFBbkIsTUFBK0IsSUFBL0IsSUFBdUN5YyxPQUFPLEtBQUssS0FBSyxDQUF4RCxHQUE0REEsT0FBNUQsR0FBc0UsQ0FBQ0QsbUJBQTVGO0FBQ0EsWUFBTUcsV0FBVyxHQUFHRCxZQUFZLEdBQUc7QUFDL0JwRixRQUFBQSxDQUFDLEVBQUUsQ0FENEI7QUFFL0JFLFFBQUFBLENBQUMsRUFBRTtBQUY0QixPQUFILEdBRzVCLElBSEo7QUFJQSxZQUFNLEtBQUt0UixHQUFMLENBQVNzQyxLQUFULEVBQWdCc04sU0FBaEIsRUFBMkJDLE1BQTNCLEVBQW1Dd0UsU0FBbkMsRUFBOENrQixTQUE5QyxFQUF5RHZFLFlBQVksS0FBSyxJQUFqQixJQUF5QkEsWUFBWSxLQUFLLEtBQUssQ0FBL0MsR0FBbURBLFlBQW5ELEdBQWtFeUYsV0FBM0gsRUFBd0k3ZCxLQUF4SSxDQUErSWUsQ0FBRCxJQUFLO0FBQ3JKLFlBQUlBLENBQUMsQ0FBQ29JLFNBQU4sRUFBaUIrQixLQUFLLEdBQUdBLEtBQUssSUFBSW5LLENBQWpCLENBQWpCLEtBQ0ssTUFBTUEsQ0FBTjtBQUNSLE9BSEssQ0FBTjs7QUFJQSxVQUFJbUssS0FBSixFQUFXO0FBQ1A0TCxRQUFBQSxNQUFNLENBQUNoSyxNQUFQLENBQWM4TyxJQUFkLENBQW1CLGtCQUFuQixFQUF1QzFRLEtBQXZDLEVBQThDdVEsU0FBOUMsRUFBeURILFVBQXpEO0FBQ0EsY0FBTXBRLEtBQU47QUFDSDs7QUFDRCxVQUFJOU0sS0FBSixFQUFxQyxFQUlwQzs7QUFDRDBZLE1BQUFBLE1BQU0sQ0FBQ2hLLE1BQVAsQ0FBYzhPLElBQWQsQ0FBbUIscUJBQW5CLEVBQTBDL2IsRUFBMUMsRUFBOEN5YixVQUE5QztBQUNBLGFBQU8sSUFBUDtBQUNILEtBdEVELENBc0VFLE9BQU83RCxJQUFQLEVBQWE7QUFDWCxVQUFJQSxJQUFJLENBQUN0TyxTQUFULEVBQW9CO0FBQ2hCLGVBQU8sS0FBUDtBQUNIOztBQUNELFlBQU1zTyxJQUFOO0FBQ0g7QUFDSjs7QUFDRFEsRUFBQUEsV0FBVyxDQUFDMEMsTUFBRCxFQUFTekksR0FBVCxFQUFjclMsRUFBZCxFQUFrQkMsT0FBTyxHQUFHLEVBQTVCLEVBQ1I7QUFDQyxjQUEyQztBQUN2QyxVQUFJLE9BQU8wRixNQUFNLENBQUN1USxPQUFkLEtBQTBCLFdBQTlCLEVBQTJDO0FBQ3ZDeGMsUUFBQUEsT0FBTyxDQUFDMlIsS0FBUixDQUFlLDJDQUFmO0FBQ0E7QUFDSDs7QUFDRCxVQUFJLE9BQU8xRixNQUFNLENBQUN1USxPQUFQLENBQWU0RSxNQUFmLENBQVAsS0FBa0MsV0FBdEMsRUFBbUQ7QUFDL0NwaEIsUUFBQUEsT0FBTyxDQUFDMlIsS0FBUixDQUFlLDJCQUEwQnlQLE1BQU8sbUJBQWhEO0FBQ0E7QUFDSDtBQUNKOztBQUNELFFBQUlBLE1BQU0sS0FBSyxXQUFYLElBQTBCLENBQUMsR0FBR3RLLE1BQUosRUFBWTZILE1BQVosT0FBeUJyWSxFQUF2RCxFQUEyRDtBQUN2RCxXQUFLcVosUUFBTCxHQUFnQnBaLE9BQU8sQ0FBQ21CLE9BQXhCO0FBQ0F1RSxNQUFBQSxNQUFNLENBQUN1USxPQUFQLENBQWU0RSxNQUFmLEVBQXVCO0FBQ25CekksUUFBQUEsR0FEbUI7QUFFbkJyUyxRQUFBQSxFQUZtQjtBQUduQkMsUUFBQUEsT0FIbUI7QUFJbkJxWSxRQUFBQSxHQUFHLEVBQUUsSUFKYztBQUtuQkUsUUFBQUEsR0FBRyxFQUFFLEtBQUtOLElBQUwsR0FBWTRDLE1BQU0sS0FBSyxXQUFYLEdBQXlCLEtBQUs1QyxJQUE5QixHQUFxQyxLQUFLQSxJQUFMLEdBQVk7QUFML0MsT0FBdkIsRUFNRztBQUNIO0FBQ0E7QUFDQSxRQVRBLEVBU0lsWSxFQVRKO0FBVUg7QUFDSjs7QUFDeUIsUUFBcEJtZSxvQkFBb0IsQ0FBQy9kLEdBQUQsRUFBTXlSLFFBQU4sRUFBZ0JlLEtBQWhCLEVBQXVCNVMsRUFBdkIsRUFBMkJ5YixVQUEzQixFQUF1QzJDLGFBQXZDLEVBQXNEO0FBQzVFLFFBQUloZSxHQUFHLENBQUNrSixTQUFSLEVBQW1CO0FBQ2Y7QUFDQSxZQUFNbEosR0FBTjtBQUNIOztBQUNELFFBQUksQ0FBQyxHQUFHZ1EsWUFBSixFQUFrQjVKLFlBQWxCLENBQStCcEcsR0FBL0IsS0FBdUNnZSxhQUEzQyxFQUEwRDtBQUN0RG5ILE1BQUFBLE1BQU0sQ0FBQ2hLLE1BQVAsQ0FBYzhPLElBQWQsQ0FBbUIsa0JBQW5CLEVBQXVDM2IsR0FBdkMsRUFBNENKLEVBQTVDLEVBQWdEeWIsVUFBaEQsRUFEc0QsQ0FFdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTlWLE1BQUFBLE1BQU0sQ0FBQzBVLFFBQVAsQ0FBZ0J0YSxJQUFoQixHQUF1QkMsRUFBdkIsQ0FQc0QsQ0FRdEQ7QUFDQTs7QUFDQSxZQUFNbVIsc0JBQXNCLEVBQTVCO0FBQ0g7O0FBQ0QsUUFBSTtBQUNBLFVBQUl3RyxVQUFKO0FBQ0EsVUFBSW5OLFdBQUo7QUFDQSxVQUFJMVIsS0FBSjs7QUFDQSxVQUFJLE9BQU82ZSxVQUFQLEtBQXNCLFdBQXRCLElBQXFDLE9BQU9uTixXQUFQLEtBQXVCLFdBQWhFLEVBQTZFO0FBQ3pFLFNBQUM7QUFBRXNMLFVBQUFBLElBQUksRUFBRTZCLFVBQVI7QUFBcUJuTixVQUFBQTtBQUFyQixZQUFzQyxNQUFNLEtBQUtnVCxjQUFMLENBQW9CLFNBQXBCLENBQTdDO0FBQ0g7O0FBQ0QsWUFBTVYsU0FBUyxHQUFHO0FBQ2Roa0IsUUFBQUEsS0FEYztBQUVkNGUsUUFBQUEsU0FBUyxFQUFFQyxVQUZHO0FBR2RuTixRQUFBQSxXQUhjO0FBSWRwSyxRQUFBQSxHQUpjO0FBS2RpTCxRQUFBQSxLQUFLLEVBQUVqTDtBQUxPLE9BQWxCOztBQU9BLFVBQUksQ0FBQzBjLFNBQVMsQ0FBQ2hrQixLQUFmLEVBQXNCO0FBQ2xCLFlBQUk7QUFDQWdrQixVQUFBQSxTQUFTLENBQUNoa0IsS0FBVixHQUFrQixNQUFNLEtBQUs4VyxlQUFMLENBQXFCK0gsVUFBckIsRUFBaUM7QUFDckR2WCxZQUFBQSxHQURxRDtBQUVyRHlSLFlBQUFBLFFBRnFEO0FBR3JEZSxZQUFBQTtBQUhxRCxXQUFqQyxDQUF4QjtBQUtILFNBTkQsQ0FNRSxPQUFPeUwsTUFBUCxFQUFlO0FBQ2Iza0IsVUFBQUEsT0FBTyxDQUFDMlIsS0FBUixDQUFjLHlDQUFkLEVBQXlEZ1QsTUFBekQ7QUFDQXZCLFVBQUFBLFNBQVMsQ0FBQ2hrQixLQUFWLEdBQWtCLEVBQWxCO0FBRUg7QUFDSjs7QUFDRCxhQUFPZ2tCLFNBQVA7QUFDSCxLQTVCRCxDQTRCRSxPQUFPd0IsWUFBUCxFQUFxQjtBQUNuQixhQUFPLEtBQUtILG9CQUFMLENBQTBCRyxZQUExQixFQUF3Q3pNLFFBQXhDLEVBQWtEZSxLQUFsRCxFQUF5RDVTLEVBQXpELEVBQTZEeWIsVUFBN0QsRUFBeUUsSUFBekUsQ0FBUDtBQUNIO0FBQ0o7O0FBQ2lCLFFBQVpzQixZQUFZLENBQUNsVCxLQUFELEVBQVFnSSxRQUFSLEVBQWtCZSxLQUFsQixFQUF5QjVTLEVBQXpCLEVBQTZCK0MsVUFBN0IsRUFBeUMwWSxVQUF6QyxFQUFxRDtBQUNuRSxRQUFJO0FBQ0EsWUFBTThDLGlCQUFpQixHQUFHLEtBQUtqRixVQUFMLENBQWdCelAsS0FBaEIsQ0FBMUI7O0FBQ0EsVUFBSTRSLFVBQVUsQ0FBQ3JhLE9BQVgsSUFBc0JtZCxpQkFBdEIsSUFBMkMsS0FBSzFVLEtBQUwsS0FBZUEsS0FBOUQsRUFBcUU7QUFDakUsZUFBTzBVLGlCQUFQO0FBQ0g7O0FBQ0QsWUFBTUMsZUFBZSxHQUFHRCxpQkFBaUIsSUFBSSxhQUFhQSxpQkFBbEMsR0FBc0Q5UCxTQUF0RCxHQUFrRThQLGlCQUExRjtBQUNBLFlBQU16QixTQUFTLEdBQUcwQixlQUFlLEdBQUdBLGVBQUgsR0FBcUIsTUFBTSxLQUFLaEIsY0FBTCxDQUFvQjNULEtBQXBCLEVBQTJCckMsSUFBM0IsQ0FBaUNVLEdBQUQsS0FBUTtBQUM1RndQLFFBQUFBLFNBQVMsRUFBRXhQLEdBQUcsQ0FBQzROLElBRDZFO0FBRTVGdEwsUUFBQUEsV0FBVyxFQUFFdEMsR0FBRyxDQUFDc0MsV0FGMkU7QUFHNUZnUCxRQUFBQSxPQUFPLEVBQUV0UixHQUFHLENBQUN1VyxHQUFKLENBQVFqRixPQUgyRTtBQUk1RkMsUUFBQUEsT0FBTyxFQUFFdlIsR0FBRyxDQUFDdVcsR0FBSixDQUFRaEY7QUFKMkUsT0FBUixDQUFoQyxDQUE1RDtBQU9BLFlBQU07QUFBRS9CLFFBQUFBLFNBQVMsRUFBRUMsVUFBYjtBQUEwQjZCLFFBQUFBLE9BQTFCO0FBQW9DQyxRQUFBQTtBQUFwQyxVQUFpRHFELFNBQXZEOztBQUNBLGdCQUEyQztBQUN2QyxjQUFNO0FBQUU0QixVQUFBQTtBQUFGLFlBQTBCcGYsbUJBQU8sQ0FBQywwQkFBRCxDQUF2Qzs7QUFDQSxZQUFJLENBQUNvZixrQkFBa0IsQ0FBQy9HLFVBQUQsQ0FBdkIsRUFBcUM7QUFDakMsZ0JBQU0sSUFBSWhXLEtBQUosQ0FBVyx5REFBd0RrUSxRQUFTLEdBQTVFLENBQU47QUFDSDtBQUNKOztBQUNELFVBQUlrRixRQUFKOztBQUNBLFVBQUl5QyxPQUFPLElBQUlDLE9BQWYsRUFBd0I7QUFDcEIxQyxRQUFBQSxRQUFRLEdBQUcsS0FBS1EsVUFBTCxDQUFnQm9ILFdBQWhCLENBQTRCLENBQUMsR0FBR25PLE1BQUosRUFBWTRELG9CQUFaLENBQWlDO0FBQ3BFdkMsVUFBQUEsUUFEb0U7QUFFcEVlLFVBQUFBO0FBRm9FLFNBQWpDLENBQTVCLEVBR1A3UCxVQUhPLEVBR0t5VyxPQUhMLEVBR2MsS0FBS2xaLE1BSG5CLENBQVg7QUFJSDs7QUFDRCxZQUFNeEgsS0FBSyxHQUFHLE1BQU0sS0FBSzhsQixRQUFMLENBQWMsTUFBSXBGLE9BQU8sR0FBRyxLQUFLcUYsY0FBTCxDQUFvQjlILFFBQXBCLENBQUgsR0FBbUMwQyxPQUFPLEdBQUcsS0FBS3FGLGNBQUwsQ0FBb0IvSCxRQUFwQixDQUFILEdBQW1DLEtBQUtuSCxlQUFMLENBQXFCK0gsVUFBckIsRUFBaUM7QUFDdko7QUFDSTlGLFFBQUFBLFFBREo7QUFFSWUsUUFBQUEsS0FGSjtBQUdJZ0MsUUFBQUEsTUFBTSxFQUFFNVUsRUFIWjtBQUlJTSxRQUFBQSxNQUFNLEVBQUUsS0FBS0EsTUFKakI7QUFLSW1FLFFBQUFBLE9BQU8sRUFBRSxLQUFLQSxPQUxsQjtBQU1JSSxRQUFBQSxhQUFhLEVBQUUsS0FBS0E7QUFOeEIsT0FEc0gsQ0FBdEcsQ0FBcEI7QUFVQWlZLE1BQUFBLFNBQVMsQ0FBQ2hrQixLQUFWLEdBQWtCQSxLQUFsQjtBQUNBLFdBQUt3Z0IsVUFBTCxDQUFnQnpQLEtBQWhCLElBQXlCaVQsU0FBekI7QUFDQSxhQUFPQSxTQUFQO0FBQ0gsS0F4Q0QsQ0F3Q0UsT0FBT2lDLElBQVAsRUFBYTtBQUNYLGFBQU8sS0FBS1osb0JBQUwsQ0FBMEJZLElBQTFCLEVBQWdDbE4sUUFBaEMsRUFBMENlLEtBQTFDLEVBQWlENVMsRUFBakQsRUFBcUR5YixVQUFyRCxDQUFQO0FBQ0g7QUFDSjs7QUFDRGxVLEVBQUFBLEdBQUcsQ0FBQ3NDLEtBQUQsRUFBUWdJLFFBQVIsRUFBa0JlLEtBQWxCLEVBQXlCNVMsRUFBekIsRUFBNkJuRixJQUE3QixFQUFtQ21qQixXQUFuQyxFQUFnRDtBQUMvQyxTQUFLbEcsVUFBTCxHQUFrQixLQUFsQjtBQUNBLFNBQUtqTyxLQUFMLEdBQWFBLEtBQWI7QUFDQSxTQUFLZ0ksUUFBTCxHQUFnQkEsUUFBaEI7QUFDQSxTQUFLZSxLQUFMLEdBQWFBLEtBQWI7QUFDQSxTQUFLZ0MsTUFBTCxHQUFjNVUsRUFBZDtBQUNBLFdBQU8sS0FBS2ljLE1BQUwsQ0FBWXBoQixJQUFaLEVBQWtCbWpCLFdBQWxCLENBQVA7QUFDSDtBQUNEO0FBQ0o7QUFDQTtBQUNBOzs7QUFBTWdCLEVBQUFBLGNBQWMsQ0FBQ3BaLEVBQUQsRUFBSztBQUNqQixTQUFLdVQsSUFBTCxHQUFZdlQsRUFBWjtBQUNIOztBQUNEa1csRUFBQUEsZUFBZSxDQUFDOWIsRUFBRCxFQUFLO0FBQ2hCLFFBQUksQ0FBQyxLQUFLNFUsTUFBVixFQUFrQixPQUFPLEtBQVA7QUFDbEIsVUFBTSxDQUFDcUssWUFBRCxFQUFlQyxPQUFmLElBQTBCLEtBQUt0SyxNQUFMLENBQVlILEtBQVosQ0FBa0IsR0FBbEIsQ0FBaEM7QUFDQSxVQUFNLENBQUMwSyxZQUFELEVBQWVDLE9BQWYsSUFBMEJwZixFQUFFLENBQUN5VSxLQUFILENBQVMsR0FBVCxDQUFoQyxDQUhnQixDQUloQjs7QUFDQSxRQUFJMkssT0FBTyxJQUFJSCxZQUFZLEtBQUtFLFlBQTVCLElBQTRDRCxPQUFPLEtBQUtFLE9BQTVELEVBQXFFO0FBQ2pFLGFBQU8sSUFBUDtBQUNILEtBUGUsQ0FRaEI7OztBQUNBLFFBQUlILFlBQVksS0FBS0UsWUFBckIsRUFBbUM7QUFDL0IsYUFBTyxLQUFQO0FBQ0gsS0FYZSxDQVloQjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsV0FBT0QsT0FBTyxLQUFLRSxPQUFuQjtBQUNIOztBQUNEcEQsRUFBQUEsWUFBWSxDQUFDaGMsRUFBRCxFQUFLO0FBQ2IsVUFBTSxHQUFHa1YsSUFBSCxJQUFXbFYsRUFBRSxDQUFDeVUsS0FBSCxDQUFTLEdBQVQsQ0FBakIsQ0FEYSxDQUViO0FBQ0E7O0FBQ0EsUUFBSVMsSUFBSSxLQUFLLEVBQVQsSUFBZUEsSUFBSSxLQUFLLEtBQTVCLEVBQW1DO0FBQy9CdlAsTUFBQUEsTUFBTSxDQUFDMFosUUFBUCxDQUFnQixDQUFoQixFQUFtQixDQUFuQjtBQUNBO0FBQ0gsS0FQWSxDQVFiOzs7QUFDQSxVQUFNQyxJQUFJLEdBQUczWCxRQUFRLENBQUM0WCxjQUFULENBQXdCckssSUFBeEIsQ0FBYjs7QUFDQSxRQUFJb0ssSUFBSixFQUFVO0FBQ05BLE1BQUFBLElBQUksQ0FBQ0UsY0FBTDtBQUNBO0FBQ0gsS0FiWSxDQWNiO0FBQ0E7OztBQUNBLFVBQU1DLE1BQU0sR0FBRzlYLFFBQVEsQ0FBQytYLGlCQUFULENBQTJCeEssSUFBM0IsRUFBaUMsQ0FBakMsQ0FBZjs7QUFDQSxRQUFJdUssTUFBSixFQUFZO0FBQ1JBLE1BQUFBLE1BQU0sQ0FBQ0QsY0FBUDtBQUNIO0FBQ0o7O0FBQ0RsRCxFQUFBQSxRQUFRLENBQUMxSCxNQUFELEVBQVM7QUFDYixXQUFPLEtBQUtBLE1BQUwsS0FBZ0JBLE1BQXZCO0FBQ0g7QUFDRDtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUFvQixRQUFSL1UsUUFBUSxDQUFDd1MsR0FBRCxFQUFNdUMsTUFBTSxHQUFHdkMsR0FBZixFQUFvQnBTLE9BQU8sR0FBRyxFQUE5QixFQUNiO0FBQ0MsUUFBSWljLE1BQU0sR0FBRyxDQUFDLEdBQUd4TCxpQkFBSixFQUF1QnVJLGdCQUF2QixDQUF3QzVHLEdBQXhDLENBQWI7QUFDQSxRQUFJO0FBQUVSLE1BQUFBLFFBQVEsRUFBRThOO0FBQVosUUFBMkJ6RCxNQUEvQjs7QUFDQSxRQUFJM2QsS0FBSixFQUFxQyxFQVdwQzs7QUFDRCxVQUFNbVgsS0FBSyxHQUFHLE1BQU0sS0FBSzZCLFVBQUwsQ0FBZ0I2RSxXQUFoQixFQUFwQjtBQUNBLFFBQUlyWixVQUFVLEdBQUc2UixNQUFqQjs7QUFDQSxRQUFJclcsS0FBSixFQUErRCxFQUEvRCxNQWFPO0FBQ0gyZCxNQUFBQSxNQUFNLENBQUNySyxRQUFQLEdBQWtCNEQsbUJBQW1CLENBQUN5RyxNQUFNLENBQUNySyxRQUFSLEVBQWtCNkQsS0FBbEIsQ0FBckM7O0FBQ0EsVUFBSXdHLE1BQU0sQ0FBQ3JLLFFBQVAsS0FBb0I4TixTQUF4QixFQUFtQztBQUMvQkEsUUFBQUEsU0FBUyxHQUFHekQsTUFBTSxDQUFDckssUUFBbkI7QUFDQXFLLFFBQUFBLE1BQU0sQ0FBQ3JLLFFBQVAsR0FBa0I4TixTQUFsQjtBQUNBdE4sUUFBQUEsR0FBRyxHQUFHLENBQUMsR0FBRzdCLE1BQUosRUFBWTRELG9CQUFaLENBQWlDOEgsTUFBakMsQ0FBTjtBQUNIO0FBQ0o7O0FBQ0QsVUFBTXJTLEtBQUssR0FBRyxDQUFDLEdBQUdzRyx1QkFBSixFQUE2Qm5MLHVCQUE3QixDQUFxRDJhLFNBQXJELENBQWQsQ0F0Q0QsQ0F1Q0M7O0FBQ0EsY0FBMkM7QUFDdkM7QUFDSDs7QUFDRCxVQUFNeFksT0FBTyxDQUFDdUUsR0FBUixDQUFZLENBQ2QsS0FBSzZMLFVBQUwsQ0FBZ0JxSSxNQUFoQixDQUF1Qi9WLEtBQXZCLEVBQThCckMsSUFBOUIsQ0FBb0NxWSxLQUFELElBQVM7QUFDeEMsYUFBT0EsS0FBSyxHQUFHLEtBQUtoQixjQUFMLENBQW9CLEtBQUt0SCxVQUFMLENBQWdCb0gsV0FBaEIsQ0FBNEJ0TSxHQUE1QixFQUFpQ3RQLFVBQWpDLEVBQTZDLElBQTdDLEVBQW1ELE9BQU85QyxPQUFPLENBQUNLLE1BQWYsS0FBMEIsV0FBMUIsR0FBd0NMLE9BQU8sQ0FBQ0ssTUFBaEQsR0FBeUQsS0FBS0EsTUFBakgsQ0FBcEIsQ0FBSCxHQUFtSixLQUEvSjtBQUNILEtBRkQsQ0FEYyxFQUlkLEtBQUtpWCxVQUFMLENBQWdCdFgsT0FBTyxDQUFDb0UsUUFBUixHQUFtQixVQUFuQixHQUFnQyxVQUFoRCxFQUE0RHdGLEtBQTVELENBSmMsQ0FBWixDQUFOO0FBTUg7O0FBQ21CLFFBQWQyVCxjQUFjLENBQUMzVCxLQUFELEVBQVE7QUFDeEIsUUFBSVAsU0FBUyxHQUFHLEtBQWhCOztBQUNBLFVBQU13VyxNQUFNLEdBQUcsS0FBS2hHLEdBQUwsR0FBVyxNQUFJO0FBQzFCeFEsTUFBQUEsU0FBUyxHQUFHLElBQVo7QUFDSCxLQUZEOztBQUdBLFVBQU15VyxlQUFlLEdBQUcsTUFBTSxLQUFLeEksVUFBTCxDQUFnQnlJLFFBQWhCLENBQXlCblcsS0FBekIsQ0FBOUI7O0FBQ0EsUUFBSVAsU0FBSixFQUFlO0FBQ1gsWUFBTStCLEtBQUssR0FBRyxJQUFJMUosS0FBSixDQUFXLHdDQUF1Q2tJLEtBQU0sR0FBeEQsQ0FBZDtBQUNBd0IsTUFBQUEsS0FBSyxDQUFDL0IsU0FBTixHQUFrQixJQUFsQjtBQUNBLFlBQU0rQixLQUFOO0FBQ0g7O0FBQ0QsUUFBSXlVLE1BQU0sS0FBSyxLQUFLaEcsR0FBcEIsRUFBeUI7QUFDckIsV0FBS0EsR0FBTCxHQUFXLElBQVg7QUFDSDs7QUFDRCxXQUFPaUcsZUFBUDtBQUNIOztBQUNEbkIsRUFBQUEsUUFBUSxDQUFDelQsRUFBRCxFQUFLO0FBQ1QsUUFBSTdCLFNBQVMsR0FBRyxLQUFoQjs7QUFDQSxVQUFNd1csTUFBTSxHQUFHLE1BQUk7QUFDZnhXLE1BQUFBLFNBQVMsR0FBRyxJQUFaO0FBQ0gsS0FGRDs7QUFHQSxTQUFLd1EsR0FBTCxHQUFXZ0csTUFBWDtBQUNBLFdBQU8zVSxFQUFFLEdBQUczRCxJQUFMLENBQVczTSxJQUFELElBQVE7QUFDckIsVUFBSWlsQixNQUFNLEtBQUssS0FBS2hHLEdBQXBCLEVBQXlCO0FBQ3JCLGFBQUtBLEdBQUwsR0FBVyxJQUFYO0FBQ0g7O0FBQ0QsVUFBSXhRLFNBQUosRUFBZTtBQUNYLGNBQU15VixJQUFJLEdBQUcsSUFBSXBkLEtBQUosQ0FBVSxpQ0FBVixDQUFiO0FBQ0FvZCxRQUFBQSxJQUFJLENBQUN6VixTQUFMLEdBQWlCLElBQWpCO0FBQ0EsY0FBTXlWLElBQU47QUFDSDs7QUFDRCxhQUFPbGtCLElBQVA7QUFDSCxLQVZNLENBQVA7QUFXSDs7QUFDRGdrQixFQUFBQSxjQUFjLENBQUM5SCxRQUFELEVBQVc7QUFDckIsVUFBTTtBQUFFaFgsTUFBQUEsSUFBSSxFQUFFa2dCO0FBQVIsUUFBc0IsSUFBSXhOLEdBQUosQ0FBUXNFLFFBQVIsRUFBa0JwUixNQUFNLENBQUMwVSxRQUFQLENBQWdCdGEsSUFBbEMsQ0FBNUI7O0FBQ0EsUUFBSSxLQUFKLEVBQW9GLEVBRW5GOztBQUNELFdBQU8rVyxhQUFhLENBQUNDLFFBQUQsRUFBVyxLQUFLbUMsS0FBaEIsQ0FBYixDQUFvQzFSLElBQXBDLENBQTBDM00sSUFBRCxJQUFRO0FBQ3BELFdBQUttZCxHQUFMLENBQVNpSSxRQUFULElBQXFCcGxCLElBQXJCO0FBQ0EsYUFBT0EsSUFBUDtBQUNILEtBSE0sQ0FBUDtBQUlIOztBQUNEaWtCLEVBQUFBLGNBQWMsQ0FBQy9ILFFBQUQsRUFBVztBQUNyQixVQUFNO0FBQUVoWCxNQUFBQSxJQUFJLEVBQUVtZ0I7QUFBUixRQUF5QixJQUFJek4sR0FBSixDQUFRc0UsUUFBUixFQUFrQnBSLE1BQU0sQ0FBQzBVLFFBQVAsQ0FBZ0J0YSxJQUFsQyxDQUEvQjs7QUFDQSxRQUFJLEtBQUtrWSxHQUFMLENBQVNpSSxXQUFULENBQUosRUFBMkI7QUFDdkIsYUFBTyxLQUFLakksR0FBTCxDQUFTaUksV0FBVCxDQUFQO0FBQ0g7O0FBQ0QsV0FBTyxLQUFLakksR0FBTCxDQUFTaUksV0FBVCxJQUF3QnBKLGFBQWEsQ0FBQ0MsUUFBRCxFQUFXLEtBQUttQyxLQUFoQixDQUFiLENBQW9DMVIsSUFBcEMsQ0FBMEMzTSxJQUFELElBQVE7QUFDNUUsYUFBTyxLQUFLb2QsR0FBTCxDQUFTaUksV0FBVCxDQUFQO0FBQ0EsYUFBT3JsQixJQUFQO0FBQ0gsS0FIOEIsRUFHNUJzRixLQUg0QixDQUdyQjRlLElBQUQsSUFBUTtBQUNiLGFBQU8sS0FBSzlHLEdBQUwsQ0FBU2lJLFdBQVQsQ0FBUDtBQUNBLFlBQU1uQixJQUFOO0FBQ0gsS0FOOEIsQ0FBL0I7QUFPSDs7QUFDRG5QLEVBQUFBLGVBQWUsQ0FBQzhILFNBQUQsRUFBWXlJLEdBQVosRUFBaUI7QUFDNUIsVUFBTTtBQUFFekksTUFBQUEsU0FBUyxFQUFFMEk7QUFBYixRQUF1QixLQUFLOUcsVUFBTCxDQUFnQixPQUFoQixDQUE3Qjs7QUFDQSxVQUFNK0csT0FBTyxHQUFHLEtBQUt0RyxRQUFMLENBQWNxRyxJQUFkLENBQWhCOztBQUNBRCxJQUFBQSxHQUFHLENBQUNFLE9BQUosR0FBY0EsT0FBZDtBQUNBLFdBQU8sQ0FBQyxHQUFHN1AsTUFBSixFQUFZOFAsbUJBQVosQ0FBZ0NGLElBQWhDLEVBQXNDO0FBQ3pDQyxNQUFBQSxPQUR5QztBQUV6QzNJLE1BQUFBLFNBRnlDO0FBR3pDNVgsTUFBQUEsTUFBTSxFQUFFLElBSGlDO0FBSXpDcWdCLE1BQUFBO0FBSnlDLEtBQXRDLENBQVA7QUFNSDs7QUFDRHhFLEVBQUFBLGtCQUFrQixDQUFDM2IsRUFBRCxFQUFLeWIsVUFBTCxFQUFpQjtBQUMvQixRQUFJLEtBQUszQixHQUFULEVBQWM7QUFDVjdDLE1BQUFBLE1BQU0sQ0FBQ2hLLE1BQVAsQ0FBYzhPLElBQWQsQ0FBbUIsa0JBQW5CLEVBQXVDNUssc0JBQXNCLEVBQTdELEVBQWlFblIsRUFBakUsRUFBcUV5YixVQUFyRTtBQUNBLFdBQUszQixHQUFMO0FBQ0EsV0FBS0EsR0FBTCxHQUFXLElBQVg7QUFDSDtBQUNKOztBQUNEbUMsRUFBQUEsTUFBTSxDQUFDcGhCLElBQUQsRUFBT21qQixXQUFQLEVBQW9CO0FBQ3RCLFdBQU8sS0FBS25FLEdBQUwsQ0FBU2hmLElBQVQsRUFBZSxLQUFLeWUsVUFBTCxDQUFnQixPQUFoQixFQUF5QjVCLFNBQXhDLEVBQW1Ec0csV0FBbkQsQ0FBUDtBQUNIOztBQXZ2QlE7O0FBeXZCYi9HLE1BQU0sQ0FBQ2hLLE1BQVAsR0FBZ0IsQ0FBQyxHQUFHc0QsS0FBSixFQUFXcFIsT0FBWCxFQUFoQjtBQUNBRCxlQUFBLEdBQWtCK1gsTUFBbEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZpQ0E7QUFDQTs7O0FBQ0EsU0FBU3NKLFNBQVQsR0FBcUI7QUFDakIsc0JBQU8sOERBQUMsMERBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFQO0FBQ0g7O0FBRUQsaUVBQWVBLFNBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTkE7QUFDQTtBQUVBO0FBQ0E7QUFHTyxNQUFNTyxxQkFBcUIsR0FBRyxJQUFJemlCLGlFQUFKLENBQ25DLDZDQURtQyxDQUE5QjtBQUlQLE1BQU0yaUIsdUNBQXVDLEdBQUcsSUFBSTNpQixpRUFBSixDQUM5Qyw4Q0FEOEMsQ0FBaEQ7QUFJQSxNQUFNNGlCLHlCQUF5QixHQUFHLElBQUk1aUIsaUVBQUosQ0FDaEMsNkNBRGdDLENBQWxDO0FBa0JPLGVBQWVDLG1CQUFmLENBQ0x2RSxVQURLLEVBRUxtbkIsWUFGSyxFQUdMO0FBQ0E7QUFDQSxRQUFNQyxhQUFhLEdBQUcsTUFBTXBuQixVQUFVLENBQUNxbkIsNkJBQVgsQ0FDMUJGLFlBRDBCLEVBRTFCO0FBQ0VHLElBQUFBLFNBQVMsRUFBRVgsK0RBQWdCQTtBQUQ3QixHQUYwQixDQUE1QjtBQU9BaG5CLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZd25CLGFBQVosRUFUQSxDQVVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxPQUFLLElBQUlHLEtBQUssR0FBRyxDQUFqQixFQUFvQkEsS0FBSyxHQUFHSCxhQUFhLENBQUNubEIsS0FBZCxDQUFvQmlXLE1BQWhELEVBQXdEcVAsS0FBSyxFQUE3RCxFQUFpRTtBQUMvRCxVQUFNQyxZQUFZLEdBQUdKLGFBQWEsQ0FBQ25sQixLQUFkLENBQW9Cc2xCLEtBQXBCLENBQXJCO0FBQ0EsVUFBTUUsV0FBVyxHQUFHRCxZQUFZLENBQUNFLE9BQWIsQ0FBcUI1bUIsSUFBckIsQ0FBMEJxaEIsTUFBMUIsQ0FBaUN3RixJQUFqQyxDQUFzQ0YsV0FBMUQ7QUFFQSxVQUFNRyxJQUFJLEdBQUdKLFlBQVksQ0FBQ0UsT0FBYixDQUFxQjVtQixJQUFyQixDQUEwQnFoQixNQUExQixDQUFpQ3dGLElBQWpDLENBQXNDQyxJQUFuRDs7QUFDQSxRQUNFQSxJQUFJLEtBQUtwakIsT0FBTyxDQUFDQyxHQUFSLENBQVlvakIseUJBQXJCLElBQ0FKLFdBQVcsQ0FBQ0ssUUFBWixHQUF1QixDQUZ6QixFQUdFO0FBQ0Fub0IsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQmdvQixJQUFJLEtBQUtwakIsT0FBTyxDQUFDQyxHQUFSLENBQVlvakIseUJBQTFDO0FBQ0EsYUFBTyxJQUFQO0FBQ0Q7QUFDRjs7QUFDRCxTQUFPLEtBQVA7QUFDRDtBQUVNLE1BQU1FLHFDQUFxQyxHQUFHLE9BQ25EQyxJQURtRCxFQUVuREMsT0FGbUQsRUFHbkRqb0IsVUFIbUQsRUFJbkRrb0IsVUFBa0MsR0FBRyxRQUpjLEVBS25EQyxXQUFXLEdBQUcsS0FMcUMsS0FNSTtBQUN2RCxNQUFJQyxJQUFJLEdBQUcsS0FBWDtBQUNBLE1BQUl4TCxNQUFpRCxHQUFHO0FBQ3REeUwsSUFBQUEsSUFBSSxFQUFFLENBRGdEO0FBRXREQyxJQUFBQSxhQUFhLEVBQUUsQ0FGdUM7QUFHdERqaUIsSUFBQUEsR0FBRyxFQUFFO0FBSGlELEdBQXhEO0FBS0EsTUFBSWtpQixLQUFLLEdBQUcsQ0FBWjtBQUNBM0wsRUFBQUEsTUFBTSxHQUFHLE1BQU0sSUFBSXhQLE9BQUosQ0FBWSxPQUFPQyxPQUFQLEVBQWdCNkIsTUFBaEIsS0FBMkI7QUFDcERqRCxJQUFBQSxVQUFVLENBQUMsTUFBTTtBQUNmLFVBQUltYyxJQUFKLEVBQVU7QUFDUjtBQUNEOztBQUNEQSxNQUFBQSxJQUFJLEdBQUcsSUFBUDtBQUNBem9CLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDBCQUFaO0FBQ0FzUCxNQUFBQSxNQUFNLENBQUM7QUFBRStZLFFBQUFBLE9BQU8sRUFBRTtBQUFYLE9BQUQsQ0FBTjtBQUNELEtBUFMsRUFPUEEsT0FQTyxDQUFWOztBQVFBLFFBQUk7QUFDRk0sTUFBQUEsS0FBSyxHQUFHdm9CLFVBQVUsQ0FBQ3dvQixXQUFYLENBQ05SLElBRE0sRUFFTixDQUFDbE8sTUFBRCxFQUFjMk8sT0FBZCxLQUErQjtBQUM3QkwsUUFBQUEsSUFBSSxHQUFHLElBQVA7QUFDQXhMLFFBQUFBLE1BQU0sR0FBRztBQUNQdlcsVUFBQUEsR0FBRyxFQUFFeVQsTUFBTSxDQUFDelQsR0FETDtBQUVQZ2lCLFVBQUFBLElBQUksRUFBRUksT0FBTyxDQUFDSixJQUZQO0FBR1BDLFVBQUFBLGFBQWEsRUFBRTtBQUhSLFNBQVQ7O0FBS0EsWUFBSXhPLE1BQU0sQ0FBQ3pULEdBQVgsRUFBZ0I7QUFDZDFHLFVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHdCQUFaLEVBQXNDa2EsTUFBTSxDQUFDelQsR0FBN0M7QUFDQTZJLFVBQUFBLE1BQU0sQ0FBQzBOLE1BQUQsQ0FBTjtBQUNELFNBSEQsTUFHTztBQUNMamQsVUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksd0JBQVosRUFBc0NrYSxNQUF0QztBQUNBek0sVUFBQUEsT0FBTyxDQUFDdVAsTUFBRCxDQUFQO0FBQ0Q7QUFDRixPQWhCSyxFQWlCTnNMLFVBakJNLENBQVI7QUFtQkQsS0FwQkQsQ0FvQkUsT0FBTy9nQixDQUFQLEVBQVU7QUFDVmloQixNQUFBQSxJQUFJLEdBQUcsSUFBUDtBQUNBem9CLE1BQUFBLE9BQU8sQ0FBQzJSLEtBQVIsQ0FBYyxtQkFBZCxFQUFtQzBXLElBQW5DLEVBQXlDN2dCLENBQXpDO0FBQ0Q7O0FBQ0QsV0FBTyxDQUFDaWhCLElBQUQsSUFBU0QsV0FBaEIsRUFBNkI7QUFDM0IsT0FBQyxZQUFZO0FBQ1gsWUFBSTtBQUNGLGdCQUFNTyxpQkFBaUIsR0FBRyxNQUFNMW9CLFVBQVUsQ0FBQzJvQixvQkFBWCxDQUFnQyxDQUM5RFgsSUFEOEQsQ0FBaEMsQ0FBaEM7QUFHQXBMLFVBQUFBLE1BQU0sR0FBRzhMLGlCQUFpQixJQUFJQSxpQkFBaUIsQ0FBQ3ptQixLQUFsQixDQUF3QixDQUF4QixDQUE5Qjs7QUFDQSxjQUFJLENBQUNtbUIsSUFBTCxFQUFXO0FBQ1QsZ0JBQUksQ0FBQ3hMLE1BQUwsRUFBYTtBQUNYamQsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksc0JBQVosRUFBb0Nvb0IsSUFBcEMsRUFBMENwTCxNQUExQztBQUNELGFBRkQsTUFFTyxJQUFJQSxNQUFNLENBQUN2VyxHQUFYLEVBQWdCO0FBQ3JCMUcsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZ0JBQVosRUFBOEJvb0IsSUFBOUIsRUFBb0NwTCxNQUFwQztBQUNBd0wsY0FBQUEsSUFBSSxHQUFHLElBQVA7QUFDQWxaLGNBQUFBLE1BQU0sQ0FBQzBOLE1BQU0sQ0FBQ3ZXLEdBQVIsQ0FBTjtBQUNELGFBSk0sTUFJQSxJQUFJLENBQUN1VyxNQUFNLENBQUMwTCxhQUFaLEVBQTJCO0FBQ2hDM29CLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDJCQUFaLEVBQXlDb29CLElBQXpDLEVBQStDcEwsTUFBL0M7QUFDRCxhQUZNLE1BRUE7QUFDTGpkLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHVCQUFaLEVBQXFDb29CLElBQXJDLEVBQTJDcEwsTUFBM0M7QUFDQXdMLGNBQUFBLElBQUksR0FBRyxJQUFQO0FBQ0EvYSxjQUFBQSxPQUFPLENBQUN1UCxNQUFELENBQVA7QUFDRDtBQUNGO0FBQ0YsU0FwQkQsQ0FvQkUsT0FBT3pWLENBQVAsRUFBVTtBQUNWLGNBQUksQ0FBQ2loQixJQUFMLEVBQVc7QUFDVHpvQixZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWixFQUEyQ29vQixJQUEzQyxFQUFpRDdnQixDQUFqRDtBQUNEO0FBQ0Y7QUFDRixPQTFCRDs7QUEyQkEsWUFBTTJmLHdDQUFLLENBQUMsSUFBRCxDQUFYO0FBQ0Q7QUFDRixHQS9EYyxDQUFmLENBUnVELENBeUV2RDs7QUFDQSxNQUFJOW1CLFVBQVUsQ0FBQzRvQix1QkFBWCxDQUFtQ0wsS0FBbkMsQ0FBSixFQUErQztBQUM3Q3ZvQixJQUFBQSxVQUFVLENBQUM2b0IsdUJBQVgsQ0FBbUNOLEtBQW5DO0FBQ0Q7O0FBQ0RILEVBQUFBLElBQUksR0FBRyxJQUFQO0FBQ0F6b0IsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksa0JBQVosRUFBZ0NnZCxNQUFoQztBQUNBLFNBQU9BLE1BQVA7QUFDRCxDQXRGTTs7QUF3RlAsTUFBTWtNLHVDQUF1QyxHQUFHLENBQzlDQyxzQkFEOEMsRUFFOUNDLEtBRjhDLEVBRzlDQyxhQUg4QyxFQUk5Q0MsbUJBSjhDLEtBSzNDO0FBQ0gsUUFBTWhoQixJQUFJLEdBQUcsQ0FDWDtBQUFFaWhCLElBQUFBLE1BQU0sRUFBRUgsS0FBVjtBQUFpQkksSUFBQUEsUUFBUSxFQUFFLElBQTNCO0FBQWlDQyxJQUFBQSxVQUFVLEVBQUU7QUFBN0MsR0FEVyxFQUVYO0FBQUVGLElBQUFBLE1BQU0sRUFBRUosc0JBQVY7QUFBa0NLLElBQUFBLFFBQVEsRUFBRSxLQUE1QztBQUFtREMsSUFBQUEsVUFBVSxFQUFFO0FBQS9ELEdBRlcsRUFHWDtBQUFFRixJQUFBQSxNQUFNLEVBQUVGLGFBQVY7QUFBeUJHLElBQUFBLFFBQVEsRUFBRSxLQUFuQztBQUEwQ0MsSUFBQUEsVUFBVSxFQUFFO0FBQXRELEdBSFcsRUFJWDtBQUFFRixJQUFBQSxNQUFNLEVBQUVELG1CQUFWO0FBQStCRSxJQUFBQSxRQUFRLEVBQUUsS0FBekM7QUFBZ0RDLElBQUFBLFVBQVUsRUFBRTtBQUE1RCxHQUpXLEVBS1g7QUFDRUYsSUFBQUEsTUFBTSxFQUFFN2tCLCtFQURWO0FBRUU4a0IsSUFBQUEsUUFBUSxFQUFFLEtBRlo7QUFHRUMsSUFBQUEsVUFBVSxFQUFFO0FBSGQsR0FMVyxFQVVYO0FBQUVGLElBQUFBLE1BQU0sRUFBRXhDLCtEQUFWO0FBQTRCeUMsSUFBQUEsUUFBUSxFQUFFLEtBQXRDO0FBQTZDQyxJQUFBQSxVQUFVLEVBQUU7QUFBekQsR0FWVyxFQVdYO0FBQ0VGLElBQUFBLE1BQU0sRUFBRTdrQiwwRUFEVjtBQUVFOGtCLElBQUFBLFFBQVEsRUFBRSxLQUZaO0FBR0VDLElBQUFBLFVBQVUsRUFBRTtBQUhkLEdBWFcsQ0FBYjtBQWlCQSxTQUFPLElBQUkva0IsOEVBQUosQ0FBdUM7QUFDNUM0RCxJQUFBQSxJQUQ0QztBQUU1Q29mLElBQUFBLFNBQVMsRUFBRUwsdUNBRmlDO0FBRzVDbm1CLElBQUFBLElBQUksRUFBRTJvQixNQUFNLENBQUNDLElBQVAsQ0FBWSxFQUFaO0FBSHNDLEdBQXZDLENBQVA7QUFLRCxDQTVCRDs7QUE4Qk8sTUFBTUMsb0JBQW9CLEdBQUcsT0FDbENwcUIsWUFEa0MsRUFFbENXLGNBRmtDLEVBR2xDRixVQUhrQyxLQUlIO0FBQy9CLFFBQU00cEIsUUFBUSxHQUFHLElBQUl0bEIsMkRBQUosQ0FBb0J0RSxVQUFwQixFQUFnQ1QsWUFBaEMsRUFBOEM7QUFDN0R1cUIsSUFBQUEsbUJBQW1CLEVBQUU7QUFEd0MsR0FBOUMsQ0FBakI7QUFJQSxRQUFNQyxHQUFHLEdBQUcsTUFBTXpsQixtRUFBQSxDQUF3QnlpQixxQkFBeEIsRUFBK0M2QyxRQUEvQyxDQUFsQjs7QUFFQSxNQUFJRyxHQUFKLEVBQVM7QUFDUCxVQUFNRyxPQUFPLEdBQUcsSUFBSTVsQiwwREFBSixDQUFtQnlsQixHQUFuQixFQUF3QmhELHFCQUF4QixFQUErQzZDLFFBQS9DLENBQWhCO0FBQ0EsVUFBTU8sWUFBWSxHQUFHO0FBQ25CN2QsTUFBQUEsRUFBRSxFQUFFcE0sY0FEZTtBQUVuQkYsTUFBQUEsVUFGbUI7QUFHbkJrcUIsTUFBQUE7QUFIbUIsS0FBckI7QUFLQSxVQUFNL21CLEtBQVUsR0FBRyxNQUFNK21CLE9BQU8sQ0FBQ3hDLE9BQVIsQ0FBZ0J5QyxZQUFoQixDQUE2QnRaLEtBQTdCLENBQW1DM1EsY0FBbkMsQ0FBekI7QUFDQSxVQUFNa3FCLGNBQWMsR0FBR2puQixLQUFLLENBQUNyQyxJQUFOLENBQVdzcEIsY0FBWCxDQUEwQkMsUUFBMUIsRUFBdkI7QUFDQSxVQUFNQyxhQUFhLEdBQUdubkIsS0FBSyxDQUFDbW5CLGFBQU4sQ0FBb0JELFFBQXBCLEVBQXRCO0FBQ0EsVUFBTUUsY0FBYyxHQUFHSCxjQUFjLEdBQUdFLGFBQXhDO0FBRUEsUUFBSUUsVUFBVSxHQUFHcm5CLEtBQUssQ0FBQ3JDLElBQU4sQ0FBVzBwQixVQUFYLENBQXNCSCxRQUF0QixFQUFqQjtBQUNBRyxJQUFBQSxVQUFVLEdBQUcsSUFBSXplLElBQUosQ0FBU3llLFVBQVUsR0FBRyxJQUF0QixDQUFiO0FBRUEsV0FBTztBQUNMTCxNQUFBQSxZQURLO0FBRUxDLE1BQUFBLGNBRks7QUFHTEUsTUFBQUEsYUFISztBQUlMQyxNQUFBQSxjQUpLO0FBS0xDLE1BQUFBO0FBTEssS0FBUDtBQU9ELEdBdEJELE1Bc0JPO0FBQ0wsVUFBTSxJQUFJNWlCLEtBQUosQ0FBVyx5REFBWCxDQUFOO0FBQ0Q7QUFDRixDQXBDTTs7QUFzQ1AsTUFBTTZpQixnQkFBZ0IsR0FBRyxNQUN2QjdDLElBRHVCLElBRVk7QUFDbkMsU0FBTyxDQUNMLE1BQU10akIsb0ZBQUEsQ0FDSixDQUNFbWxCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFVBQVosQ0FERixFQUVFeEMseUJBQXlCLENBQUN5RCxRQUExQixFQUZGLEVBR0UvQyxJQUFJLENBQUMrQyxRQUFMLEVBSEYsRUFJRWxCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosQ0FKRixDQURJLEVBT0p4Qyx5QkFQSSxDQURELEVBVUwsQ0FWSyxDQUFQO0FBV0QsQ0FkRDs7QUFnQkEsTUFBTTBELFdBQVcsR0FBRyxNQUNsQmhELElBRGtCLElBRWlCO0FBQ25DLFNBQU8sQ0FDTCxNQUFNdGpCLG9GQUFBLENBQ0osQ0FDRW1sQixNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLENBREYsRUFFRXhDLHlCQUF5QixDQUFDeUQsUUFBMUIsRUFGRixFQUdFL0MsSUFBSSxDQUFDK0MsUUFBTCxFQUhGLENBREksRUFNSnpELHlCQU5JLENBREQsRUFTTCxDQVRLLENBQVA7QUFVRCxDQWJEOztBQWVBLE1BQU0yRCxjQUFjLEdBQUcsT0FDckIxckIsTUFEcUIsRUFFckJ5b0IsSUFGcUIsS0FHbEI7QUFDSCxTQUFPLENBQ0wsTUFBTXRqQixvRkFBQSxDQUNKLENBQUNuRixNQUFNLENBQUN3ckIsUUFBUCxFQUFELEVBQW9CaEUsd0VBQUEsRUFBcEIsRUFBaURpQixJQUFJLENBQUMrQyxRQUFMLEVBQWpELENBREksRUFFSjFELHVDQUZJLENBREQsRUFLTCxDQUxLLENBQVA7QUFNRCxDQVZEOztBQVlPLGVBQWV2b0IsZUFBZixDQUNMc0IsVUFESyxFQUVMbW5CLFlBRkssRUFHTDtBQUNBLFFBQU0yRCxTQUFTLEdBQUcsRUFBbEI7QUFDQSxRQUFNMUQsYUFBYSxHQUFHLE1BQU1wbkIsVUFBVSxDQUFDcW5CLDZCQUFYLENBQzFCRixZQUQwQixFQUUxQjtBQUNFRyxJQUFBQSxTQUFTLEVBQUVYLCtEQUFnQkE7QUFEN0IsR0FGMEIsQ0FBNUI7O0FBT0EsT0FBSyxJQUFJWSxLQUFLLEdBQUcsQ0FBakIsRUFBb0JBLEtBQUssR0FBR0gsYUFBYSxDQUFDbmxCLEtBQWQsQ0FBb0JpVyxNQUFoRCxFQUF3RHFQLEtBQUssRUFBN0QsRUFBaUU7QUFDL0QsVUFBTUMsWUFBWSxHQUFHSixhQUFhLENBQUNubEIsS0FBZCxDQUFvQnNsQixLQUFwQixDQUFyQjtBQUNBLFVBQU1FLFdBQVcsR0FBR0QsWUFBWSxDQUFDRSxPQUFiLENBQXFCNW1CLElBQXJCLENBQTBCcWhCLE1BQTFCLENBQWlDd0YsSUFBakMsQ0FBc0NGLFdBQTFEOztBQUVBLFFBQ0VBLFdBQVcsQ0FBQ3NELE1BQVosSUFBc0IsR0FBdEIsSUFDQXRELFdBQVcsQ0FBQ3VELFFBQVosSUFBd0IsR0FGMUIsRUFHRTtBQUNBLFVBQUksQ0FBQ0MsR0FBRCxJQUFRLE1BQU0zbUIsb0ZBQUEsQ0FDaEIsQ0FDRW1sQixNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLENBREYsRUFFRXhDLHlCQUF5QixDQUFDeUQsUUFBMUIsRUFGRixFQUdFLElBQUlybUIsaUVBQUosQ0FDRWtqQixZQUFZLENBQUNFLE9BQWIsQ0FBcUI1bUIsSUFBckIsQ0FBMEJxaEIsTUFBMUIsQ0FBaUN3RixJQUFqQyxDQUFzQ0MsSUFEeEMsRUFFRStDLFFBRkYsRUFIRixDQURnQixFQVFoQnpELHlCQVJnQixDQUFsQjtBQVVBLFlBQU1nRSxXQUFnQixHQUFHLE1BQU1sckIsVUFBVSxDQUFDbXJCLG9CQUFYLENBQWdDRixHQUFoQyxDQUEvQjtBQUVBLFlBQU1HLFFBQWEsR0FBRyxJQUFJM0Usa0RBQUosQ0FDcEJVLFlBQVksQ0FBQ3BuQixRQUFiLEVBRG9CLEVBRXBCbXJCLFdBQVcsQ0FBQ2pwQixLQUZRLENBQXRCO0FBSUEsWUFBTW9wQixPQUFPLEdBQUcsTUFBTXhhLEtBQUssQ0FBQ3VhLFFBQVEsQ0FBQ3RxQixJQUFULENBQWNBLElBQWQsQ0FBbUJ3cUIsR0FBcEIsQ0FBM0I7O0FBQ0EsVUFBSUQsT0FBTyxDQUFDek8sTUFBUixLQUFtQixHQUF2QixFQUE0QjtBQUMxQmtPLFFBQUFBLFNBQVMsQ0FBQ2hZLElBQVYsQ0FBZSxNQUFNdVksT0FBTyxDQUFDeE8sSUFBUixFQUFyQjtBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxTQUFPaU8sU0FBUDtBQUNEO0FBRU0sTUFBTVMsWUFBWSxHQUFHLE9BQzFCcEIsWUFEMEIsRUFFMUJxQixNQUYwQixFQUcxQnhDLEtBSDBCLEVBSTFCeUMsUUFKMEIsS0FLTjtBQUNwQixRQUFNN0QsSUFBSSxHQUFHdGpCLHdFQUFBLEVBQWI7QUFDQSxRQUFNc25CLEtBQUssR0FBRyxNQUFNZixjQUFjLENBQUM3QixLQUFELEVBQVFwQixJQUFJLENBQUNwb0IsU0FBYixDQUFsQztBQUNBLFFBQU07QUFBRVEsSUFBQUEsVUFBRjtBQUFja3FCLElBQUFBO0FBQWQsTUFBMEJDLFlBQWhDO0FBQ0EsUUFBTWlCLFFBQVEsR0FBRyxNQUFNUixXQUFXLENBQUNoRCxJQUFJLENBQUNwb0IsU0FBTixDQUFsQztBQUNBLFFBQU1xc0IsYUFBYSxHQUFHLE1BQU1wQixnQkFBZ0IsQ0FBQzdDLElBQUksQ0FBQ3BvQixTQUFOLENBQTVDO0FBRUEsUUFBTXNzQixJQUFJLEdBQUcsTUFBTTlyQixVQUFVLENBQUMrckIsaUNBQVgsQ0FDakJyRiw4REFEaUIsQ0FBbkI7QUFJQSxTQUFPLE1BQU13RCxPQUFPLENBQUMrQixHQUFSLENBQVlDLE9BQVosQ0FBb0I7QUFDL0JDLElBQUFBLFFBQVEsRUFBRTtBQUNSWCxNQUFBQSxNQURRO0FBRVJyQixNQUFBQSxZQUFZLEVBQUVBLFlBQVksQ0FBQzdkLEVBRm5CO0FBR1IwYyxNQUFBQSxLQUFLLEVBQUVBLEtBSEM7QUFJUjdwQixNQUFBQSxNQUFNLEVBQUVzc0IsUUFKQTtBQUtSN0QsTUFBQUEsSUFBSSxFQUFFQSxJQUFJLENBQUNwb0IsU0FMSDtBQU1SNHJCLE1BQUFBLFFBTlE7QUFPUlMsTUFBQUEsYUFQUTtBQVFSTyxNQUFBQSxhQUFhLEVBQUVwRCxLQVJQO0FBU1JxRCxNQUFBQSxlQUFlLEVBQUVyRCxLQVRUO0FBVVJzRCxNQUFBQSxvQkFBb0IsRUFBRXBGLHlCQVZkO0FBV1JxRixNQUFBQSxZQUFZLEVBQUU1RiwrREFYTjtBQVlSNkYsTUFBQUEsYUFBYSxFQUFFbG9CLCtFQVpQO0FBYVJ3bkIsTUFBQUEsSUFBSSxFQUFFeG5CLDBFQWJFO0FBY1Jtb0IsTUFBQUEsS0FBSyxFQUFFbm9CLDJFQUErQm9vQjtBQWQ5QixLQURxQjtBQWlCL0JDLElBQUFBLE9BQU8sRUFBRSxDQUFDL0UsSUFBRCxDQWpCc0I7QUFrQi9CZ0YsSUFBQUEsWUFBWSxFQUFFLENBQ1p0b0IsbUZBQUEsQ0FBd0M7QUFDdEN3b0IsTUFBQUEsVUFBVSxFQUFFOUQsS0FEMEI7QUFFdEMrRCxNQUFBQSxnQkFBZ0IsRUFBRW5GLElBQUksQ0FBQ3BvQixTQUZlO0FBR3RDd3RCLE1BQUFBLEtBQUssRUFBRXRHLDhEQUgrQjtBQUl0Q3VHLE1BQUFBLFFBQVEsRUFBRW5CLElBSjRCO0FBS3RDeEUsTUFBQUEsU0FBUyxFQUFFWCwrREFBZ0JBO0FBTFcsS0FBeEMsQ0FEWSxFQVFaQyw4RUFBQSxDQUNFRCwrREFERixFQUVFaUIsSUFBSSxDQUFDcG9CLFNBRlAsRUFHRSxDQUhGLEVBSUV3cEIsS0FKRixFQUtFQSxLQUxGLENBUlksRUFlWkYsdUNBQXVDLENBQ3JDOEMsS0FEcUMsRUFFckM1QyxLQUZxQyxFQUdyQ0EsS0FIcUMsRUFJckNwQixJQUFJLENBQUNwb0IsU0FKZ0MsQ0FmM0IsRUFxQlpvbkIsNEVBQUEsQ0FDRUQsK0RBREYsRUFFRWlCLElBQUksQ0FBQ3BvQixTQUZQLEVBR0Vvc0IsS0FIRixFQUlFNUMsS0FKRixFQUtFLEVBTEYsRUFNRSxDQU5GLENBckJZO0FBbEJpQixHQUFwQixDQUFiO0FBaURELENBakVNO0FBbUVBLE1BQU1vRSxpQkFBaUIsR0FBRyxPQUMvQmpELFlBRCtCLEVBRS9CcUIsTUFGK0IsRUFHL0J4QyxLQUgrQixFQUkvQnlDLFFBSitCLEVBSy9CNEIsUUFBZ0IsR0FBRyxDQUxZLEtBTTVCO0FBQ0gsUUFBTUMsYUFBYSxHQUFHLEVBQXRCO0FBQ0EsUUFBTUMsa0JBQWtCLEdBQUcsRUFBM0I7O0FBRUEsT0FBSyxJQUFJaEcsS0FBSyxHQUFHLENBQWpCLEVBQW9CQSxLQUFLLEdBQUc4RixRQUE1QixFQUFzQzlGLEtBQUssRUFBM0MsRUFBK0M7QUFDN0MsVUFBTUssSUFBSSxHQUFHdGpCLHdFQUFBLEVBQWI7QUFDQSxVQUFNc25CLEtBQUssR0FBRyxNQUFNZixjQUFjLENBQUM3QixLQUFELEVBQVFwQixJQUFJLENBQUNwb0IsU0FBYixDQUFsQztBQUNBLFVBQU07QUFBRVEsTUFBQUE7QUFBRixRQUFpQm1xQixZQUF2QjtBQUNBLFVBQU0yQixJQUFJLEdBQUcsTUFBTTlyQixVQUFVLENBQUMrckIsaUNBQVgsQ0FDakJyRiw4REFEaUIsQ0FBbkI7QUFHQSxVQUFNa0csWUFBWSxHQUFHLENBQ25CdG9CLG1GQUFBLENBQXdDO0FBQ3RDd29CLE1BQUFBLFVBQVUsRUFBRTlELEtBRDBCO0FBRXRDK0QsTUFBQUEsZ0JBQWdCLEVBQUVuRixJQUFJLENBQUNwb0IsU0FGZTtBQUd0Q3d0QixNQUFBQSxLQUFLLEVBQUV0Ryw4REFIK0I7QUFJdEN1RyxNQUFBQSxRQUFRLEVBQUVuQixJQUo0QjtBQUt0Q3hFLE1BQUFBLFNBQVMsRUFBRVgsK0RBQWdCQTtBQUxXLEtBQXhDLENBRG1CLEVBUW5CQyw4RUFBQSxDQUNFRCwrREFERixFQUVFaUIsSUFBSSxDQUFDcG9CLFNBRlAsRUFHRSxDQUhGLEVBSUV3cEIsS0FKRixFQUtFQSxLQUxGLENBUm1CLEVBZW5CRix1Q0FBdUMsQ0FDckM4QyxLQURxQyxFQUVyQzVDLEtBRnFDLEVBR3JDQSxLQUhxQyxFQUlyQ3BCLElBQUksQ0FBQ3BvQixTQUpnQyxDQWZwQixFQXFCbkJvbkIsNEVBQUEsQ0FDRUQsK0RBREYsRUFFRWlCLElBQUksQ0FBQ3BvQixTQUZQLEVBR0Vvc0IsS0FIRixFQUlFNUMsS0FKRixFQUtFLEVBTEYsRUFNRSxDQU5GLENBckJtQixDQUFyQjtBQThCQSxVQUFNNkMsYUFBYSxHQUFHLE1BQU1wQixnQkFBZ0IsQ0FBQzdDLElBQUksQ0FBQ3BvQixTQUFOLENBQTVDO0FBQ0EsVUFBTTRyQixRQUFRLEdBQUcsTUFBTVIsV0FBVyxDQUFDaEQsSUFBSSxDQUFDcG9CLFNBQU4sQ0FBbEM7QUFFQW90QixJQUFBQSxZQUFZLENBQUM5WixJQUFiLENBQ0UsTUFBTXFYLFlBQVksQ0FBQ0QsT0FBYixDQUFxQnNELFdBQXJCLENBQWlDdEIsT0FBakMsQ0FBeUM7QUFDN0NDLE1BQUFBLFFBQVEsRUFBRTtBQUNSWCxRQUFBQSxNQURRO0FBRVJyQixRQUFBQSxZQUFZLEVBQUVBLFlBQVksQ0FBQzdkLEVBRm5CO0FBR1IwYyxRQUFBQSxLQUFLLEVBQUVBLEtBSEM7QUFJUjdwQixRQUFBQSxNQUFNLEVBQUVzc0IsUUFKQTtBQUtSN0QsUUFBQUEsSUFBSSxFQUFFQSxJQUFJLENBQUNwb0IsU0FMSDtBQU1SNHJCLFFBQUFBLFFBTlE7QUFPUlMsUUFBQUEsYUFQUTtBQVFSTyxRQUFBQSxhQUFhLEVBQUVwRCxLQVJQO0FBU1JxRCxRQUFBQSxlQUFlLEVBQUVyRCxLQVRUO0FBVVJzRCxRQUFBQSxvQkFBb0IsRUFBRXBGLHlCQVZkO0FBV1JxRixRQUFBQSxZQUFZLEVBQUU1RiwrREFYTjtBQVlSNkYsUUFBQUEsYUFBYSxFQUFFbG9CLCtFQVpQO0FBYVJ3bkIsUUFBQUEsSUFBSSxFQUFFeG5CLDBFQWJFO0FBY1Jtb0IsUUFBQUEsS0FBSyxFQUFFbm9CLDJFQUErQm9vQjtBQWQ5QjtBQURtQyxLQUF6QyxDQURSO0FBb0JBLFVBQU1DLE9BQThCLEdBQUcsQ0FBQy9FLElBQUQsQ0FBdkM7QUFFQTBGLElBQUFBLGFBQWEsQ0FBQ3hhLElBQWQsQ0FBbUI2WixPQUFuQjtBQUNBWSxJQUFBQSxrQkFBa0IsQ0FBQ3phLElBQW5CLENBQXdCOFosWUFBeEI7QUFDRDs7QUFFRCxTQUFPLE1BQU0vRixtREFBZ0IsQ0FDM0JzRCxZQUFZLENBQUNELE9BQWIsQ0FBcUJOLFFBQXJCLENBQThCNXBCLFVBREgsRUFFM0JtcUIsWUFBWSxDQUFDRCxPQUFiLENBQXFCTixRQUFyQixDQUE4QnpxQixNQUZILEVBRzNCb3VCLGtCQUgyQixFQUkzQkQsYUFKMkIsQ0FBN0I7QUFNRCxDQWxGTTtBQW9GQSxNQUFNRyxjQUFjLEdBQUcsQ0FBQ0MsT0FBRCxFQUFrQkMsS0FBSyxHQUFHLENBQTFCLEtBQXdDO0FBQ3BFLFNBQVEsR0FBRUQsT0FBTyxDQUFDcmlCLEtBQVIsQ0FBYyxDQUFkLEVBQWlCc2lCLEtBQWpCLENBQXdCLE1BQUtELE9BQU8sQ0FBQ3JpQixLQUFSLENBQWMsQ0FBQ3NpQixLQUFmLENBQXNCLEVBQTdEO0FBQ0QsQ0FGTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pkUDtBQWNBO0FBT08sTUFBTUcsc0JBQXNCLEdBQUcsT0FDcEM5dEIsVUFEb0MsRUFFcENnb0IsSUFGb0MsS0FHakM7QUFDSDtBQUNBLFFBQU1ob0IsVUFBVSxDQUFDK3RCLGtCQUFYLENBQThCL0YsSUFBOUIsRUFBb0MsS0FBcEMsQ0FBTjtBQUVBLFFBQU1nRyxFQUFFLEdBQUcsTUFBTWh1QixVQUFVLENBQUNpdUIsNkJBQVgsQ0FBeUNqRyxJQUF6QyxDQUFqQjtBQUVBLFFBQU1rRyxNQUFnQixHQUFHLEVBQXpCOztBQUNBLE1BQUlGLEVBQUUsU0FBRixJQUFBQSxFQUFFLFdBQUYsSUFBQUEsRUFBRSxDQUFFRyxJQUFKLElBQVlILEVBQUUsQ0FBQ0csSUFBSCxDQUFRQyxXQUF4QixFQUFxQztBQUNuQ0osSUFBQUEsRUFBRSxDQUFDRyxJQUFILENBQVFDLFdBQVIsQ0FBb0JqbUIsT0FBcEIsQ0FBNkJ2SSxHQUFELElBQVM7QUFDbkMsWUFBTXl1QixLQUFLLEdBQUcsZUFBZDtBQUNBLFVBQUlDLENBQUo7O0FBQ0EsYUFBTyxDQUFDQSxDQUFDLEdBQUdELEtBQUssQ0FBQ0UsSUFBTixDQUFXM3VCLEdBQVgsQ0FBTCxNQUEwQixJQUFqQyxFQUF1QztBQUNyQztBQUNBLFlBQUkwdUIsQ0FBQyxDQUFDL0csS0FBRixLQUFZOEcsS0FBSyxDQUFDRyxTQUF0QixFQUFpQztBQUMvQkgsVUFBQUEsS0FBSyxDQUFDRyxTQUFOO0FBQ0Q7O0FBRUQsWUFBSUYsQ0FBQyxDQUFDcFcsTUFBRixHQUFXLENBQWYsRUFBa0I7QUFDaEJnVyxVQUFBQSxNQUFNLENBQUNwYixJQUFQLENBQVl3YixDQUFDLENBQUMsQ0FBRCxDQUFiO0FBQ0Q7QUFDRjtBQUNGLEtBYkQ7QUFjRDs7QUFFRCxTQUFPSixNQUFQO0FBQ0QsQ0E1Qk07QUE4QkEsSUFBS08sWUFBWjs7V0FBWUE7QUFBQUEsRUFBQUEsYUFBQUE7QUFBQUEsRUFBQUEsYUFBQUE7QUFBQUEsRUFBQUEsYUFBQUE7R0FBQUEsaUJBQUFBOztBQU1MLE1BQU01SCxnQkFBZ0IsR0FBRyxPQUM5QjdtQixVQUQ4QixFQUU5QmIsTUFGOEIsRUFHOUJ1dkIsY0FIOEIsRUFJOUJDLFVBSjhCLEVBSzlCQyxZQUEwQixHQUFHSCxZQUFZLENBQUNJLFFBTFosRUFNOUIzRyxVQUFzQixHQUFHLGNBTkssRUFPOUI0RyxLQVA4QixLQVFDO0FBQy9CLE1BQUksQ0FBQzN2QixNQUFNLENBQUNLLFNBQVosRUFBdUIsTUFBTSxJQUFJcXVCLGdGQUFKLEVBQU47QUFFdkIsUUFBTWtCLFlBQTJCLEdBQUcsRUFBcEM7O0FBRUEsTUFBSSxDQUFDRCxLQUFMLEVBQVk7QUFDVkEsSUFBQUEsS0FBSyxHQUFHLE1BQU05dUIsVUFBVSxDQUFDZ3ZCLGtCQUFYLENBQThCOUcsVUFBOUIsQ0FBZDtBQUNEOztBQUVELE9BQUssSUFBSStHLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdQLGNBQWMsQ0FBQ3hXLE1BQW5DLEVBQTJDK1csQ0FBQyxFQUE1QyxFQUFnRDtBQUM5QyxVQUFNckMsWUFBWSxHQUFHOEIsY0FBYyxDQUFDTyxDQUFELENBQW5DO0FBQ0EsVUFBTXRDLE9BQU8sR0FBR2dDLFVBQVUsQ0FBQ00sQ0FBRCxDQUExQjs7QUFFQSxRQUFJckMsWUFBWSxDQUFDMVUsTUFBYixLQUF3QixDQUE1QixFQUErQjtBQUM3QjtBQUNEOztBQUVELFFBQUlnWCxXQUFXLEdBQUcsSUFBSXRCLHdEQUFKLEVBQWxCO0FBQ0FoQixJQUFBQSxZQUFZLENBQUN6a0IsT0FBYixDQUFzQnFsQixXQUFELElBQWlCMEIsV0FBVyxDQUFDQyxHQUFaLENBQWdCM0IsV0FBaEIsQ0FBdEM7QUFDQTBCLElBQUFBLFdBQVcsQ0FBQ0UsZUFBWixHQUE4Qk4sS0FBSyxDQUFDTyxTQUFwQztBQUNBSCxJQUFBQSxXQUFXLENBQUNJLFVBQVosRUFDRTtBQUNBbndCLElBQUFBLE1BQU0sQ0FBQ0ssU0FGVCxFQUdFLEdBQUdtdEIsT0FBTyxDQUFDNW9CLEdBQVIsQ0FBYXdyQixDQUFELElBQU9BLENBQUMsQ0FBQy92QixTQUFyQixDQUhMOztBQU1BLFFBQUltdEIsT0FBTyxDQUFDelUsTUFBUixHQUFpQixDQUFyQixFQUF3QjtBQUN0QmdYLE1BQUFBLFdBQVcsQ0FBQ00sV0FBWixDQUF3QixHQUFHN0MsT0FBM0I7QUFDRDs7QUFFRG9DLElBQUFBLFlBQVksQ0FBQ2pjLElBQWIsQ0FBa0JvYyxXQUFsQjtBQUNEOztBQUVELFFBQU1PLFVBQVUsR0FBRyxNQUFNdHdCLE1BQU0sQ0FBQ00sbUJBQVAsQ0FBMkJzdkIsWUFBM0IsQ0FBekI7QUFFQSxRQUFNVyxXQUFzRCxHQUFHLEVBQS9EO0FBRUEsTUFBSUMsZ0JBQWdCLEdBQUc7QUFBRUMsSUFBQUEsVUFBVSxFQUFFLEtBQWQ7QUFBcUJYLElBQUFBLENBQUMsRUFBRTtBQUF4QixHQUF2QjtBQUNBdHZCLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUNFLG9CQURGLEVBRUU2dkIsVUFBVSxDQUFDdlgsTUFGYixFQUdFLHFCQUhGLEVBSUV3VyxjQUFjLENBQUN4VyxNQUpqQjtBQU9BLFFBQU0yWCxLQUFLLEdBQUcsRUFBZDs7QUFDQSxPQUFLLElBQUlaLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdRLFVBQVUsQ0FBQ3ZYLE1BQS9CLEVBQXVDK1csQ0FBQyxFQUF4QyxFQUE0QztBQUMxQyxVQUFNYSxnQkFBZ0IsR0FBR0MscUJBQXFCLENBQUM7QUFDN0MvdkIsTUFBQUEsVUFENkM7QUFFN0Nnd0IsTUFBQUEsaUJBQWlCLEVBQUVQLFVBQVUsQ0FBQ1IsQ0FBRDtBQUZnQixLQUFELENBQTlDOztBQUtBLFFBQUk7QUFDRixZQUFNO0FBQUVqSCxRQUFBQTtBQUFGLFVBQVcsTUFBTThILGdCQUF2QjtBQUNBRCxNQUFBQSxLQUFLLENBQUMvYyxJQUFOLENBQVdrVixJQUFYO0FBQ0QsS0FIRCxDQUdFLE9BQU8xVyxLQUFQLEVBQWM7QUFDZDNSLE1BQUFBLE9BQU8sQ0FBQzJSLEtBQVIsQ0FBY0EsS0FBZCxFQURjLENBRWQ7O0FBQ0EyZSxNQUFBQSxZQUFZLENBQUNSLFVBQVUsQ0FBQ1IsQ0FBRCxDQUFYLEVBQWdCQSxDQUFoQixDQUFaOztBQUNBLFVBQUlMLFlBQVksS0FBS0gsWUFBWSxDQUFDeUIsYUFBbEMsRUFBaUQ7QUFDL0NQLFFBQUFBLGdCQUFnQixDQUFDQyxVQUFqQixHQUE4QixJQUE5QjtBQUNBRCxRQUFBQSxnQkFBZ0IsQ0FBQ1YsQ0FBakIsR0FBcUJBLENBQXJCO0FBQ0Q7QUFDRjs7QUFFRCxRQUFJTCxZQUFZLEtBQUtILFlBQVksQ0FBQ0ksUUFBbEMsRUFBNEM7QUFDMUMsVUFBSTtBQUNGLGNBQU1pQixnQkFBTjtBQUNELE9BRkQsQ0FFRSxPQUFPM29CLENBQVAsRUFBVTtBQUNWeEgsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZ0JBQVosRUFBOEJ1SCxDQUE5Qjs7QUFDQSxZQUFJd29CLGdCQUFnQixDQUFDQyxVQUFyQixFQUFpQztBQUMvQmp3QixVQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCK3ZCLGdCQUFnQixDQUFDVixDQUF6QztBQUNBLGlCQUFPVSxnQkFBZ0IsQ0FBQ1YsQ0FBeEIsQ0FGK0IsQ0FFSjtBQUM1QjtBQUNGO0FBQ0YsS0FWRCxNQVVPO0FBQ0xTLE1BQUFBLFdBQVcsQ0FBQzVjLElBQVosQ0FBaUJnZCxnQkFBakI7QUFDRDtBQUNGOztBQUVELE1BQUlsQixZQUFZLEtBQUtILFlBQVksQ0FBQ0ksUUFBbEMsRUFBNEM7QUFDMUMsVUFBTXpoQixPQUFPLENBQUN1RSxHQUFSLENBQVkrZCxXQUFaLENBQU47QUFDRDs7QUFFRCxTQUFPRyxLQUFQO0FBQ0QsQ0E3Rk07QUErRkEsTUFBTWx0QixlQUFlLEdBQUcsT0FDN0IzQyxVQUQ2QixFQUU3QmIsTUFGNkIsRUFHN0J5dEIsWUFINkIsRUFJN0JELE9BSjZCLEVBSzdCd0QsaUJBQWlCLEdBQUcsSUFMUyxFQU03QmpJLFVBQXNCLEdBQUcsY0FOSSxFQU83QmtJLGdCQUF5QixHQUFHLEtBUEMsRUFRN0J0QixLQVI2QixLQVMxQjtBQUNILE1BQUksQ0FBQzN2QixNQUFNLENBQUNLLFNBQVosRUFBdUIsTUFBTSxJQUFJcXVCLGdGQUFKLEVBQU47QUFFdkIsTUFBSXFCLFdBQVcsR0FBRyxJQUFJdEIsd0RBQUosRUFBbEI7QUFDQWhCLEVBQUFBLFlBQVksQ0FBQ3prQixPQUFiLENBQXNCcWxCLFdBQUQsSUFBaUIwQixXQUFXLENBQUNDLEdBQVosQ0FBZ0IzQixXQUFoQixDQUF0QztBQUNBMEIsRUFBQUEsV0FBVyxDQUFDRSxlQUFaLEdBQThCLENBQzVCTixLQUFLLEtBQUssTUFBTTl1QixVQUFVLENBQUNndkIsa0JBQVgsQ0FBOEI5RyxVQUE5QixDQUFYLENBRHVCLEVBRTVCbUgsU0FGRjs7QUFJQSxNQUFJZSxnQkFBSixFQUFzQjtBQUNwQmxCLElBQUFBLFdBQVcsQ0FBQ0ksVUFBWixDQUF1QixHQUFHM0MsT0FBTyxDQUFDNW9CLEdBQVIsQ0FBYXdyQixDQUFELElBQU9BLENBQUMsQ0FBQy92QixTQUFyQixDQUExQjtBQUNELEdBRkQsTUFFTztBQUNMMHZCLElBQUFBLFdBQVcsQ0FBQ0ksVUFBWixFQUNFO0FBQ0Fud0IsSUFBQUEsTUFBTSxDQUFDSyxTQUZULEVBR0UsR0FBR210QixPQUFPLENBQUM1b0IsR0FBUixDQUFhd3JCLENBQUQsSUFBT0EsQ0FBQyxDQUFDL3ZCLFNBQXJCLENBSEw7QUFLRDs7QUFFRCxNQUFJbXRCLE9BQU8sQ0FBQ3pVLE1BQVIsR0FBaUIsQ0FBckIsRUFBd0I7QUFDdEJnWCxJQUFBQSxXQUFXLENBQUNNLFdBQVosQ0FBd0IsR0FBRzdDLE9BQTNCO0FBQ0Q7O0FBQ0QsTUFBSSxDQUFDeUQsZ0JBQUwsRUFBdUI7QUFDckJsQixJQUFBQSxXQUFXLEdBQUcsTUFBTS92QixNQUFNLENBQUNPLGVBQVAsQ0FBdUJ3dkIsV0FBdkIsQ0FBcEI7QUFDRDs7QUFFRCxRQUFNbUIsY0FBYyxHQUFHbkIsV0FBVyxDQUFDb0IsU0FBWixFQUF2QjtBQUNBLE1BQUlwcUIsT0FBTyxHQUFHO0FBQ1pxcUIsSUFBQUEsYUFBYSxFQUFFLElBREg7QUFFWnJJLElBQUFBO0FBRlksR0FBZDtBQUtBLFFBQU1GLElBQUksR0FBRyxNQUFNaG9CLFVBQVUsQ0FBQ3d3QixrQkFBWCxDQUE4QkgsY0FBOUIsRUFBOENucUIsT0FBOUMsQ0FBbkI7QUFDQSxNQUFJbWlCLElBQUksR0FBRyxDQUFYOztBQUVBLE1BQUk4SCxpQkFBSixFQUF1QjtBQUNyQixVQUFNTSxZQUFZLEdBQUcsTUFBTTFJLHFDQUFxQyxDQUM5REMsSUFEOEQsRUFFOUQwSSxlQUY4RCxFQUc5RDF3QixVQUg4RCxFQUk5RGtvQixVQUo4RCxDQUFoRTtBQU9BLFFBQUksQ0FBQ3VJLFlBQUwsRUFDRSxNQUFNLElBQUk3b0IsS0FBSixDQUFVLGdEQUFWLENBQU47QUFDRnlnQixJQUFBQSxJQUFJLEdBQUcsQ0FBQW9JLFlBQVksU0FBWixJQUFBQSxZQUFZLFdBQVosWUFBQUEsWUFBWSxDQUFFcEksSUFBZCxLQUFzQixDQUE3Qjs7QUFFQSxRQUFJb0ksWUFBSixhQUFJQSxZQUFKLGVBQUlBLFlBQVksQ0FBRXBxQixHQUFsQixFQUF1QjtBQUNyQixZQUFNNm5CLE1BQU0sR0FBRyxNQUFNSixzQkFBc0IsQ0FBQzl0QixVQUFELEVBQWFnb0IsSUFBYixDQUEzQztBQUVBcm9CLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZc3VCLE1BQVo7QUFDQSxZQUFNLElBQUl0bUIsS0FBSixDQUFXLG1CQUFrQm9nQixJQUFLLFNBQWxDLENBQU47QUFDRDtBQUNGOztBQUVELFNBQU87QUFBRUEsSUFBQUEsSUFBRjtBQUFRSyxJQUFBQTtBQUFSLEdBQVA7QUFDRCxDQWpFTTtBQW1FQSxNQUFNc0ksd0JBQXdCLEdBQUcsT0FDdEMzd0IsVUFEc0MsRUFFdENiLE1BRnNDLEVBR3RDeXRCLFlBSHNDLEVBSXRDRCxPQUpzQyxFQUt0Q3pFLFVBQXNCLEdBQUcsY0FMYSxFQU10Q2tJLGdCQUF5QixHQUFHLEtBTlUsRUFPdEN0QixLQVBzQyxFQVF0QzhCLFVBUnNDLEtBU25DO0FBQ0gsTUFBSSxDQUFDenhCLE1BQU0sQ0FBQ0ssU0FBWixFQUF1QixNQUFNLElBQUlxdUIsZ0ZBQUosRUFBTjtBQUV2QixNQUFJcUIsV0FBVyxHQUFHLElBQUl0Qix3REFBSixFQUFsQjtBQUNBaEIsRUFBQUEsWUFBWSxDQUFDemtCLE9BQWIsQ0FBc0JxbEIsV0FBRCxJQUFpQjBCLFdBQVcsQ0FBQ0MsR0FBWixDQUFnQjNCLFdBQWhCLENBQXRDO0FBQ0EwQixFQUFBQSxXQUFXLENBQUNFLGVBQVosR0FBOEIsQ0FDNUJOLEtBQUssS0FBSyxNQUFNOXVCLFVBQVUsQ0FBQ2d2QixrQkFBWCxDQUE4QjlHLFVBQTlCLENBQVgsQ0FEdUIsRUFFNUJtSCxTQUZGOztBQUlBLE1BQUllLGdCQUFKLEVBQXNCO0FBQ3BCbEIsSUFBQUEsV0FBVyxDQUFDSSxVQUFaLENBQXVCLEdBQUczQyxPQUFPLENBQUM1b0IsR0FBUixDQUFhd3JCLENBQUQsSUFBT0EsQ0FBQyxDQUFDL3ZCLFNBQXJCLENBQTFCO0FBQ0QsR0FGRCxNQUVPO0FBQ0wwdkIsSUFBQUEsV0FBVyxDQUFDSSxVQUFaLEVBQ0U7QUFDQW53QixJQUFBQSxNQUFNLENBQUNLLFNBRlQsRUFHRSxHQUFHbXRCLE9BQU8sQ0FBQzVvQixHQUFSLENBQWF3ckIsQ0FBRCxJQUFPQSxDQUFDLENBQUMvdkIsU0FBckIsQ0FITDtBQUtEOztBQUVELE1BQUltdEIsT0FBTyxDQUFDelUsTUFBUixHQUFpQixDQUFyQixFQUF3QjtBQUN0QmdYLElBQUFBLFdBQVcsQ0FBQ00sV0FBWixDQUF3QixHQUFHN0MsT0FBM0I7QUFDRDs7QUFDRCxNQUFJLENBQUN5RCxnQkFBTCxFQUF1QjtBQUNyQmxCLElBQUFBLFdBQVcsR0FBRyxNQUFNL3ZCLE1BQU0sQ0FBQ08sZUFBUCxDQUF1Qnd2QixXQUF2QixDQUFwQjtBQUNEOztBQUVELE1BQUkwQixVQUFKLEVBQWdCO0FBQ2RBLElBQUFBLFVBQVU7QUFDWDs7QUFFRCxRQUFNO0FBQUU1SSxJQUFBQSxJQUFGO0FBQVFLLElBQUFBO0FBQVIsTUFBaUIsTUFBTTBILHFCQUFxQixDQUFDO0FBQ2pEL3ZCLElBQUFBLFVBRGlEO0FBRWpEZ3dCLElBQUFBLGlCQUFpQixFQUFFZDtBQUY4QixHQUFELENBQWxEO0FBS0EsU0FBTztBQUFFbEgsSUFBQUEsSUFBRjtBQUFRSyxJQUFBQTtBQUFSLEdBQVA7QUFDRCxDQTdDTTtBQStDQSxNQUFNd0ksU0FBUyxHQUFHLE1BQU07QUFDN0IsU0FBTyxJQUFJOWtCLElBQUosR0FBVytrQixPQUFYLEtBQXVCLElBQTlCO0FBQ0QsQ0FGTTtBQUlQLE1BQU1KLGVBQWUsR0FBRyxLQUF4QjtBQUVPLGVBQWVYLHFCQUFmLENBQXFDO0FBQzFDQyxFQUFBQSxpQkFEMEM7QUFFMUNod0IsRUFBQUEsVUFGMEM7QUFHMUNpb0IsRUFBQUEsT0FBTyxHQUFHeUk7QUFIZ0MsQ0FBckMsRUFXcUM7QUFDMUMsUUFBTUwsY0FBYyxHQUFHTCxpQkFBaUIsQ0FBQ00sU0FBbEIsRUFBdkI7QUFDQSxRQUFNUyxTQUFTLEdBQUdGLFNBQVMsRUFBM0I7QUFDQSxNQUFJeEksSUFBSSxHQUFHLENBQVg7QUFDQSxRQUFNTCxJQUEwQixHQUFHLE1BQU1ob0IsVUFBVSxDQUFDd3dCLGtCQUFYLENBQ3ZDSCxjQUR1QyxFQUV2QztBQUNFRSxJQUFBQSxhQUFhLEVBQUU7QUFEakIsR0FGdUMsQ0FBekM7QUFPQTV3QixFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxtQ0FBWixFQUFpRG9vQixJQUFqRDtBQUVBLE1BQUlJLElBQUksR0FBRyxLQUFYOztBQUNBLEdBQUMsWUFBWTtBQUNYLFdBQU8sQ0FBQ0EsSUFBRCxJQUFTeUksU0FBUyxLQUFLRSxTQUFkLEdBQTBCOUksT0FBMUMsRUFBbUQ7QUFDakRqb0IsTUFBQUEsVUFBVSxDQUFDd3dCLGtCQUFYLENBQThCSCxjQUE5QixFQUE4QztBQUM1Q0UsUUFBQUEsYUFBYSxFQUFFO0FBRDZCLE9BQTlDO0FBR0EsWUFBTXpKLEtBQUssQ0FBQyxHQUFELENBQVg7QUFDRDtBQUNGLEdBUEQ7O0FBUUEsTUFBSTtBQUNGLFVBQU0ySixZQUFZLEdBQUcsTUFBTTFJLHFDQUFxQyxDQUM5REMsSUFEOEQsRUFFOURDLE9BRjhELEVBRzlEam9CLFVBSDhELEVBSTlELFFBSjhELEVBSzlELElBTDhELENBQWhFO0FBUUEsUUFBSSxDQUFDeXdCLFlBQUwsRUFDRSxNQUFNLElBQUk3b0IsS0FBSixDQUFVLGdEQUFWLENBQU47O0FBRUYsUUFBSTZvQixZQUFZLENBQUNwcUIsR0FBakIsRUFBc0I7QUFDcEIxRyxNQUFBQSxPQUFPLENBQUMyUixLQUFSLENBQWNtZixZQUFZLENBQUNwcUIsR0FBM0I7QUFDQSxZQUFNLElBQUl1QixLQUFKLENBQVUsOENBQVYsQ0FBTjtBQUNEOztBQUVEeWdCLElBQUFBLElBQUksR0FBRyxDQUFBb0ksWUFBWSxTQUFaLElBQUFBLFlBQVksV0FBWixZQUFBQSxZQUFZLENBQUVwSSxJQUFkLEtBQXNCLENBQTdCO0FBQ0QsR0FsQkQsQ0FrQkUsT0FBT2hpQixHQUFQLEVBQWlCO0FBQ2pCMUcsSUFBQUEsT0FBTyxDQUFDMlIsS0FBUixDQUFjLHNCQUFkLEVBQXNDakwsR0FBdEM7O0FBQ0EsUUFBSUEsR0FBRyxDQUFDNGhCLE9BQVIsRUFBaUI7QUFDZixZQUFNLElBQUlyZ0IsS0FBSixDQUFVLGdEQUFWLENBQU47QUFDRDs7QUFDRCxRQUFJb3BCLGNBQW1ELEdBQUcsSUFBMUQ7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxjQUFjLEdBQUcsQ0FDZixNQUFNQyxtQkFBbUIsQ0FBQ2p4QixVQUFELEVBQWFnd0IsaUJBQWIsRUFBZ0MsUUFBaEMsQ0FEVixFQUVmL3RCLEtBRkY7QUFHRCxLQUpELENBSUUsT0FBT2tGLENBQVAsRUFBVSxDQUFFOztBQUNkLFFBQUk2cEIsY0FBYyxJQUFJQSxjQUFjLENBQUMzcUIsR0FBckMsRUFBMEM7QUFDeEMsVUFBSTJxQixjQUFjLENBQUNFLElBQW5CLEVBQXlCO0FBQ3ZCLGFBQUssSUFBSWpDLENBQUMsR0FBRytCLGNBQWMsQ0FBQ0UsSUFBZixDQUFvQmhaLE1BQXBCLEdBQTZCLENBQTFDLEVBQTZDK1csQ0FBQyxJQUFJLENBQWxELEVBQXFELEVBQUVBLENBQXZELEVBQTBEO0FBQ3hELGdCQUFNa0MsSUFBSSxHQUFHSCxjQUFjLENBQUNFLElBQWYsQ0FBb0JqQyxDQUFwQixDQUFiOztBQUNBLGNBQUlrQyxJQUFJLENBQUM1WixVQUFMLENBQWdCLGVBQWhCLENBQUosRUFBc0M7QUFDcEMsa0JBQU0sSUFBSTNQLEtBQUosQ0FDSix5QkFBeUJ1cEIsSUFBSSxDQUFDOWxCLEtBQUwsQ0FBVyxnQkFBZ0I2TSxNQUEzQixDQURyQixDQUFOO0FBR0Q7QUFDRjtBQUNGOztBQUNELFlBQU0sSUFBSXRRLEtBQUosQ0FBVThXLElBQUksQ0FBQ0MsU0FBTCxDQUFlcVMsY0FBYyxDQUFDM3FCLEdBQTlCLENBQVYsQ0FBTjtBQUNELEtBdkJnQixDQXdCakI7O0FBQ0QsR0EzQ0QsU0EyQ1U7QUFDUitoQixJQUFBQSxJQUFJLEdBQUcsSUFBUDtBQUNEOztBQUVEem9CLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVosRUFBdUJvb0IsSUFBdkIsRUFBNkI2SSxTQUFTLEtBQUtFLFNBQTNDO0FBQ0EsU0FBTztBQUFFL0ksSUFBQUEsSUFBRjtBQUFRSyxJQUFBQTtBQUFSLEdBQVA7QUFDRDs7QUFFRCxlQUFlNEksbUJBQWYsQ0FDRWp4QixVQURGLEVBRUVrdkIsV0FGRixFQUdFaEgsVUFIRixFQUlnRTtBQUM5RDtBQUNBZ0gsRUFBQUEsV0FBVyxDQUFDRSxlQUFaLEdBQThCLE1BQU1wdkIsVUFBVSxDQUFDb3hCLGdCQUFYLEVBQ2xDO0FBQ0FweEIsRUFBQUEsVUFBVSxDQUFDcXhCLHdCQUZ1QixDQUFwQztBQUtBLFFBQU1DLFFBQVEsR0FBR3BDLFdBQVcsQ0FBQ3FDLGdCQUFaLEVBQWpCLENBUDhELENBUTlEOztBQUNBLFFBQU1DLGVBQWUsR0FBR3RDLFdBQVcsQ0FBQ3VDLFVBQVosQ0FBdUJILFFBQXZCLENBQXhCOztBQUNBLFFBQU1JLGtCQUFrQixHQUFHRixlQUFlLENBQUN6eEIsUUFBaEIsQ0FBeUIsUUFBekIsQ0FBM0I7QUFDQSxRQUFNeXJCLE1BQVcsR0FBRztBQUFFbUcsSUFBQUEsUUFBUSxFQUFFLFFBQVo7QUFBc0J6SixJQUFBQTtBQUF0QixHQUFwQjtBQUNBLFFBQU12Z0IsSUFBSSxHQUFHLENBQUMrcEIsa0JBQUQsRUFBcUJsRyxNQUFyQixDQUFiLENBWjhELENBYzlEOztBQUNBLFFBQU1yZCxHQUFHLEdBQUcsTUFBTW5PLFVBQVUsQ0FBQzR4QixXQUFYLENBQXVCLHFCQUF2QixFQUE4Q2pxQixJQUE5QyxDQUFsQjs7QUFDQSxNQUFJd0csR0FBRyxDQUFDbUQsS0FBUixFQUFlO0FBQ2IsVUFBTSxJQUFJMUosS0FBSixDQUFVLHFDQUFxQ3VHLEdBQUcsQ0FBQ21ELEtBQUosQ0FBVXFDLE9BQXpELENBQU47QUFDRDs7QUFDRCxTQUFPeEYsR0FBRyxDQUFDMkwsTUFBWDtBQUNEOztBQUVELGVBQWVpTyxxQ0FBZixDQUNFQyxJQURGLEVBRUVDLE9BRkYsRUFHRWpvQixVQUhGLEVBSUVrb0IsVUFBc0IsR0FBRyxRQUozQixFQUtFQyxXQUFXLEdBQUcsS0FMaEIsRUFNMEM7QUFDeEMsTUFBSUMsSUFBSSxHQUFHLEtBQVg7QUFDQSxNQUFJeEwsTUFBcUMsR0FBRztBQUMxQ3lMLElBQUFBLElBQUksRUFBRSxDQURvQztBQUUxQ0MsSUFBQUEsYUFBYSxFQUFFLENBRjJCO0FBRzFDamlCLElBQUFBLEdBQUcsRUFBRTtBQUhxQyxHQUE1QztBQUtBLE1BQUlraUIsS0FBSyxHQUFHLENBQVo7QUFDQTNMLEVBQUFBLE1BQU0sR0FBRyxNQUFNLElBQUl4UCxPQUFKLENBQVksT0FBT0MsT0FBUCxFQUFnQjZCLE1BQWhCLEtBQTJCO0FBQ3BEakQsSUFBQUEsVUFBVSxDQUFDLE1BQU07QUFDZixVQUFJbWMsSUFBSixFQUFVO0FBQ1I7QUFDRDs7QUFDREEsTUFBQUEsSUFBSSxHQUFHLElBQVA7QUFDQXpvQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSwwQkFBWjtBQUNBc1AsTUFBQUEsTUFBTSxDQUFDO0FBQUUrWSxRQUFBQSxPQUFPLEVBQUU7QUFBWCxPQUFELENBQU47QUFDRCxLQVBTLEVBT1BBLE9BUE8sQ0FBVjs7QUFRQSxRQUFJO0FBQ0ZNLE1BQUFBLEtBQUssR0FBR3ZvQixVQUFVLENBQUN3b0IsV0FBWCxDQUNOUixJQURNLEVBRU4sQ0FBQ2xPLE1BQUQsRUFBUzJPLE9BQVQsS0FBcUI7QUFDbkJMLFFBQUFBLElBQUksR0FBRyxJQUFQO0FBQ0F4TCxRQUFBQSxNQUFNLEdBQUc7QUFDUHZXLFVBQUFBLEdBQUcsRUFBRXlULE1BQU0sQ0FBQ3pULEdBREw7QUFFUGdpQixVQUFBQSxJQUFJLEVBQUVJLE9BQU8sQ0FBQ0osSUFGUDtBQUdQQyxVQUFBQSxhQUFhLEVBQUU7QUFIUixTQUFUOztBQUtBLFlBQUl4TyxNQUFNLENBQUN6VCxHQUFYLEVBQWdCO0FBQ2QxRyxVQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBWixFQUFzQ2thLE1BQU0sQ0FBQ3pULEdBQTdDO0FBQ0E2SSxVQUFBQSxNQUFNLENBQUMwTixNQUFELENBQU47QUFDRCxTQUhELE1BR087QUFDTGpkLFVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHdCQUFaLEVBQXNDa2EsTUFBdEM7QUFDQXpNLFVBQUFBLE9BQU8sQ0FBQ3VQLE1BQUQsQ0FBUDtBQUNEO0FBQ0YsT0FoQkssRUFpQk5zTCxVQWpCTSxDQUFSO0FBbUJELEtBcEJELENBb0JFLE9BQU8vZ0IsQ0FBUCxFQUFVO0FBQ1ZpaEIsTUFBQUEsSUFBSSxHQUFHLElBQVA7QUFDQXpvQixNQUFBQSxPQUFPLENBQUMyUixLQUFSLENBQWMsbUJBQWQsRUFBbUMwVyxJQUFuQyxFQUF5QzdnQixDQUF6QztBQUNEOztBQUNELFdBQU8sQ0FBQ2loQixJQUFELElBQVNELFdBQWhCLEVBQTZCO0FBQzNCO0FBQ0EsT0FBQyxZQUFZO0FBQ1gsWUFBSTtBQUNGLGdCQUFNTyxpQkFBaUIsR0FBRyxNQUFNMW9CLFVBQVUsQ0FBQzJvQixvQkFBWCxDQUFnQyxDQUM5RFgsSUFEOEQsQ0FBaEMsQ0FBaEM7QUFHQXBMLFVBQUFBLE1BQU0sR0FBRzhMLGlCQUFpQixJQUFJQSxpQkFBaUIsQ0FBQ3ptQixLQUFsQixDQUF3QixDQUF4QixDQUE5Qjs7QUFDQSxjQUFJLENBQUNtbUIsSUFBTCxFQUFXO0FBQ1QsZ0JBQUksQ0FBQ3hMLE1BQUwsRUFBYTtBQUNYamQsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksc0JBQVosRUFBb0Nvb0IsSUFBcEMsRUFBMENwTCxNQUExQztBQUNELGFBRkQsTUFFTyxJQUFJQSxNQUFNLENBQUN2VyxHQUFYLEVBQWdCO0FBQ3JCMUcsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZ0JBQVosRUFBOEJvb0IsSUFBOUIsRUFBb0NwTCxNQUFwQztBQUNBd0wsY0FBQUEsSUFBSSxHQUFHLElBQVA7QUFDQWxaLGNBQUFBLE1BQU0sQ0FBQzBOLE1BQU0sQ0FBQ3ZXLEdBQVIsQ0FBTjtBQUNELGFBSk0sTUFJQSxJQUFJLENBQUN1VyxNQUFNLENBQUMwTCxhQUFaLEVBQTJCO0FBQ2hDM29CLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDJCQUFaLEVBQXlDb29CLElBQXpDLEVBQStDcEwsTUFBL0M7QUFDRCxhQUZNLE1BRUE7QUFDTGpkLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHVCQUFaLEVBQXFDb29CLElBQXJDLEVBQTJDcEwsTUFBM0M7QUFDQXdMLGNBQUFBLElBQUksR0FBRyxJQUFQO0FBQ0EvYSxjQUFBQSxPQUFPLENBQUN1UCxNQUFELENBQVA7QUFDRDtBQUNGO0FBQ0YsU0FwQkQsQ0FvQkUsT0FBT3pWLENBQVAsRUFBVTtBQUNWLGNBQUksQ0FBQ2loQixJQUFMLEVBQVc7QUFDVHpvQixZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWixFQUEyQ29vQixJQUEzQyxFQUFpRDdnQixDQUFqRDtBQUNEO0FBQ0Y7QUFDRixPQTFCRDs7QUEyQkEsWUFBTTJmLEtBQUssQ0FBQyxJQUFELENBQVg7QUFDRDtBQUNGLEdBaEVjLENBQWYsQ0FSd0MsQ0EwRXhDOztBQUNBLE1BQUk5bUIsVUFBVSxDQUFDNG9CLHVCQUFYLENBQW1DTCxLQUFuQyxDQUFKLEVBQ0V2b0IsVUFBVSxDQUFDNm9CLHVCQUFYLENBQW1DTixLQUFuQztBQUNGSCxFQUFBQSxJQUFJLEdBQUcsSUFBUDtBQUNBem9CLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGtCQUFaLEVBQWdDZ2QsTUFBaEM7QUFDQSxTQUFPQSxNQUFQO0FBQ0Q7O0FBRU0sTUFBTWtLLEtBQUssR0FBSXhYLEVBQUQsSUFBK0I7QUFDbEQsU0FBTyxJQUFJbEMsT0FBSixDQUFhQyxPQUFELElBQWFwQixVQUFVLENBQUNvQixPQUFELEVBQVVpQyxFQUFWLENBQW5DLENBQVA7QUFDRCxDQUZNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdGRQO0FBQ0E7QUFDTyxNQUFNd2lCLGlCQUFOLFNBQWdDRCxzREFBaEMsQ0FBNkM7QUFFN0MsSUFBSUUsb0JBQUo7O0FBQ1AsQ0FBQyxVQUFVQSxvQkFBVixFQUFnQztBQUM3QkEsRUFBQUEsb0JBQW9CLENBQUMsU0FBRCxDQUFwQixHQUFrQyxjQUFsQztBQUNBQSxFQUFBQSxvQkFBb0IsQ0FBQyxTQUFELENBQXBCLEdBQWtDLFNBQWxDO0FBQ0FBLEVBQUFBLG9CQUFvQixDQUFDLFFBQUQsQ0FBcEIsR0FBaUMsUUFBakM7QUFDSCxDQUpELEVBSUdBLG9CQUFvQixLQUFLQSxvQkFBb0IsR0FBRyxFQUE1QixDQUp2Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0xPLE1BQU1DLFdBQU4sU0FBMEJwcUIsS0FBMUIsQ0FBZ0M7QUFDbkM7QUFDQXVWLEVBQUFBLFdBQVcsQ0FBQ3hKLE9BQUQsRUFBVXJDLEtBQVYsRUFBaUI7QUFDeEIsVUFBTXFDLE9BQU47QUFDQSxTQUFLckMsS0FBTCxHQUFhQSxLQUFiO0FBQ0g7O0FBTGtDO0FBT2hDLE1BQU0yZ0IsbUJBQU4sU0FBa0NELFdBQWxDLENBQThDO0FBQ2pEN1UsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHK1UsU0FBVDtBQUNBLFNBQUtueEIsSUFBTCxHQUFZLHFCQUFaO0FBQ0g7O0FBSmdEO0FBTTlDLE1BQU1veEIsdUJBQU4sU0FBc0NILFdBQXRDLENBQWtEO0FBQ3JEN1UsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHK1UsU0FBVDtBQUNBLFNBQUtueEIsSUFBTCxHQUFZLHlCQUFaO0FBQ0g7O0FBSm9EO0FBTWxELE1BQU1xeEIsbUJBQU4sU0FBa0NKLFdBQWxDLENBQThDO0FBQ2pEN1UsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHK1UsU0FBVDtBQUNBLFNBQUtueEIsSUFBTCxHQUFZLHFCQUFaO0FBQ0g7O0FBSmdEO0FBTTlDLE1BQU1zeEIscUJBQU4sU0FBb0NMLFdBQXBDLENBQWdEO0FBQ25EN1UsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHK1UsU0FBVDtBQUNBLFNBQUtueEIsSUFBTCxHQUFZLHVCQUFaO0FBQ0g7O0FBSmtEO0FBTWhELE1BQU11eEIsdUJBQU4sU0FBc0NOLFdBQXRDLENBQWtEO0FBQ3JEN1UsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHK1UsU0FBVDtBQUNBLFNBQUtueEIsSUFBTCxHQUFZLHlCQUFaO0FBQ0g7O0FBSm9EO0FBTWxELE1BQU13eEIsd0JBQU4sU0FBdUNQLFdBQXZDLENBQW1EO0FBQ3REN1UsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHK1UsU0FBVDtBQUNBLFNBQUtueEIsSUFBTCxHQUFZLDBCQUFaO0FBQ0g7O0FBSnFEO0FBTW5ELE1BQU15eEIsa0JBQU4sU0FBaUNSLFdBQWpDLENBQTZDO0FBQ2hEN1UsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHK1UsU0FBVDtBQUNBLFNBQUtueEIsSUFBTCxHQUFZLG9CQUFaO0FBQ0g7O0FBSitDO0FBTTdDLE1BQU0weEIsb0JBQU4sU0FBbUNULFdBQW5DLENBQStDO0FBQ2xEN1UsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHK1UsU0FBVDtBQUNBLFNBQUtueEIsSUFBTCxHQUFZLHNCQUFaO0FBQ0g7O0FBSmlEO0FBTS9DLE1BQU0yeEIsa0JBQU4sU0FBaUNWLFdBQWpDLENBQTZDO0FBQ2hEN1UsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHK1UsU0FBVDtBQUNBLFNBQUtueEIsSUFBTCxHQUFZLG9CQUFaO0FBQ0g7O0FBSitDO0FBTTdDLE1BQU04c0IsdUJBQU4sU0FBc0NtRSxXQUF0QyxDQUFrRDtBQUNyRDdVLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBRytVLFNBQVQ7QUFDQSxTQUFLbnhCLElBQUwsR0FBWSx5QkFBWjtBQUNIOztBQUpvRDtBQU1sRCxNQUFNNHhCLDBCQUFOLFNBQXlDWCxXQUF6QyxDQUFxRDtBQUN4RDdVLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBRytVLFNBQVQ7QUFDQSxTQUFLbnhCLElBQUwsR0FBWSw0QkFBWjtBQUNIOztBQUp1RDtBQU1yRCxNQUFNNnhCLHNCQUFOLFNBQXFDWixXQUFyQyxDQUFpRDtBQUNwRDdVLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBRytVLFNBQVQ7QUFDQSxTQUFLbnhCLElBQUwsR0FBWSx3QkFBWjtBQUNIOztBQUptRDtBQU1qRCxNQUFNOHhCLDBCQUFOLFNBQXlDYixXQUF6QyxDQUFxRDtBQUN4RDdVLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBRytVLFNBQVQ7QUFDQSxTQUFLbnhCLElBQUwsR0FBWSw0QkFBWjtBQUNIOztBQUp1RDtBQU1yRCxNQUFNK3hCLGtCQUFOLFNBQWlDZCxXQUFqQyxDQUE2QztBQUNoRDdVLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBRytVLFNBQVQ7QUFDQSxTQUFLbnhCLElBQUwsR0FBWSxvQkFBWjtBQUNIOztBQUorQztBQU03QyxNQUFNZ3lCLHdCQUFOLFNBQXVDZixXQUF2QyxDQUFtRDtBQUN0RDdVLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBRytVLFNBQVQ7QUFDQSxTQUFLbnhCLElBQUwsR0FBWSwwQkFBWjtBQUNIOztBQUpxRDtBQU1uRCxNQUFNaXlCLHVCQUFOLFNBQXNDaEIsV0FBdEMsQ0FBa0Q7QUFDckQ3VSxFQUFBQSxXQUFXLEdBQUc7QUFDVixVQUFNLEdBQUcrVSxTQUFUO0FBQ0EsU0FBS254QixJQUFMLEdBQVkseUJBQVo7QUFDSDs7QUFKb0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqR3pEO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGQSxJQUFJa3lCLFNBQVMsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxTQUFkLElBQTRCLFVBQVVDLE9BQVYsRUFBbUJDLFVBQW5CLEVBQStCQyxDQUEvQixFQUFrQ3BtQixTQUFsQyxFQUE2QztBQUNyRixXQUFTcW1CLEtBQVQsQ0FBZXB4QixLQUFmLEVBQXNCO0FBQUUsV0FBT0EsS0FBSyxZQUFZbXhCLENBQWpCLEdBQXFCbnhCLEtBQXJCLEdBQTZCLElBQUlteEIsQ0FBSixDQUFNLFVBQVUvbEIsT0FBVixFQUFtQjtBQUFFQSxNQUFBQSxPQUFPLENBQUNwTCxLQUFELENBQVA7QUFBaUIsS0FBNUMsQ0FBcEM7QUFBb0Y7O0FBQzVHLFNBQU8sS0FBS214QixDQUFDLEtBQUtBLENBQUMsR0FBR2htQixPQUFULENBQU4sRUFBeUIsVUFBVUMsT0FBVixFQUFtQjZCLE1BQW5CLEVBQTJCO0FBQ3ZELGFBQVNva0IsU0FBVCxDQUFtQnJ4QixLQUFuQixFQUEwQjtBQUFFLFVBQUk7QUFBRXN4QixRQUFBQSxJQUFJLENBQUN2bUIsU0FBUyxDQUFDMlcsSUFBVixDQUFlMWhCLEtBQWYsQ0FBRCxDQUFKO0FBQThCLE9BQXBDLENBQXFDLE9BQU9rRixDQUFQLEVBQVU7QUFBRStILFFBQUFBLE1BQU0sQ0FBQy9ILENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzNGLGFBQVNxc0IsUUFBVCxDQUFrQnZ4QixLQUFsQixFQUF5QjtBQUFFLFVBQUk7QUFBRXN4QixRQUFBQSxJQUFJLENBQUN2bUIsU0FBUyxDQUFDLE9BQUQsQ0FBVCxDQUFtQi9LLEtBQW5CLENBQUQsQ0FBSjtBQUFrQyxPQUF4QyxDQUF5QyxPQUFPa0YsQ0FBUCxFQUFVO0FBQUUrSCxRQUFBQSxNQUFNLENBQUMvSCxDQUFELENBQU47QUFBWTtBQUFFOztBQUM5RixhQUFTb3NCLElBQVQsQ0FBY3paLE1BQWQsRUFBc0I7QUFBRUEsTUFBQUEsTUFBTSxDQUFDc08sSUFBUCxHQUFjL2EsT0FBTyxDQUFDeU0sTUFBTSxDQUFDN1gsS0FBUixDQUFyQixHQUFzQ294QixLQUFLLENBQUN2WixNQUFNLENBQUM3WCxLQUFSLENBQUwsQ0FBb0J3TCxJQUFwQixDQUF5QjZsQixTQUF6QixFQUFvQ0UsUUFBcEMsQ0FBdEM7QUFBc0Y7O0FBQzlHRCxJQUFBQSxJQUFJLENBQUMsQ0FBQ3ZtQixTQUFTLEdBQUdBLFNBQVMsQ0FBQ3ltQixLQUFWLENBQWdCUCxPQUFoQixFQUF5QkMsVUFBVSxJQUFJLEVBQXZDLENBQWIsRUFBeUR4UCxJQUF6RCxFQUFELENBQUo7QUFDSCxHQUxNLENBQVA7QUFNSCxDQVJEOztBQVNPLFNBQVMrUCxJQUFULENBQWMzZSxRQUFkLEVBQXdCNGUsUUFBeEIsRUFBa0NDLEtBQWxDLEVBQXlDO0FBQzVDLE1BQUlBLEtBQUssR0FBRyxDQUFaLEVBQWU7QUFDWDNuQixJQUFBQSxVQUFVLENBQUMsTUFBTWduQixTQUFTLENBQUMsSUFBRCxFQUFPLEtBQUssQ0FBWixFQUFlLEtBQUssQ0FBcEIsRUFBdUIsYUFBYTtBQUMxRCxZQUFNN0ssSUFBSSxHQUFHLE1BQU1yVCxRQUFRLEVBQTNCO0FBQ0EsVUFBSSxDQUFDcVQsSUFBTCxFQUNJc0wsSUFBSSxDQUFDM2UsUUFBRCxFQUFXNGUsUUFBWCxFQUFxQkMsS0FBSyxHQUFHLENBQTdCLENBQUo7QUFDUCxLQUp5QixDQUFoQixFQUlORCxRQUpNLENBQVY7QUFLSDtBQUNKO0FBQ00sU0FBU0UsY0FBVCxDQUF3QkMsT0FBeEIsRUFBaUNDLFlBQWpDLEVBQStDQyxTQUEvQyxFQUEwRDtBQUM3RE4sRUFBQUEsSUFBSSxDQUFDLE1BQU07QUFDUCxVQUFNO0FBQUU3Z0IsTUFBQUE7QUFBRixRQUFZaWhCLE9BQWxCOztBQUNBLFFBQUlqaEIsS0FBSixFQUFXO0FBQ1AsVUFBSSxDQUFDaWhCLE9BQU8sQ0FBQzlSLElBQVIsQ0FBYSxPQUFiLENBQUwsRUFBNEI7QUFDeEJyaUIsUUFBQUEsT0FBTyxDQUFDaUosSUFBUixDQUFjLEdBQUVrckIsT0FBTyxDQUFDM1csV0FBUixDQUFvQnBjLElBQUssMENBQXpDO0FBQ0g7QUFDSjs7QUFDRCxXQUFPOFIsS0FBUDtBQUNILEdBUkcsRUFRRGtoQixZQVJDLEVBUWFDLFNBUmIsQ0FBSjtBQVNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1QkQsSUFBSWYsU0FBUyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFNBQWQsSUFBNEIsVUFBVUMsT0FBVixFQUFtQkMsVUFBbkIsRUFBK0JDLENBQS9CLEVBQWtDcG1CLFNBQWxDLEVBQTZDO0FBQ3JGLFdBQVNxbUIsS0FBVCxDQUFlcHhCLEtBQWYsRUFBc0I7QUFBRSxXQUFPQSxLQUFLLFlBQVlteEIsQ0FBakIsR0FBcUJueEIsS0FBckIsR0FBNkIsSUFBSW14QixDQUFKLENBQU0sVUFBVS9sQixPQUFWLEVBQW1CO0FBQUVBLE1BQUFBLE9BQU8sQ0FBQ3BMLEtBQUQsQ0FBUDtBQUFpQixLQUE1QyxDQUFwQztBQUFvRjs7QUFDNUcsU0FBTyxLQUFLbXhCLENBQUMsS0FBS0EsQ0FBQyxHQUFHaG1CLE9BQVQsQ0FBTixFQUF5QixVQUFVQyxPQUFWLEVBQW1CNkIsTUFBbkIsRUFBMkI7QUFDdkQsYUFBU29rQixTQUFULENBQW1CcnhCLEtBQW5CLEVBQTBCO0FBQUUsVUFBSTtBQUFFc3hCLFFBQUFBLElBQUksQ0FBQ3ZtQixTQUFTLENBQUMyVyxJQUFWLENBQWUxaEIsS0FBZixDQUFELENBQUo7QUFBOEIsT0FBcEMsQ0FBcUMsT0FBT2tGLENBQVAsRUFBVTtBQUFFK0gsUUFBQUEsTUFBTSxDQUFDL0gsQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDM0YsYUFBU3FzQixRQUFULENBQWtCdnhCLEtBQWxCLEVBQXlCO0FBQUUsVUFBSTtBQUFFc3hCLFFBQUFBLElBQUksQ0FBQ3ZtQixTQUFTLENBQUMsT0FBRCxDQUFULENBQW1CL0ssS0FBbkIsQ0FBRCxDQUFKO0FBQWtDLE9BQXhDLENBQXlDLE9BQU9rRixDQUFQLEVBQVU7QUFBRStILFFBQUFBLE1BQU0sQ0FBQy9ILENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzlGLGFBQVNvc0IsSUFBVCxDQUFjelosTUFBZCxFQUFzQjtBQUFFQSxNQUFBQSxNQUFNLENBQUNzTyxJQUFQLEdBQWMvYSxPQUFPLENBQUN5TSxNQUFNLENBQUM3WCxLQUFSLENBQXJCLEdBQXNDb3hCLEtBQUssQ0FBQ3ZaLE1BQU0sQ0FBQzdYLEtBQVIsQ0FBTCxDQUFvQndMLElBQXBCLENBQXlCNmxCLFNBQXpCLEVBQW9DRSxRQUFwQyxDQUF0QztBQUFzRjs7QUFDOUdELElBQUFBLElBQUksQ0FBQyxDQUFDdm1CLFNBQVMsR0FBR0EsU0FBUyxDQUFDeW1CLEtBQVYsQ0FBZ0JQLE9BQWhCLEVBQXlCQyxVQUFVLElBQUksRUFBdkMsQ0FBYixFQUF5RHhQLElBQXpELEVBQUQsQ0FBSjtBQUNILEdBTE0sQ0FBUDtBQU1ILENBUkQ7O0FBU0EsSUFBSXNRLE1BQU0sR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxNQUFkLElBQXlCLFVBQVUxRSxDQUFWLEVBQWFwb0IsQ0FBYixFQUFnQjtBQUNsRCxNQUFJK3NCLENBQUMsR0FBRyxFQUFSOztBQUNBLE9BQUssSUFBSXJyQixDQUFULElBQWMwbUIsQ0FBZCxFQUFpQixJQUFJdHFCLE1BQU0sQ0FBQ2t2QixTQUFQLENBQWlCQyxjQUFqQixDQUFnQ0MsSUFBaEMsQ0FBcUM5RSxDQUFyQyxFQUF3QzFtQixDQUF4QyxLQUE4QzFCLENBQUMsQ0FBQ00sT0FBRixDQUFVb0IsQ0FBVixJQUFlLENBQWpFLEVBQ2JxckIsQ0FBQyxDQUFDcnJCLENBQUQsQ0FBRCxHQUFPMG1CLENBQUMsQ0FBQzFtQixDQUFELENBQVI7O0FBQ0osTUFBSTBtQixDQUFDLElBQUksSUFBTCxJQUFhLE9BQU90cUIsTUFBTSxDQUFDcXZCLHFCQUFkLEtBQXdDLFVBQXpELEVBQ0ksS0FBSyxJQUFJckYsQ0FBQyxHQUFHLENBQVIsRUFBV3BtQixDQUFDLEdBQUc1RCxNQUFNLENBQUNxdkIscUJBQVAsQ0FBNkIvRSxDQUE3QixDQUFwQixFQUFxRE4sQ0FBQyxHQUFHcG1CLENBQUMsQ0FBQ3FQLE1BQTNELEVBQW1FK1csQ0FBQyxFQUFwRSxFQUF3RTtBQUNwRSxRQUFJOW5CLENBQUMsQ0FBQ00sT0FBRixDQUFVb0IsQ0FBQyxDQUFDb21CLENBQUQsQ0FBWCxJQUFrQixDQUFsQixJQUF1QmhxQixNQUFNLENBQUNrdkIsU0FBUCxDQUFpQkksb0JBQWpCLENBQXNDRixJQUF0QyxDQUEyQzlFLENBQTNDLEVBQThDMW1CLENBQUMsQ0FBQ29tQixDQUFELENBQS9DLENBQTNCLEVBQ0lpRixDQUFDLENBQUNyckIsQ0FBQyxDQUFDb21CLENBQUQsQ0FBRixDQUFELEdBQVVNLENBQUMsQ0FBQzFtQixDQUFDLENBQUNvbUIsQ0FBRCxDQUFGLENBQVg7QUFDUDtBQUNMLFNBQU9pRixDQUFQO0FBQ0gsQ0FWRDs7QUFXQTtBQUNBO0FBQ08sTUFBTU0sdUJBQU4sU0FBc0MxQyx1REFBdEMsQ0FBd0Q7QUFDM0RudkIsRUFBQUEsZUFBZSxDQUFDdXNCLFdBQUQsRUFBY2x2QixVQUFkLEVBQTBCa0csT0FBTyxHQUFHLEVBQXBDLEVBQXdDO0FBQ25ELFdBQU8rc0IsU0FBUyxDQUFDLElBQUQsRUFBTyxLQUFLLENBQVosRUFBZSxLQUFLLENBQXBCLEVBQXVCLGFBQWE7QUFDaEQsVUFBSWpSLElBQUksR0FBRyxJQUFYOztBQUNBLFVBQUk7QUFDQSxZQUFJO0FBQ0FrTixVQUFBQSxXQUFXLENBQUN1RixRQUFaLEtBQXlCdkYsV0FBVyxDQUFDdUYsUUFBWixHQUF1QixLQUFLajFCLFNBQUwsSUFBa0JrVixTQUFsRTtBQUNBd2EsVUFBQUEsV0FBVyxDQUFDRSxlQUFaLEtBQWdDRixXQUFXLENBQUNFLGVBQVosR0FBOEIsQ0FBQyxNQUFNcHZCLFVBQVUsQ0FBQ2d2QixrQkFBWCxDQUE4QixXQUE5QixDQUFQLEVBQW1ESyxTQUFqSDs7QUFDQSxnQkFBTTtBQUFFMUMsWUFBQUE7QUFBRixjQUFjem1CLE9BQXBCO0FBQUEsZ0JBQTZCd3VCLFdBQVcsR0FBR1QsTUFBTSxDQUFDL3RCLE9BQUQsRUFBVSxDQUFDLFNBQUQsQ0FBVixDQUFqRDs7QUFDQSxXQUFDeW1CLE9BQU8sS0FBSyxJQUFaLElBQW9CQSxPQUFPLEtBQUssS0FBSyxDQUFyQyxHQUF5QyxLQUFLLENBQTlDLEdBQWtEQSxPQUFPLENBQUN6VSxNQUEzRCxLQUFzRWdYLFdBQVcsQ0FBQ00sV0FBWixDQUF3QixHQUFHN0MsT0FBM0IsQ0FBdEU7QUFDQXVDLFVBQUFBLFdBQVcsR0FBRyxNQUFNLEtBQUt4dkIsZUFBTCxDQUFxQnd2QixXQUFyQixDQUFwQjtBQUNBLGdCQUFNbUIsY0FBYyxHQUFHbkIsV0FBVyxDQUFDb0IsU0FBWixFQUF2QjtBQUNBLGlCQUFPLE1BQU10d0IsVUFBVSxDQUFDd3dCLGtCQUFYLENBQThCSCxjQUE5QixFQUE4Q3FFLFdBQTlDLENBQWI7QUFDSCxTQVJELENBU0EsT0FBT3BqQixLQUFQLEVBQWM7QUFDVjtBQUNBLGNBQUlBLEtBQUssWUFBWTBnQixnREFBckIsRUFBa0M7QUFDOUJoUSxZQUFBQSxJQUFJLEdBQUcsS0FBUDtBQUNBLGtCQUFNMVEsS0FBTjtBQUNIOztBQUNELGdCQUFNLElBQUlxaEIsK0RBQUosQ0FBK0JyaEIsS0FBSyxLQUFLLElBQVYsSUFBa0JBLEtBQUssS0FBSyxLQUFLLENBQWpDLEdBQXFDLEtBQUssQ0FBMUMsR0FBOENBLEtBQUssQ0FBQ3FDLE9BQW5GLEVBQTRGckMsS0FBNUYsQ0FBTjtBQUNIO0FBQ0osT0FsQkQsQ0FtQkEsT0FBT0EsS0FBUCxFQUFjO0FBQ1YsWUFBSTBRLElBQUosRUFBVTtBQUNOLGVBQUtBLElBQUwsQ0FBVSxPQUFWLEVBQW1CMVEsS0FBbkI7QUFDSDs7QUFDRCxjQUFNQSxLQUFOO0FBQ0g7QUFDSixLQTNCZSxDQUFoQjtBQTRCSDs7QUE5QjBEO0FBZ0N4RCxNQUFNcWpCLDhCQUFOLFNBQTZDSCx1QkFBN0MsQ0FBcUU7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEQ1RTtBQUNPLE1BQU1JLE1BQU0sR0FBSTcxQixLQUFELElBQVc7QUFDN0IsUUFBTTgxQixjQUFjLEdBQUc5MUIsS0FBSyxDQUFDKzFCLE9BQU4sSUFBaUIvMUIsS0FBSyxDQUFDZzJCLFNBQXZCLEdBQW1DLGVBQW5DLEdBQXFELFFBQTVFO0FBQ0Esc0JBQVE1MEIsMERBQUEsQ0FBb0IsUUFBcEIsRUFBOEI7QUFBRTYwQixJQUFBQSxTQUFTLEVBQUcseUJBQXdCajJCLEtBQUssQ0FBQ2kyQixTQUFOLElBQW1CLEVBQUcsRUFBNUQ7QUFBK0QzZ0IsSUFBQUEsUUFBUSxFQUFFdFYsS0FBSyxDQUFDc1YsUUFBL0U7QUFBeUZsSyxJQUFBQSxPQUFPLEVBQUVwTCxLQUFLLENBQUNvTCxPQUF4RztBQUFpSDhxQixJQUFBQSxLQUFLLEVBQUVod0IsTUFBTSxDQUFDK00sTUFBUCxDQUFjO0FBQUU2aUIsTUFBQUE7QUFBRixLQUFkLEVBQWtDOTFCLEtBQUssQ0FBQ2syQixLQUF4QyxDQUF4SDtBQUF3S0MsSUFBQUEsUUFBUSxFQUFFbjJCLEtBQUssQ0FBQ20yQixRQUFOLElBQWtCLENBQXBNO0FBQXVNcjFCLElBQUFBLElBQUksRUFBRTtBQUE3TSxHQUE5QixFQUNKZCxLQUFLLENBQUNnMkIsU0FBTixpQkFBbUI1MEIsMERBQUEsQ0FBb0IsR0FBcEIsRUFBeUI7QUFBRTYwQixJQUFBQSxTQUFTLEVBQUU7QUFBYixHQUF6QixFQUE0RWoyQixLQUFLLENBQUNnMkIsU0FBbEYsQ0FEZixFQUVKaDJCLEtBQUssQ0FBQ21LLFFBRkYsRUFHSm5LLEtBQUssQ0FBQysxQixPQUFOLGlCQUFpQjMwQiwwREFBQSxDQUFvQixHQUFwQixFQUF5QjtBQUFFNjBCLElBQUFBLFNBQVMsRUFBRTtBQUFiLEdBQXpCLEVBQTBFajJCLEtBQUssQ0FBQysxQixPQUFoRixDQUhiLENBQVI7QUFJSCxDQU5NOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBQ08sTUFBTU0sUUFBUSxHQUFHLENBQUM7QUFBRTlvQixFQUFBQSxFQUFGO0FBQU1wRCxFQUFBQSxRQUFOO0FBQWdCbXNCLEVBQUFBLFFBQVEsR0FBRztBQUEzQixDQUFELEtBQXdDO0FBQzVELFFBQU03ckIsR0FBRyxHQUFHZCw2Q0FBTSxDQUFDLElBQUQsQ0FBbEI7QUFDQSxRQUFNNHNCLE9BQU8sR0FBRzVzQiw2Q0FBTSxDQUFDLElBQUQsQ0FBdEI7QUFDQSxRQUFNNnNCLFVBQVUsR0FBRyx1QkFBbkI7O0FBQ0EsUUFBTUMsWUFBWSxHQUFHLE1BQU07QUFDdkIsVUFBTUMsSUFBSSxHQUFHanNCLEdBQUcsQ0FBQ2IsT0FBakI7QUFDQSxRQUFJLENBQUM4c0IsSUFBTCxFQUNJO0FBQ0pDLElBQUFBLHFCQUFxQixDQUFDLE1BQU07QUFDeEJELE1BQUFBLElBQUksQ0FBQ1IsS0FBTCxDQUFXVSxNQUFYLEdBQW9CRixJQUFJLENBQUNHLFlBQUwsR0FBb0IsSUFBeEM7QUFDSCxLQUZvQixDQUFyQjtBQUdILEdBUEQ7O0FBUUEsUUFBTUMsYUFBYSxHQUFHLE1BQU07QUFDeEIsVUFBTUosSUFBSSxHQUFHanNCLEdBQUcsQ0FBQ2IsT0FBakI7QUFDQSxRQUFJLENBQUM4c0IsSUFBTCxFQUNJO0FBQ0pDLElBQUFBLHFCQUFxQixDQUFDLE1BQU07QUFDeEJELE1BQUFBLElBQUksQ0FBQ1IsS0FBTCxDQUFXVSxNQUFYLEdBQW9CRixJQUFJLENBQUNLLFlBQUwsR0FBb0IsSUFBeEM7QUFDQUwsTUFBQUEsSUFBSSxDQUFDUixLQUFMLENBQVdjLFFBQVgsR0FBc0IsUUFBdEI7QUFDQUwsTUFBQUEscUJBQXFCLENBQUMsTUFBTTtBQUN4QkQsUUFBQUEsSUFBSSxDQUFDUixLQUFMLENBQVdVLE1BQVgsR0FBb0IsR0FBcEI7QUFDSCxPQUZvQixDQUFyQjtBQUdILEtBTm9CLENBQXJCO0FBT0gsR0FYRDs7QUFZQVIsRUFBQUEsc0RBQWUsQ0FBQyxNQUFNO0FBQ2xCLFFBQUlFLFFBQUosRUFBYztBQUNWRyxNQUFBQSxZQUFZO0FBQ2YsS0FGRCxNQUdLO0FBQ0RLLE1BQUFBLGFBQWE7QUFDaEI7QUFDSixHQVBjLEVBT1osQ0FBQ1IsUUFBRCxDQVBZLENBQWY7QUFRQUYsRUFBQUEsc0RBQWUsQ0FBQyxNQUFNO0FBQ2xCLFVBQU1NLElBQUksR0FBR2pzQixHQUFHLENBQUNiLE9BQWpCO0FBQ0EsUUFBSSxDQUFDOHNCLElBQUwsRUFDSTs7QUFDSixhQUFTTyxjQUFULEdBQTBCO0FBQ3RCLFVBQUksQ0FBQ1AsSUFBTCxFQUNJO0FBQ0pBLE1BQUFBLElBQUksQ0FBQ1IsS0FBTCxDQUFXYyxRQUFYLEdBQXNCVixRQUFRLEdBQUcsU0FBSCxHQUFlLFFBQTdDOztBQUNBLFVBQUlBLFFBQUosRUFBYztBQUNWSSxRQUFBQSxJQUFJLENBQUNSLEtBQUwsQ0FBV1UsTUFBWCxHQUFvQixNQUFwQjtBQUNIO0FBQ0o7O0FBQ0QsYUFBU00sbUJBQVQsQ0FBNkJ4dkIsS0FBN0IsRUFBb0M7QUFDaEMsVUFBSWd2QixJQUFJLElBQUlodkIsS0FBSyxDQUFDQyxNQUFOLEtBQWlCK3VCLElBQXpCLElBQWlDaHZCLEtBQUssQ0FBQ3l2QixZQUFOLEtBQXVCLFFBQTVELEVBQXNFO0FBQ2xFRixRQUFBQSxjQUFjO0FBQ2pCO0FBQ0o7O0FBQ0QsUUFBSVYsT0FBTyxDQUFDM3NCLE9BQVosRUFBcUI7QUFDakJxdEIsTUFBQUEsY0FBYztBQUNkVixNQUFBQSxPQUFPLENBQUMzc0IsT0FBUixHQUFrQixLQUFsQjtBQUNIOztBQUNEOHNCLElBQUFBLElBQUksQ0FBQzlVLGdCQUFMLENBQXNCLGVBQXRCLEVBQXVDc1YsbUJBQXZDO0FBQ0EsV0FBTyxNQUFNUixJQUFJLENBQUNVLG1CQUFMLENBQXlCLGVBQXpCLEVBQTBDRixtQkFBMUMsQ0FBYjtBQUNILEdBdkJjLEVBdUJaLENBQUNaLFFBQUQsQ0F2QlksQ0FBZjtBQXdCQSxzQkFBUWwxQiwwREFBQSxDQUFvQixLQUFwQixFQUEyQjtBQUFFK0ksSUFBQUEsUUFBUSxFQUFFQSxRQUFaO0FBQXNCOHJCLElBQUFBLFNBQVMsRUFBRSx5QkFBakM7QUFBNEQxb0IsSUFBQUEsRUFBRSxFQUFFQSxFQUFoRTtBQUFvRTlDLElBQUFBLEdBQUcsRUFBRUEsR0FBekU7QUFBOEU0c0IsSUFBQUEsSUFBSSxFQUFFLFFBQXBGO0FBQThGbkIsSUFBQUEsS0FBSyxFQUFFO0FBQUVVLE1BQUFBLE1BQU0sRUFBRSxDQUFWO0FBQWFKLE1BQUFBLFVBQVUsRUFBRUQsT0FBTyxDQUFDM3NCLE9BQVIsR0FBa0IrTCxTQUFsQixHQUE4QjZnQjtBQUF2RDtBQUFyRyxHQUEzQixDQUFSO0FBQ0gsQ0F6RE07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRFAsSUFBSXRCLE1BQU0sR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxNQUFkLElBQXlCLFVBQVUxRSxDQUFWLEVBQWFwb0IsQ0FBYixFQUFnQjtBQUNsRCxNQUFJK3NCLENBQUMsR0FBRyxFQUFSOztBQUNBLE9BQUssSUFBSXJyQixDQUFULElBQWMwbUIsQ0FBZCxFQUFpQixJQUFJdHFCLE1BQU0sQ0FBQ2t2QixTQUFQLENBQWlCQyxjQUFqQixDQUFnQ0MsSUFBaEMsQ0FBcUM5RSxDQUFyQyxFQUF3QzFtQixDQUF4QyxLQUE4QzFCLENBQUMsQ0FBQ00sT0FBRixDQUFVb0IsQ0FBVixJQUFlLENBQWpFLEVBQ2JxckIsQ0FBQyxDQUFDcnJCLENBQUQsQ0FBRCxHQUFPMG1CLENBQUMsQ0FBQzFtQixDQUFELENBQVI7O0FBQ0osTUFBSTBtQixDQUFDLElBQUksSUFBTCxJQUFhLE9BQU90cUIsTUFBTSxDQUFDcXZCLHFCQUFkLEtBQXdDLFVBQXpELEVBQ0ksS0FBSyxJQUFJckYsQ0FBQyxHQUFHLENBQVIsRUFBV3BtQixDQUFDLEdBQUc1RCxNQUFNLENBQUNxdkIscUJBQVAsQ0FBNkIvRSxDQUE3QixDQUFwQixFQUFxRE4sQ0FBQyxHQUFHcG1CLENBQUMsQ0FBQ3FQLE1BQTNELEVBQW1FK1csQ0FBQyxFQUFwRSxFQUF3RTtBQUNwRSxRQUFJOW5CLENBQUMsQ0FBQ00sT0FBRixDQUFVb0IsQ0FBQyxDQUFDb21CLENBQUQsQ0FBWCxJQUFrQixDQUFsQixJQUF1QmhxQixNQUFNLENBQUNrdkIsU0FBUCxDQUFpQkksb0JBQWpCLENBQXNDRixJQUF0QyxDQUEyQzlFLENBQTNDLEVBQThDMW1CLENBQUMsQ0FBQ29tQixDQUFELENBQS9DLENBQTNCLEVBQ0lpRixDQUFDLENBQUNyckIsQ0FBQyxDQUFDb21CLENBQUQsQ0FBRixDQUFELEdBQVVNLENBQUMsQ0FBQzFtQixDQUFDLENBQUNvbUIsQ0FBRCxDQUFGLENBQVg7QUFDUDtBQUNMLFNBQU9pRixDQUFQO0FBQ0gsQ0FWRDs7QUFXQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1vQyxtQkFBbUIsR0FBSUMsRUFBRCxJQUFRO0FBQ3ZDLE1BQUk7QUFBRXJ0QixJQUFBQSxRQUFGO0FBQVltTCxJQUFBQSxRQUFaO0FBQXNCbEssSUFBQUE7QUFBdEIsTUFBa0Nvc0IsRUFBdEM7QUFBQSxNQUEwQ3gzQixLQUFLLEdBQUdrMUIsTUFBTSxDQUFDc0MsRUFBRCxFQUFLLENBQUMsVUFBRCxFQUFhLFVBQWIsRUFBeUIsU0FBekIsQ0FBTCxDQUF4RDs7QUFDQSxRQUFNO0FBQUVwM0IsSUFBQUEsTUFBRjtBQUFVcTNCLElBQUFBLE9BQVY7QUFBbUJDLElBQUFBLFVBQW5CO0FBQStCQyxJQUFBQTtBQUEvQixNQUE2Qy8zQix1RUFBUyxFQUE1RDtBQUNBLFFBQU1nNEIsV0FBVyxHQUFHN3NCLGtEQUFXLENBQUVyRCxLQUFELElBQVc7QUFDdkMsUUFBSTBELE9BQUosRUFDSUEsT0FBTyxDQUFDMUQsS0FBRCxDQUFQLENBRm1DLENBR3ZDOztBQUNBLFFBQUksQ0FBQ0EsS0FBSyxDQUFDMkQsZ0JBQVgsRUFDSW9zQixPQUFPLEdBQUdwd0IsS0FBVixDQUFnQixNQUFNLENBQUcsQ0FBekI7QUFDUCxHQU44QixFQU01QixDQUFDK0QsT0FBRCxFQUFVcXNCLE9BQVYsQ0FONEIsQ0FBL0I7QUFPQSxRQUFNeGxCLE9BQU8sR0FBR3ZTLDhDQUFPLENBQUMsTUFBTTtBQUMxQixRQUFJeUssUUFBSixFQUNJLE9BQU9BLFFBQVA7QUFDSixRQUFJdXRCLFVBQUosRUFDSSxPQUFPLGdCQUFQO0FBQ0osUUFBSUMsU0FBSixFQUNJLE9BQU8sV0FBUDtBQUNKLFFBQUl2M0IsTUFBSixFQUNJLE9BQU8sU0FBUDtBQUNKLFdBQU8sZ0JBQVA7QUFDSCxHQVZzQixFQVVwQixDQUFDK0osUUFBRCxFQUFXdXRCLFVBQVgsRUFBdUJDLFNBQXZCLEVBQWtDdjNCLE1BQWxDLENBVm9CLENBQXZCO0FBV0Esc0JBQVFnQiwwREFBQSxDQUFvQnkwQiwyQ0FBcEIsRUFBNEIzdkIsTUFBTSxDQUFDK00sTUFBUCxDQUFjO0FBQUVnakIsSUFBQUEsU0FBUyxFQUFFLCtCQUFiO0FBQThDM2dCLElBQUFBLFFBQVEsRUFBRUEsUUFBUSxJQUFJLENBQUNsVixNQUFiLElBQXVCczNCLFVBQXZCLElBQXFDQyxTQUE3RjtBQUF3RzNCLElBQUFBLFNBQVMsRUFBRTUxQixNQUFNLGdCQUFHZ0IsMERBQUEsQ0FBb0JrMkIsbURBQXBCLEVBQWdDO0FBQUVsM0IsTUFBQUEsTUFBTSxFQUFFQTtBQUFWLEtBQWhDLENBQUgsR0FBeUR1VixTQUFsTDtBQUE2THZLLElBQUFBLE9BQU8sRUFBRXdzQjtBQUF0TSxHQUFkLEVBQW1PNTNCLEtBQW5PLENBQTVCLEVBQXVRaVMsT0FBdlEsQ0FBUjtBQUNILENBdEJNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2ZQLElBQUlpakIsTUFBTSxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLE1BQWQsSUFBeUIsVUFBVTFFLENBQVYsRUFBYXBvQixDQUFiLEVBQWdCO0FBQ2xELE1BQUkrc0IsQ0FBQyxHQUFHLEVBQVI7O0FBQ0EsT0FBSyxJQUFJcnJCLENBQVQsSUFBYzBtQixDQUFkLEVBQWlCLElBQUl0cUIsTUFBTSxDQUFDa3ZCLFNBQVAsQ0FBaUJDLGNBQWpCLENBQWdDQyxJQUFoQyxDQUFxQzlFLENBQXJDLEVBQXdDMW1CLENBQXhDLEtBQThDMUIsQ0FBQyxDQUFDTSxPQUFGLENBQVVvQixDQUFWLElBQWUsQ0FBakUsRUFDYnFyQixDQUFDLENBQUNyckIsQ0FBRCxDQUFELEdBQU8wbUIsQ0FBQyxDQUFDMW1CLENBQUQsQ0FBUjs7QUFDSixNQUFJMG1CLENBQUMsSUFBSSxJQUFMLElBQWEsT0FBT3RxQixNQUFNLENBQUNxdkIscUJBQWQsS0FBd0MsVUFBekQsRUFDSSxLQUFLLElBQUlyRixDQUFDLEdBQUcsQ0FBUixFQUFXcG1CLENBQUMsR0FBRzVELE1BQU0sQ0FBQ3F2QixxQkFBUCxDQUE2Qi9FLENBQTdCLENBQXBCLEVBQXFETixDQUFDLEdBQUdwbUIsQ0FBQyxDQUFDcVAsTUFBM0QsRUFBbUUrVyxDQUFDLEVBQXBFLEVBQXdFO0FBQ3BFLFFBQUk5bkIsQ0FBQyxDQUFDTSxPQUFGLENBQVVvQixDQUFDLENBQUNvbUIsQ0FBRCxDQUFYLElBQWtCLENBQWxCLElBQXVCaHFCLE1BQU0sQ0FBQ2t2QixTQUFQLENBQWlCSSxvQkFBakIsQ0FBc0NGLElBQXRDLENBQTJDOUUsQ0FBM0MsRUFBOEMxbUIsQ0FBQyxDQUFDb21CLENBQUQsQ0FBL0MsQ0FBM0IsRUFDSWlGLENBQUMsQ0FBQ3JyQixDQUFDLENBQUNvbUIsQ0FBRCxDQUFGLENBQUQsR0FBVU0sQ0FBQyxDQUFDMW1CLENBQUMsQ0FBQ29tQixDQUFELENBQUYsQ0FBWDtBQUNQO0FBQ0wsU0FBT2lGLENBQVA7QUFDSCxDQVZEOztBQVdBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTTBDLHNCQUFzQixHQUFJTCxFQUFELElBQVE7QUFDMUMsTUFBSTtBQUFFcnRCLElBQUFBLFFBQUY7QUFBWW1MLElBQUFBLFFBQVo7QUFBc0JsSyxJQUFBQTtBQUF0QixNQUFrQ29zQixFQUF0QztBQUFBLE1BQTBDeDNCLEtBQUssR0FBR2sxQixNQUFNLENBQUNzQyxFQUFELEVBQUssQ0FBQyxVQUFELEVBQWEsVUFBYixFQUF5QixTQUF6QixDQUFMLENBQXhEOztBQUNBLFFBQU07QUFBRXAzQixJQUFBQSxNQUFGO0FBQVVrVyxJQUFBQSxVQUFWO0FBQXNCd2hCLElBQUFBO0FBQXRCLE1BQXdDbDRCLHVFQUFTLEVBQXZEO0FBQ0EsUUFBTWc0QixXQUFXLEdBQUc3c0Isa0RBQVcsQ0FBRXJELEtBQUQsSUFBVztBQUN2QyxRQUFJMEQsT0FBSixFQUNJQSxPQUFPLENBQUMxRCxLQUFELENBQVAsQ0FGbUMsQ0FHdkM7O0FBQ0EsUUFBSSxDQUFDQSxLQUFLLENBQUMyRCxnQkFBWCxFQUNJaUwsVUFBVSxHQUFHalAsS0FBYixDQUFtQixNQUFNLENBQUcsQ0FBNUI7QUFDUCxHQU44QixFQU01QixDQUFDK0QsT0FBRCxFQUFVa0wsVUFBVixDQU40QixDQUEvQjtBQU9BLFFBQU1yRSxPQUFPLEdBQUd2Uyw4Q0FBTyxDQUFDLE1BQU07QUFDMUIsUUFBSXlLLFFBQUosRUFDSSxPQUFPQSxRQUFQO0FBQ0osUUFBSTJ0QixhQUFKLEVBQ0ksT0FBTyxtQkFBUDtBQUNKLFFBQUkxM0IsTUFBSixFQUNJLE9BQU8sWUFBUDtBQUNKLFdBQU8sbUJBQVA7QUFDSCxHQVJzQixFQVFwQixDQUFDK0osUUFBRCxFQUFXMnRCLGFBQVgsRUFBMEIxM0IsTUFBMUIsQ0FSb0IsQ0FBdkI7QUFTQSxzQkFBUWdCLDBEQUFBLENBQW9CeTBCLDJDQUFwQixFQUE0QjN2QixNQUFNLENBQUMrTSxNQUFQLENBQWM7QUFBRWdqQixJQUFBQSxTQUFTLEVBQUUsK0JBQWI7QUFBOEMzZ0IsSUFBQUEsUUFBUSxFQUFFQSxRQUFRLElBQUksQ0FBQ2xWLE1BQXJFO0FBQTZFNDFCLElBQUFBLFNBQVMsRUFBRTUxQixNQUFNLGdCQUFHZ0IsMERBQUEsQ0FBb0JrMkIsbURBQXBCLEVBQWdDO0FBQUVsM0IsTUFBQUEsTUFBTSxFQUFFQTtBQUFWLEtBQWhDLENBQUgsR0FBeUR1VixTQUF2SjtBQUFrS3ZLLElBQUFBLE9BQU8sRUFBRXdzQjtBQUEzSyxHQUFkLEVBQXdNNTNCLEtBQXhNLENBQTVCLEVBQTRPaVMsT0FBNU8sQ0FBUjtBQUNILENBcEJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQ2ZQLElBQUlpakIsTUFBTSxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLE1BQWQsSUFBeUIsVUFBVTFFLENBQVYsRUFBYXBvQixDQUFiLEVBQWdCO0FBQ2xELE1BQUkrc0IsQ0FBQyxHQUFHLEVBQVI7O0FBQ0EsT0FBSyxJQUFJcnJCLENBQVQsSUFBYzBtQixDQUFkLEVBQWlCLElBQUl0cUIsTUFBTSxDQUFDa3ZCLFNBQVAsQ0FBaUJDLGNBQWpCLENBQWdDQyxJQUFoQyxDQUFxQzlFLENBQXJDLEVBQXdDMW1CLENBQXhDLEtBQThDMUIsQ0FBQyxDQUFDTSxPQUFGLENBQVVvQixDQUFWLElBQWUsQ0FBakUsRUFDYnFyQixDQUFDLENBQUNyckIsQ0FBRCxDQUFELEdBQU8wbUIsQ0FBQyxDQUFDMW1CLENBQUQsQ0FBUjs7QUFDSixNQUFJMG1CLENBQUMsSUFBSSxJQUFMLElBQWEsT0FBT3RxQixNQUFNLENBQUNxdkIscUJBQWQsS0FBd0MsVUFBekQsRUFDSSxLQUFLLElBQUlyRixDQUFDLEdBQUcsQ0FBUixFQUFXcG1CLENBQUMsR0FBRzVELE1BQU0sQ0FBQ3F2QixxQkFBUCxDQUE2Qi9FLENBQTdCLENBQXBCLEVBQXFETixDQUFDLEdBQUdwbUIsQ0FBQyxDQUFDcVAsTUFBM0QsRUFBbUUrVyxDQUFDLEVBQXBFLEVBQXdFO0FBQ3BFLFFBQUk5bkIsQ0FBQyxDQUFDTSxPQUFGLENBQVVvQixDQUFDLENBQUNvbUIsQ0FBRCxDQUFYLElBQWtCLENBQWxCLElBQXVCaHFCLE1BQU0sQ0FBQ2t2QixTQUFQLENBQWlCSSxvQkFBakIsQ0FBc0NGLElBQXRDLENBQTJDOUUsQ0FBM0MsRUFBOEMxbUIsQ0FBQyxDQUFDb21CLENBQUQsQ0FBL0MsQ0FBM0IsRUFDSWlGLENBQUMsQ0FBQ3JyQixDQUFDLENBQUNvbUIsQ0FBRCxDQUFGLENBQUQsR0FBVU0sQ0FBQyxDQUFDMW1CLENBQUMsQ0FBQ29tQixDQUFELENBQUYsQ0FBWDtBQUNQO0FBQ0wsU0FBT2lGLENBQVA7QUFDSCxDQVZEOztBQVdBO0FBQ08sTUFBTW1DLFVBQVUsR0FBSUUsRUFBRCxJQUFRO0FBQzlCLE1BQUk7QUFBRXAzQixJQUFBQTtBQUFGLE1BQWFvM0IsRUFBakI7QUFBQSxNQUFxQngzQixLQUFLLEdBQUdrMUIsTUFBTSxDQUFDc0MsRUFBRCxFQUFLLENBQUMsUUFBRCxDQUFMLENBQW5DOztBQUNBLFNBQU9wM0IsTUFBTSxpQkFBSWdCLDBEQUFBLENBQW9CLEtBQXBCLEVBQTJCOEUsTUFBTSxDQUFDK00sTUFBUCxDQUFjO0FBQUVoRCxJQUFBQSxHQUFHLEVBQUU3UCxNQUFNLENBQUMyM0IsSUFBZDtBQUFvQkMsSUFBQUEsR0FBRyxFQUFHLEdBQUU1M0IsTUFBTSxDQUFDNEIsSUFBSztBQUF4QyxHQUFkLEVBQWdFaEMsS0FBaEUsQ0FBM0IsQ0FBakI7QUFDSCxDQUhNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWlA7QUFDQTtBQUNBO0FBQ08sTUFBTWk0QixjQUFjLEdBQUcsQ0FBQztBQUFFTCxFQUFBQSxXQUFGO0FBQWV6QixFQUFBQSxRQUFmO0FBQXlCLzFCLEVBQUFBO0FBQXpCLENBQUQsS0FBdUM7QUFDakUsc0JBQVFnQiwwREFBQSxDQUFvQixJQUFwQixFQUEwQixJQUExQixlQUNKQSwwREFBQSxDQUFvQnkwQiwyQ0FBcEIsRUFBNEI7QUFBRXpxQixJQUFBQSxPQUFPLEVBQUV3c0IsV0FBWDtBQUF3QjdCLElBQUFBLE9BQU8sZUFBRTMwQiwwREFBQSxDQUFvQmsyQixtREFBcEIsRUFBZ0M7QUFBRWwzQixNQUFBQSxNQUFNLEVBQUVBO0FBQVYsS0FBaEMsQ0FBakM7QUFBc0YrMUIsSUFBQUEsUUFBUSxFQUFFQTtBQUFoRyxHQUE1QixFQUF3SS8xQixNQUFNLENBQUM0QixJQUEvSSxDQURJLENBQVI7QUFFSCxDQUhNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1vMkIsV0FBVyxHQUFHLENBQUM7QUFBRW5DLEVBQUFBLFNBQVMsR0FBRyxFQUFkO0FBQWtCb0MsRUFBQUEsSUFBbEI7QUFBd0JDLEVBQUFBLGVBQWUsR0FBRyxDQUExQztBQUE2Q0MsRUFBQUEsU0FBUyxHQUFHO0FBQXpELENBQUQsS0FBd0U7QUFDL0YsUUFBTTl0QixHQUFHLEdBQUdkLDZDQUFNLENBQUMsSUFBRCxDQUFsQjtBQUNBLFFBQU07QUFBRTZ1QixJQUFBQSxPQUFGO0FBQVdDLElBQUFBO0FBQVgsTUFBc0I3NEIsdUVBQVMsRUFBckM7QUFDQSxRQUFNO0FBQUU4VixJQUFBQTtBQUFGLE1BQWlCeWlCLCtEQUFjLEVBQXJDO0FBQ0EsUUFBTTtBQUFBLE9BQUM3QixRQUFEO0FBQUEsT0FBV29DO0FBQVgsTUFBMEJwekIsK0NBQVEsQ0FBQyxLQUFELENBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUNxekIsTUFBRDtBQUFBLE9BQVNDO0FBQVQsTUFBc0J0ekIsK0NBQVEsQ0FBQyxLQUFELENBQXBDO0FBQ0EsUUFBTTtBQUFBLE9BQUN1ekIsTUFBRDtBQUFBLE9BQVNDO0FBQVQsTUFBc0J4ekIsK0NBQVEsQ0FBQyxJQUFELENBQXBDO0FBQ0EsUUFBTTtBQUFBLE9BQUN5ekIsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBbUJ0NUIsOENBQU8sQ0FBQyxNQUFNLENBQUM4NEIsT0FBTyxDQUFDbHNCLEtBQVIsQ0FBYyxDQUFkLEVBQWlCZ3NCLGVBQWpCLENBQUQsRUFBb0NFLE9BQU8sQ0FBQ2xzQixLQUFSLENBQWNnc0IsZUFBZCxDQUFwQyxDQUFQLEVBQTRFLENBQUNFLE9BQUQsRUFBVUYsZUFBVixDQUE1RSxDQUFoQztBQUNBLFFBQU1XLFNBQVMsR0FBR2x1QixrREFBVyxDQUFDLE1BQU07QUFDaEM2dEIsSUFBQUEsU0FBUyxDQUFDLEtBQUQsQ0FBVDtBQUNBMXJCLElBQUFBLFVBQVUsQ0FBQyxNQUFNd0ksVUFBVSxDQUFDLEtBQUQsQ0FBakIsRUFBMEIsR0FBMUIsQ0FBVjtBQUNILEdBSDRCLEVBRzFCLENBQUNrakIsU0FBRCxFQUFZbGpCLFVBQVosQ0FIMEIsQ0FBN0I7QUFJQSxRQUFNd2pCLFdBQVcsR0FBR251QixrREFBVyxDQUFFckQsS0FBRCxJQUFXO0FBQ3ZDQSxJQUFBQSxLQUFLLENBQUNlLGNBQU47QUFDQXd3QixJQUFBQSxTQUFTO0FBQ1osR0FIOEIsRUFHNUIsQ0FBQ0EsU0FBRCxDQUg0QixDQUEvQjtBQUlBLFFBQU1FLGlCQUFpQixHQUFHcHVCLGtEQUFXLENBQUMsQ0FBQ3JELEtBQUQsRUFBUTB4QixVQUFSLEtBQXVCO0FBQ3pEWCxJQUFBQSxNQUFNLENBQUNXLFVBQUQsQ0FBTjtBQUNBRixJQUFBQSxXQUFXLENBQUN4eEIsS0FBRCxDQUFYO0FBQ0gsR0FIb0MsRUFHbEMsQ0FBQyt3QixNQUFELEVBQVNTLFdBQVQsQ0FIa0MsQ0FBckM7QUFJQSxRQUFNRyxtQkFBbUIsR0FBR3R1QixrREFBVyxDQUFDLE1BQU0ydEIsV0FBVyxDQUFDLENBQUNwQyxRQUFGLENBQWxCLEVBQStCLENBQUNvQyxXQUFELEVBQWNwQyxRQUFkLENBQS9CLENBQXZDO0FBQ0EsUUFBTWdELFlBQVksR0FBR3Z1QixrREFBVyxDQUFFckQsS0FBRCxJQUFXO0FBQ3hDLFVBQU1ndkIsSUFBSSxHQUFHanNCLEdBQUcsQ0FBQ2IsT0FBakI7QUFDQSxRQUFJLENBQUM4c0IsSUFBTCxFQUNJLE9BSG9DLENBSXhDOztBQUNBLFVBQU02QyxpQkFBaUIsR0FBRzdDLElBQUksQ0FBQzhDLGdCQUFMLENBQXNCLFFBQXRCLENBQTFCO0FBQ0EsVUFBTUMsWUFBWSxHQUFHRixpQkFBaUIsQ0FBQyxDQUFELENBQXRDO0FBQ0EsVUFBTUcsV0FBVyxHQUFHSCxpQkFBaUIsQ0FBQ0EsaUJBQWlCLENBQUNwZ0IsTUFBbEIsR0FBMkIsQ0FBNUIsQ0FBckM7O0FBQ0EsUUFBSXpSLEtBQUssQ0FBQ0ssUUFBVixFQUFvQjtBQUNoQjtBQUNBLFVBQUk4RyxRQUFRLENBQUM4cUIsYUFBVCxLQUEyQkYsWUFBL0IsRUFBNkM7QUFDekNDLFFBQUFBLFdBQVcsQ0FBQ0UsS0FBWjtBQUNBbHlCLFFBQUFBLEtBQUssQ0FBQ2UsY0FBTjtBQUNIO0FBQ0osS0FORCxNQU9LO0FBQ0Q7QUFDQSxVQUFJb0csUUFBUSxDQUFDOHFCLGFBQVQsS0FBMkJELFdBQS9CLEVBQTRDO0FBQ3hDRCxRQUFBQSxZQUFZLENBQUNHLEtBQWI7QUFDQWx5QixRQUFBQSxLQUFLLENBQUNlLGNBQU47QUFDSDtBQUNKO0FBQ0osR0F0QitCLEVBc0I3QixDQUFDZ0MsR0FBRCxDQXRCNkIsQ0FBaEM7QUF1QkEyckIsRUFBQUEsc0RBQWUsQ0FBQyxNQUFNO0FBQ2xCLFVBQU15RCxhQUFhLEdBQUlueUIsS0FBRCxJQUFXO0FBQzdCLFVBQUlBLEtBQUssQ0FBQ29CLEdBQU4sS0FBYyxRQUFsQixFQUE0QjtBQUN4Qm13QixRQUFBQSxTQUFTO0FBQ1osT0FGRCxNQUdLLElBQUl2eEIsS0FBSyxDQUFDb0IsR0FBTixLQUFjLEtBQWxCLEVBQXlCO0FBQzFCd3dCLFFBQUFBLFlBQVksQ0FBQzV4QixLQUFELENBQVo7QUFDSDtBQUNKLEtBUEQsQ0FEa0IsQ0FTbEI7OztBQUNBLFVBQU07QUFBRXN2QixNQUFBQTtBQUFGLFFBQWVucUIsTUFBTSxDQUFDaXRCLGdCQUFQLENBQXdCanJCLFFBQVEsQ0FBQ3VCLElBQWpDLENBQXJCLENBVmtCLENBV2xCOztBQUNBbEQsSUFBQUEsVUFBVSxDQUFDLE1BQU0wckIsU0FBUyxDQUFDLElBQUQsQ0FBaEIsRUFBd0IsQ0FBeEIsQ0FBVixDQVprQixDQWFsQjs7QUFDQS9wQixJQUFBQSxRQUFRLENBQUN1QixJQUFULENBQWM4bEIsS0FBZCxDQUFvQmMsUUFBcEIsR0FBK0IsUUFBL0IsQ0Fka0IsQ0FlbEI7O0FBQ0FucUIsSUFBQUEsTUFBTSxDQUFDK1UsZ0JBQVAsQ0FBd0IsU0FBeEIsRUFBbUNpWSxhQUFuQyxFQUFrRCxLQUFsRDtBQUNBLFdBQU8sTUFBTTtBQUNUO0FBQ0FockIsTUFBQUEsUUFBUSxDQUFDdUIsSUFBVCxDQUFjOGxCLEtBQWQsQ0FBb0JjLFFBQXBCLEdBQStCQSxRQUEvQjtBQUNBbnFCLE1BQUFBLE1BQU0sQ0FBQ3VxQixtQkFBUCxDQUEyQixTQUEzQixFQUFzQ3lDLGFBQXRDLEVBQXFELEtBQXJEO0FBQ0gsS0FKRDtBQUtILEdBdEJjLEVBc0JaLENBQUNaLFNBQUQsRUFBWUssWUFBWixDQXRCWSxDQUFmO0FBdUJBbEQsRUFBQUEsc0RBQWUsQ0FBQyxNQUFNMEMsU0FBUyxDQUFDanFCLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QmlwQixTQUF2QixDQUFELENBQWhCLEVBQXFELENBQUNPLFNBQUQsRUFBWVAsU0FBWixDQUFyRCxDQUFmO0FBQ0EsU0FBUU0sTUFBTSxpQkFDVlgsdURBQVksZUFBQzkyQiwwREFBQSxDQUFvQixLQUFwQixFQUEyQjtBQUFFLHVCQUFtQiw0QkFBckI7QUFBbUQsa0JBQWMsTUFBakU7QUFBeUU2MEIsSUFBQUEsU0FBUyxFQUFHLHdCQUF1QjBDLE1BQU0sSUFBSSw4QkFBK0IsSUFBRzFDLFNBQVUsRUFBbEs7QUFBcUt4ckIsSUFBQUEsR0FBRyxFQUFFQSxHQUExSztBQUErSzRzQixJQUFBQSxJQUFJLEVBQUU7QUFBckwsR0FBM0IsZUFDVGoyQiwwREFBQSxDQUFvQixLQUFwQixFQUEyQjtBQUFFNjBCLElBQUFBLFNBQVMsRUFBRTtBQUFiLEdBQTNCLGVBQ0k3MEIsMERBQUEsQ0FBb0IsS0FBcEIsRUFBMkI7QUFBRTYwQixJQUFBQSxTQUFTLEVBQUcsZ0NBQStCLENBQUNvQyxJQUFELElBQVMsc0NBQXVDO0FBQTdGLEdBQTNCLEVBQ0lBLElBQUksaUJBQUtqM0IsMERBQUEsQ0FBb0IsS0FBcEIsRUFBMkI7QUFBRTYwQixJQUFBQSxTQUFTLEVBQUU7QUFBYixHQUEzQixFQUErRSxPQUFPb0MsSUFBUCxLQUFnQixRQUFoQixnQkFBNEJqM0IsMERBQUEsQ0FBb0IsS0FBcEIsRUFBMkI7QUFBRTQyQixJQUFBQSxHQUFHLEVBQUUsTUFBUDtBQUFlL0IsSUFBQUEsU0FBUyxFQUFFLDJCQUExQjtBQUF1RGhtQixJQUFBQSxHQUFHLEVBQUVvb0I7QUFBNUQsR0FBM0IsQ0FBNUIsR0FBK0hBLElBQTlNLENBRGIsZUFFSWozQiwwREFBQSxDQUFvQixJQUFwQixFQUEwQjtBQUFFNjBCLElBQUFBLFNBQVMsRUFBRSw0QkFBYjtBQUEyQzFvQixJQUFBQSxFQUFFLEVBQUU7QUFBL0MsR0FBMUIsRUFBeUcsZ0JBQXpHLENBRkosZUFHSW5NLDBEQUFBLENBQW9CLFFBQXBCLEVBQThCO0FBQUVnSyxJQUFBQSxPQUFPLEVBQUU4dEIsV0FBWDtBQUF3QmpELElBQUFBLFNBQVMsRUFBRTtBQUFuQyxHQUE5QixlQUNJNzBCLDBEQUFBLENBQW9CLEtBQXBCLEVBQTJCO0FBQUU4RCxJQUFBQSxLQUFLLEVBQUUsSUFBVDtBQUFlMHhCLElBQUFBLE1BQU0sRUFBRTtBQUF2QixHQUEzQixlQUNJeDFCLDBEQUFBLENBQW9CLE1BQXBCLEVBQTRCO0FBQUUyNEIsSUFBQUEsQ0FBQyxFQUFFO0FBQUwsR0FBNUIsQ0FESixDQURKLENBSEosZUFNSTM0QiwwREFBQSxDQUFvQixJQUFwQixFQUEwQjtBQUFFNjBCLElBQUFBLFNBQVMsRUFBRTtBQUFiLEdBQTFCLEVBQXNFOEMsUUFBUSxDQUFDL3pCLEdBQVQsQ0FBYzVFLE1BQUQsaUJBQWFnQiwwREFBQSxDQUFvQjYyQiwyREFBcEIsRUFBb0M7QUFBRW52QixJQUFBQSxHQUFHLEVBQUUxSSxNQUFNLENBQUM0QixJQUFkO0FBQW9CNDFCLElBQUFBLFdBQVcsRUFBR2x3QixLQUFELElBQVd5eEIsaUJBQWlCLENBQUN6eEIsS0FBRCxFQUFRdEgsTUFBTSxDQUFDNEIsSUFBZixDQUE3RDtBQUFtRjVCLElBQUFBLE1BQU0sRUFBRUE7QUFBM0YsR0FBcEMsQ0FBMUIsQ0FBdEUsQ0FOSixFQU9JNDRCLElBQUksQ0FBQzdmLE1BQUwsZ0JBQWUvWCwwREFBQSxDQUFvQkEsdURBQXBCLEVBQW9DLElBQXBDLGVBQ1hBLDBEQUFBLENBQW9CaTFCLCtDQUFwQixFQUE4QjtBQUFFQyxJQUFBQSxRQUFRLEVBQUVBLFFBQVo7QUFBc0Ivb0IsSUFBQUEsRUFBRSxFQUFFO0FBQTFCLEdBQTlCLGVBQ0luTSwwREFBQSxDQUFvQixJQUFwQixFQUEwQjtBQUFFNjBCLElBQUFBLFNBQVMsRUFBRTtBQUFiLEdBQTFCLEVBQXNFK0MsSUFBSSxDQUFDaDBCLEdBQUwsQ0FBVTVFLE1BQUQsaUJBQWFnQiwwREFBQSxDQUFvQjYyQiwyREFBcEIsRUFBb0M7QUFBRW52QixJQUFBQSxHQUFHLEVBQUUxSSxNQUFNLENBQUM0QixJQUFkO0FBQW9CNDFCLElBQUFBLFdBQVcsRUFBR2x3QixLQUFELElBQVd5eEIsaUJBQWlCLENBQUN6eEIsS0FBRCxFQUFRdEgsTUFBTSxDQUFDNEIsSUFBZixDQUE3RDtBQUFtRm0wQixJQUFBQSxRQUFRLEVBQUVHLFFBQVEsR0FBRyxDQUFILEdBQU8sQ0FBQyxDQUE3RztBQUFnSGwyQixJQUFBQSxNQUFNLEVBQUVBO0FBQXhILEdBQXBDLENBQXRCLENBQXRFLENBREosQ0FEVyxlQUdYZ0IsMERBQUEsQ0FBb0J5MEIsMkNBQXBCLEVBQTRCO0FBQUUscUJBQWlCLCtCQUFuQjtBQUFvRCxxQkFBaUJTLFFBQXJFO0FBQStFTCxJQUFBQSxTQUFTLEVBQUcsd0NBQXVDSyxRQUFRLElBQUksNkNBQThDLEVBQTVMO0FBQStMUCxJQUFBQSxPQUFPLGVBQUUzMEIsMERBQUEsQ0FBb0IsS0FBcEIsRUFBMkI7QUFBRThELE1BQUFBLEtBQUssRUFBRSxJQUFUO0FBQWUweEIsTUFBQUEsTUFBTSxFQUFFLEdBQXZCO0FBQTRCcUQsTUFBQUEsS0FBSyxFQUFFO0FBQW5DLEtBQTNCLGVBQzVONzRCLDBEQUFBLENBQW9CLE1BQXBCLEVBQTRCO0FBQUUyNEIsTUFBQUEsQ0FBQyxFQUFFO0FBQUwsS0FBNUIsQ0FENE4sQ0FBeE07QUFDcU0zdUIsSUFBQUEsT0FBTyxFQUFFaXVCO0FBRDlNLEdBQTVCLEVBRUkvQyxRQUFRLEdBQUcsTUFBSCxHQUFZLE1BRnhCLEVBR0ksVUFISixDQUhXLENBQWYsR0FNd0IsSUFiNUIsQ0FESixDQURTLGVBZ0JUbDFCLDBEQUFBLENBQW9CLEtBQXBCLEVBQTJCO0FBQUU2MEIsSUFBQUEsU0FBUyxFQUFFLDhCQUFiO0FBQTZDaUUsSUFBQUEsV0FBVyxFQUFFaEI7QUFBMUQsR0FBM0IsQ0FoQlMsQ0FBRCxFQWdCOEZMLE1BaEI5RixDQURoQjtBQWtCSCxDQXRGTTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BQLElBQUkzRCxNQUFNLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsTUFBZCxJQUF5QixVQUFVMUUsQ0FBVixFQUFhcG9CLENBQWIsRUFBZ0I7QUFDbEQsTUFBSStzQixDQUFDLEdBQUcsRUFBUjs7QUFDQSxPQUFLLElBQUlyckIsQ0FBVCxJQUFjMG1CLENBQWQsRUFBaUIsSUFBSXRxQixNQUFNLENBQUNrdkIsU0FBUCxDQUFpQkMsY0FBakIsQ0FBZ0NDLElBQWhDLENBQXFDOUUsQ0FBckMsRUFBd0MxbUIsQ0FBeEMsS0FBOEMxQixDQUFDLENBQUNNLE9BQUYsQ0FBVW9CLENBQVYsSUFBZSxDQUFqRSxFQUNicXJCLENBQUMsQ0FBQ3JyQixDQUFELENBQUQsR0FBTzBtQixDQUFDLENBQUMxbUIsQ0FBRCxDQUFSOztBQUNKLE1BQUkwbUIsQ0FBQyxJQUFJLElBQUwsSUFBYSxPQUFPdHFCLE1BQU0sQ0FBQ3F2QixxQkFBZCxLQUF3QyxVQUF6RCxFQUNJLEtBQUssSUFBSXJGLENBQUMsR0FBRyxDQUFSLEVBQVdwbUIsQ0FBQyxHQUFHNUQsTUFBTSxDQUFDcXZCLHFCQUFQLENBQTZCL0UsQ0FBN0IsQ0FBcEIsRUFBcUROLENBQUMsR0FBR3BtQixDQUFDLENBQUNxUCxNQUEzRCxFQUFtRStXLENBQUMsRUFBcEUsRUFBd0U7QUFDcEUsUUFBSTluQixDQUFDLENBQUNNLE9BQUYsQ0FBVW9CLENBQUMsQ0FBQ29tQixDQUFELENBQVgsSUFBa0IsQ0FBbEIsSUFBdUJocUIsTUFBTSxDQUFDa3ZCLFNBQVAsQ0FBaUJJLG9CQUFqQixDQUFzQ0YsSUFBdEMsQ0FBMkM5RSxDQUEzQyxFQUE4QzFtQixDQUFDLENBQUNvbUIsQ0FBRCxDQUEvQyxDQUEzQixFQUNJaUYsQ0FBQyxDQUFDcnJCLENBQUMsQ0FBQ29tQixDQUFELENBQUYsQ0FBRCxHQUFVTSxDQUFDLENBQUMxbUIsQ0FBQyxDQUFDb21CLENBQUQsQ0FBRixDQUFYO0FBQ1A7QUFDTCxTQUFPaUYsQ0FBUDtBQUNILENBVkQ7O0FBV0E7QUFDQTtBQUNBO0FBQ08sTUFBTWdGLGlCQUFpQixHQUFJM0MsRUFBRCxJQUFRO0FBQ3JDLE1BQUk7QUFBRXJ0QixJQUFBQSxRQUFRLEdBQUcsZUFBYjtBQUE4QmlCLElBQUFBO0FBQTlCLE1BQTBDb3NCLEVBQTlDO0FBQUEsTUFBa0R4M0IsS0FBSyxHQUFHazFCLE1BQU0sQ0FBQ3NDLEVBQUQsRUFBSyxDQUFDLFVBQUQsRUFBYSxTQUFiLENBQUwsQ0FBaEU7O0FBQ0EsUUFBTTtBQUFFL2hCLElBQUFBLE9BQUY7QUFBV0MsSUFBQUE7QUFBWCxNQUEwQnlpQiwrREFBYyxFQUE5QztBQUNBLFFBQU1QLFdBQVcsR0FBRzdzQixrREFBVyxDQUFFckQsS0FBRCxJQUFXO0FBQ3ZDLFFBQUkwRCxPQUFKLEVBQ0lBLE9BQU8sQ0FBQzFELEtBQUQsQ0FBUDtBQUNKLFFBQUksQ0FBQ0EsS0FBSyxDQUFDMkQsZ0JBQVgsRUFDSXFLLFVBQVUsQ0FBQyxDQUFDRCxPQUFGLENBQVY7QUFDUCxHQUw4QixFQUs1QixDQUFDckssT0FBRCxFQUFVc0ssVUFBVixFQUFzQkQsT0FBdEIsQ0FMNEIsQ0FBL0I7QUFNQSxzQkFBUXJVLDBEQUFBLENBQW9CeTBCLDJDQUFwQixFQUE0QjN2QixNQUFNLENBQUMrTSxNQUFQLENBQWM7QUFBRWdqQixJQUFBQSxTQUFTLEVBQUUsK0JBQWI7QUFBOEM3cUIsSUFBQUEsT0FBTyxFQUFFd3NCO0FBQXZELEdBQWQsRUFBb0Y1M0IsS0FBcEYsQ0FBNUIsRUFBd0htSyxRQUF4SCxDQUFSO0FBQ0gsQ0FWTTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2RQLElBQUkrcUIsTUFBTSxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLE1BQWQsSUFBeUIsVUFBVTFFLENBQVYsRUFBYXBvQixDQUFiLEVBQWdCO0FBQ2xELE1BQUkrc0IsQ0FBQyxHQUFHLEVBQVI7O0FBQ0EsT0FBSyxJQUFJcnJCLENBQVQsSUFBYzBtQixDQUFkLEVBQWlCLElBQUl0cUIsTUFBTSxDQUFDa3ZCLFNBQVAsQ0FBaUJDLGNBQWpCLENBQWdDQyxJQUFoQyxDQUFxQzlFLENBQXJDLEVBQXdDMW1CLENBQXhDLEtBQThDMUIsQ0FBQyxDQUFDTSxPQUFGLENBQVVvQixDQUFWLElBQWUsQ0FBakUsRUFDYnFyQixDQUFDLENBQUNyckIsQ0FBRCxDQUFELEdBQU8wbUIsQ0FBQyxDQUFDMW1CLENBQUQsQ0FBUjs7QUFDSixNQUFJMG1CLENBQUMsSUFBSSxJQUFMLElBQWEsT0FBT3RxQixNQUFNLENBQUNxdkIscUJBQWQsS0FBd0MsVUFBekQsRUFDSSxLQUFLLElBQUlyRixDQUFDLEdBQUcsQ0FBUixFQUFXcG1CLENBQUMsR0FBRzVELE1BQU0sQ0FBQ3F2QixxQkFBUCxDQUE2Qi9FLENBQTdCLENBQXBCLEVBQXFETixDQUFDLEdBQUdwbUIsQ0FBQyxDQUFDcVAsTUFBM0QsRUFBbUUrVyxDQUFDLEVBQXBFLEVBQXdFO0FBQ3BFLFFBQUk5bkIsQ0FBQyxDQUFDTSxPQUFGLENBQVVvQixDQUFDLENBQUNvbUIsQ0FBRCxDQUFYLElBQWtCLENBQWxCLElBQXVCaHFCLE1BQU0sQ0FBQ2t2QixTQUFQLENBQWlCSSxvQkFBakIsQ0FBc0NGLElBQXRDLENBQTJDOUUsQ0FBM0MsRUFBOEMxbUIsQ0FBQyxDQUFDb21CLENBQUQsQ0FBL0MsQ0FBM0IsRUFDSWlGLENBQUMsQ0FBQ3JyQixDQUFDLENBQUNvbUIsQ0FBRCxDQUFGLENBQUQsR0FBVU0sQ0FBQyxDQUFDMW1CLENBQUMsQ0FBQ29tQixDQUFELENBQUYsQ0FBWDtBQUNQO0FBQ0wsU0FBT2lGLENBQVA7QUFDSCxDQVZEOztBQVdBO0FBQ0E7QUFDQTtBQUNPLE1BQU1rRixtQkFBbUIsR0FBSTdDLEVBQUQsSUFBUTtBQUN2QyxNQUFJO0FBQUVydEIsSUFBQUE7QUFBRixNQUFlcXRCLEVBQW5CO0FBQUEsTUFBdUJ4M0IsS0FBSyxHQUFHazFCLE1BQU0sQ0FBQ3NDLEVBQUQsRUFBSyxDQUFDLFVBQUQsQ0FBTCxDQUFyQzs7QUFDQSxRQUFNO0FBQUEsT0FBQy9oQixPQUFEO0FBQUEsT0FBVUM7QUFBVixNQUF3QnBRLCtDQUFRLENBQUMsS0FBRCxDQUF0QztBQUNBLHNCQUFRbEUsMERBQUEsQ0FBb0JnNUIsd0VBQXBCLEVBQWlEO0FBQUVsM0IsSUFBQUEsS0FBSyxFQUFFO0FBQzFEdVMsTUFBQUEsT0FEMEQ7QUFFMURDLE1BQUFBO0FBRjBEO0FBQVQsR0FBakQsRUFJSnZMLFFBSkksRUFLSnNMLE9BQU8saUJBQUlyVSwwREFBQSxDQUFvQmczQixxREFBcEIsRUFBaUNseUIsTUFBTSxDQUFDK00sTUFBUCxDQUFjLEVBQWQsRUFBa0JqVCxLQUFsQixDQUFqQyxDQUxQLENBQVI7QUFNSCxDQVRNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2RQLElBQUlrMEIsU0FBUyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFNBQWQsSUFBNEIsVUFBVUMsT0FBVixFQUFtQkMsVUFBbkIsRUFBK0JDLENBQS9CLEVBQWtDcG1CLFNBQWxDLEVBQTZDO0FBQ3JGLFdBQVNxbUIsS0FBVCxDQUFlcHhCLEtBQWYsRUFBc0I7QUFBRSxXQUFPQSxLQUFLLFlBQVlteEIsQ0FBakIsR0FBcUJueEIsS0FBckIsR0FBNkIsSUFBSW14QixDQUFKLENBQU0sVUFBVS9sQixPQUFWLEVBQW1CO0FBQUVBLE1BQUFBLE9BQU8sQ0FBQ3BMLEtBQUQsQ0FBUDtBQUFpQixLQUE1QyxDQUFwQztBQUFvRjs7QUFDNUcsU0FBTyxLQUFLbXhCLENBQUMsS0FBS0EsQ0FBQyxHQUFHaG1CLE9BQVQsQ0FBTixFQUF5QixVQUFVQyxPQUFWLEVBQW1CNkIsTUFBbkIsRUFBMkI7QUFDdkQsYUFBU29rQixTQUFULENBQW1CcnhCLEtBQW5CLEVBQTBCO0FBQUUsVUFBSTtBQUFFc3hCLFFBQUFBLElBQUksQ0FBQ3ZtQixTQUFTLENBQUMyVyxJQUFWLENBQWUxaEIsS0FBZixDQUFELENBQUo7QUFBOEIsT0FBcEMsQ0FBcUMsT0FBT2tGLENBQVAsRUFBVTtBQUFFK0gsUUFBQUEsTUFBTSxDQUFDL0gsQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDM0YsYUFBU3FzQixRQUFULENBQWtCdnhCLEtBQWxCLEVBQXlCO0FBQUUsVUFBSTtBQUFFc3hCLFFBQUFBLElBQUksQ0FBQ3ZtQixTQUFTLENBQUMsT0FBRCxDQUFULENBQW1CL0ssS0FBbkIsQ0FBRCxDQUFKO0FBQWtDLE9BQXhDLENBQXlDLE9BQU9rRixDQUFQLEVBQVU7QUFBRStILFFBQUFBLE1BQU0sQ0FBQy9ILENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzlGLGFBQVNvc0IsSUFBVCxDQUFjelosTUFBZCxFQUFzQjtBQUFFQSxNQUFBQSxNQUFNLENBQUNzTyxJQUFQLEdBQWMvYSxPQUFPLENBQUN5TSxNQUFNLENBQUM3WCxLQUFSLENBQXJCLEdBQXNDb3hCLEtBQUssQ0FBQ3ZaLE1BQU0sQ0FBQzdYLEtBQVIsQ0FBTCxDQUFvQndMLElBQXBCLENBQXlCNmxCLFNBQXpCLEVBQW9DRSxRQUFwQyxDQUF0QztBQUFzRjs7QUFDOUdELElBQUFBLElBQUksQ0FBQyxDQUFDdm1CLFNBQVMsR0FBR0EsU0FBUyxDQUFDeW1CLEtBQVYsQ0FBZ0JQLE9BQWhCLEVBQXlCQyxVQUFVLElBQUksRUFBdkMsQ0FBYixFQUF5RHhQLElBQXpELEVBQUQsQ0FBSjtBQUNILEdBTE0sQ0FBUDtBQU1ILENBUkQ7O0FBU0EsSUFBSXNRLE1BQU0sR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxNQUFkLElBQXlCLFVBQVUxRSxDQUFWLEVBQWFwb0IsQ0FBYixFQUFnQjtBQUNsRCxNQUFJK3NCLENBQUMsR0FBRyxFQUFSOztBQUNBLE9BQUssSUFBSXJyQixDQUFULElBQWMwbUIsQ0FBZCxFQUFpQixJQUFJdHFCLE1BQU0sQ0FBQ2t2QixTQUFQLENBQWlCQyxjQUFqQixDQUFnQ0MsSUFBaEMsQ0FBcUM5RSxDQUFyQyxFQUF3QzFtQixDQUF4QyxLQUE4QzFCLENBQUMsQ0FBQ00sT0FBRixDQUFVb0IsQ0FBVixJQUFlLENBQWpFLEVBQ2JxckIsQ0FBQyxDQUFDcnJCLENBQUQsQ0FBRCxHQUFPMG1CLENBQUMsQ0FBQzFtQixDQUFELENBQVI7O0FBQ0osTUFBSTBtQixDQUFDLElBQUksSUFBTCxJQUFhLE9BQU90cUIsTUFBTSxDQUFDcXZCLHFCQUFkLEtBQXdDLFVBQXpELEVBQ0ksS0FBSyxJQUFJckYsQ0FBQyxHQUFHLENBQVIsRUFBV3BtQixDQUFDLEdBQUc1RCxNQUFNLENBQUNxdkIscUJBQVAsQ0FBNkIvRSxDQUE3QixDQUFwQixFQUFxRE4sQ0FBQyxHQUFHcG1CLENBQUMsQ0FBQ3FQLE1BQTNELEVBQW1FK1csQ0FBQyxFQUFwRSxFQUF3RTtBQUNwRSxRQUFJOW5CLENBQUMsQ0FBQ00sT0FBRixDQUFVb0IsQ0FBQyxDQUFDb21CLENBQUQsQ0FBWCxJQUFrQixDQUFsQixJQUF1QmhxQixNQUFNLENBQUNrdkIsU0FBUCxDQUFpQkksb0JBQWpCLENBQXNDRixJQUF0QyxDQUEyQzlFLENBQTNDLEVBQThDMW1CLENBQUMsQ0FBQ29tQixDQUFELENBQS9DLENBQTNCLEVBQ0lpRixDQUFDLENBQUNyckIsQ0FBQyxDQUFDb21CLENBQUQsQ0FBRixDQUFELEdBQVVNLENBQUMsQ0FBQzFtQixDQUFDLENBQUNvbUIsQ0FBRCxDQUFGLENBQVg7QUFDUDtBQUNMLFNBQU9pRixDQUFQO0FBQ0gsQ0FWRDs7QUFXQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU10eUIsaUJBQWlCLEdBQUkyMEIsRUFBRCxJQUFRO0FBQ3JDLE1BQUk7QUFBRXJ0QixJQUFBQTtBQUFGLE1BQWVxdEIsRUFBbkI7QUFBQSxNQUF1QngzQixLQUFLLEdBQUdrMUIsTUFBTSxDQUFDc0MsRUFBRCxFQUFLLENBQUMsVUFBRCxDQUFMLENBQXJDOztBQUNBLFFBQU07QUFBRS8yQixJQUFBQSxTQUFGO0FBQWFMLElBQUFBLE1BQWI7QUFBcUJrVyxJQUFBQTtBQUFyQixNQUFvQzFXLHVFQUFTLEVBQW5EO0FBQ0EsUUFBTTtBQUFFOFYsSUFBQUE7QUFBRixNQUFpQnlpQiwrREFBYyxFQUFyQztBQUNBLFFBQU07QUFBQSxPQUFDbUMsTUFBRDtBQUFBLE9BQVNDO0FBQVQsTUFBc0JqMUIsK0NBQVEsQ0FBQyxLQUFELENBQXBDO0FBQ0EsUUFBTTtBQUFBLE9BQUNrMUIsTUFBRDtBQUFBLE9BQVNDO0FBQVQsTUFBc0JuMUIsK0NBQVEsQ0FBQyxLQUFELENBQXBDO0FBQ0EsUUFBTW1GLEdBQUcsR0FBR2QsNkNBQU0sQ0FBQyxJQUFELENBQWxCO0FBQ0EsUUFBTSt3QixNQUFNLEdBQUdoN0IsOENBQU8sQ0FBQyxNQUFNZSxTQUFTLEtBQUssSUFBZCxJQUFzQkEsU0FBUyxLQUFLLEtBQUssQ0FBekMsR0FBNkMsS0FBSyxDQUFsRCxHQUFzREEsU0FBUyxDQUFDazZCLFFBQVYsRUFBN0QsRUFBbUYsQ0FBQ2w2QixTQUFELENBQW5GLENBQXRCO0FBQ0EsUUFBTXdSLE9BQU8sR0FBR3ZTLDhDQUFPLENBQUMsTUFBTTtBQUMxQixRQUFJeUssUUFBSixFQUNJLE9BQU9BLFFBQVA7QUFDSixRQUFJLENBQUMvSixNQUFELElBQVcsQ0FBQ3M2QixNQUFoQixFQUNJLE9BQU8sSUFBUDtBQUNKLFdBQU9BLE1BQU0sQ0FBQ3B1QixLQUFQLENBQWEsQ0FBYixFQUFnQixDQUFoQixJQUFxQixJQUFyQixHQUE0Qm91QixNQUFNLENBQUNwdUIsS0FBUCxDQUFhLENBQUMsQ0FBZCxDQUFuQztBQUNILEdBTnNCLEVBTXBCLENBQUNuQyxRQUFELEVBQVcvSixNQUFYLEVBQW1CczZCLE1BQW5CLENBTm9CLENBQXZCO0FBT0EsUUFBTUUsV0FBVyxHQUFHN3ZCLGtEQUFXLENBQUMsTUFBTW1wQixTQUFTLENBQUMsS0FBSyxDQUFOLEVBQVMsS0FBSyxDQUFkLEVBQWlCLEtBQUssQ0FBdEIsRUFBeUIsYUFBYTtBQUNqRixRQUFJd0csTUFBSixFQUFZO0FBQ1IsWUFBTXZuQixTQUFTLENBQUMwbkIsU0FBVixDQUFvQkMsU0FBcEIsQ0FBOEJKLE1BQTlCLENBQU47QUFDQUgsTUFBQUEsU0FBUyxDQUFDLElBQUQsQ0FBVDtBQUNBcnRCLE1BQUFBLFVBQVUsQ0FBQyxNQUFNcXRCLFNBQVMsQ0FBQyxLQUFELENBQWhCLEVBQXlCLEdBQXpCLENBQVY7QUFDSDtBQUNKLEdBTjhDLENBQWhCLEVBTTNCLENBQUNHLE1BQUQsQ0FOMkIsQ0FBL0I7QUFPQSxRQUFNSyxZQUFZLEdBQUdod0Isa0RBQVcsQ0FBQyxNQUFNMHZCLFNBQVMsQ0FBQyxJQUFELENBQWhCLEVBQXdCLENBQUNBLFNBQUQsQ0FBeEIsQ0FBaEM7QUFDQSxRQUFNTyxhQUFhLEdBQUdqd0Isa0RBQVcsQ0FBQyxNQUFNMHZCLFNBQVMsQ0FBQyxLQUFELENBQWhCLEVBQXlCLENBQUNBLFNBQUQsQ0FBekIsQ0FBakM7QUFDQSxRQUFNUSxTQUFTLEdBQUdsd0Isa0RBQVcsQ0FBQyxNQUFNO0FBQ2hDMkssSUFBQUEsVUFBVSxDQUFDLElBQUQsQ0FBVjtBQUNBc2xCLElBQUFBLGFBQWE7QUFDaEIsR0FINEIsRUFHMUIsQ0FBQ3RsQixVQUFELEVBQWFzbEIsYUFBYixDQUgwQixDQUE3QjtBQUlBdjdCLEVBQUFBLGdEQUFTLENBQUMsTUFBTTtBQUNaLFVBQU15N0IsUUFBUSxHQUFJeHpCLEtBQUQsSUFBVztBQUN4QixZQUFNZ3ZCLElBQUksR0FBR2pzQixHQUFHLENBQUNiLE9BQWpCLENBRHdCLENBRXhCOztBQUNBLFVBQUksQ0FBQzhzQixJQUFELElBQVNBLElBQUksQ0FBQ3lFLFFBQUwsQ0FBY3p6QixLQUFLLENBQUNDLE1BQXBCLENBQWIsRUFDSTtBQUNKcXpCLE1BQUFBLGFBQWE7QUFDaEIsS0FORDs7QUFPQW5zQixJQUFBQSxRQUFRLENBQUMrUyxnQkFBVCxDQUEwQixXQUExQixFQUF1Q3NaLFFBQXZDO0FBQ0Fyc0IsSUFBQUEsUUFBUSxDQUFDK1MsZ0JBQVQsQ0FBMEIsWUFBMUIsRUFBd0NzWixRQUF4QztBQUNBLFdBQU8sTUFBTTtBQUNUcnNCLE1BQUFBLFFBQVEsQ0FBQ3VvQixtQkFBVCxDQUE2QixXQUE3QixFQUEwQzhELFFBQTFDO0FBQ0Fyc0IsTUFBQUEsUUFBUSxDQUFDdW9CLG1CQUFULENBQTZCLFlBQTdCLEVBQTJDOEQsUUFBM0M7QUFDSCxLQUhEO0FBSUgsR0FkUSxFQWNOLENBQUN6d0IsR0FBRCxFQUFNdXdCLGFBQU4sQ0FkTSxDQUFUO0FBZUEsTUFBSSxDQUFDNTZCLE1BQUwsRUFDSSxvQkFBT2dCLDBEQUFBLENBQW9CKzRCLGlFQUFwQixFQUF1Q2owQixNQUFNLENBQUMrTSxNQUFQLENBQWMsRUFBZCxFQUFrQmpULEtBQWxCLENBQXZDLEVBQWlFbUssUUFBakUsQ0FBUDtBQUNKLE1BQUksQ0FBQ3V3QixNQUFMLEVBQ0ksb0JBQU90NUIsMERBQUEsQ0FBb0JtMkIscUVBQXBCLEVBQXlDcnhCLE1BQU0sQ0FBQytNLE1BQVAsQ0FBYyxFQUFkLEVBQWtCalQsS0FBbEIsQ0FBekMsRUFBbUVtSyxRQUFuRSxDQUFQO0FBQ0osc0JBQVEvSSwwREFBQSxDQUFvQixLQUFwQixFQUEyQjtBQUFFNjBCLElBQUFBLFNBQVMsRUFBRTtBQUFiLEdBQTNCLGVBQ0o3MEIsMERBQUEsQ0FBb0J5MEIsMkNBQXBCLEVBQTRCM3ZCLE1BQU0sQ0FBQytNLE1BQVAsQ0FBYztBQUFFLHFCQUFpQnVuQixNQUFuQjtBQUEyQnZFLElBQUFBLFNBQVMsRUFBRSwrQkFBdEM7QUFBdUVDLElBQUFBLEtBQUssRUFBRWh3QixNQUFNLENBQUMrTSxNQUFQLENBQWM7QUFBRW1vQixNQUFBQSxhQUFhLEVBQUVaLE1BQU0sR0FBRyxNQUFILEdBQVk7QUFBbkMsS0FBZCxFQUEyRHg2QixLQUFLLENBQUNrMkIsS0FBakUsQ0FBOUU7QUFBdUo5cUIsSUFBQUEsT0FBTyxFQUFFMnZCLFlBQWhLO0FBQThLL0UsSUFBQUEsU0FBUyxlQUFFNTBCLDBEQUFBLENBQW9CazJCLG1EQUFwQixFQUFnQztBQUFFbDNCLE1BQUFBLE1BQU0sRUFBRUE7QUFBVixLQUFoQztBQUF6TCxHQUFkLEVBQThQSixLQUE5UCxDQUE1QixFQUFrU2lTLE9BQWxTLENBREksZUFFSjdRLDBEQUFBLENBQW9CLElBQXBCLEVBQTBCO0FBQUUsa0JBQWMsZUFBaEI7QUFBaUM2MEIsSUFBQUEsU0FBUyxFQUFHLGdDQUErQnVFLE1BQU0sSUFBSSxxQ0FBc0MsRUFBNUg7QUFBK0gvdkIsSUFBQUEsR0FBRyxFQUFFQSxHQUFwSTtBQUF5STRzQixJQUFBQSxJQUFJLEVBQUU7QUFBL0ksR0FBMUIsZUFDSWoyQiwwREFBQSxDQUFvQixJQUFwQixFQUEwQjtBQUFFZ0ssSUFBQUEsT0FBTyxFQUFFd3ZCLFdBQVg7QUFBd0IzRSxJQUFBQSxTQUFTLEVBQUUsbUNBQW5DO0FBQXdFb0IsSUFBQUEsSUFBSSxFQUFFO0FBQTlFLEdBQTFCLEVBQXNIaUQsTUFBTSxHQUFHLFFBQUgsR0FBYyxjQUExSSxDQURKLGVBRUlsNUIsMERBQUEsQ0FBb0IsSUFBcEIsRUFBMEI7QUFBRWdLLElBQUFBLE9BQU8sRUFBRTZ2QixTQUFYO0FBQXNCaEYsSUFBQUEsU0FBUyxFQUFFLG1DQUFqQztBQUFzRW9CLElBQUFBLElBQUksRUFBRTtBQUE1RSxHQUExQixFQUFvSCw0QkFBcEgsQ0FGSixlQUdJajJCLDBEQUFBLENBQW9CLElBQXBCLEVBQTBCO0FBQUVnSyxJQUFBQSxPQUFPLEVBQUVrTCxVQUFYO0FBQXVCMmYsSUFBQUEsU0FBUyxFQUFFLG1DQUFsQztBQUF1RW9CLElBQUFBLElBQUksRUFBRTtBQUE3RSxHQUExQixFQUFxSCxZQUFySCxDQUhKLENBRkksQ0FBUjtBQU1ILENBckRNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNCUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ05BO0FBQ08sTUFBTStDLGtCQUFrQixnQkFBR2lCLG9EQUFhLENBQUMsRUFBRCxDQUF4QztBQUNBLFNBQVNsRCxjQUFULEdBQTBCO0FBQzdCLFNBQU9yakIsaURBQVUsQ0FBQ3NsQixrQkFBRCxDQUFqQjtBQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0pEO0FBQ0E7QUFDQTtBQUNPLE1BQU1tQixrQkFBa0IsR0FBRyxDQUFDO0FBQUVweEIsRUFBQUEsUUFBRjtBQUFZcXhCLEVBQUFBLFFBQVo7QUFBc0IvTyxFQUFBQSxNQUFNLEdBQUc7QUFBRXRELElBQUFBLFVBQVUsRUFBRTtBQUFkO0FBQS9CLENBQUQsS0FBbUU7QUFDakcsUUFBTWxvQixVQUFVLEdBQUd2Qiw4Q0FBTyxDQUFDLE1BQU0sSUFBSW1HLHVEQUFKLENBQWUyMUIsUUFBZixFQUF5Qi9PLE1BQXpCLENBQVAsRUFBeUMsQ0FBQytPLFFBQUQsRUFBVy9PLE1BQVgsQ0FBekMsQ0FBMUI7QUFDQSxzQkFBT3JyQiwwREFBQSxDQUFvQms2QixzRUFBcEIsRUFBZ0Q7QUFBRXA0QixJQUFBQSxLQUFLLEVBQUU7QUFBRWpDLE1BQUFBO0FBQUY7QUFBVCxHQUFoRCxFQUEyRWtKLFFBQTNFLENBQVA7QUFDSCxDQUhNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIUCxJQUFJK3BCLFNBQVMsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxTQUFkLElBQTRCLFVBQVVDLE9BQVYsRUFBbUJDLFVBQW5CLEVBQStCQyxDQUEvQixFQUFrQ3BtQixTQUFsQyxFQUE2QztBQUNyRixXQUFTcW1CLEtBQVQsQ0FBZXB4QixLQUFmLEVBQXNCO0FBQUUsV0FBT0EsS0FBSyxZQUFZbXhCLENBQWpCLEdBQXFCbnhCLEtBQXJCLEdBQTZCLElBQUlteEIsQ0FBSixDQUFNLFVBQVUvbEIsT0FBVixFQUFtQjtBQUFFQSxNQUFBQSxPQUFPLENBQUNwTCxLQUFELENBQVA7QUFBaUIsS0FBNUMsQ0FBcEM7QUFBb0Y7O0FBQzVHLFNBQU8sS0FBS214QixDQUFDLEtBQUtBLENBQUMsR0FBR2htQixPQUFULENBQU4sRUFBeUIsVUFBVUMsT0FBVixFQUFtQjZCLE1BQW5CLEVBQTJCO0FBQ3ZELGFBQVNva0IsU0FBVCxDQUFtQnJ4QixLQUFuQixFQUEwQjtBQUFFLFVBQUk7QUFBRXN4QixRQUFBQSxJQUFJLENBQUN2bUIsU0FBUyxDQUFDMlcsSUFBVixDQUFlMWhCLEtBQWYsQ0FBRCxDQUFKO0FBQThCLE9BQXBDLENBQXFDLE9BQU9rRixDQUFQLEVBQVU7QUFBRStILFFBQUFBLE1BQU0sQ0FBQy9ILENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzNGLGFBQVNxc0IsUUFBVCxDQUFrQnZ4QixLQUFsQixFQUF5QjtBQUFFLFVBQUk7QUFBRXN4QixRQUFBQSxJQUFJLENBQUN2bUIsU0FBUyxDQUFDLE9BQUQsQ0FBVCxDQUFtQi9LLEtBQW5CLENBQUQsQ0FBSjtBQUFrQyxPQUF4QyxDQUF5QyxPQUFPa0YsQ0FBUCxFQUFVO0FBQUUrSCxRQUFBQSxNQUFNLENBQUMvSCxDQUFELENBQU47QUFBWTtBQUFFOztBQUM5RixhQUFTb3NCLElBQVQsQ0FBY3paLE1BQWQsRUFBc0I7QUFBRUEsTUFBQUEsTUFBTSxDQUFDc08sSUFBUCxHQUFjL2EsT0FBTyxDQUFDeU0sTUFBTSxDQUFDN1gsS0FBUixDQUFyQixHQUFzQ294QixLQUFLLENBQUN2WixNQUFNLENBQUM3WCxLQUFSLENBQUwsQ0FBb0J3TCxJQUFwQixDQUF5QjZsQixTQUF6QixFQUFvQ0UsUUFBcEMsQ0FBdEM7QUFBc0Y7O0FBQzlHRCxJQUFBQSxJQUFJLENBQUMsQ0FBQ3ZtQixTQUFTLEdBQUdBLFNBQVMsQ0FBQ3ltQixLQUFWLENBQWdCUCxPQUFoQixFQUF5QkMsVUFBVSxJQUFJLEVBQXZDLENBQWIsRUFBeUR4UCxJQUF6RCxFQUFELENBQUo7QUFDSCxHQUxNLENBQVA7QUFNSCxDQVJEOztBQVNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNZ1gsWUFBWSxHQUFHO0FBQ2pCeDdCLEVBQUFBLE1BQU0sRUFBRSxJQURTO0FBRWpCMjBCLEVBQUFBLE9BQU8sRUFBRSxJQUZRO0FBR2pCamhCLEVBQUFBLEtBQUssRUFBRSxLQUhVO0FBSWpCclQsRUFBQUEsU0FBUyxFQUFFLElBSk07QUFLakJrM0IsRUFBQUEsU0FBUyxFQUFFO0FBTE0sQ0FBckI7QUFPTyxNQUFNa0UsY0FBYyxHQUFHLENBQUM7QUFBRTF4QixFQUFBQSxRQUFGO0FBQVlxdUIsRUFBQUEsT0FBWjtBQUFxQnNELEVBQUFBLFdBQVcsR0FBRyxLQUFuQztBQUEwQ0MsRUFBQUEsT0FBTyxFQUFFQyxRQUFRLEdBQUl6cEIsS0FBRCxJQUFXM1IsT0FBTyxDQUFDMlIsS0FBUixDQUFjQSxLQUFkLENBQXpFO0FBQStGMHBCLEVBQUFBLGVBQWUsR0FBRztBQUFqSCxDQUFELEtBQXNJO0FBQ2hLLFFBQU0sQ0FBQ2o2QixJQUFELEVBQU9rNkIsT0FBUCxJQUFrQlIsaUVBQWUsQ0FBQ08sZUFBRCxFQUFrQixJQUFsQixDQUF2QztBQUNBLFFBQU07QUFBQSxPQUFDO0FBQUU3N0IsTUFBQUEsTUFBRjtBQUFVMjBCLE1BQUFBLE9BQVY7QUFBbUJqaEIsTUFBQUEsS0FBbkI7QUFBMEJyVCxNQUFBQSxTQUExQjtBQUFxQ2szQixNQUFBQTtBQUFyQyxLQUFEO0FBQUEsT0FBbUR3RTtBQUFuRCxNQUErRDcyQiwrQ0FBUSxDQUFDczJCLFlBQUQsQ0FBN0U7QUFDQSxRQUFNO0FBQUEsT0FBQ2xFLFVBQUQ7QUFBQSxPQUFhMEU7QUFBYixNQUE4QjkyQiwrQ0FBUSxDQUFDLEtBQUQsQ0FBNUM7QUFDQSxRQUFNO0FBQUEsT0FBQ3d5QixhQUFEO0FBQUEsT0FBZ0J1RTtBQUFoQixNQUFvQy8yQiwrQ0FBUSxDQUFDLEtBQUQsQ0FBbEQ7QUFDQSxRQUFNZzNCLFlBQVksR0FBRzN5Qiw2Q0FBTSxDQUFDLEtBQUQsQ0FBM0I7QUFDQSxRQUFNNHlCLGVBQWUsR0FBRzV5Qiw2Q0FBTSxDQUFDLEtBQUQsQ0FBOUI7QUFDQSxRQUFNNnlCLFdBQVcsR0FBRzd5Qiw2Q0FBTSxDQUFDLEtBQUQsQ0FBMUIsQ0FQZ0ssQ0FRaEs7O0FBQ0EsUUFBTTh5QixhQUFhLEdBQUcvOEIsOENBQU8sQ0FBQyxNQUFNODRCLE9BQU8sQ0FBQ2tFLE1BQVIsQ0FBZSxDQUFDRCxhQUFELEVBQWdCcjhCLE1BQWhCLEtBQTJCO0FBQzFFcThCLElBQUFBLGFBQWEsQ0FBQ3I4QixNQUFNLENBQUM0QixJQUFSLENBQWIsR0FBNkI1QixNQUE3QjtBQUNBLFdBQU9xOEIsYUFBUDtBQUNILEdBSG1DLEVBR2pDLEVBSGlDLENBQVAsRUFHckIsQ0FBQ2pFLE9BQUQsQ0FIcUIsQ0FBN0IsQ0FUZ0ssQ0FhaEs7O0FBQ0EvNEIsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ1osVUFBTVcsTUFBTSxHQUFJNEIsSUFBSSxJQUFJeTZCLGFBQWEsQ0FBQ3o2QixJQUFELENBQXRCLElBQWlDLElBQWhEO0FBQ0EsVUFBTSt5QixPQUFPLEdBQUczMEIsTUFBTSxJQUFJQSxNQUFNLENBQUMyMEIsT0FBUCxFQUExQjs7QUFDQSxRQUFJQSxPQUFKLEVBQWE7QUFDVCxZQUFNO0FBQUVqaEIsUUFBQUEsS0FBRjtBQUFTclQsUUFBQUEsU0FBVDtBQUFvQmszQixRQUFBQTtBQUFwQixVQUFrQzVDLE9BQXhDO0FBQ0FvSCxNQUFBQSxRQUFRLENBQUM7QUFBRS83QixRQUFBQSxNQUFGO0FBQVUyMEIsUUFBQUEsT0FBVjtBQUFtQjRDLFFBQUFBLFNBQW5CO0FBQThCbDNCLFFBQUFBLFNBQTlCO0FBQXlDcVQsUUFBQUE7QUFBekMsT0FBRCxDQUFSO0FBQ0gsS0FIRCxNQUlLO0FBQ0Rxb0IsTUFBQUEsUUFBUSxDQUFDUCxZQUFELENBQVI7QUFDSDtBQUNKLEdBVlEsRUFVTixDQUFDNTVCLElBQUQsRUFBT3k2QixhQUFQLEVBQXNCTixRQUF0QixDQVZNLENBQVQsQ0FkZ0ssQ0F5QmhLOztBQUNBMThCLEVBQUFBLGdEQUFTLENBQUMsTUFBTTtBQUNaLFFBQUk2OEIsWUFBWSxDQUFDMXlCLE9BQWIsSUFBd0I4dEIsVUFBeEIsSUFBc0NDLFNBQXRDLElBQW1ELENBQUNtRSxXQUFwRCxJQUFtRSxDQUFDL0csT0FBcEUsSUFBK0UsQ0FBQ2poQixLQUFwRixFQUNJOztBQUNKLEtBQUMsWUFBWTtBQUNULGFBQU9vZ0IsU0FBUyxDQUFDLElBQUQsRUFBTyxLQUFLLENBQVosRUFBZSxLQUFLLENBQXBCLEVBQXVCLGFBQWE7QUFDaERvSSxRQUFBQSxZQUFZLENBQUMxeUIsT0FBYixHQUF1QixJQUF2QjtBQUNBd3lCLFFBQUFBLGFBQWEsQ0FBQyxJQUFELENBQWI7O0FBQ0EsWUFBSTtBQUNBLGdCQUFNckgsT0FBTyxDQUFDMEMsT0FBUixFQUFOO0FBQ0gsU0FGRCxDQUdBLE9BQU9sbEIsS0FBUCxFQUFjO0FBQ1Y7QUFDQTJwQixVQUFBQSxPQUFPLENBQUMsSUFBRCxDQUFQLENBRlUsQ0FHVjtBQUNILFNBUEQsU0FRUTtBQUNKRSxVQUFBQSxhQUFhLENBQUMsS0FBRCxDQUFiO0FBQ0FFLFVBQUFBLFlBQVksQ0FBQzF5QixPQUFiLEdBQXVCLEtBQXZCO0FBQ0g7QUFDSixPQWZlLENBQWhCO0FBZ0JILEtBakJEO0FBa0JILEdBckJRLEVBcUJOLENBQUMweUIsWUFBRCxFQUFlNUUsVUFBZixFQUEyQkMsU0FBM0IsRUFBc0NtRSxXQUF0QyxFQUFtRC9HLE9BQW5ELEVBQTREamhCLEtBQTVELEVBQW1Fc29CLGFBQW5FLEVBQWtGRixPQUFsRixDQXJCTSxDQUFULENBMUJnSyxDQWdEaEs7O0FBQ0F6OEIsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ1osYUFBU3k3QixRQUFULEdBQW9CO0FBQ2hCc0IsTUFBQUEsV0FBVyxDQUFDNXlCLE9BQVosR0FBc0IsSUFBdEI7QUFDSDs7QUFDRGlELElBQUFBLE1BQU0sQ0FBQytVLGdCQUFQLENBQXdCLGNBQXhCLEVBQXdDc1osUUFBeEM7QUFDQSxXQUFPLE1BQU1ydUIsTUFBTSxDQUFDdXFCLG1CQUFQLENBQTJCLGNBQTNCLEVBQTJDOEQsUUFBM0MsQ0FBYjtBQUNILEdBTlEsRUFNTixDQUFDc0IsV0FBRCxDQU5NLENBQVQsQ0FqRGdLLENBd0RoSzs7QUFDQSxRQUFNL0QsTUFBTSxHQUFHMXRCLGtEQUFXLENBQUU0eEIsT0FBRCxJQUFhekksU0FBUyxDQUFDLEtBQUssQ0FBTixFQUFTLEtBQUssQ0FBZCxFQUFpQixLQUFLLENBQXRCLEVBQXlCLGFBQWE7QUFDbkYsUUFBSWx5QixJQUFJLEtBQUsyNkIsT0FBYixFQUNJO0FBQ0osUUFBSTVILE9BQUosRUFDSSxNQUFNQSxPQUFPLENBQUN6ZSxVQUFSLEVBQU47QUFDSjRsQixJQUFBQSxPQUFPLENBQUNTLE9BQUQsQ0FBUDtBQUNILEdBTmdELENBQXZCLEVBTXRCLENBQUMzNkIsSUFBRCxFQUFPK3lCLE9BQVAsRUFBZ0JtSCxPQUFoQixDQU5zQixDQUExQixDQXpEZ0ssQ0FnRWhLOztBQUNBLFFBQU1VLE9BQU8sR0FBRzd4QixrREFBVyxDQUFDLE1BQU1veEIsUUFBUSxDQUFFLzNCLEtBQUQsSUFBWThCLE1BQU0sQ0FBQytNLE1BQVAsQ0FBYy9NLE1BQU0sQ0FBQytNLE1BQVAsQ0FBYyxFQUFkLEVBQWtCN08sS0FBbEIsQ0FBZCxFQUF3QztBQUFFMFAsSUFBQUEsS0FBSyxFQUFFO0FBQVQsR0FBeEMsQ0FBYixDQUFmLEVBQXdGLENBQUNxb0IsUUFBRCxDQUF4RixDQUEzQixDQWpFZ0ssQ0FrRWhLOztBQUNBLFFBQU1VLFNBQVMsR0FBRzl4QixrREFBVyxDQUFDLE1BQU07QUFDaEMsUUFBSSxDQUFDZ3FCLE9BQUwsRUFDSTtBQUNKLFVBQU07QUFBRTRDLE1BQUFBLFNBQUY7QUFBYWwzQixNQUFBQSxTQUFiO0FBQXdCcVQsTUFBQUE7QUFBeEIsUUFBa0NpaEIsT0FBeEM7QUFDQW9ILElBQUFBLFFBQVEsQ0FBRS8zQixLQUFELElBQVk4QixNQUFNLENBQUMrTSxNQUFQLENBQWMvTSxNQUFNLENBQUMrTSxNQUFQLENBQWMsRUFBZCxFQUFrQjdPLEtBQWxCLENBQWQsRUFBd0M7QUFBRXV6QixNQUFBQSxTQUFGO0FBQ3pEbDNCLE1BQUFBLFNBRHlEO0FBRXpEcVQsTUFBQUE7QUFGeUQsS0FBeEMsQ0FBYixDQUFSO0FBR0gsR0FQNEIsRUFPMUIsQ0FBQ2loQixPQUFELEVBQVVvSCxRQUFWLENBUDBCLENBQTdCLENBbkVnSyxDQTJFaEs7O0FBQ0EsUUFBTVcsWUFBWSxHQUFHL3hCLGtEQUFXLENBQUMsTUFBTTtBQUNuQztBQUNBLFFBQUksQ0FBQ3l4QixXQUFXLENBQUM1eUIsT0FBakIsRUFDSXN5QixPQUFPLENBQUMsSUFBRCxDQUFQO0FBQ1AsR0FKK0IsRUFJN0IsQ0FBQ00sV0FBRCxFQUFjTixPQUFkLENBSjZCLENBQWhDLENBNUVnSyxDQWlGaEs7O0FBQ0EsUUFBTUgsT0FBTyxHQUFHaHhCLGtEQUFXLENBQUV3SCxLQUFELElBQVc7QUFDbkM7QUFDQSxRQUFJLENBQUNpcUIsV0FBVyxDQUFDNXlCLE9BQWpCLEVBQ0lveUIsUUFBUSxDQUFDenBCLEtBQUQsQ0FBUjtBQUNKLFdBQU9BLEtBQVA7QUFDSCxHQUwwQixFQUt4QixDQUFDaXFCLFdBQUQsRUFBY1IsUUFBZCxDQUx3QixDQUEzQixDQWxGZ0ssQ0F3RmhLOztBQUNBLFFBQU12RSxPQUFPLEdBQUcxc0Isa0RBQVcsQ0FBQyxNQUFNbXBCLFNBQVMsQ0FBQyxLQUFLLENBQU4sRUFBUyxLQUFLLENBQWQsRUFBaUIsS0FBSyxDQUF0QixFQUF5QixhQUFhO0FBQzdFLFFBQUlvSSxZQUFZLENBQUMxeUIsT0FBYixJQUF3Qjh0QixVQUF4QixJQUFzQ0ksYUFBdEMsSUFBdURILFNBQTNELEVBQ0k7QUFDSixRQUFJLENBQUN2M0IsTUFBRCxJQUFXLENBQUMyMEIsT0FBaEIsRUFDSSxNQUFNZ0gsT0FBTyxDQUFDLElBQUlOLDJEQUFKLEVBQUQsQ0FBYjs7QUFDSixRQUFJLENBQUMzbkIsS0FBTCxFQUFZO0FBQ1I7QUFDQW9vQixNQUFBQSxPQUFPLENBQUMsSUFBRCxDQUFQOztBQUNBLGlCQUFtQyxFQUVsQzs7QUFDRCxZQUFNSCxPQUFPLENBQUMsSUFBSTFJLDRFQUFKLEVBQUQsQ0FBYjtBQUNIOztBQUNEaUosSUFBQUEsWUFBWSxDQUFDMXlCLE9BQWIsR0FBdUIsSUFBdkI7QUFDQXd5QixJQUFBQSxhQUFhLENBQUMsSUFBRCxDQUFiOztBQUNBLFFBQUk7QUFDQSxZQUFNckgsT0FBTyxDQUFDMEMsT0FBUixFQUFOO0FBQ0gsS0FGRCxDQUdBLE9BQU9sbEIsS0FBUCxFQUFjO0FBQ1Y7QUFDQTJwQixNQUFBQSxPQUFPLENBQUMsSUFBRCxDQUFQLENBRlUsQ0FHVjs7QUFDQSxZQUFNM3BCLEtBQU47QUFDSCxLQVJELFNBU1E7QUFDSjZwQixNQUFBQSxhQUFhLENBQUMsS0FBRCxDQUFiO0FBQ0FFLE1BQUFBLFlBQVksQ0FBQzF5QixPQUFiLEdBQXVCLEtBQXZCO0FBQ0g7QUFDSixHQTVCMEMsQ0FBaEIsRUE0QnZCLENBQUMweUIsWUFBRCxFQUFlNUUsVUFBZixFQUEyQkksYUFBM0IsRUFBMENILFNBQTFDLEVBQXFEdjNCLE1BQXJELEVBQTZEMjBCLE9BQTdELEVBQXNFZ0gsT0FBdEUsRUFBK0Vqb0IsS0FBL0UsRUFBc0Zzb0IsYUFBdEYsRUFBcUdGLE9BQXJHLENBNUJ1QixDQUEzQixDQXpGZ0ssQ0FzSGhLOztBQUNBLFFBQU01bEIsVUFBVSxHQUFHdkwsa0RBQVcsQ0FBQyxNQUFNbXBCLFNBQVMsQ0FBQyxLQUFLLENBQU4sRUFBUyxLQUFLLENBQWQsRUFBaUIsS0FBSyxDQUF0QixFQUF5QixhQUFhO0FBQ2hGLFFBQUlxSSxlQUFlLENBQUMzeUIsT0FBaEIsSUFBMkJrdUIsYUFBL0IsRUFDSTtBQUNKLFFBQUksQ0FBQy9DLE9BQUwsRUFDSSxPQUFPbUgsT0FBTyxDQUFDLElBQUQsQ0FBZDtBQUNKSyxJQUFBQSxlQUFlLENBQUMzeUIsT0FBaEIsR0FBMEIsSUFBMUI7QUFDQXl5QixJQUFBQSxnQkFBZ0IsQ0FBQyxJQUFELENBQWhCOztBQUNBLFFBQUk7QUFDQSxZQUFNdEgsT0FBTyxDQUFDemUsVUFBUixFQUFOO0FBQ0gsS0FGRCxDQUdBLE9BQU8vRCxLQUFQLEVBQWM7QUFDVjtBQUNBMnBCLE1BQUFBLE9BQU8sQ0FBQyxJQUFELENBQVAsQ0FGVSxDQUdWOztBQUNBLFlBQU0zcEIsS0FBTjtBQUNILEtBUkQsU0FTUTtBQUNKOHBCLE1BQUFBLGdCQUFnQixDQUFDLEtBQUQsQ0FBaEI7QUFDQUUsTUFBQUEsZUFBZSxDQUFDM3lCLE9BQWhCLEdBQTBCLEtBQTFCO0FBQ0g7QUFDSixHQXBCNkMsQ0FBaEIsRUFvQjFCLENBQUMyeUIsZUFBRCxFQUFrQnpFLGFBQWxCLEVBQWlDL0MsT0FBakMsRUFBMENzSCxnQkFBMUMsRUFBNERILE9BQTVELENBcEIwQixDQUE5QixDQXZIZ0ssQ0E0SWhLOztBQUNBLFFBQU10NEIsZUFBZSxHQUFHbUgsa0RBQVcsQ0FBQyxDQUFDb2xCLFdBQUQsRUFBY2x2QixVQUFkLEVBQTBCa0csT0FBMUIsS0FBc0Mrc0IsU0FBUyxDQUFDLEtBQUssQ0FBTixFQUFTLEtBQUssQ0FBZCxFQUFpQixLQUFLLENBQXRCLEVBQXlCLGFBQWE7QUFDckgsUUFBSSxDQUFDYSxPQUFMLEVBQ0ksTUFBTWdILE9BQU8sQ0FBQyxJQUFJTiwyREFBSixFQUFELENBQWI7QUFDSixRQUFJLENBQUM5RCxTQUFMLEVBQ0ksTUFBTW9FLE9BQU8sQ0FBQyxJQUFJak4sZ0ZBQUosRUFBRCxDQUFiO0FBQ0osV0FBTyxNQUFNaUcsT0FBTyxDQUFDbnhCLGVBQVIsQ0FBd0J1c0IsV0FBeEIsRUFBcUNsdkIsVUFBckMsRUFBaURrRyxPQUFqRCxDQUFiO0FBQ0gsR0FOa0YsQ0FBaEQsRUFNL0IsQ0FBQzR0QixPQUFELEVBQVVnSCxPQUFWLEVBQW1CcEUsU0FBbkIsQ0FOK0IsQ0FBbkMsQ0E3SWdLLENBb0poSzs7QUFDQSxRQUFNaDNCLGVBQWUsR0FBR2pCLDhDQUFPLENBQUMsTUFBTXExQixPQUFPLElBQUkscUJBQXFCQSxPQUFoQyxHQUMvQjVFLFdBQUQsSUFBaUIrRCxTQUFTLENBQUMsS0FBSyxDQUFOLEVBQVMsS0FBSyxDQUFkLEVBQWlCLEtBQUssQ0FBdEIsRUFBeUIsYUFBYTtBQUM5RCxRQUFJLENBQUN5RCxTQUFMLEVBQ0ksTUFBTW9FLE9BQU8sQ0FBQyxJQUFJak4sZ0ZBQUosRUFBRCxDQUFiO0FBQ0osV0FBTyxNQUFNaUcsT0FBTyxDQUFDcDBCLGVBQVIsQ0FBd0J3dkIsV0FBeEIsQ0FBYjtBQUNILEdBSjJCLENBRE0sR0FNaEN4YSxTQU55QixFQU1kLENBQUNvZixPQUFELEVBQVVnSCxPQUFWLEVBQW1CcEUsU0FBbkIsQ0FOYyxDQUEvQixDQXJKZ0ssQ0E0SmhLOztBQUNBLFFBQU1qM0IsbUJBQW1CLEdBQUdoQiw4Q0FBTyxDQUFDLE1BQU1xMUIsT0FBTyxJQUFJLHlCQUF5QkEsT0FBcEMsR0FDbkNpSSxZQUFELElBQWtCOUksU0FBUyxDQUFDLEtBQUssQ0FBTixFQUFTLEtBQUssQ0FBZCxFQUFpQixLQUFLLENBQXRCLEVBQXlCLGFBQWE7QUFDL0QsUUFBSSxDQUFDeUQsU0FBTCxFQUNJLE1BQU1vRSxPQUFPLENBQUMsSUFBSWpOLGdGQUFKLEVBQUQsQ0FBYjtBQUNKLFdBQU8sTUFBTWlHLE9BQU8sQ0FBQ3IwQixtQkFBUixDQUE0QnM4QixZQUE1QixDQUFiO0FBQ0gsR0FKNEIsQ0FEUyxHQU1wQ3JuQixTQU42QixFQU1sQixDQUFDb2YsT0FBRCxFQUFVZ0gsT0FBVixFQUFtQnBFLFNBQW5CLENBTmtCLENBQW5DLENBN0pnSyxDQW9LaEs7O0FBQ0EsUUFBTXNGLFdBQVcsR0FBR3Y5Qiw4Q0FBTyxDQUFDLE1BQU1xMUIsT0FBTyxJQUFJLGlCQUFpQkEsT0FBNUIsR0FDM0JuZ0IsT0FBRCxJQUFhc2YsU0FBUyxDQUFDLEtBQUssQ0FBTixFQUFTLEtBQUssQ0FBZCxFQUFpQixLQUFLLENBQXRCLEVBQXlCLGFBQWE7QUFDMUQsUUFBSSxDQUFDeUQsU0FBTCxFQUNJLE1BQU1vRSxPQUFPLENBQUMsSUFBSWpOLGdGQUFKLEVBQUQsQ0FBYjtBQUNKLFdBQU8sTUFBTWlHLE9BQU8sQ0FBQ2tJLFdBQVIsQ0FBb0Jyb0IsT0FBcEIsQ0FBYjtBQUNILEdBSnVCLENBRE0sR0FNNUJlLFNBTnFCLEVBTVYsQ0FBQ29mLE9BQUQsRUFBVWdILE9BQVYsRUFBbUJwRSxTQUFuQixDQU5VLENBQTNCLENBcktnSyxDQTRLaEs7O0FBQ0FsNEIsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ1osUUFBSXMxQixPQUFKLEVBQWE7QUFDVEEsTUFBQUEsT0FBTyxDQUFDemdCLEVBQVIsQ0FBVyxPQUFYLEVBQW9Cc29CLE9BQXBCO0FBQ0E3SCxNQUFBQSxPQUFPLENBQUN6Z0IsRUFBUixDQUFXLFNBQVgsRUFBc0J1b0IsU0FBdEI7QUFDQTlILE1BQUFBLE9BQU8sQ0FBQ3pnQixFQUFSLENBQVcsWUFBWCxFQUF5QndvQixZQUF6QjtBQUNBL0gsTUFBQUEsT0FBTyxDQUFDemdCLEVBQVIsQ0FBVyxPQUFYLEVBQW9CeW5CLE9BQXBCO0FBQ0EsYUFBTyxNQUFNO0FBQ1RoSCxRQUFBQSxPQUFPLENBQUNtSSxHQUFSLENBQVksT0FBWixFQUFxQk4sT0FBckI7QUFDQTdILFFBQUFBLE9BQU8sQ0FBQ21JLEdBQVIsQ0FBWSxTQUFaLEVBQXVCTCxTQUF2QjtBQUNBOUgsUUFBQUEsT0FBTyxDQUFDbUksR0FBUixDQUFZLFlBQVosRUFBMEJKLFlBQTFCO0FBQ0EvSCxRQUFBQSxPQUFPLENBQUNtSSxHQUFSLENBQVksT0FBWixFQUFxQm5CLE9BQXJCO0FBQ0gsT0FMRDtBQU1IO0FBQ0osR0FiUSxFQWFOLENBQUNoSCxPQUFELEVBQVU2SCxPQUFWLEVBQW1CQyxTQUFuQixFQUE4QkMsWUFBOUIsRUFBNENmLE9BQTVDLENBYk0sQ0FBVDtBQWNBLHNCQUFRMzZCLDBEQUFBLENBQW9CdTZCLDhEQUFwQixFQUE0QztBQUFFejRCLElBQUFBLEtBQUssRUFBRTtBQUNyRHMxQixNQUFBQSxPQURxRDtBQUVyRHNELE1BQUFBLFdBRnFEO0FBR3JEMTdCLE1BQUFBLE1BSHFEO0FBSXJEMjBCLE1BQUFBLE9BSnFEO0FBS3JEdDBCLE1BQUFBLFNBTHFEO0FBTXJEcVQsTUFBQUEsS0FOcUQ7QUFPckQ2akIsTUFBQUEsU0FQcUQ7QUFRckRELE1BQUFBLFVBUnFEO0FBU3JESSxNQUFBQSxhQVRxRDtBQVVyRFcsTUFBQUEsTUFWcUQ7QUFXckRoQixNQUFBQSxPQVhxRDtBQVlyRG5oQixNQUFBQSxVQVpxRDtBQWFyRDFTLE1BQUFBLGVBYnFEO0FBY3JEakQsTUFBQUEsZUFkcUQ7QUFlckRELE1BQUFBLG1CQWZxRDtBQWdCckR1OEIsTUFBQUE7QUFoQnFEO0FBQVQsR0FBNUMsRUFpQkM5eUIsUUFqQkQsQ0FBUjtBQWtCSCxDQTdNTTs7Ozs7Ozs7Ozs7Ozs7OztBQ3JCUDtBQUNPLE1BQU1zeEIsc0JBQU4sU0FBcUN4SSxvRUFBckMsQ0FBaUQ7QUFDcEQ3VSxFQUFBQSxXQUFXLEdBQUc7QUFDVixVQUFNLEdBQUcrVSxTQUFUO0FBQ0EsU0FBS254QixJQUFMLEdBQVksd0JBQVo7QUFDSDs7QUFKbUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTEE7QUFDQTtBQUNPLFNBQVNtN0IsZUFBVCxHQUEyQjtBQUM5QixRQUFNO0FBQUUxOEIsSUFBQUEsU0FBRjtBQUFhRSxJQUFBQSxlQUFiO0FBQThCRCxJQUFBQTtBQUE5QixNQUFzRGQscURBQVMsRUFBckU7QUFDQSxTQUFPRiw4Q0FBTyxDQUFDLE1BQU1lLFNBQVMsSUFBSUUsZUFBYixJQUFnQ0QsbUJBQWhDLEdBQ2Y7QUFBRUQsSUFBQUEsU0FBRjtBQUFhRSxJQUFBQSxlQUFiO0FBQThCRCxJQUFBQTtBQUE5QixHQURlLEdBRWZpVixTQUZRLEVBRUcsQ0FBQ2xWLFNBQUQsRUFBWUUsZUFBWixFQUE2QkQsbUJBQTdCLENBRkgsQ0FBZDtBQUdIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQRDtBQUNPLE1BQU00NkIsaUJBQWlCLGdCQUFHRCxvREFBYSxDQUFDLEVBQUQsQ0FBdkM7QUFDQSxTQUFTaDJCLGFBQVQsR0FBeUI7QUFDNUIsU0FBT3lQLGlEQUFVLENBQUN3bUIsaUJBQUQsQ0FBakI7QUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNKRDtBQUNPLFNBQVNJLGVBQVQsQ0FBeUI1eUIsR0FBekIsRUFBOEJzMEIsWUFBOUIsRUFBNEM7QUFDL0MsUUFBTTtBQUFBLE9BQUNsNkIsS0FBRDtBQUFBLE9BQVFtNkI7QUFBUixNQUFvQi8zQiwrQ0FBUSxDQUFDLE1BQU07QUFDckMsUUFBSSxPQUFPZzRCLFlBQVAsS0FBd0IsV0FBNUIsRUFDSSxPQUFPRixZQUFQO0FBQ0osVUFBTWw2QixLQUFLLEdBQUdvNkIsWUFBWSxDQUFDcmQsT0FBYixDQUFxQm5YLEdBQXJCLENBQWQ7O0FBQ0EsUUFBSTtBQUNBLGFBQU81RixLQUFLLEdBQUd5YyxJQUFJLENBQUNPLEtBQUwsQ0FBV2hkLEtBQVgsQ0FBSCxHQUF1Qms2QixZQUFuQztBQUNILEtBRkQsQ0FHQSxPQUFPN3FCLEtBQVAsRUFBYztBQUNWM1IsTUFBQUEsT0FBTyxDQUFDaUosSUFBUixDQUFhMEksS0FBYjtBQUNBLGFBQU82cUIsWUFBUDtBQUNIO0FBQ0osR0FYaUMsQ0FBbEM7QUFZQSxRQUFNRyxlQUFlLEdBQUd4eUIsa0RBQVcsQ0FBRXl5QixRQUFELElBQWM7QUFDOUMsUUFBSUEsUUFBUSxLQUFLdDZCLEtBQWpCLEVBQ0k7QUFDSm02QixJQUFBQSxRQUFRLENBQUNHLFFBQUQsQ0FBUjs7QUFDQSxRQUFJQSxRQUFRLEtBQUssSUFBakIsRUFBdUI7QUFDbkJGLE1BQUFBLFlBQVksQ0FBQy9mLFVBQWIsQ0FBd0J6VSxHQUF4QjtBQUNILEtBRkQsTUFHSztBQUNELFVBQUk7QUFDQXcwQixRQUFBQSxZQUFZLENBQUNoZ0IsT0FBYixDQUFxQnhVLEdBQXJCLEVBQTBCNlcsSUFBSSxDQUFDQyxTQUFMLENBQWU0ZCxRQUFmLENBQTFCO0FBQ0gsT0FGRCxDQUdBLE9BQU9qckIsS0FBUCxFQUFjO0FBQ1YzUixRQUFBQSxPQUFPLENBQUMyUixLQUFSLENBQWNBLEtBQWQ7QUFDSDtBQUNKO0FBQ0osR0Fma0MsRUFlaEMsQ0FBQ3JQLEtBQUQsRUFBUW02QixRQUFSLEVBQWtCdjBCLEdBQWxCLENBZmdDLENBQW5DO0FBZ0JBLFNBQU8sQ0FBQzVGLEtBQUQsRUFBUXE2QixlQUFSLENBQVA7QUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0JEO0FBQ08sTUFBTTVCLGFBQWEsZ0JBQUdOLG9EQUFhLENBQUMsRUFBRCxDQUFuQztBQUNBLFNBQVN6N0IsU0FBVCxHQUFxQjtBQUN4QixTQUFPa1YsaURBQVUsQ0FBQzZtQixhQUFELENBQWpCO0FBQ0g7Ozs7Ozs7Ozs7QUNKRCx5R0FBOEM7Ozs7Ozs7Ozs7OztBQ0E5Qzs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL2NvbXBvbmVudHMvQ29ubmVjdFRvV2FsbGV0LnRzeCIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vY29tcG9uZW50cy9EYXNoYm9hcmQvTGluZUNoYXJ0LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9jb21wb25lbnRzL0Rhc2hib2FyZC9Ob3RDb25uZWN0ZWQuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL2NvbXBvbmVudHMvRGFzaGJvYXJkL1N0YWtpbmdDYXJkLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9jb21wb25lbnRzL0Rhc2hib2FyZC9TdGF0cy5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vY29tcG9uZW50cy9EYXNoYm9hcmQvVG9rZW5DYXJkLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9jb21wb25lbnRzL0Rhc2hib2FyZC9pbmRleC5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vY29tcG9uZW50cy9ORlQuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL2NvbXBvbmVudHMvTkZUQ2Fyb3VzZWwuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL2NvbXBvbmVudHMvTmF2YmFyL2luZGV4LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ob29rcy91c2VXYWxsZXRORlRzLnRzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9saW5rLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9ub3JtYWxpemUtdHJhaWxpbmctc2xhc2guanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3JlcXVlc3QtaWRsZS1jYWxsYmFjay5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvcm91dGUtbG9hZGVyLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9yb3V0ZXIuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3VzZS1pbnRlcnNlY3Rpb24uanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3dpdGgtcm91dGVyLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3JvdXRlci5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vcGFnZXMvZGFzaGJvYXJkLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi91dGlscy9jYW5keU1hY2hpbmUudHMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL3V0aWxzL2luZGV4LnRzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlL2xpYi9hZGFwdGVyLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlL2xpYi9lcnJvcnMuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLWJhc2UvbGliL2luZGV4LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlL2xpYi9wb2xsLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlL2xpYi9zaWduZXIuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0LXVpL2xpYi9CdXR0b24uanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0LXVpL2xpYi9Db2xsYXBzZS5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QtdWkvbGliL1dhbGxldENvbm5lY3RCdXR0b24uanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0LXVpL2xpYi9XYWxsZXREaXNjb25uZWN0QnV0dG9uLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC11aS9saWIvV2FsbGV0SWNvbi5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QtdWkvbGliL1dhbGxldExpc3RJdGVtLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC11aS9saWIvV2FsbGV0TW9kYWwuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0LXVpL2xpYi9XYWxsZXRNb2RhbEJ1dHRvbi5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QtdWkvbGliL1dhbGxldE1vZGFsUHJvdmlkZXIuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0LXVpL2xpYi9XYWxsZXRNdWx0aUJ1dHRvbi5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QtdWkvbGliL2luZGV4LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC11aS9saWIvdXNlV2FsbGV0TW9kYWwuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0L2xpYi9Db25uZWN0aW9uUHJvdmlkZXIuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0L2xpYi9XYWxsZXRQcm92aWRlci5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QvbGliL2Vycm9ycy5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QvbGliL2luZGV4LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC9saWIvdXNlQW5jaG9yV2FsbGV0LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC9saWIvdXNlQ29ubmVjdGlvbi5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QvbGliL3VzZUxvY2FsU3RvcmFnZS5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QvbGliL3VzZVdhbGxldC5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL25leHQvbGluay5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwiQG1ldGFwbGV4L2pzXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcIkBwcm9qZWN0LXNlcnVtL2FuY2hvclwiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJAc29sYW5hL3NwbC10b2tlblwiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJAc29sYW5hL3dlYjMuanNcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwiZXZlbnRlbWl0dGVyM1wiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2VydmVyL2Rlbm9ybWFsaXplLXBhZ2UtcGF0aC5qc1wiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9pMThuL25vcm1hbGl6ZS1sb2NhbGUtcGF0aC5qc1wiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9taXR0LmpzXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci1jb250ZXh0LmpzXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci91dGlscy9nZXQtYXNzZXQtcGF0aC1mcm9tLXJvdXRlLmpzXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci91dGlscy9pcy1keW5hbWljLmpzXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci91dGlscy9wYXJzZS1yZWxhdGl2ZS11cmwuanNcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL3F1ZXJ5c3RyaW5nLmpzXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci91dGlscy9yb3V0ZS1tYXRjaGVyLmpzXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci91dGlscy9yb3V0ZS1yZWdleC5qc1wiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi91dGlscy5qc1wiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovL25leHQtY20tdjIvZXh0ZXJuYWwgXCJyZWFjdC1kb21cIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwicmVhY3QtaXNcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwicmVhY3QtcmVkdXhcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwicmVhY3Qtc2xpY2tcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcInJlYWN0c3RyYXBcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwicmVjaGFydHNcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2lnbm9yZWR8RzpcXGNsaWVudHNcXGR5bGFuXFxzdGFraW5nXFxub2RlX21vZHVsZXNcXG5leHRcXGRpc3RcXHNoYXJlZFxcbGliXFxyb3V0ZXJ8Li91dGlscy9yZXNvbHZlLXJld3JpdGVzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmltcG9ydCAqIGFzIGFuY2hvciBmcm9tIFwiQHByb2plY3Qtc2VydW0vYW5jaG9yXCI7XHJcblxyXG5pbXBvcnQgeyBleGlzdHNPd25lclNQTFRva2VuLCBnZXRORlRzRm9yT3duZXIgfSBmcm9tIFwiLi4vdXRpbHMvY2FuZHlNYWNoaW5lXCI7XHJcbmltcG9ydCB7IExBTVBPUlRTX1BFUl9TT0wsIFB1YmxpY0tleSB9IGZyb20gXCJAc29sYW5hL3dlYjMuanNcIjtcclxuLy8gaW1wb3J0IHVzZVdhbGxldEJhbGFuY2UgZnJvbSBcIi4uL2hvb2tzL3VzZVdhbGxldEJhbGFuY2VcIjtcclxuaW1wb3J0IHsgdXNlV2FsbGV0IH0gZnJvbSBcIkBzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3RcIjtcclxuaW1wb3J0IHVzZVdhbGxldE5mdHMgZnJvbSBcIi4uL2hvb2tzL3VzZVdhbGxldE5GVHNcIjtcclxuaW1wb3J0IHsgdXNlRGlzcGF0Y2ggfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuZXhwb3J0IGludGVyZmFjZSBIb21lUHJvcHMge1xyXG4gIGNhbmR5TWFjaGluZUlkPzogYW5jaG9yLndlYjMuUHVibGljS2V5O1xyXG4gIGNvbm5lY3Rpb246IGFuY2hvci53ZWIzLkNvbm5lY3Rpb247XHJcbiAgc3RhcnREYXRlOiBudW1iZXI7XHJcbiAgdHhUaW1lb3V0OiBudW1iZXI7XHJcbiAgcnBjSG9zdDogc3RyaW5nO1xyXG59XHJcbmZ1bmN0aW9uIENvbm5lY3RUb1dhbGxldChwcm9wczogSG9tZVByb3BzKSB7XHJcbiAgICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKCk7XHJcbiAgICBjb25zdCBycGNVcmwgPSBwcm9wcy5ycGNIb3N0O1xyXG4gIGNvbnN0IHdhbGxldCA9IHVzZVdhbGxldCgpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsbmZ0cywgaXNTUExFeGlzdHNdID0gdXNlV2FsbGV0TmZ0cyhwcm9wcyk7XHJcbiAgICBjb25zdCBhbmNob3JXYWxsZXQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgaWYgKFxyXG4gICAgICAgICF3YWxsZXQgfHxcclxuICAgICAgICAhd2FsbGV0LnB1YmxpY0tleSB8fFxyXG4gICAgICAgICF3YWxsZXQuc2lnbkFsbFRyYW5zYWN0aW9ucyB8fFxyXG4gICAgICAgICF3YWxsZXQuc2lnblRyYW5zYWN0aW9uXHJcbiAgICAgICkge1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICBwdWJsaWNLZXk6IHdhbGxldC5wdWJsaWNLZXksXHJcbiAgICAgICAgc2lnbkFsbFRyYW5zYWN0aW9uczogd2FsbGV0LnNpZ25BbGxUcmFuc2FjdGlvbnMsXHJcbiAgICAgICAgc2lnblRyYW5zYWN0aW9uOiB3YWxsZXQuc2lnblRyYW5zYWN0aW9uLFxyXG4gICAgICB9IGFzIGFuY2hvci5XYWxsZXQ7XHJcbiAgICB9LCBbd2FsbGV0XSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAoYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICBcclxuICAgICAgIFxyXG4gICAgICBpZiAoIWFuY2hvcldhbGxldCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiZGlzY29ubmVjdGVkXCIpO1xyXG4gICAgICAgIGRpc3BhdGNoKHtcclxuICAgICAgICAgIHR5cGU6IFwiV0FMTEVUX0lEXCIsXHJcbiAgICAgICAgICBwYXlsb2FkOiBudWxsLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGRpc3BhdGNoKHtcclxuICAgICAgICAgIHR5cGU6IFwiU0VUTkZUXCIsXHJcbiAgICAgICAgICBwYXlsb2FkOiBudWxsLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgfVxyXG4gICAgICAgIC8vICBjb25zb2xlLmxvZyhhbmNob3JXYWxsZXQsIFwiYW5jaG9yV2FsbGV0XCIpO1xyXG4gICAgICAgICBpZiAoYW5jaG9yV2FsbGV0Py5wdWJsaWNLZXkpIHtcclxuICAgICAgICAgICBkaXNwYXRjaCh7XHJcbiAgICAgICAgICAgICB0eXBlOiBcIldBTExFVF9JRFwiLFxyXG4gICAgICAgICAgICAgcGF5bG9hZDogYW5jaG9yV2FsbGV0Py5wdWJsaWNLZXk/LnRvU3RyaW5nKCksXHJcbiAgICAgICAgICAgfSk7XHJcbiAgICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgICBpZiAocHJvcHM/LmNvbm5lY3Rpb24gJiYgYW5jaG9yV2FsbGV0Py5wdWJsaWNLZXkpIHtcclxuICAgICAgICAgICBjb25zdCBuZnRzRm9yT3duZXIgPSBhd2FpdCBnZXRORlRzRm9yT3duZXIoXHJcbiAgICAgICAgICAgICBwcm9wcy5jb25uZWN0aW9uLFxyXG4gICAgICAgICAgICAgYW5jaG9yV2FsbGV0Py5wdWJsaWNLZXlcclxuICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICBjb25zb2xlLmxvZyhuZnRzRm9yT3duZXIsIFwiTkZUc0Zvck93bmVyXCIpO1xyXG4gICAgICAgICB9XHJcblxyXG4gICAgICAgICAvL3NldE5mdHMobmZ0c0Zvck93bmVyIGFzIGFueSk7XHJcblxyXG5cclxuICAgICAgIH0pKCk7XHJcbiAgICAgfSwgW2FuY2hvcldhbGxldCwgcHJvcHMuY2FuZHlNYWNoaW5lSWQsIHByb3BzLmNvbm5lY3Rpb25dKTtcclxuICBcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKG5mdHMpIHtcclxuICAgICAgZGlzcGF0Y2goe1xyXG4gICAgICAgIHR5cGU6IFwiU0VUTkZUXCIsXHJcbiAgICAgICAgcGF5bG9hZDogbmZ0cyxcclxuICAgICAgfSk7XHJcbiAgICAgIC8vIGNvbnNvbGUubG9nKG5mdHMsJ25mdHMgYWRkZWQnKVxyXG4gICAgfVxyXG4gIH0sW25mdHNdKVxyXG5cclxuXHJcblxyXG4gIHJldHVybiA8PjwvPjtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ29ubmVjdFRvV2FsbGV0O1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgTGluZUNoYXJ0LFxyXG4gIExpbmUsXHJcbiAgWEF4aXMsXHJcbiAgWUF4aXMsXHJcbiAgQ2FydGVzaWFuR3JpZCxcclxuICBUb29sdGlwLFxyXG4gIExlZ2VuZCxcclxuICBSZXNwb25zaXZlQ29udGFpbmVyLFxyXG4gIEFyZWFDaGFydCxcclxuICBBcmVhLFxyXG59IGZyb20gXCJyZWNoYXJ0c1wiO1xyXG5cclxuY29uc3QgZGF0YSA9IFtcclxuICB7XHJcbiAgICBuYW1lOiBcIjEgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiA0MDAwLFxyXG4gICAgZmxvb3I6IDI0MDAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjIgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiAzMDAwLFxyXG4gICAgZmxvb3I6IDEzOTgsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjMgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiAyMDAwLFxyXG4gICAgZmxvb3I6IDk4MDAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjQgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiAyNzgwLFxyXG4gICAgZmxvb3I6IDM5MDgsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjUgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiAxODkwLFxyXG4gICAgZmxvb3I6IDQ4MDAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjYgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiAyMzkwLFxyXG4gICAgZmxvb3I6IDM4MDAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjcgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiAzNDkwLFxyXG4gICAgZmxvb3I6IDQzMDAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjggSmFuXCIsXHJcbiAgICBhdmVyYWdlOiA0MDAwLFxyXG4gICAgZmxvb3I6IDI0MDAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjkgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiAzMDAwLFxyXG4gICAgZmxvb3I6IDEzOTgsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjEwIEphblwiLFxyXG4gICAgYXZlcmFnZTogMjAwMCxcclxuICAgIGZsb29yOiA5ODAwLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCIxMSBKYW5cIixcclxuICAgIGF2ZXJhZ2U6IDI3ODAsXHJcbiAgICBmbG9vcjogMzkwOCxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiMTIgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiAxODkwLFxyXG4gICAgZmxvb3I6IDQ4MDAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjEzIEphblwiLFxyXG4gICAgYXZlcmFnZTogMjM5MCxcclxuICAgIGZsb29yOiAzODAwLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCIxNCBKYW5cIixcclxuICAgIGF2ZXJhZ2U6IDM0OTAsXHJcbiAgICBmbG9vcjogNDMwMCxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiMTUgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiA0MDAwLFxyXG4gICAgZmxvb3I6IDI0MDAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjE2IEphblwiLFxyXG4gICAgYXZlcmFnZTogMzAwMCxcclxuICAgIGZsb29yOiAxMzk4LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCIxNyBKYW5cIixcclxuICAgIGF2ZXJhZ2U6IDIwMDAsXHJcbiAgICBmbG9vcjogOTgwMCxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiMTggSmFuXCIsXHJcbiAgICBhdmVyYWdlOiAyNzgwLFxyXG4gICAgZmxvb3I6IDM5MDgsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjE5IEphblwiLFxyXG4gICAgYXZlcmFnZTogMTg5MCxcclxuICAgIGZsb29yOiA0ODAwLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCIyMCBKYW5cIixcclxuICAgIGF2ZXJhZ2U6IDIzOTAsXHJcbiAgICBmbG9vcjogMzgwMCxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiMjEgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiAzNDkwLFxyXG4gICAgZmxvb3I6IDQzMDAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjIyIEphblwiLFxyXG4gICAgYXZlcmFnZTogNDAwMCxcclxuICAgIGZsb29yOiAyNDAwLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCIyMyBKYW5cIixcclxuICAgIGF2ZXJhZ2U6IDMwMDAsXHJcbiAgICBmbG9vcjogMTM5OCxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiMjQgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiAyMDAwLFxyXG4gICAgZmxvb3I6IDk4MDAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjI1IEphblwiLFxyXG4gICAgYXZlcmFnZTogMjc4MCxcclxuICAgIGZsb29yOiAzOTA4LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCIyNiBKYW5cIixcclxuICAgIGF2ZXJhZ2U6IDE4OTAsXHJcbiAgICBmbG9vcjogNDgwMCxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiMjcgSmFuXCIsXHJcbiAgICBhdmVyYWdlOiAyMzkwLFxyXG4gICAgZmxvb3I6IDM4MDAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIjI4IEphblwiLFxyXG4gICAgYXZlcmFnZTogMzQ5MCxcclxuICAgIGZsb29yOiA0MzAwLFxyXG4gIH0sXHJcbl07XHJcbmNvbnN0IGRhcmtUaGVtZSA9IHtcclxuICBiYWNrZ3JvdW5kQ29sb3I6IFwiIzJlMmMzNFwiLFxyXG4gIGNvbG9yOiBcIiNkZGRkZGRcIixcclxufTtcclxuY29uc3QgZ2V0VG9vbHRpcFN0eWxlcyA9ICgpID0+IHtcclxuICBjb25zdCB7IGJhY2tncm91bmRDb2xvciwgY29sb3IgfSA9IGRhcmtUaGVtZTtcclxuICByZXR1cm4ge1xyXG4gICAgY29udGVudFN0eWxlOiB7IGJhY2tncm91bmRDb2xvciB9LFxyXG4gICAgaXRlbVN0eWxlOiB7IGNvbG9yIH0sXHJcbiAgfTtcclxufTtcclxuZnVuY3Rpb24gTGluZUNoYXJ0eCgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJweS0xMiB0ZXh0LXdoaXRlXCI+XHJcbiAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIGhlaWdodD17MzUwfSBjbGFzc05hbWU9XCJkYXNoYm9hcmRfX2FyZWFcIj5cclxuICAgICAgICA8QXJlYUNoYXJ0IGRhdGE9e2RhdGF9IG1hcmdpbj17eyB0b3A6IDIwLCBsZWZ0OiAtMTUsIGJvdHRvbTogMjAgfX0+XHJcbiAgICAgICAgICA8ZGVmcz5cclxuICAgICAgICAgICAgPGxpbmVhckdyYWRpZW50IGlkPVwiY29sb3JVdlwiIHgxPVwiMFwiIHkxPVwiMFwiIHgyPVwiMFwiIHkyPVwiMVwiPlxyXG4gICAgICAgICAgICAgIDxzdG9wIG9mZnNldD1cIjUlXCIgc3RvcENvbG9yPVwiIzg4ODRkOFwiIHN0b3BPcGFjaXR5PXswLjh9IC8+XHJcbiAgICAgICAgICAgICAgPHN0b3Agb2Zmc2V0PVwiOTUlXCIgc3RvcENvbG9yPVwiIzg4ODRkOFwiIHN0b3BPcGFjaXR5PXswfSAvPlxyXG4gICAgICAgICAgICA8L2xpbmVhckdyYWRpZW50PlxyXG4gICAgICAgICAgICA8bGluZWFyR3JhZGllbnQgaWQ9XCJjb2xvclB2XCIgeDE9XCIwXCIgeTE9XCIwXCIgeDI9XCIwXCIgeTI9XCIxXCI+XHJcbiAgICAgICAgICAgICAgPHN0b3Agb2Zmc2V0PVwiNSVcIiBzdG9wQ29sb3I9XCIjODJjYTlkXCIgc3RvcE9wYWNpdHk9ezAuOH0gLz5cclxuICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCI5NSVcIiBzdG9wQ29sb3I9XCIjODJjYTlkXCIgc3RvcE9wYWNpdHk9ezB9IC8+XHJcbiAgICAgICAgICAgIDwvbGluZWFyR3JhZGllbnQ+XHJcbiAgICAgICAgICA8L2RlZnM+XHJcbiAgICAgICAgICA8WEF4aXMgZGF0YUtleT1cIm5hbWVcIiB0aWNrTGluZT17ZmFsc2V9IC8+XHJcbiAgICAgICAgICA8WUF4aXMgdGlja0xpbmU9e2ZhbHNlfSAvPlxyXG4gICAgICAgICAgPFRvb2x0aXAgey4uLmdldFRvb2x0aXBTdHlsZXMoKX0gLz5cclxuICAgICAgICAgIDxMZWdlbmQgLz5cclxuICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIC8+XHJcbiAgICAgICAgICA8QXJlYVxyXG4gICAgICAgICAgICBuYW1lPVwiRmxvb3JcIlxyXG4gICAgICAgICAgICB0eXBlPVwibW9ub3RvbmVcIlxyXG4gICAgICAgICAgICBkYXRhS2V5PVwiZmxvb3JcIlxyXG4gICAgICAgICAgICBzdHJva2U9XCIjODg4NGQ4XCJcclxuICAgICAgICAgICAgZmlsbE9wYWNpdHk9ezF9XHJcbiAgICAgICAgICAgIGZpbGw9XCJ1cmwoI2NvbG9yVXYpXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8QXJlYVxyXG4gICAgICAgICAgICBuYW1lPVwiQXZlcmFnZVwiXHJcbiAgICAgICAgICAgIHR5cGU9XCJtb25vdG9uZVwiXHJcbiAgICAgICAgICAgIGRhdGFLZXk9XCJhdmVyYWdlXCJcclxuICAgICAgICAgICAgc3Ryb2tlPVwiIzgyY2E5ZFwiXHJcbiAgICAgICAgICAgIGZpbGxPcGFjaXR5PXsxfVxyXG4gICAgICAgICAgICBmaWxsPVwidXJsKCNjb2xvclB2KVwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvQXJlYUNoYXJ0PlxyXG4gICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMaW5lQ2hhcnR4O1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuaW1wb3J0IHsgV2FsbGV0TXVsdGlCdXR0b24gfSBmcm9tIFwiQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC11aVwiO1xyXG5mdW5jdGlvbiBOb3RDb25uZWN0ZWQoKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNlbnRlciBwLTZcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGxnOnRleHQtNXhsIGZvbnQtYm9sZCB0ZXh0LWNlbnRlciBweS02IFwiPlxyXG4gICAgICAgICAgICBTdGFraW5nIDxzcGFuIGNsYXNzTmFtZT0ndGV4dC1icmFuZF9hY2NlbnQnPlByb2plY3Q8L3NwYW4+XHJcbiAgICAgICAgICA8L2gxPlxyXG5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInBiLTQgdGV4dC0yeGxcIj5cclxuICAgICAgICAgICAgTG9nIGluIHdpdGggeW91ciB3ZWIzIHByb3ZpZGVyIHRvIGNvbnRpbnVlXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICA8V2FsbGV0TXVsdGlCdXR0b24+Q29ubmVjdCBXYWxsZXQ8L1dhbGxldE11bHRpQnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTm90Q29ubmVjdGVkO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IFBpZSwgUGllQ2hhcnQsIFJlc3BvbnNpdmVDb250YWluZXIgfSBmcm9tIFwicmVjaGFydHNcIjtcclxuXHJcblxyXG5jb25zdCBkYXRhMDEgPSBbXHJcbiAgeyB2YWx1ZTogNTAsIGZpbGw6IFwiIzExOGYxNVwiIH0sXHJcbiAgeyB2YWx1ZTogNTAsIGZpbGw6IFwiI2VlZWVlZVwiIH0sXHJcbl07XHJcblxyXG5jb25zdCBkYXRhMDIgPSBbXHJcbiAgeyB2YWx1ZTogNjAsIGZpbGw6IFwiI2ZmNDg2MVwiIH0sXHJcbiAgeyB2YWx1ZTogNDAsIGZpbGw6IFwiI2VlZWVlZVwiIH0sXHJcbl07XHJcblxyXG5jb25zdCBTdGFraW5nQ2FyZCA9ICgpID0+IHtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGxnOnctNi8xMiBsZzpwbC0zIHJlbGF0aXZlIG10LTMgbGc6bS0wXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYnJhbmRfYWNjZW50IHAtNiAgbGc6bWluLWgtNTB2aCByb3VuZGVkXCI+XHJcbiAgICAgICAgPGg1IGNsYXNzTmFtZT1cIiBwYi02IHVwcGVyY2FzZSBmb250LW1lZGl1bSB0ZXh0LXNtIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICBTdGFraW5nXHJcbiAgICAgICAgPC9oNT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBiLTYgbGc6cGItMCBjaGFydC0xIHctZnVsbCBtZDp3LTYvMTIgcC0yIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2VudGVyIHJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgPFBpZUNoYXJ0IGhlaWdodD17MTIwfSB3aWR0aD17MTIwfT5cclxuICAgICAgICAgICAgICAgIDxQaWVcclxuICAgICAgICAgICAgICAgICAgZGF0YT17ZGF0YTAxfVxyXG4gICAgICAgICAgICAgICAgICBkYXRhS2V5PVwidmFsdWVcIlxyXG4gICAgICAgICAgICAgICAgICBjeD17NTV9XHJcbiAgICAgICAgICAgICAgICAgIGN5PXs1NX1cclxuICAgICAgICAgICAgICAgICAgaW5uZXJSYWRpdXM9ezU1fVxyXG4gICAgICAgICAgICAgICAgICBvdXRlclJhZGl1cz17NjB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvUGllQ2hhcnQ+XHJcbiAgICAgICAgICAgICAgey8qIDxwXHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyB0b3A6IFwiMzUlXCIsIGxlZnQ6IFwiMzglXCIsIGNvbG9yOiBcIiNiOGU5ODZcIiB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdGV4dC0zeGxcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDAlXHJcbiAgICAgICAgICAgICAgPC9wPiAqL31cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mbyBwdC00IHRleHQtZ3JheS0xMDBcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCB0ZXh0LWluZGlnby0xMDBcIj4wJTwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktMTAwXCI+TXkgTkZUcyBTdGFrZWQ8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNoYXJ0LTIgdy1mdWxsIG1kOnctNi8xMiBwLTIgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjZW50ZXIgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICA8UGllQ2hhcnQgaGVpZ2h0PXsxMjB9IHdpZHRoPXsxMjB9PlxyXG4gICAgICAgICAgICAgICAgPFBpZVxyXG4gICAgICAgICAgICAgICAgICBkYXRhPXtkYXRhMDJ9XHJcbiAgICAgICAgICAgICAgICAgIGRhdGFLZXk9XCJ2YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgIGN4PXs1NX1cclxuICAgICAgICAgICAgICAgICAgY3k9ezU1fVxyXG4gICAgICAgICAgICAgICAgICBpbm5lclJhZGl1cz17NTV9XHJcbiAgICAgICAgICAgICAgICAgIG91dGVyUmFkaXVzPXs2MH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9QaWVDaGFydD5cclxuICAgICAgICAgICAgICB7LyogPHBcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHRvcDogXCIzNSVcIiwgbGVmdDogXCIzOCVcIiwgY29sb3I6IFwiI2ZmNDg2MVwiIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0ZXh0LTN4bFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgNzglXHJcbiAgICAgICAgICAgICAgPC9wPiAqL31cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mbyBwdC00IHRleHQtZ3JheS0xMDBcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bFwiIHN0eWxlPXt7IGNvbG9yOiBcIiNmZjQ4NjFcIiB9fT5cclxuICAgICAgICAgICAgICAgIDYwJVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktMTAwXCI+T3ZlcmFsbCBORlRzIFN0YWtlZDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNlbnRlclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ1cHBlcmNhc2UgdGV4dC13aGl0ZSBmb250LW1lZGl1bSB0cmFja2luZy13aWRlciBwdC02IHRleHQteGxcIj5cclxuICAgICAgICAgICAgICAwIFNvbCAvRGF5XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTEwMFwiPlJld2FyZHM8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgU3Rha2luZ0NhcmQ7XHJcblxyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXHJcblxyXG5mdW5jdGlvbiBTdGF0cygpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9J2JvcmRlciBib3JkZXItYnJhbmRfdGVydGlhcnkgcm91bmRlZCBzaGFkb3ctMnhsJz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBzdGF0cyByb3VuZGVkIHRleHQtYnJhbmRfYmxhY2tcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXItciBib3JkZXItYnJhbmRfdGVydGlhcnkgcC02IG1kOnctNi8xMiBsZzp3LTMvMTIgXCI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXdoaXRlXCI+QXZlcmFnZSBWYWx1ZTwvcD5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2VudGVyIHB5LTJcIj5cclxuICAgICAgICAgICAgPGltZyB3aWR0aD17NDB9IHNyYz1cIi9zb2wucG5nXCIgLz5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGwtNCB0ZXh0LWJyYW5kX3RlcnRpYXJ5IHRleHQtMnhsIGZvbnQtYm9sZCBcIj4yMzYuMjg8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXItciBib3JkZXItYnJhbmRfdGVydGlhcnkgcC02IG1kOnctNi8xMiBsZzp3LTMvMTIgXCI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXdoaXRlXCI+Rmxvb3IgVmFsdWU8L3A+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNlbnRlciBweS0yXCI+XHJcbiAgICAgICAgICAgIDxpbWcgd2lkdGg9ezQwfSBzcmM9XCIvc29sLnBuZ1wiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBsLTQgdGV4dC1icmFuZF90ZXJ0aWFyeSB0ZXh0LTJ4bCBmb250LWJvbGQgXCI+MjI3LjA2PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyLXIgYm9yZGVyLWJyYW5kX3RlcnRpYXJ5IHAtNiBtZDp3LTYvMTIgbGc6dy0zLzEyIFwiPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC13aGl0ZVwiPk5GVHMgaW4gVmF1bHQ8L3A+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNlbnRlciBweS0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBsLTQgdGV4dC1icmFuZF90ZXJ0aWFyeSB0ZXh0LTJ4bCBmb250LWJvbGQgXCI+ODE8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBwLTYgbWQ6dy02LzEyIGxnOnctMy8xMiBcIj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtd2hpdGVcIj5MYXVuY2ggRGF0ZTwvcD5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2VudGVyIHB5LTJcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGwtNCB0ZXh0LWJyYW5kX3RlcnRpYXJ5IHRleHQtMnhsIGZvbnQtYm9sZCBcIj5Ob3YgMjEsIDIwMjE8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFN0YXRzXHJcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7ICBQcm9ncmVzcyB9IGZyb20gXCJyZWFjdHN0cmFwXCI7XHJcblxyXG5cclxuXHJcbmZ1bmN0aW9uIFRva2VuQ2FyZCgpIHtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGxnOnctNi8xMiBsZzpwci0zIG1iLTMgbGc6bS0wXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYnJhbmRfYWNjZW50IHAtNiAgbGc6aC01MHZoIHJvdW5kZWRcIj5cclxuICAgICAgICA8aDUgY2xhc3NOYW1lPVwiIHBiLTYgdXBwZXJjYXNlIGZvbnQtbWVkaXVtIHRleHQtc20gdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgIFRva2VuIEJhbGFuY2VcclxuICAgICAgICA8L2g1PlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtd2hpdGUgdGV4dC1zbSBwYi0xIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICBUb3RhbFxyXG4gICAgICAgIDwvcD5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LTN4bCBsZzp0ZXh0LTV4bCB0ZXh0LWdyZWVuLTMwMFwiPjE1LjAwPC9wPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMTYgbGc6cHktMTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XHJcbiAgICAgICAgICAgIDxQcm9ncmVzcyBjb2xvcj1cInN1Y2Nlc3NcIiBjbGFzc05hbWU9J2JnLWdyZWVuLTUwMCcgdmFsdWU9XCI1MFwiPlxyXG4gICAgICAgICAgICAgIDUwJVxyXG4gICAgICAgICAgICA8L1Byb2dyZXNzPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1ldmVubHkgcHktMiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC14bFwiPjUuMDA8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSAgdGV4dC1ncmVlbi0zMDAgcHQtMVwiPldhbGxldDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1icmFuZF93aGl0ZSB0ZXh0LXhsXCI+MTAuMDA8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBwdC0xIHRleHQtd2hpdGVcIj5VbmNsYWltZWQ8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgVG9rZW5DYXJkXHJcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBOb3RDb25uZWN0ZWQgZnJvbSAnLi9Ob3RDb25uZWN0ZWQnO1xyXG5pbXBvcnQgVG9rZW5DYXJkIGZyb20gJy4vVG9rZW5DYXJkJztcclxuaW1wb3J0IFN0YWtpbmdDYXJkIGZyb20gJy4vU3Rha2luZ0NhcmQnO1xyXG5pbXBvcnQgU3RhdHMgZnJvbSAnLi9TdGF0cyc7XHJcbmltcG9ydCBMaW5lQ2hhcnQgZnJvbSAnLi9MaW5lQ2hhcnQnO1xyXG5pbXBvcnQgeyB1c2VXYWxsZXQgfSBmcm9tIFwiQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9OYXZiYXJcIlxyXG5pbXBvcnQgTkZUQ2Fyb3VzZWwgZnJvbSAnLi4vTkZUQ2Fyb3VzZWwnO1xyXG5mdW5jdGlvbiBEYXNoYm9hcmQocHJvcHMpIHtcclxuICBcclxuICBjb25zdCB7IHB1YmxpY0tleSwgc2VuZFRyYW5zYWN0aW9uIH0gPSB1c2VXYWxsZXQoKTtcclxuICAgIGlmICghcHVibGljS2V5KSB7XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxOb3RDb25uZWN0ZWQgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIClcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0ZXh0LWJsYWNrXCI+XHJcbiAgICAgICAgICAgIDxOYXZiYXIgLz5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBiZy1icmFuZF9hY2NlbnQgcm91bmRlZCBteS02IHAtNlwiPlxyXG4gICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCIgcGItNiB1cHBlcmNhc2UgZm9udC1tZWRpdW0gdGV4dC1zbSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgTXkgTkZUc1xyXG4gICAgICAgICAgICAgIDwvaDU+XHJcbiAgICAgICAgICAgICAgPE5GVENhcm91c2VsIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIml0ZW0tY2VudGVyIGZsZXgganVzdGlmeS1iZXR3ZWVuIGZsZXgtd3JhcCBteS02XCI+XHJcbiAgICAgICAgICAgICAgPFRva2VuQ2FyZCAvPlxyXG4gICAgICAgICAgICAgIDxTdGFraW5nQ2FyZCAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGJnLWJyYW5kX2FjY2VudCByb3VuZGVkIG15LTYgcC02XCI+XHJcbiAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cIiBwYi02IHVwcGVyY2FzZSBmb250LW1lZGl1bSB0ZXh0LXNtIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICBDb21tdW5pdHkgVmF1bHRcclxuICAgICAgICAgICAgICA8L2g1PlxyXG4gICAgICAgICAgICAgIDxTdGF0cyAvPlxyXG4gICAgICAgICAgICAgIDxMaW5lQ2hhcnQgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGFzaGJvYXJkXHJcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcblxyXG5mdW5jdGlvbiBORlQocHJvcHMpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHAtNCBiZy1yZWQtNTAwICBtZDp3LTMvMTIgbGc6dy0xLzNcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICA8aW1nIHNyYz17cHJvcHMuaW1nfSAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ncC0zJz5cclxuICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cInRleHQtbWQgZm9udC1ib2xkXCI+e3Byb3BzLm5hbWV9PC9oNT5cclxuICAgICAgICAgICAgey8qIDxwIGNsYXNzTmFtZT1cInB0LTQgdGV4dC1zbVwiPntwcm9wcy5kZXNjcmlwdGlvbn08L3A+ICovfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBORlQ7XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IE5GVCBmcm9tIFwiLi9ORlRcIjtcclxuaW1wb3J0IHsgdXNlU2VsZWN0b3IgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IFNsaWRlciBmcm9tIFwicmVhY3Qtc2xpY2tcIjtcclxuZnVuY3Rpb24gTkZUQ2Fyb3VzZWwoKSB7XHJcbiAgY29uc3QgeyB1c2VyLCB3YWxsZXRfaWQsIG5mdF9saXN0IH0gPSB1c2VTZWxlY3Rvcigoc3RhdGUpID0+ICh7XHJcbiAgICB3YWxsZXRfaWQ6IHN0YXRlLmFwcF9yZWR1Y2VyLndhbGxldF9pZCxcclxuICAgIG5mdF9saXN0OiBzdGF0ZS5hcHBfcmVkdWNlci5uZnRfbGlzdCxcclxuICB9KSk7XHJcbiAgICBjb25zdCBzZXR0aW5ncyA9IHtcclxuICAgICAgZG90czogdHJ1ZSxcclxuICAgICAgaW5maW5pdGU6IGZhbHNlLFxyXG4gICAgICBzcGVlZDogNTAwLFxyXG4gICAgICBhdXRvcGxheTogdHJ1ZSxcclxuICAgICAgc3dpcGVUb1NsaWRlOiB0cnVlLFxyXG4gICAgICBzbGlkZXNUb1Njcm9sbDogMSxcclxuICAgIFxyXG4gICAgICByZXNwb25zaXZlOiBbXHJcbiAgICAgICAgeyBicmVha3BvaW50OiA3NjgsIHNldHRpbmdzOiB7IHNsaWRlc1RvU2hvdzogMSB9IH0sXHJcbiAgICAgICAgeyBicmVha3BvaW50OiA5OTIsIHNldHRpbmdzOiB7IHNsaWRlc1RvU2hvdzogMiB9IH0sXHJcbiAgICAgICAgeyBicmVha3BvaW50OiAxMjAwLCBzZXR0aW5nczogeyBzbGlkZXNUb1Nob3c6IDMgfSB9LFxyXG4gICAgICAgIHsgYnJlYWtwb2ludDogMTAwMDAwLCBzZXR0aW5nczogeyBzbGlkZXNUb1Nob3c6IDQgfSB9LFxyXG4gICAgICBdLFxyXG4gICAgfTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJcIj5cclxuICAgICAgPFNsaWRlciB7Li4uc2V0dGluZ3N9PlxyXG4gICAgICAgIHtuZnRfbGlzdD8ubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICA8ZGl2IGtleT17aXRlbS5pbWFnZX0gY2xhc3NOYW1lPVwicC02XCIgc3R5bGU9e3t3aWR0aDogMjAwfX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtpdGVtLmltYWdlfSBhbHQ9XCJORlRcIi8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0zIGJnLWJyYW5kX2JsYWNrIHB4LTJcIj5cclxuICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJ0ZXh0LW1kIGZvbnQtYm9sZFwiPntpdGVtLm5hbWV9PC9oNT5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9TbGlkZXI+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBORlRDYXJvdXNlbDtcclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcbmltcG9ydCB7IFdhbGxldE11bHRpQnV0dG9uIH0gZnJvbSAnQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC11aSdcclxuaW1wb3J0IHsgdXNlQ29ubmVjdGlvbiwgdXNlV2FsbGV0IH0gZnJvbSBcIkBzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3RcIjtcclxuaW1wb3J0IENvbm5lY3RUb1dhbGxldCBmcm9tICcuLi9Db25uZWN0VG9XYWxsZXQnO1xyXG5mdW5jdGlvbiBOYXZiYXIocHJvcHMpIHtcclxuICBjb25zdCB7IHB1YmxpY0tleSwgc2VuZFRyYW5zYWN0aW9uIH0gPSB1c2VXYWxsZXQoKTtcclxuICByZXR1cm4gKFxyXG4gICAgPG5hdiBjbGFzc05hbWU9XCJ0ZXh0LWJyYW5kX3doaXRlIHBiLTMgbWItMyB3LWZ1bGwgZmxleCBmbGV4LXdyYXAganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1icmFuZF9hY2NlbnRcIj5cclxuICAgICAgPENvbm5lY3RUb1dhbGxldCAvPlxyXG4gICAgICA8dWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgdy1mdWxsIHctZnVsbCBtZDp3LTgvMTIganVzdGlmeS1jZW50ZXIgbWQ6anVzdGlmeS1zdGFydFwiPlxyXG4gICAgICAgIDxsaSBjbGFzc05hbWU9XCJtZDptci00IGN1cnNvci1wb2ludGVyIHAtMyBmb250LWJvbGQgdXBwZXJjYXNlIFwiPlxyXG4gICAgICAgICAgPExpbmsgaHJlZj1cIi9kYXNoYm9hcmRcIj5cclxuICAgICAgICAgICAgPHNwYW4+RGFzaGJvYXJkPC9zcGFuPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvbGk+XHJcbiAgICAgICAgPGxpIGNsYXNzTmFtZT1cIm1kOm1yLTQgY3Vyc29yLXBvaW50ZXIgcC0zIGZvbnQtYm9sZCB1cHBlcmNhc2UgXCI+XHJcbiAgICAgICAgICA8TGluayBocmVmPVwiL3N0YWtpbmdcIj5cclxuICAgICAgICAgICAgPHNwYW4+U3Rha2luZzwvc3Bhbj5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L2xpPlxyXG4gICAgICA8L3VsPlxyXG5cclxuICAgICAge3B1YmxpY0tleSAmJiAoXHJcbiAgICAgICAgPGxpIGNsYXNzTmFtZT1cInBsLTQgcHktMSBmb250LWJvbGQgdXBwZXJjYXNlIHctZnVsbCBtZDp3LTQvMTIgZmxleCBqdXN0aWZ5LWNlbnRlciBtZDpqdXN0aWZ5LWVuZCBteS0zIG1kOm0tMFwiPlxyXG4gICAgICAgICAgPFdhbGxldE11bHRpQnV0dG9uIC8+XHJcbiAgICAgICAgPC9saT5cclxuICAgICAgKX1cclxuICAgIDwvbmF2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE5hdmJhciIsImltcG9ydCB7IHVzZVdhbGxldCB9IGZyb20gXCJAc29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0ICogYXMgYW5jaG9yIGZyb20gXCJAcHJvamVjdC1zZXJ1bS9hbmNob3JcIjtcclxuaW1wb3J0IHsgZXhpc3RzT3duZXJTUExUb2tlbiwgZ2V0TkZUc0Zvck93bmVyIH0gZnJvbSBcIi4uL3V0aWxzL2NhbmR5TWFjaGluZVwiO1xyXG5cclxuY29uc3QgcnBjSG9zdCA9IHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX1NPTEFOQV9SUENfSE9TVCE7XHJcbmNvbnN0IGNvbm5lY3Rpb24gPSBuZXcgYW5jaG9yLndlYjMuQ29ubmVjdGlvbihycGNIb3N0KTtcclxuXHJcbmNvbnN0IHVzZVdhbGxldE5mdHMgPSAocHJvcHM6IGFueSkgPT4ge1xyXG4gIGNvbnN0IHdhbGxldCA9IHVzZVdhbGxldCgpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzU1BMRXhpc3RzLCBzZXRTUExFeGlzdHNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbbmZ0cywgc2V0TmZ0c10gPSB1c2VTdGF0ZTxBcnJheTxhbnk+PihbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAoYXN5bmMgKCkgPT4ge1xyXG4gICAgICBpZiAoXHJcbiAgICAgICAgIXdhbGxldCB8fFxyXG4gICAgICAgICF3YWxsZXQucHVibGljS2V5IHx8XHJcbiAgICAgICAgIXdhbGxldC5zaWduQWxsVHJhbnNhY3Rpb25zIHx8XHJcbiAgICAgICAgIXdhbGxldC5zaWduVHJhbnNhY3Rpb25cclxuICAgICAgKSB7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICBjb25zdCBpc0V4aXN0U1BMVG9rZW4gPSBhd2FpdCBleGlzdHNPd25lclNQTFRva2VuKFxyXG4gICAgICAgIGNvbm5lY3Rpb24sXHJcbiAgICAgICAgd2FsbGV0LnB1YmxpY0tleVxyXG4gICAgICApO1xyXG4gICAgICBjb25zb2xlLmxvZyhcImlzU1BMRXhpc3RzIFwiICsgaXNTUExFeGlzdHMpO1xyXG4gICAgICBzZXRTUExFeGlzdHMoaXNFeGlzdFNQTFRva2VuKTtcclxuXHJcbiAgICAgIGNvbnN0IG5mdHNGb3JPd25lciA9IGF3YWl0IGdldE5GVHNGb3JPd25lcihjb25uZWN0aW9uLCB3YWxsZXQucHVibGljS2V5KTtcclxuXHJcbiAgICAgIHNldE5mdHMobmZ0c0Zvck93bmVyIGFzIGFueSk7XHJcbiAgICAgIC8vIGNvbnNvbGUubG9nKG5mdHNGb3JPd25lcik7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9KSgpO1xyXG4gIH0sIFt3YWxsZXRdKTtcclxuXHJcbiAgcmV0dXJuIFtpc0xvYWRpbmcsIG5mdHMsIGlzU1BMRXhpc3RzXTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHVzZVdhbGxldE5mdHM7XHJcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0cy5kZWZhdWx0ID0gdm9pZCAwO1xudmFyIF9yZWFjdCA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcInJlYWN0XCIpKTtcbnZhciBfcm91dGVyID0gcmVxdWlyZShcIi4uL3NoYXJlZC9saWIvcm91dGVyL3JvdXRlclwiKTtcbnZhciBfcm91dGVyMSA9IHJlcXVpcmUoXCIuL3JvdXRlclwiKTtcbnZhciBfdXNlSW50ZXJzZWN0aW9uID0gcmVxdWlyZShcIi4vdXNlLWludGVyc2VjdGlvblwiKTtcbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gICAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICAgICAgZGVmYXVsdDogb2JqXG4gICAgfTtcbn1cbmNvbnN0IHByZWZldGNoZWQgPSB7XG59O1xuZnVuY3Rpb24gcHJlZmV0Y2gocm91dGVyLCBocmVmLCBhcywgb3B0aW9ucykge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJyB8fCAhcm91dGVyKSByZXR1cm47XG4gICAgaWYgKCEoMCwgX3JvdXRlcikuaXNMb2NhbFVSTChocmVmKSkgcmV0dXJuO1xuICAgIC8vIFByZWZldGNoIHRoZSBKU09OIHBhZ2UgaWYgYXNrZWQgKG9ubHkgaW4gdGhlIGNsaWVudClcbiAgICAvLyBXZSBuZWVkIHRvIGhhbmRsZSBhIHByZWZldGNoIGVycm9yIGhlcmUgc2luY2Ugd2UgbWF5IGJlXG4gICAgLy8gbG9hZGluZyB3aXRoIHByaW9yaXR5IHdoaWNoIGNhbiByZWplY3QgYnV0IHdlIGRvbid0XG4gICAgLy8gd2FudCB0byBmb3JjZSBuYXZpZ2F0aW9uIHNpbmNlIHRoaXMgaXMgb25seSBhIHByZWZldGNoXG4gICAgcm91dGVyLnByZWZldGNoKGhyZWYsIGFzLCBvcHRpb25zKS5jYXRjaCgoZXJyKT0+e1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgLy8gcmV0aHJvdyB0byBzaG93IGludmFsaWQgVVJMIGVycm9yc1xuICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgY29uc3QgY3VyTG9jYWxlID0gb3B0aW9ucyAmJiB0eXBlb2Ygb3B0aW9ucy5sb2NhbGUgIT09ICd1bmRlZmluZWQnID8gb3B0aW9ucy5sb2NhbGUgOiByb3V0ZXIgJiYgcm91dGVyLmxvY2FsZTtcbiAgICAvLyBKb2luIG9uIGFuIGludmFsaWQgVVJJIGNoYXJhY3RlclxuICAgIHByZWZldGNoZWRbaHJlZiArICclJyArIGFzICsgKGN1ckxvY2FsZSA/ICclJyArIGN1ckxvY2FsZSA6ICcnKV0gPSB0cnVlO1xufVxuZnVuY3Rpb24gaXNNb2RpZmllZEV2ZW50KGV2ZW50KSB7XG4gICAgY29uc3QgeyB0YXJnZXQgIH0gPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgIHJldHVybiB0YXJnZXQgJiYgdGFyZ2V0ICE9PSAnX3NlbGYnIHx8IGV2ZW50Lm1ldGFLZXkgfHwgZXZlbnQuY3RybEtleSB8fCBldmVudC5zaGlmdEtleSB8fCBldmVudC5hbHRLZXkgfHwgZXZlbnQubmF0aXZlRXZlbnQgJiYgZXZlbnQubmF0aXZlRXZlbnQud2hpY2ggPT09IDI7XG59XG5mdW5jdGlvbiBsaW5rQ2xpY2tlZChlLCByb3V0ZXIsIGhyZWYsIGFzLCByZXBsYWNlLCBzaGFsbG93LCBzY3JvbGwsIGxvY2FsZSkge1xuICAgIGNvbnN0IHsgbm9kZU5hbWUgIH0gPSBlLmN1cnJlbnRUYXJnZXQ7XG4gICAgaWYgKG5vZGVOYW1lID09PSAnQScgJiYgKGlzTW9kaWZpZWRFdmVudChlKSB8fCAhKDAsIF9yb3V0ZXIpLmlzTG9jYWxVUkwoaHJlZikpKSB7XG4gICAgICAgIC8vIGlnbm9yZSBjbGljayBmb3IgYnJvd3NlcuKAmXMgZGVmYXVsdCBiZWhhdmlvclxuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAvLyAgYXZvaWQgc2Nyb2xsIGZvciB1cmxzIHdpdGggYW5jaG9yIHJlZnNcbiAgICBpZiAoc2Nyb2xsID09IG51bGwgJiYgYXMuaW5kZXhPZignIycpID49IDApIHtcbiAgICAgICAgc2Nyb2xsID0gZmFsc2U7XG4gICAgfVxuICAgIC8vIHJlcGxhY2Ugc3RhdGUgaW5zdGVhZCBvZiBwdXNoIGlmIHByb3AgaXMgcHJlc2VudFxuICAgIHJvdXRlcltyZXBsYWNlID8gJ3JlcGxhY2UnIDogJ3B1c2gnXShocmVmLCBhcywge1xuICAgICAgICBzaGFsbG93LFxuICAgICAgICBsb2NhbGUsXG4gICAgICAgIHNjcm9sbFxuICAgIH0pO1xufVxuZnVuY3Rpb24gTGluayhwcm9wcykge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGZ1bmN0aW9uIGNyZWF0ZVByb3BFcnJvcihhcmdzKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IEVycm9yKGBGYWlsZWQgcHJvcCB0eXBlOiBUaGUgcHJvcCBcXGAke2FyZ3Mua2V5fVxcYCBleHBlY3RzIGEgJHthcmdzLmV4cGVjdGVkfSBpbiBcXGA8TGluaz5cXGAsIGJ1dCBnb3QgXFxgJHthcmdzLmFjdHVhbH1cXGAgaW5zdGVhZC5gICsgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnID8gXCJcXG5PcGVuIHlvdXIgYnJvd3NlcidzIGNvbnNvbGUgdG8gdmlldyB0aGUgQ29tcG9uZW50IHN0YWNrIHRyYWNlLlwiIDogJycpKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuICAgICAgICBjb25zdCByZXF1aXJlZFByb3BzR3VhcmQgPSB7XG4gICAgICAgICAgICBocmVmOiB0cnVlXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHJlcXVpcmVkUHJvcHMgPSBPYmplY3Qua2V5cyhyZXF1aXJlZFByb3BzR3VhcmQpO1xuICAgICAgICByZXF1aXJlZFByb3BzLmZvckVhY2goKGtleSk9PntcbiAgICAgICAgICAgIGlmIChrZXkgPT09ICdocmVmJykge1xuICAgICAgICAgICAgICAgIGlmIChwcm9wc1trZXldID09IG51bGwgfHwgdHlwZW9mIHByb3BzW2tleV0gIT09ICdzdHJpbmcnICYmIHR5cGVvZiBwcm9wc1trZXldICE9PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBjcmVhdGVQcm9wRXJyb3Ioe1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0ZWQ6ICdgc3RyaW5nYCBvciBgb2JqZWN0YCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3R1YWw6IHByb3BzW2tleV0gPT09IG51bGwgPyAnbnVsbCcgOiB0eXBlb2YgcHJvcHNba2V5XVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIFR5cGVTY3JpcHQgdHJpY2sgZm9yIHR5cGUtZ3VhcmRpbmc6XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICAgICAgICAgICAgICAgIGNvbnN0IF8gPSBrZXk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICAvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuICAgICAgICBjb25zdCBvcHRpb25hbFByb3BzR3VhcmQgPSB7XG4gICAgICAgICAgICBhczogdHJ1ZSxcbiAgICAgICAgICAgIHJlcGxhY2U6IHRydWUsXG4gICAgICAgICAgICBzY3JvbGw6IHRydWUsXG4gICAgICAgICAgICBzaGFsbG93OiB0cnVlLFxuICAgICAgICAgICAgcGFzc0hyZWY6IHRydWUsXG4gICAgICAgICAgICBwcmVmZXRjaDogdHJ1ZSxcbiAgICAgICAgICAgIGxvY2FsZTogdHJ1ZVxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBvcHRpb25hbFByb3BzID0gT2JqZWN0LmtleXMob3B0aW9uYWxQcm9wc0d1YXJkKTtcbiAgICAgICAgb3B0aW9uYWxQcm9wcy5mb3JFYWNoKChrZXkpPT57XG4gICAgICAgICAgICBjb25zdCB2YWxUeXBlID0gdHlwZW9mIHByb3BzW2tleV07XG4gICAgICAgICAgICBpZiAoa2V5ID09PSAnYXMnKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb3BzW2tleV0gJiYgdmFsVHlwZSAhPT0gJ3N0cmluZycgJiYgdmFsVHlwZSAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgY3JlYXRlUHJvcEVycm9yKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkOiAnYHN0cmluZ2Agb3IgYG9iamVjdGAnLFxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0dWFsOiB2YWxUeXBlXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAoa2V5ID09PSAnbG9jYWxlJykge1xuICAgICAgICAgICAgICAgIGlmIChwcm9wc1trZXldICYmIHZhbFR5cGUgIT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IGNyZWF0ZVByb3BFcnJvcih7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBlY3RlZDogJ2BzdHJpbmdgJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdHVhbDogdmFsVHlwZVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGtleSA9PT0gJ3JlcGxhY2UnIHx8IGtleSA9PT0gJ3Njcm9sbCcgfHwga2V5ID09PSAnc2hhbGxvdycgfHwga2V5ID09PSAncGFzc0hyZWYnIHx8IGtleSA9PT0gJ3ByZWZldGNoJykge1xuICAgICAgICAgICAgICAgIGlmIChwcm9wc1trZXldICE9IG51bGwgJiYgdmFsVHlwZSAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IGNyZWF0ZVByb3BFcnJvcih7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBlY3RlZDogJ2Bib29sZWFuYCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3R1YWw6IHZhbFR5cGVcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbiAgICAgICAgICAgICAgICBjb25zdCBfID0ga2V5O1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgLy8gVGhpcyBob29rIGlzIGluIGEgY29uZGl0aW9uYWwgYnV0IHRoYXQgaXMgb2sgYmVjYXVzZSBgcHJvY2Vzcy5lbnYuTk9ERV9FTlZgIG5ldmVyIGNoYW5nZXNcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gICAgICAgIGNvbnN0IGhhc1dhcm5lZCA9IF9yZWFjdC5kZWZhdWx0LnVzZVJlZihmYWxzZSk7XG4gICAgICAgIGlmIChwcm9wcy5wcmVmZXRjaCAmJiAhaGFzV2FybmVkLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIGhhc1dhcm5lZC5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignTmV4dC5qcyBhdXRvLXByZWZldGNoZXMgYXV0b21hdGljYWxseSBiYXNlZCBvbiB2aWV3cG9ydC4gVGhlIHByZWZldGNoIGF0dHJpYnV0ZSBpcyBubyBsb25nZXIgbmVlZGVkLiBNb3JlOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9wcmVmZXRjaC10cnVlLWRlcHJlY2F0ZWQnKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBwID0gcHJvcHMucHJlZmV0Y2ggIT09IGZhbHNlO1xuICAgIGNvbnN0IHJvdXRlciA9ICgwLCBfcm91dGVyMSkudXNlUm91dGVyKCk7XG4gICAgY29uc3QgeyBocmVmICwgYXMgIH0gPSBfcmVhY3QuZGVmYXVsdC51c2VNZW1vKCgpPT57XG4gICAgICAgIGNvbnN0IFtyZXNvbHZlZEhyZWYsIHJlc29sdmVkQXNdID0gKDAsIF9yb3V0ZXIpLnJlc29sdmVIcmVmKHJvdXRlciwgcHJvcHMuaHJlZiwgdHJ1ZSk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBocmVmOiByZXNvbHZlZEhyZWYsXG4gICAgICAgICAgICBhczogcHJvcHMuYXMgPyAoMCwgX3JvdXRlcikucmVzb2x2ZUhyZWYocm91dGVyLCBwcm9wcy5hcykgOiByZXNvbHZlZEFzIHx8IHJlc29sdmVkSHJlZlxuICAgICAgICB9O1xuICAgIH0sIFtcbiAgICAgICAgcm91dGVyLFxuICAgICAgICBwcm9wcy5ocmVmLFxuICAgICAgICBwcm9wcy5hc1xuICAgIF0pO1xuICAgIGxldCB7IGNoaWxkcmVuICwgcmVwbGFjZSAsIHNoYWxsb3cgLCBzY3JvbGwgLCBsb2NhbGUgIH0gPSBwcm9wcztcbiAgICAvLyBEZXByZWNhdGVkLiBXYXJuaW5nIHNob3duIGJ5IHByb3BUeXBlIGNoZWNrLiBJZiB0aGUgY2hpbGRyZW4gcHJvdmlkZWQgaXMgYSBzdHJpbmcgKDxMaW5rPmV4YW1wbGU8L0xpbms+KSB3ZSB3cmFwIGl0IGluIGFuIDxhPiB0YWdcbiAgICBpZiAodHlwZW9mIGNoaWxkcmVuID09PSAnc3RyaW5nJykge1xuICAgICAgICBjaGlsZHJlbiA9IC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImFcIiwgbnVsbCwgY2hpbGRyZW4pO1xuICAgIH1cbiAgICAvLyBUaGlzIHdpbGwgcmV0dXJuIHRoZSBmaXJzdCBjaGlsZCwgaWYgbXVsdGlwbGUgYXJlIHByb3ZpZGVkIGl0IHdpbGwgdGhyb3cgYW4gZXJyb3JcbiAgICBsZXQgY2hpbGQ7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAnZGV2ZWxvcG1lbnQnKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjaGlsZCA9IF9yZWFjdC5kZWZhdWx0LkNoaWxkcmVuLm9ubHkoY2hpbGRyZW4pO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgTXVsdGlwbGUgY2hpbGRyZW4gd2VyZSBwYXNzZWQgdG8gPExpbms+IHdpdGggXFxgaHJlZlxcYCBvZiBcXGAke3Byb3BzLmhyZWZ9XFxgIGJ1dCBvbmx5IG9uZSBjaGlsZCBpcyBzdXBwb3J0ZWQgaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvbGluay1tdWx0aXBsZS1jaGlsZHJlbmAgKyAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyBcIiBcXG5PcGVuIHlvdXIgYnJvd3NlcidzIGNvbnNvbGUgdG8gdmlldyB0aGUgQ29tcG9uZW50IHN0YWNrIHRyYWNlLlwiIDogJycpKTtcbiAgICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAgIGNoaWxkID0gX3JlYWN0LmRlZmF1bHQuQ2hpbGRyZW4ub25seShjaGlsZHJlbik7XG4gICAgfVxuICAgIGNvbnN0IGNoaWxkUmVmID0gY2hpbGQgJiYgdHlwZW9mIGNoaWxkID09PSAnb2JqZWN0JyAmJiBjaGlsZC5yZWY7XG4gICAgY29uc3QgW3NldEludGVyc2VjdGlvblJlZiwgaXNWaXNpYmxlXSA9ICgwLCBfdXNlSW50ZXJzZWN0aW9uKS51c2VJbnRlcnNlY3Rpb24oe1xuICAgICAgICByb290TWFyZ2luOiAnMjAwcHgnXG4gICAgfSk7XG4gICAgY29uc3Qgc2V0UmVmID0gX3JlYWN0LmRlZmF1bHQudXNlQ2FsbGJhY2soKGVsKT0+e1xuICAgICAgICBzZXRJbnRlcnNlY3Rpb25SZWYoZWwpO1xuICAgICAgICBpZiAoY2hpbGRSZWYpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY2hpbGRSZWYgPT09ICdmdW5jdGlvbicpIGNoaWxkUmVmKGVsKTtcbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjaGlsZFJlZiA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgICBjaGlsZFJlZi5jdXJyZW50ID0gZWw7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbXG4gICAgICAgIGNoaWxkUmVmLFxuICAgICAgICBzZXRJbnRlcnNlY3Rpb25SZWZcbiAgICBdKTtcbiAgICBfcmVhY3QuZGVmYXVsdC51c2VFZmZlY3QoKCk9PntcbiAgICAgICAgY29uc3Qgc2hvdWxkUHJlZmV0Y2ggPSBpc1Zpc2libGUgJiYgcCAmJiAoMCwgX3JvdXRlcikuaXNMb2NhbFVSTChocmVmKTtcbiAgICAgICAgY29uc3QgY3VyTG9jYWxlID0gdHlwZW9mIGxvY2FsZSAhPT0gJ3VuZGVmaW5lZCcgPyBsb2NhbGUgOiByb3V0ZXIgJiYgcm91dGVyLmxvY2FsZTtcbiAgICAgICAgY29uc3QgaXNQcmVmZXRjaGVkID0gcHJlZmV0Y2hlZFtocmVmICsgJyUnICsgYXMgKyAoY3VyTG9jYWxlID8gJyUnICsgY3VyTG9jYWxlIDogJycpXTtcbiAgICAgICAgaWYgKHNob3VsZFByZWZldGNoICYmICFpc1ByZWZldGNoZWQpIHtcbiAgICAgICAgICAgIHByZWZldGNoKHJvdXRlciwgaHJlZiwgYXMsIHtcbiAgICAgICAgICAgICAgICBsb2NhbGU6IGN1ckxvY2FsZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9LCBbXG4gICAgICAgIGFzLFxuICAgICAgICBocmVmLFxuICAgICAgICBpc1Zpc2libGUsXG4gICAgICAgIGxvY2FsZSxcbiAgICAgICAgcCxcbiAgICAgICAgcm91dGVyXG4gICAgXSk7XG4gICAgY29uc3QgY2hpbGRQcm9wcyA9IHtcbiAgICAgICAgcmVmOiBzZXRSZWYsXG4gICAgICAgIG9uQ2xpY2s6IChlKT0+e1xuICAgICAgICAgICAgaWYgKGNoaWxkLnByb3BzICYmIHR5cGVvZiBjaGlsZC5wcm9wcy5vbkNsaWNrID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgY2hpbGQucHJvcHMub25DbGljayhlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghZS5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgICAgICAgICAgbGlua0NsaWNrZWQoZSwgcm91dGVyLCBocmVmLCBhcywgcmVwbGFjZSwgc2hhbGxvdywgc2Nyb2xsLCBsb2NhbGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjaGlsZFByb3BzLm9uTW91c2VFbnRlciA9IChlKT0+e1xuICAgICAgICBpZiAoISgwLCBfcm91dGVyKS5pc0xvY2FsVVJMKGhyZWYpKSByZXR1cm47XG4gICAgICAgIGlmIChjaGlsZC5wcm9wcyAmJiB0eXBlb2YgY2hpbGQucHJvcHMub25Nb3VzZUVudGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBjaGlsZC5wcm9wcy5vbk1vdXNlRW50ZXIoZSk7XG4gICAgICAgIH1cbiAgICAgICAgcHJlZmV0Y2gocm91dGVyLCBocmVmLCBhcywge1xuICAgICAgICAgICAgcHJpb3JpdHk6IHRydWVcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICAvLyBJZiBjaGlsZCBpcyBhbiA8YT4gdGFnIGFuZCBkb2Vzbid0IGhhdmUgYSBocmVmIGF0dHJpYnV0ZSwgb3IgaWYgdGhlICdwYXNzSHJlZicgcHJvcGVydHkgaXNcbiAgICAvLyBkZWZpbmVkLCB3ZSBzcGVjaWZ5IHRoZSBjdXJyZW50ICdocmVmJywgc28gdGhhdCByZXBldGl0aW9uIGlzIG5vdCBuZWVkZWQgYnkgdGhlIHVzZXJcbiAgICBpZiAocHJvcHMucGFzc0hyZWYgfHwgY2hpbGQudHlwZSA9PT0gJ2EnICYmICEoJ2hyZWYnIGluIGNoaWxkLnByb3BzKSkge1xuICAgICAgICBjb25zdCBjdXJMb2NhbGUgPSB0eXBlb2YgbG9jYWxlICE9PSAndW5kZWZpbmVkJyA/IGxvY2FsZSA6IHJvdXRlciAmJiByb3V0ZXIubG9jYWxlO1xuICAgICAgICAvLyB3ZSBvbmx5IHJlbmRlciBkb21haW4gbG9jYWxlcyBpZiB3ZSBhcmUgY3VycmVudGx5IG9uIGEgZG9tYWluIGxvY2FsZVxuICAgICAgICAvLyBzbyB0aGF0IGxvY2FsZSBsaW5rcyBhcmUgc3RpbGwgdmlzaXRhYmxlIGluIGRldmVsb3BtZW50L3ByZXZpZXcgZW52c1xuICAgICAgICBjb25zdCBsb2NhbGVEb21haW4gPSByb3V0ZXIgJiYgcm91dGVyLmlzTG9jYWxlRG9tYWluICYmICgwLCBfcm91dGVyKS5nZXREb21haW5Mb2NhbGUoYXMsIGN1ckxvY2FsZSwgcm91dGVyICYmIHJvdXRlci5sb2NhbGVzLCByb3V0ZXIgJiYgcm91dGVyLmRvbWFpbkxvY2FsZXMpO1xuICAgICAgICBjaGlsZFByb3BzLmhyZWYgPSBsb2NhbGVEb21haW4gfHwgKDAsIF9yb3V0ZXIpLmFkZEJhc2VQYXRoKCgwLCBfcm91dGVyKS5hZGRMb2NhbGUoYXMsIGN1ckxvY2FsZSwgcm91dGVyICYmIHJvdXRlci5kZWZhdWx0TG9jYWxlKSk7XG4gICAgfVxuICAgIHJldHVybigvKiNfX1BVUkVfXyovIF9yZWFjdC5kZWZhdWx0LmNsb25lRWxlbWVudChjaGlsZCwgY2hpbGRQcm9wcykpO1xufVxudmFyIF9kZWZhdWx0ID0gTGluaztcbmV4cG9ydHMuZGVmYXVsdCA9IF9kZWZhdWx0O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1saW5rLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0cy5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaCA9IHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoO1xuZXhwb3J0cy5ub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaCA9IHZvaWQgMDtcbmZ1bmN0aW9uIHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGgpIHtcbiAgICByZXR1cm4gcGF0aC5lbmRzV2l0aCgnLycpICYmIHBhdGggIT09ICcvJyA/IHBhdGguc2xpY2UoMCwgLTEpIDogcGF0aDtcbn1cbmNvbnN0IG5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoID0gcHJvY2Vzcy5lbnYuX19ORVhUX1RSQUlMSU5HX1NMQVNIID8gKHBhdGgpPT57XG4gICAgaWYgKC9cXC5bXi9dK1xcLz8kLy50ZXN0KHBhdGgpKSB7XG4gICAgICAgIHJldHVybiByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRoKTtcbiAgICB9IGVsc2UgaWYgKHBhdGguZW5kc1dpdGgoJy8nKSkge1xuICAgICAgICByZXR1cm4gcGF0aDtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gcGF0aCArICcvJztcbiAgICB9XG59IDogcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2g7XG5leHBvcnRzLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoID0gbm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2g7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vcm1hbGl6ZS10cmFpbGluZy1zbGFzaC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICAgIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHMucmVxdWVzdElkbGVDYWxsYmFjayA9IGV4cG9ydHMuY2FuY2VsSWRsZUNhbGxiYWNrID0gdm9pZCAwO1xuY29uc3QgcmVxdWVzdElkbGVDYWxsYmFjayA9IHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyAmJiBzZWxmLnJlcXVlc3RJZGxlQ2FsbGJhY2sgJiYgc2VsZi5yZXF1ZXN0SWRsZUNhbGxiYWNrLmJpbmQod2luZG93KSB8fCBmdW5jdGlvbihjYikge1xuICAgIGxldCBzdGFydCA9IERhdGUubm93KCk7XG4gICAgcmV0dXJuIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgIGNiKHtcbiAgICAgICAgICAgIGRpZFRpbWVvdXQ6IGZhbHNlLFxuICAgICAgICAgICAgdGltZVJlbWFpbmluZzogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIE1hdGgubWF4KDAsIDUwIC0gKERhdGUubm93KCkgLSBzdGFydCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9LCAxKTtcbn07XG5leHBvcnRzLnJlcXVlc3RJZGxlQ2FsbGJhY2sgPSByZXF1ZXN0SWRsZUNhbGxiYWNrO1xuY29uc3QgY2FuY2VsSWRsZUNhbGxiYWNrID0gdHlwZW9mIHNlbGYgIT09ICd1bmRlZmluZWQnICYmIHNlbGYuY2FuY2VsSWRsZUNhbGxiYWNrICYmIHNlbGYuY2FuY2VsSWRsZUNhbGxiYWNrLmJpbmQod2luZG93KSB8fCBmdW5jdGlvbihpZCkge1xuICAgIHJldHVybiBjbGVhclRpbWVvdXQoaWQpO1xufTtcbmV4cG9ydHMuY2FuY2VsSWRsZUNhbGxiYWNrID0gY2FuY2VsSWRsZUNhbGxiYWNrO1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZXF1ZXN0LWlkbGUtY2FsbGJhY2suanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLm1hcmtBc3NldEVycm9yID0gbWFya0Fzc2V0RXJyb3I7XG5leHBvcnRzLmlzQXNzZXRFcnJvciA9IGlzQXNzZXRFcnJvcjtcbmV4cG9ydHMuZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCA9IGdldENsaWVudEJ1aWxkTWFuaWZlc3Q7XG5leHBvcnRzLmNyZWF0ZVJvdXRlTG9hZGVyID0gY3JlYXRlUm91dGVMb2FkZXI7XG52YXIgX2dldEFzc2V0UGF0aEZyb21Sb3V0ZSA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4uL3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL2dldC1hc3NldC1wYXRoLWZyb20tcm91dGVcIikpO1xudmFyIF9yZXF1ZXN0SWRsZUNhbGxiYWNrID0gcmVxdWlyZShcIi4vcmVxdWVzdC1pZGxlLWNhbGxiYWNrXCIpO1xuZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChvYmopIHtcbiAgICByZXR1cm4gb2JqICYmIG9iai5fX2VzTW9kdWxlID8gb2JqIDoge1xuICAgICAgICBkZWZhdWx0OiBvYmpcbiAgICB9O1xufVxuLy8gMy44cyB3YXMgYXJiaXRyYXJpbHkgY2hvc2VuIGFzIGl0J3Mgd2hhdCBodHRwczovL3dlYi5kZXYvaW50ZXJhY3RpdmVcbi8vIGNvbnNpZGVycyBhcyBcIkdvb2RcIiB0aW1lLXRvLWludGVyYWN0aXZlLiBXZSBtdXN0IGFzc3VtZSBzb21ldGhpbmcgd2VudFxuLy8gd3JvbmcgYmV5b25kIHRoaXMgcG9pbnQsIGFuZCB0aGVuIGZhbGwtYmFjayB0byBhIGZ1bGwgcGFnZSB0cmFuc2l0aW9uIHRvXG4vLyBzaG93IHRoZSB1c2VyIHNvbWV0aGluZyBvZiB2YWx1ZS5cbmNvbnN0IE1TX01BWF9JRExFX0RFTEFZID0gMzgwMDtcbmZ1bmN0aW9uIHdpdGhGdXR1cmUoa2V5LCBtYXAsIGdlbmVyYXRvcikge1xuICAgIGxldCBlbnRyeSA9IG1hcC5nZXQoa2V5KTtcbiAgICBpZiAoZW50cnkpIHtcbiAgICAgICAgaWYgKCdmdXR1cmUnIGluIGVudHJ5KSB7XG4gICAgICAgICAgICByZXR1cm4gZW50cnkuZnV0dXJlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoZW50cnkpO1xuICAgIH1cbiAgICBsZXQgcmVzb2x2ZXI7XG4gICAgY29uc3QgcHJvbSA9IG5ldyBQcm9taXNlKChyZXNvbHZlKT0+e1xuICAgICAgICByZXNvbHZlciA9IHJlc29sdmU7XG4gICAgfSk7XG4gICAgbWFwLnNldChrZXksIGVudHJ5ID0ge1xuICAgICAgICByZXNvbHZlOiByZXNvbHZlcixcbiAgICAgICAgZnV0dXJlOiBwcm9tXG4gICAgfSk7XG4gICAgcmV0dXJuIGdlbmVyYXRvciA/IGdlbmVyYXRvcigpLnRoZW4oKHZhbHVlKT0+KHJlc29sdmVyKHZhbHVlKSwgdmFsdWUpXG4gICAgKSA6IHByb207XG59XG5mdW5jdGlvbiBoYXNQcmVmZXRjaChsaW5rKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpbmsnKTtcbiAgICAgICAgcmV0dXJuKC8vIGRldGVjdCBJRTExIHNpbmNlIGl0IHN1cHBvcnRzIHByZWZldGNoIGJ1dCBpc24ndCBkZXRlY3RlZFxuICAgICAgICAvLyB3aXRoIHJlbExpc3Quc3VwcG9ydFxuICAgICAgICAoISF3aW5kb3cuTVNJbnB1dE1ldGhvZENvbnRleHQgJiYgISFkb2N1bWVudC5kb2N1bWVudE1vZGUpIHx8IGxpbmsucmVsTGlzdC5zdXBwb3J0cygncHJlZmV0Y2gnKSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufVxuY29uc3QgY2FuUHJlZmV0Y2ggPSBoYXNQcmVmZXRjaCgpO1xuZnVuY3Rpb24gcHJlZmV0Y2hWaWFEb20oaHJlZiwgYXMsIGxpbmspIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlcywgcmVqKT0+e1xuICAgICAgICBpZiAoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihgbGlua1tyZWw9XCJwcmVmZXRjaFwiXVtocmVmXj1cIiR7aHJlZn1cIl1gKSkge1xuICAgICAgICAgICAgcmV0dXJuIHJlcygpO1xuICAgICAgICB9XG4gICAgICAgIGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaW5rJyk7XG4gICAgICAgIC8vIFRoZSBvcmRlciBvZiBwcm9wZXJ0eSBhc3NpZ25tZW50IGhlcmUgaXMgaW50ZW50aW9uYWw6XG4gICAgICAgIGlmIChhcykgbGluay5hcyA9IGFzO1xuICAgICAgICBsaW5rLnJlbCA9IGBwcmVmZXRjaGA7XG4gICAgICAgIGxpbmsuY3Jvc3NPcmlnaW4gPSBwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOO1xuICAgICAgICBsaW5rLm9ubG9hZCA9IHJlcztcbiAgICAgICAgbGluay5vbmVycm9yID0gcmVqO1xuICAgICAgICAvLyBgaHJlZmAgc2hvdWxkIGFsd2F5cyBiZSBsYXN0OlxuICAgICAgICBsaW5rLmhyZWYgPSBocmVmO1xuICAgICAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKGxpbmspO1xuICAgIH0pO1xufVxuY29uc3QgQVNTRVRfTE9BRF9FUlJPUiA9IFN5bWJvbCgnQVNTRVRfTE9BRF9FUlJPUicpO1xuZnVuY3Rpb24gbWFya0Fzc2V0RXJyb3IoZXJyKSB7XG4gICAgcmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlcnIsIEFTU0VUX0xPQURfRVJST1IsIHtcbiAgICB9KTtcbn1cbmZ1bmN0aW9uIGlzQXNzZXRFcnJvcihlcnIpIHtcbiAgICByZXR1cm4gZXJyICYmIEFTU0VUX0xPQURfRVJST1IgaW4gZXJyO1xufVxuZnVuY3Rpb24gYXBwZW5kU2NyaXB0KHNyYywgc2NyaXB0KSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpPT57XG4gICAgICAgIHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpO1xuICAgICAgICAvLyBUaGUgb3JkZXIgb2YgcHJvcGVydHkgYXNzaWdubWVudCBoZXJlIGlzIGludGVudGlvbmFsLlxuICAgICAgICAvLyAxLiBTZXR1cCBzdWNjZXNzL2ZhaWx1cmUgaG9va3MgaW4gY2FzZSB0aGUgYnJvd3NlciBzeW5jaHJvbm91c2x5XG4gICAgICAgIC8vICAgIGV4ZWN1dGVzIHdoZW4gYHNyY2AgaXMgc2V0LlxuICAgICAgICBzY3JpcHQub25sb2FkID0gcmVzb2x2ZTtcbiAgICAgICAgc2NyaXB0Lm9uZXJyb3IgPSAoKT0+cmVqZWN0KG1hcmtBc3NldEVycm9yKG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc2NyaXB0OiAke3NyY31gKSkpXG4gICAgICAgIDtcbiAgICAgICAgLy8gMi4gQ29uZmlndXJlIHRoZSBjcm9zcy1vcmlnaW4gYXR0cmlidXRlIGJlZm9yZSBzZXR0aW5nIGBzcmNgIGluIGNhc2UgdGhlXG4gICAgICAgIC8vICAgIGJyb3dzZXIgYmVnaW5zIHRvIGZldGNoLlxuICAgICAgICBzY3JpcHQuY3Jvc3NPcmlnaW4gPSBwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOO1xuICAgICAgICAvLyAzLiBGaW5hbGx5LCBzZXQgdGhlIHNvdXJjZSBhbmQgaW5qZWN0IGludG8gdGhlIERPTSBpbiBjYXNlIHRoZSBjaGlsZFxuICAgICAgICAvLyAgICBtdXN0IGJlIGFwcGVuZGVkIGZvciBmZXRjaGluZyB0byBzdGFydC5cbiAgICAgICAgc2NyaXB0LnNyYyA9IHNyYztcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChzY3JpcHQpO1xuICAgIH0pO1xufVxuLy8gV2Ugd2FpdCBmb3IgcGFnZXMgdG8gYmUgYnVpbHQgaW4gZGV2IGJlZm9yZSB3ZSBzdGFydCB0aGUgcm91dGUgdHJhbnNpdGlvblxuLy8gdGltZW91dCB0byBwcmV2ZW50IGFuIHVuLW5lY2Vzc2FyeSBoYXJkIG5hdmlnYXRpb24gaW4gZGV2ZWxvcG1lbnQuXG5sZXQgZGV2QnVpbGRQcm9taXNlO1xuLy8gUmVzb2x2ZSBhIHByb21pc2UgdGhhdCB0aW1lcyBvdXQgYWZ0ZXIgZ2l2ZW4gYW1vdW50IG9mIG1pbGxpc2Vjb25kcy5cbmZ1bmN0aW9uIHJlc29sdmVQcm9taXNlV2l0aFRpbWVvdXQocCwgbXMsIGVycikge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KT0+e1xuICAgICAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgICAgIHAudGhlbigocik9PntcbiAgICAgICAgICAgIC8vIFJlc29sdmVkLCBjYW5jZWwgdGhlIHRpbWVvdXRcbiAgICAgICAgICAgIGNhbmNlbGxlZCA9IHRydWU7XG4gICAgICAgICAgICByZXNvbHZlKHIpO1xuICAgICAgICB9KS5jYXRjaChyZWplY3QpO1xuICAgICAgICAvLyBXZSB3cmFwIHRoZXNlIGNoZWNrcyBzZXBhcmF0ZWx5IGZvciBiZXR0ZXIgZGVhZC1jb2RlIGVsaW1pbmF0aW9uIGluXG4gICAgICAgIC8vIHByb2R1Y3Rpb24gYnVuZGxlcy5cbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAnZGV2ZWxvcG1lbnQnKSB7XG4gICAgICAgICAgICAoZGV2QnVpbGRQcm9taXNlIHx8IFByb21pc2UucmVzb2x2ZSgpKS50aGVuKCgpPT57XG4gICAgICAgICAgICAgICAgKDAsIF9yZXF1ZXN0SWRsZUNhbGxiYWNrKS5yZXF1ZXN0SWRsZUNhbGxiYWNrKCgpPT5zZXRUaW1lb3V0KCgpPT57XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWNhbmNlbGxlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9LCBtcylcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAnZGV2ZWxvcG1lbnQnKSB7XG4gICAgICAgICAgICAoMCwgX3JlcXVlc3RJZGxlQ2FsbGJhY2spLnJlcXVlc3RJZGxlQ2FsbGJhY2soKCk9PnNldFRpbWVvdXQoKCk9PntcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSwgbXMpXG4gICAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgfSk7XG59XG5mdW5jdGlvbiBnZXRDbGllbnRCdWlsZE1hbmlmZXN0KCkge1xuICAgIGlmIChzZWxmLl9fQlVJTERfTUFOSUZFU1QpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShzZWxmLl9fQlVJTERfTUFOSUZFU1QpO1xuICAgIH1cbiAgICBjb25zdCBvbkJ1aWxkTWFuaWZlc3QgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSk9PntcbiAgICAgICAgLy8gTWFuZGF0b3J5IGJlY2F1c2UgdGhpcyBpcyBub3QgY29uY3VycmVudCBzYWZlOlxuICAgICAgICBjb25zdCBjYiA9IHNlbGYuX19CVUlMRF9NQU5JRkVTVF9DQjtcbiAgICAgICAgc2VsZi5fX0JVSUxEX01BTklGRVNUX0NCID0gKCk9PntcbiAgICAgICAgICAgIHJlc29sdmUoc2VsZi5fX0JVSUxEX01BTklGRVNUKTtcbiAgICAgICAgICAgIGNiICYmIGNiKCk7XG4gICAgICAgIH07XG4gICAgfSk7XG4gICAgcmV0dXJuIHJlc29sdmVQcm9taXNlV2l0aFRpbWVvdXQob25CdWlsZE1hbmlmZXN0LCBNU19NQVhfSURMRV9ERUxBWSwgbWFya0Fzc2V0RXJyb3IobmV3IEVycm9yKCdGYWlsZWQgdG8gbG9hZCBjbGllbnQgYnVpbGQgbWFuaWZlc3QnKSkpO1xufVxuZnVuY3Rpb24gZ2V0RmlsZXNGb3JSb3V0ZShhc3NldFByZWZpeCwgcm91dGUpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh7XG4gICAgICAgICAgICBzY3JpcHRzOiBbXG4gICAgICAgICAgICAgICAgYXNzZXRQcmVmaXggKyAnL19uZXh0L3N0YXRpYy9jaHVua3MvcGFnZXMnICsgZW5jb2RlVVJJKCgwLCBfZ2V0QXNzZXRQYXRoRnJvbVJvdXRlKS5kZWZhdWx0KHJvdXRlLCAnLmpzJykpLCBcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAvLyBTdHlsZXMgYXJlIGhhbmRsZWQgYnkgYHN0eWxlLWxvYWRlcmAgaW4gZGV2ZWxvcG1lbnQ6XG4gICAgICAgICAgICBjc3M6IFtdXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCgpLnRoZW4oKG1hbmlmZXN0KT0+e1xuICAgICAgICBpZiAoIShyb3V0ZSBpbiBtYW5pZmVzdCkpIHtcbiAgICAgICAgICAgIHRocm93IG1hcmtBc3NldEVycm9yKG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvb2t1cCByb3V0ZTogJHtyb3V0ZX1gKSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYWxsRmlsZXMgPSBtYW5pZmVzdFtyb3V0ZV0ubWFwKChlbnRyeSk9PmFzc2V0UHJlZml4ICsgJy9fbmV4dC8nICsgZW5jb2RlVVJJKGVudHJ5KVxuICAgICAgICApO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc2NyaXB0czogYWxsRmlsZXMuZmlsdGVyKCh2KT0+di5lbmRzV2l0aCgnLmpzJylcbiAgICAgICAgICAgICksXG4gICAgICAgICAgICBjc3M6IGFsbEZpbGVzLmZpbHRlcigodik9PnYuZW5kc1dpdGgoJy5jc3MnKVxuICAgICAgICAgICAgKVxuICAgICAgICB9O1xuICAgIH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlUm91dGVMb2FkZXIoYXNzZXRQcmVmaXgpIHtcbiAgICBjb25zdCBlbnRyeXBvaW50cyA9IG5ldyBNYXAoKTtcbiAgICBjb25zdCBsb2FkZWRTY3JpcHRzID0gbmV3IE1hcCgpO1xuICAgIGNvbnN0IHN0eWxlU2hlZXRzID0gbmV3IE1hcCgpO1xuICAgIGNvbnN0IHJvdXRlcyA9IG5ldyBNYXAoKTtcbiAgICBmdW5jdGlvbiBtYXliZUV4ZWN1dGVTY3JpcHQoc3JjKSB7XG4gICAgICAgIGxldCBwcm9tID0gbG9hZGVkU2NyaXB0cy5nZXQoc3JjKTtcbiAgICAgICAgaWYgKHByb20pIHtcbiAgICAgICAgICAgIHJldHVybiBwcm9tO1xuICAgICAgICB9XG4gICAgICAgIC8vIFNraXAgZXhlY3V0aW5nIHNjcmlwdCBpZiBpdCdzIGFscmVhZHkgaW4gdGhlIERPTTpcbiAgICAgICAgaWYgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYHNjcmlwdFtzcmNePVwiJHtzcmN9XCJdYCkpIHtcbiAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICAgICAgfVxuICAgICAgICBsb2FkZWRTY3JpcHRzLnNldChzcmMsIHByb20gPSBhcHBlbmRTY3JpcHQoc3JjKSk7XG4gICAgICAgIHJldHVybiBwcm9tO1xuICAgIH1cbiAgICBmdW5jdGlvbiBmZXRjaFN0eWxlU2hlZXQoaHJlZikge1xuICAgICAgICBsZXQgcHJvbSA9IHN0eWxlU2hlZXRzLmdldChocmVmKTtcbiAgICAgICAgaWYgKHByb20pIHtcbiAgICAgICAgICAgIHJldHVybiBwcm9tO1xuICAgICAgICB9XG4gICAgICAgIHN0eWxlU2hlZXRzLnNldChocmVmLCBwcm9tID0gZmV0Y2goaHJlZikudGhlbigocmVzKT0+e1xuICAgICAgICAgICAgaWYgKCFyZXMub2spIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBsb2FkIHN0eWxlc2hlZXQ6ICR7aHJlZn1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXMudGV4dCgpLnRoZW4oKHRleHQpPT4oe1xuICAgICAgICAgICAgICAgICAgICBocmVmOiBocmVmLFxuICAgICAgICAgICAgICAgICAgICBjb250ZW50OiB0ZXh0XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICk7XG4gICAgICAgIH0pLmNhdGNoKChlcnIpPT57XG4gICAgICAgICAgICB0aHJvdyBtYXJrQXNzZXRFcnJvcihlcnIpO1xuICAgICAgICB9KSk7XG4gICAgICAgIHJldHVybiBwcm9tO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICB3aGVuRW50cnlwb2ludCAocm91dGUpIHtcbiAgICAgICAgICAgIHJldHVybiB3aXRoRnV0dXJlKHJvdXRlLCBlbnRyeXBvaW50cyk7XG4gICAgICAgIH0sXG4gICAgICAgIG9uRW50cnlwb2ludCAocm91dGUsIGV4ZWN1dGUpIHtcbiAgICAgICAgICAgIFByb21pc2UucmVzb2x2ZShleGVjdXRlKS50aGVuKChmbik9PmZuKClcbiAgICAgICAgICAgICkudGhlbigoZXhwb3J0cyk9Pih7XG4gICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudDogZXhwb3J0cyAmJiBleHBvcnRzLmRlZmF1bHQgfHwgZXhwb3J0cyxcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0czogZXhwb3J0c1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAsIChlcnIpPT4oe1xuICAgICAgICAgICAgICAgICAgICBlcnJvcjogZXJyXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICkudGhlbigoaW5wdXQpPT57XG4gICAgICAgICAgICAgICAgY29uc3Qgb2xkID0gZW50cnlwb2ludHMuZ2V0KHJvdXRlKTtcbiAgICAgICAgICAgICAgICBlbnRyeXBvaW50cy5zZXQocm91dGUsIGlucHV0KTtcbiAgICAgICAgICAgICAgICBpZiAob2xkICYmICdyZXNvbHZlJyBpbiBvbGQpIG9sZC5yZXNvbHZlKGlucHV0KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgICBsb2FkUm91dGUgKHJvdXRlLCBwcmVmZXRjaCkge1xuICAgICAgICAgICAgcmV0dXJuIHdpdGhGdXR1cmUocm91dGUsIHJvdXRlcywgKCk9PntcbiAgICAgICAgICAgICAgICBjb25zdCByb3V0ZUZpbGVzUHJvbWlzZSA9IGdldEZpbGVzRm9yUm91dGUoYXNzZXRQcmVmaXgsIHJvdXRlKS50aGVuKCh7IHNjcmlwdHMgLCBjc3MgIH0pPT57XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICAgICAgICAgICAgICBlbnRyeXBvaW50cy5oYXMocm91dGUpID8gW10gOiBQcm9taXNlLmFsbChzY3JpcHRzLm1hcChtYXliZUV4ZWN1dGVTY3JpcHQpKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFByb21pc2UuYWxsKGNzcy5tYXAoZmV0Y2hTdHlsZVNoZWV0KSksIFxuICAgICAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgICAgICB9KS50aGVuKChyZXMpPT57XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndoZW5FbnRyeXBvaW50KHJvdXRlKS50aGVuKChlbnRyeXBvaW50KT0+KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyeXBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlczogcmVzWzFdXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ2RldmVsb3BtZW50Jykge1xuICAgICAgICAgICAgICAgICAgICBkZXZCdWlsZFByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSk9PntcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyb3V0ZUZpbGVzUHJvbWlzZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByb3V0ZUZpbGVzUHJvbWlzZS5maW5hbGx5KCgpPT57XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiByZXNvbHZlUHJvbWlzZVdpdGhUaW1lb3V0KHJvdXRlRmlsZXNQcm9taXNlLCBNU19NQVhfSURMRV9ERUxBWSwgbWFya0Fzc2V0RXJyb3IobmV3IEVycm9yKGBSb3V0ZSBkaWQgbm90IGNvbXBsZXRlIGxvYWRpbmc6ICR7cm91dGV9YCkpKS50aGVuKCh7IGVudHJ5cG9pbnQgLCBzdHlsZXMgIH0pPT57XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IE9iamVjdC5hc3NpZ24oe1xuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGVzOiBzdHlsZXNcbiAgICAgICAgICAgICAgICAgICAgfSwgZW50cnlwb2ludCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAnZXJyb3InIGluIGVudHJ5cG9pbnQgPyBlbnRyeXBvaW50IDogcmVzO1xuICAgICAgICAgICAgICAgIH0pLmNhdGNoKChlcnIpPT57XG4gICAgICAgICAgICAgICAgICAgIGlmIChwcmVmZXRjaCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gd2UgZG9uJ3Qgd2FudCB0byBjYWNoZSBlcnJvcnMgZHVyaW5nIHByZWZldGNoXG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yOiBlcnJcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgICBwcmVmZXRjaCAocm91dGUpIHtcbiAgICAgICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWVMYWJzL3F1aWNrbGluay9ibG9iLzQ1M2E2NjFmYTFmYTk0MGUyZDJlMDQ0NDUyMzk4ZTM4YzY3YTk4ZmIvc3JjL2luZGV4Lm1qcyNMMTE1LUwxMThcbiAgICAgICAgICAgIC8vIExpY2Vuc2U6IEFwYWNoZSAyLjBcbiAgICAgICAgICAgIGxldCBjbjtcbiAgICAgICAgICAgIGlmIChjbiA9IG5hdmlnYXRvci5jb25uZWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgLy8gRG9uJ3QgcHJlZmV0Y2ggaWYgdXNpbmcgMkcgb3IgaWYgU2F2ZS1EYXRhIGlzIGVuYWJsZWQuXG4gICAgICAgICAgICAgICAgaWYgKGNuLnNhdmVEYXRhIHx8IC8yZy8udGVzdChjbi5lZmZlY3RpdmVUeXBlKSkgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGdldEZpbGVzRm9yUm91dGUoYXNzZXRQcmVmaXgsIHJvdXRlKS50aGVuKChvdXRwdXQpPT5Qcm9taXNlLmFsbChjYW5QcmVmZXRjaCA/IG91dHB1dC5zY3JpcHRzLm1hcCgoc2NyaXB0KT0+cHJlZmV0Y2hWaWFEb20oc2NyaXB0LCAnc2NyaXB0JylcbiAgICAgICAgICAgICAgICApIDogW10pXG4gICAgICAgICAgICApLnRoZW4oKCk9PntcbiAgICAgICAgICAgICAgICAoMCwgX3JlcXVlc3RJZGxlQ2FsbGJhY2spLnJlcXVlc3RJZGxlQ2FsbGJhY2soKCk9PnRoaXMubG9hZFJvdXRlKHJvdXRlLCB0cnVlKS5jYXRjaCgoKT0+e1xuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KS5jYXRjaCgvLyBzd2FsbG93IHByZWZldGNoIGVycm9yc1xuICAgICAgICAgICAgKCk9PntcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfTtcbn1cblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGUtbG9hZGVyLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiUm91dGVyXCIsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBfcm91dGVyLmRlZmF1bHQ7XG4gICAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJ3aXRoUm91dGVyXCIsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBfd2l0aFJvdXRlci5kZWZhdWx0O1xuICAgIH1cbn0pO1xuZXhwb3J0cy51c2VSb3V0ZXIgPSB1c2VSb3V0ZXI7XG5leHBvcnRzLmNyZWF0ZVJvdXRlciA9IGNyZWF0ZVJvdXRlcjtcbmV4cG9ydHMubWFrZVB1YmxpY1JvdXRlckluc3RhbmNlID0gbWFrZVB1YmxpY1JvdXRlckluc3RhbmNlO1xuZXhwb3J0cy5kZWZhdWx0ID0gdm9pZCAwO1xudmFyIF9yZWFjdCA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcInJlYWN0XCIpKTtcbnZhciBfcm91dGVyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi4vc2hhcmVkL2xpYi9yb3V0ZXIvcm91dGVyXCIpKTtcbnZhciBfcm91dGVyQ29udGV4dCA9IHJlcXVpcmUoXCIuLi9zaGFyZWQvbGliL3JvdXRlci1jb250ZXh0XCIpO1xudmFyIF93aXRoUm91dGVyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi93aXRoLXJvdXRlclwiKSk7XG5mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICAgIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgICAgIGRlZmF1bHQ6IG9ialxuICAgIH07XG59XG5jb25zdCBzaW5nbGV0b25Sb3V0ZXIgPSB7XG4gICAgcm91dGVyOiBudWxsLFxuICAgIHJlYWR5Q2FsbGJhY2tzOiBbXSxcbiAgICByZWFkeSAoY2IpIHtcbiAgICAgICAgaWYgKHRoaXMucm91dGVyKSByZXR1cm4gY2IoKTtcbiAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICB0aGlzLnJlYWR5Q2FsbGJhY2tzLnB1c2goY2IpO1xuICAgICAgICB9XG4gICAgfVxufTtcbi8vIENyZWF0ZSBwdWJsaWMgcHJvcGVydGllcyBhbmQgbWV0aG9kcyBvZiB0aGUgcm91dGVyIGluIHRoZSBzaW5nbGV0b25Sb3V0ZXJcbmNvbnN0IHVybFByb3BlcnR5RmllbGRzID0gW1xuICAgICdwYXRobmFtZScsXG4gICAgJ3JvdXRlJyxcbiAgICAncXVlcnknLFxuICAgICdhc1BhdGgnLFxuICAgICdjb21wb25lbnRzJyxcbiAgICAnaXNGYWxsYmFjaycsXG4gICAgJ2Jhc2VQYXRoJyxcbiAgICAnbG9jYWxlJyxcbiAgICAnbG9jYWxlcycsXG4gICAgJ2RlZmF1bHRMb2NhbGUnLFxuICAgICdpc1JlYWR5JyxcbiAgICAnaXNQcmV2aWV3JyxcbiAgICAnaXNMb2NhbGVEb21haW4nLFxuICAgICdkb21haW5Mb2NhbGVzJywgXG5dO1xuY29uc3Qgcm91dGVyRXZlbnRzID0gW1xuICAgICdyb3V0ZUNoYW5nZVN0YXJ0JyxcbiAgICAnYmVmb3JlSGlzdG9yeUNoYW5nZScsXG4gICAgJ3JvdXRlQ2hhbmdlQ29tcGxldGUnLFxuICAgICdyb3V0ZUNoYW5nZUVycm9yJyxcbiAgICAnaGFzaENoYW5nZVN0YXJ0JyxcbiAgICAnaGFzaENoYW5nZUNvbXBsZXRlJywgXG5dO1xuY29uc3QgY29yZU1ldGhvZEZpZWxkcyA9IFtcbiAgICAncHVzaCcsXG4gICAgJ3JlcGxhY2UnLFxuICAgICdyZWxvYWQnLFxuICAgICdiYWNrJyxcbiAgICAncHJlZmV0Y2gnLFxuICAgICdiZWZvcmVQb3BTdGF0ZScsIFxuXTtcbi8vIEV2ZW50cyBpcyBhIHN0YXRpYyBwcm9wZXJ0eSBvbiB0aGUgcm91dGVyLCB0aGUgcm91dGVyIGRvZXNuJ3QgaGF2ZSB0byBiZSBpbml0aWFsaXplZCB0byB1c2UgaXRcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShzaW5nbGV0b25Sb3V0ZXIsICdldmVudHMnLCB7XG4gICAgZ2V0ICgpIHtcbiAgICAgICAgcmV0dXJuIF9yb3V0ZXIuZGVmYXVsdC5ldmVudHM7XG4gICAgfVxufSk7XG51cmxQcm9wZXJ0eUZpZWxkcy5mb3JFYWNoKChmaWVsZCk9PntcbiAgICAvLyBIZXJlIHdlIG5lZWQgdG8gdXNlIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSBiZWNhdXNlIHdlIG5lZWQgdG8gcmV0dXJuXG4gICAgLy8gdGhlIHByb3BlcnR5IGFzc2lnbmVkIHRvIHRoZSBhY3R1YWwgcm91dGVyXG4gICAgLy8gVGhlIHZhbHVlIG1pZ2h0IGdldCBjaGFuZ2VkIGFzIHdlIGNoYW5nZSByb3V0ZXMgYW5kIHRoaXMgaXMgdGhlXG4gICAgLy8gcHJvcGVyIHdheSB0byBhY2Nlc3MgaXRcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoc2luZ2xldG9uUm91dGVyLCBmaWVsZCwge1xuICAgICAgICBnZXQgKCkge1xuICAgICAgICAgICAgY29uc3Qgcm91dGVyID0gZ2V0Um91dGVyKCk7XG4gICAgICAgICAgICByZXR1cm4gcm91dGVyW2ZpZWxkXTtcbiAgICAgICAgfVxuICAgIH0pO1xufSk7XG5jb3JlTWV0aG9kRmllbGRzLmZvckVhY2goKGZpZWxkKT0+e1xuICAgIHNpbmdsZXRvblJvdXRlcltmaWVsZF0gPSAoLi4uYXJncyk9PntcbiAgICAgICAgY29uc3Qgcm91dGVyID0gZ2V0Um91dGVyKCk7XG4gICAgICAgIHJldHVybiByb3V0ZXJbZmllbGRdKC4uLmFyZ3MpO1xuICAgIH07XG59KTtcbnJvdXRlckV2ZW50cy5mb3JFYWNoKChldmVudCk9PntcbiAgICBzaW5nbGV0b25Sb3V0ZXIucmVhZHkoKCk9PntcbiAgICAgICAgX3JvdXRlci5kZWZhdWx0LmV2ZW50cy5vbihldmVudCwgKC4uLmFyZ3MpPT57XG4gICAgICAgICAgICBjb25zdCBldmVudEZpZWxkID0gYG9uJHtldmVudC5jaGFyQXQoMCkudG9VcHBlckNhc2UoKX0ke2V2ZW50LnN1YnN0cmluZygxKX1gO1xuICAgICAgICAgICAgY29uc3QgX3NpbmdsZXRvblJvdXRlciA9IHNpbmdsZXRvblJvdXRlcjtcbiAgICAgICAgICAgIGlmIChfc2luZ2xldG9uUm91dGVyW2V2ZW50RmllbGRdKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgX3NpbmdsZXRvblJvdXRlcltldmVudEZpZWxkXSguLi5hcmdzKTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3Igd2hlbiBydW5uaW5nIHRoZSBSb3V0ZXIgZXZlbnQ6ICR7ZXZlbnRGaWVsZH1gKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgJHtlcnIubWVzc2FnZX1cXG4ke2Vyci5zdGFja31gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xufSk7XG5mdW5jdGlvbiBnZXRSb3V0ZXIoKSB7XG4gICAgaWYgKCFzaW5nbGV0b25Sb3V0ZXIucm91dGVyKSB7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSAnTm8gcm91dGVyIGluc3RhbmNlIGZvdW5kLlxcbicgKyAnWW91IHNob3VsZCBvbmx5IHVzZSBcIm5leHQvcm91dGVyXCIgb24gdGhlIGNsaWVudCBzaWRlIG9mIHlvdXIgYXBwLlxcbic7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKTtcbiAgICB9XG4gICAgcmV0dXJuIHNpbmdsZXRvblJvdXRlci5yb3V0ZXI7XG59XG52YXIgX2RlZmF1bHQgPSBzaW5nbGV0b25Sb3V0ZXI7XG5leHBvcnRzLmRlZmF1bHQgPSBfZGVmYXVsdDtcbmZ1bmN0aW9uIHVzZVJvdXRlcigpIHtcbiAgICByZXR1cm4gX3JlYWN0LmRlZmF1bHQudXNlQ29udGV4dChfcm91dGVyQ29udGV4dC5Sb3V0ZXJDb250ZXh0KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJvdXRlciguLi5hcmdzKSB7XG4gICAgc2luZ2xldG9uUm91dGVyLnJvdXRlciA9IG5ldyBfcm91dGVyLmRlZmF1bHQoLi4uYXJncyk7XG4gICAgc2luZ2xldG9uUm91dGVyLnJlYWR5Q2FsbGJhY2tzLmZvckVhY2goKGNiKT0+Y2IoKVxuICAgICk7XG4gICAgc2luZ2xldG9uUm91dGVyLnJlYWR5Q2FsbGJhY2tzID0gW107XG4gICAgcmV0dXJuIHNpbmdsZXRvblJvdXRlci5yb3V0ZXI7XG59XG5mdW5jdGlvbiBtYWtlUHVibGljUm91dGVySW5zdGFuY2Uocm91dGVyKSB7XG4gICAgY29uc3QgX3JvdXRlcjEgPSByb3V0ZXI7XG4gICAgY29uc3QgaW5zdGFuY2UgPSB7XG4gICAgfTtcbiAgICBmb3IgKGNvbnN0IHByb3BlcnR5IG9mIHVybFByb3BlcnR5RmllbGRzKXtcbiAgICAgICAgaWYgKHR5cGVvZiBfcm91dGVyMVtwcm9wZXJ0eV0gPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICBpbnN0YW5jZVtwcm9wZXJ0eV0gPSBPYmplY3QuYXNzaWduKEFycmF5LmlzQXJyYXkoX3JvdXRlcjFbcHJvcGVydHldKSA/IFtdIDoge1xuICAgICAgICAgICAgfSwgX3JvdXRlcjFbcHJvcGVydHldKSAvLyBtYWtlcyBzdXJlIHF1ZXJ5IGlzIG5vdCBzdGF0ZWZ1bFxuICAgICAgICAgICAgO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaW5zdGFuY2VbcHJvcGVydHldID0gX3JvdXRlcjFbcHJvcGVydHldO1xuICAgIH1cbiAgICAvLyBFdmVudHMgaXMgYSBzdGF0aWMgcHJvcGVydHkgb24gdGhlIHJvdXRlciwgdGhlIHJvdXRlciBkb2Vzbid0IGhhdmUgdG8gYmUgaW5pdGlhbGl6ZWQgdG8gdXNlIGl0XG4gICAgaW5zdGFuY2UuZXZlbnRzID0gX3JvdXRlci5kZWZhdWx0LmV2ZW50cztcbiAgICBjb3JlTWV0aG9kRmllbGRzLmZvckVhY2goKGZpZWxkKT0+e1xuICAgICAgICBpbnN0YW5jZVtmaWVsZF0gPSAoLi4uYXJncyk9PntcbiAgICAgICAgICAgIHJldHVybiBfcm91dGVyMVtmaWVsZF0oLi4uYXJncyk7XG4gICAgICAgIH07XG4gICAgfSk7XG4gICAgcmV0dXJuIGluc3RhbmNlO1xufVxuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yb3V0ZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLnVzZUludGVyc2VjdGlvbiA9IHVzZUludGVyc2VjdGlvbjtcbnZhciBfcmVhY3QgPSByZXF1aXJlKFwicmVhY3RcIik7XG52YXIgX3JlcXVlc3RJZGxlQ2FsbGJhY2sgPSByZXF1aXJlKFwiLi9yZXF1ZXN0LWlkbGUtY2FsbGJhY2tcIik7XG5jb25zdCBoYXNJbnRlcnNlY3Rpb25PYnNlcnZlciA9IHR5cGVvZiBJbnRlcnNlY3Rpb25PYnNlcnZlciAhPT0gJ3VuZGVmaW5lZCc7XG5mdW5jdGlvbiB1c2VJbnRlcnNlY3Rpb24oeyByb290TWFyZ2luICwgZGlzYWJsZWQgIH0pIHtcbiAgICBjb25zdCBpc0Rpc2FibGVkID0gZGlzYWJsZWQgfHwgIWhhc0ludGVyc2VjdGlvbk9ic2VydmVyO1xuICAgIGNvbnN0IHVub2JzZXJ2ZSA9ICgwLCBfcmVhY3QpLnVzZVJlZigpO1xuICAgIGNvbnN0IFt2aXNpYmxlLCBzZXRWaXNpYmxlXSA9ICgwLCBfcmVhY3QpLnVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBzZXRSZWYgPSAoMCwgX3JlYWN0KS51c2VDYWxsYmFjaygoZWwpPT57XG4gICAgICAgIGlmICh1bm9ic2VydmUuY3VycmVudCkge1xuICAgICAgICAgICAgdW5vYnNlcnZlLmN1cnJlbnQoKTtcbiAgICAgICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50ID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0Rpc2FibGVkIHx8IHZpc2libGUpIHJldHVybjtcbiAgICAgICAgaWYgKGVsICYmIGVsLnRhZ05hbWUpIHtcbiAgICAgICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50ID0gb2JzZXJ2ZShlbCwgKGlzVmlzaWJsZSk9PmlzVmlzaWJsZSAmJiBzZXRWaXNpYmxlKGlzVmlzaWJsZSlcbiAgICAgICAgICAgICwge1xuICAgICAgICAgICAgICAgIHJvb3RNYXJnaW5cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfSwgW1xuICAgICAgICBpc0Rpc2FibGVkLFxuICAgICAgICByb290TWFyZ2luLFxuICAgICAgICB2aXNpYmxlXG4gICAgXSk7XG4gICAgKDAsIF9yZWFjdCkudXNlRWZmZWN0KCgpPT57XG4gICAgICAgIGlmICghaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIpIHtcbiAgICAgICAgICAgIGlmICghdmlzaWJsZSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkbGVDYWxsYmFjayA9ICgwLCBfcmVxdWVzdElkbGVDYWxsYmFjaykucmVxdWVzdElkbGVDYWxsYmFjaygoKT0+c2V0VmlzaWJsZSh0cnVlKVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgcmV0dXJuICgpPT4oMCwgX3JlcXVlc3RJZGxlQ2FsbGJhY2spLmNhbmNlbElkbGVDYWxsYmFjayhpZGxlQ2FsbGJhY2spXG4gICAgICAgICAgICAgICAgO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW1xuICAgICAgICB2aXNpYmxlXG4gICAgXSk7XG4gICAgcmV0dXJuIFtcbiAgICAgICAgc2V0UmVmLFxuICAgICAgICB2aXNpYmxlXG4gICAgXTtcbn1cbmZ1bmN0aW9uIG9ic2VydmUoZWxlbWVudCwgY2FsbGJhY2ssIG9wdGlvbnMpIHtcbiAgICBjb25zdCB7IGlkICwgb2JzZXJ2ZXIgLCBlbGVtZW50cyAgfSA9IGNyZWF0ZU9ic2VydmVyKG9wdGlvbnMpO1xuICAgIGVsZW1lbnRzLnNldChlbGVtZW50LCBjYWxsYmFjayk7XG4gICAgb2JzZXJ2ZXIub2JzZXJ2ZShlbGVtZW50KTtcbiAgICByZXR1cm4gZnVuY3Rpb24gdW5vYnNlcnZlKCkge1xuICAgICAgICBlbGVtZW50cy5kZWxldGUoZWxlbWVudCk7XG4gICAgICAgIG9ic2VydmVyLnVub2JzZXJ2ZShlbGVtZW50KTtcbiAgICAgICAgLy8gRGVzdHJveSBvYnNlcnZlciB3aGVuIHRoZXJlJ3Mgbm90aGluZyBsZWZ0IHRvIHdhdGNoOlxuICAgICAgICBpZiAoZWxlbWVudHMuc2l6ZSA9PT0gMCkge1xuICAgICAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICAgICAgb2JzZXJ2ZXJzLmRlbGV0ZShpZCk7XG4gICAgICAgIH1cbiAgICB9O1xufVxuY29uc3Qgb2JzZXJ2ZXJzID0gbmV3IE1hcCgpO1xuZnVuY3Rpb24gY3JlYXRlT2JzZXJ2ZXIob3B0aW9ucykge1xuICAgIGNvbnN0IGlkID0gb3B0aW9ucy5yb290TWFyZ2luIHx8ICcnO1xuICAgIGxldCBpbnN0YW5jZSA9IG9ic2VydmVycy5nZXQoaWQpO1xuICAgIGlmIChpbnN0YW5jZSkge1xuICAgICAgICByZXR1cm4gaW5zdGFuY2U7XG4gICAgfVxuICAgIGNvbnN0IGVsZW1lbnRzID0gbmV3IE1hcCgpO1xuICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKChlbnRyaWVzKT0+e1xuICAgICAgICBlbnRyaWVzLmZvckVhY2goKGVudHJ5KT0+e1xuICAgICAgICAgICAgY29uc3QgY2FsbGJhY2sgPSBlbGVtZW50cy5nZXQoZW50cnkudGFyZ2V0KTtcbiAgICAgICAgICAgIGNvbnN0IGlzVmlzaWJsZSA9IGVudHJ5LmlzSW50ZXJzZWN0aW5nIHx8IGVudHJ5LmludGVyc2VjdGlvblJhdGlvID4gMDtcbiAgICAgICAgICAgIGlmIChjYWxsYmFjayAmJiBpc1Zpc2libGUpIHtcbiAgICAgICAgICAgICAgICBjYWxsYmFjayhpc1Zpc2libGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9LCBvcHRpb25zKTtcbiAgICBvYnNlcnZlcnMuc2V0KGlkLCBpbnN0YW5jZSA9IHtcbiAgICAgICAgaWQsXG4gICAgICAgIG9ic2VydmVyLFxuICAgICAgICBlbGVtZW50c1xuICAgIH0pO1xuICAgIHJldHVybiBpbnN0YW5jZTtcbn1cblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlLWludGVyc2VjdGlvbi5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICAgIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHMuZGVmYXVsdCA9IHdpdGhSb3V0ZXI7XG52YXIgX3JlYWN0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwicmVhY3RcIikpO1xudmFyIF9yb3V0ZXIgPSByZXF1aXJlKFwiLi9yb3V0ZXJcIik7XG5mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICAgIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgICAgIGRlZmF1bHQ6IG9ialxuICAgIH07XG59XG5mdW5jdGlvbiB3aXRoUm91dGVyKENvbXBvc2VkQ29tcG9uZW50KSB7XG4gICAgZnVuY3Rpb24gV2l0aFJvdXRlcldyYXBwZXIocHJvcHMpIHtcbiAgICAgICAgcmV0dXJuKC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChDb21wb3NlZENvbXBvbmVudCwgT2JqZWN0LmFzc2lnbih7XG4gICAgICAgICAgICByb3V0ZXI6ICgwLCBfcm91dGVyKS51c2VSb3V0ZXIoKVxuICAgICAgICB9LCBwcm9wcykpKTtcbiAgICB9XG4gICAgV2l0aFJvdXRlcldyYXBwZXIuZ2V0SW5pdGlhbFByb3BzID0gQ29tcG9zZWRDb21wb25lbnQuZ2V0SW5pdGlhbFByb3BzO1xuICAgIFdpdGhSb3V0ZXJXcmFwcGVyLm9yaWdHZXRJbml0aWFsUHJvcHMgPSBDb21wb3NlZENvbXBvbmVudC5vcmlnR2V0SW5pdGlhbFByb3BzO1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGNvbnN0IG5hbWUgPSBDb21wb3NlZENvbXBvbmVudC5kaXNwbGF5TmFtZSB8fCBDb21wb3NlZENvbXBvbmVudC5uYW1lIHx8ICdVbmtub3duJztcbiAgICAgICAgV2l0aFJvdXRlcldyYXBwZXIuZGlzcGxheU5hbWUgPSBgd2l0aFJvdXRlcigke25hbWV9KWA7XG4gICAgfVxuICAgIHJldHVybiBXaXRoUm91dGVyV3JhcHBlcjtcbn1cblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9d2l0aC1yb3V0ZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLmdldERvbWFpbkxvY2FsZSA9IGdldERvbWFpbkxvY2FsZTtcbmV4cG9ydHMuYWRkTG9jYWxlID0gYWRkTG9jYWxlO1xuZXhwb3J0cy5kZWxMb2NhbGUgPSBkZWxMb2NhbGU7XG5leHBvcnRzLmhhc0Jhc2VQYXRoID0gaGFzQmFzZVBhdGg7XG5leHBvcnRzLmFkZEJhc2VQYXRoID0gYWRkQmFzZVBhdGg7XG5leHBvcnRzLmRlbEJhc2VQYXRoID0gZGVsQmFzZVBhdGg7XG5leHBvcnRzLmlzTG9jYWxVUkwgPSBpc0xvY2FsVVJMO1xuZXhwb3J0cy5pbnRlcnBvbGF0ZUFzID0gaW50ZXJwb2xhdGVBcztcbmV4cG9ydHMucmVzb2x2ZUhyZWYgPSByZXNvbHZlSHJlZjtcbmV4cG9ydHMuZGVmYXVsdCA9IHZvaWQgMDtcbnZhciBfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCA9IHJlcXVpcmUoXCIuLi8uLi8uLi9jbGllbnQvbm9ybWFsaXplLXRyYWlsaW5nLXNsYXNoXCIpO1xudmFyIF9yb3V0ZUxvYWRlciA9IHJlcXVpcmUoXCIuLi8uLi8uLi9jbGllbnQvcm91dGUtbG9hZGVyXCIpO1xudmFyIF9kZW5vcm1hbGl6ZVBhZ2VQYXRoID0gcmVxdWlyZShcIi4uLy4uLy4uL3NlcnZlci9kZW5vcm1hbGl6ZS1wYWdlLXBhdGhcIik7XG52YXIgX25vcm1hbGl6ZUxvY2FsZVBhdGggPSByZXF1aXJlKFwiLi4vaTE4bi9ub3JtYWxpemUtbG9jYWxlLXBhdGhcIik7XG52YXIgX21pdHQgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuLi9taXR0XCIpKTtcbnZhciBfdXRpbHMgPSByZXF1aXJlKFwiLi4vdXRpbHNcIik7XG52YXIgX2lzRHluYW1pYyA9IHJlcXVpcmUoXCIuL3V0aWxzL2lzLWR5bmFtaWNcIik7XG52YXIgX3BhcnNlUmVsYXRpdmVVcmwgPSByZXF1aXJlKFwiLi91dGlscy9wYXJzZS1yZWxhdGl2ZS11cmxcIik7XG52YXIgX3F1ZXJ5c3RyaW5nID0gcmVxdWlyZShcIi4vdXRpbHMvcXVlcnlzdHJpbmdcIik7XG52YXIgX3Jlc29sdmVSZXdyaXRlcyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vdXRpbHMvcmVzb2x2ZS1yZXdyaXRlc1wiKSk7XG52YXIgX3JvdXRlTWF0Y2hlciA9IHJlcXVpcmUoXCIuL3V0aWxzL3JvdXRlLW1hdGNoZXJcIik7XG52YXIgX3JvdXRlUmVnZXggPSByZXF1aXJlKFwiLi91dGlscy9yb3V0ZS1yZWdleFwiKTtcbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gICAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICAgICAgZGVmYXVsdDogb2JqXG4gICAgfTtcbn1cbmxldCBkZXRlY3REb21haW5Mb2NhbGU7XG5pZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgIGRldGVjdERvbWFpbkxvY2FsZSA9IHJlcXVpcmUoJy4uL2kxOG4vZGV0ZWN0LWRvbWFpbi1sb2NhbGUnKS5kZXRlY3REb21haW5Mb2NhbGU7XG59XG5jb25zdCBiYXNlUGF0aCA9IHByb2Nlc3MuZW52Ll9fTkVYVF9ST1VURVJfQkFTRVBBVEggfHwgJyc7XG5mdW5jdGlvbiBidWlsZENhbmNlbGxhdGlvbkVycm9yKCkge1xuICAgIHJldHVybiBPYmplY3QuYXNzaWduKG5ldyBFcnJvcignUm91dGUgQ2FuY2VsbGVkJyksIHtcbiAgICAgICAgY2FuY2VsbGVkOiB0cnVlXG4gICAgfSk7XG59XG5mdW5jdGlvbiBhZGRQYXRoUHJlZml4KHBhdGgsIHByZWZpeCkge1xuICAgIHJldHVybiBwcmVmaXggJiYgcGF0aC5zdGFydHNXaXRoKCcvJykgPyBwYXRoID09PSAnLycgPyAoMCwgX25vcm1hbGl6ZVRyYWlsaW5nU2xhc2gpLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoKHByZWZpeCkgOiBgJHtwcmVmaXh9JHtwYXRoTm9RdWVyeUhhc2gocGF0aCkgPT09ICcvJyA/IHBhdGguc3Vic3RyaW5nKDEpIDogcGF0aH1gIDogcGF0aDtcbn1cbmZ1bmN0aW9uIGdldERvbWFpbkxvY2FsZShwYXRoLCBsb2NhbGUsIGxvY2FsZXMsIGRvbWFpbkxvY2FsZXMpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICBsb2NhbGUgPSBsb2NhbGUgfHwgKDAsIF9ub3JtYWxpemVMb2NhbGVQYXRoKS5ub3JtYWxpemVMb2NhbGVQYXRoKHBhdGgsIGxvY2FsZXMpLmRldGVjdGVkTG9jYWxlO1xuICAgICAgICBjb25zdCBkZXRlY3RlZERvbWFpbiA9IGRldGVjdERvbWFpbkxvY2FsZShkb21haW5Mb2NhbGVzLCB1bmRlZmluZWQsIGxvY2FsZSk7XG4gICAgICAgIGlmIChkZXRlY3RlZERvbWFpbikge1xuICAgICAgICAgICAgcmV0dXJuIGBodHRwJHtkZXRlY3RlZERvbWFpbi5odHRwID8gJycgOiAncyd9Oi8vJHtkZXRlY3RlZERvbWFpbi5kb21haW59JHtiYXNlUGF0aCB8fCAnJ30ke2xvY2FsZSA9PT0gZGV0ZWN0ZWREb21haW4uZGVmYXVsdExvY2FsZSA/ICcnIDogYC8ke2xvY2FsZX1gfSR7cGF0aH1gO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufVxuZnVuY3Rpb24gYWRkTG9jYWxlKHBhdGgsIGxvY2FsZSwgZGVmYXVsdExvY2FsZSkge1xuICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgIGNvbnN0IHBhdGhuYW1lID0gcGF0aE5vUXVlcnlIYXNoKHBhdGgpO1xuICAgICAgICBjb25zdCBwYXRoTG93ZXIgPSBwYXRobmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBjb25zdCBsb2NhbGVMb3dlciA9IGxvY2FsZSAmJiBsb2NhbGUudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgcmV0dXJuIGxvY2FsZSAmJiBsb2NhbGUgIT09IGRlZmF1bHRMb2NhbGUgJiYgIXBhdGhMb3dlci5zdGFydHNXaXRoKCcvJyArIGxvY2FsZUxvd2VyICsgJy8nKSAmJiBwYXRoTG93ZXIgIT09ICcvJyArIGxvY2FsZUxvd2VyID8gYWRkUGF0aFByZWZpeChwYXRoLCAnLycgKyBsb2NhbGUpIDogcGF0aDtcbiAgICB9XG4gICAgcmV0dXJuIHBhdGg7XG59XG5mdW5jdGlvbiBkZWxMb2NhbGUocGF0aCwgbG9jYWxlKSB7XG4gICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpIHtcbiAgICAgICAgY29uc3QgcGF0aG5hbWUgPSBwYXRoTm9RdWVyeUhhc2gocGF0aCk7XG4gICAgICAgIGNvbnN0IHBhdGhMb3dlciA9IHBhdGhuYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGNvbnN0IGxvY2FsZUxvd2VyID0gbG9jYWxlICYmIGxvY2FsZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICByZXR1cm4gbG9jYWxlICYmIChwYXRoTG93ZXIuc3RhcnRzV2l0aCgnLycgKyBsb2NhbGVMb3dlciArICcvJykgfHwgcGF0aExvd2VyID09PSAnLycgKyBsb2NhbGVMb3dlcikgPyAocGF0aG5hbWUubGVuZ3RoID09PSBsb2NhbGUubGVuZ3RoICsgMSA/ICcvJyA6ICcnKSArIHBhdGguc3Vic3RyKGxvY2FsZS5sZW5ndGggKyAxKSA6IHBhdGg7XG4gICAgfVxuICAgIHJldHVybiBwYXRoO1xufVxuZnVuY3Rpb24gcGF0aE5vUXVlcnlIYXNoKHBhdGgpIHtcbiAgICBjb25zdCBxdWVyeUluZGV4ID0gcGF0aC5pbmRleE9mKCc/Jyk7XG4gICAgY29uc3QgaGFzaEluZGV4ID0gcGF0aC5pbmRleE9mKCcjJyk7XG4gICAgaWYgKHF1ZXJ5SW5kZXggPiAtMSB8fCBoYXNoSW5kZXggPiAtMSkge1xuICAgICAgICBwYXRoID0gcGF0aC5zdWJzdHJpbmcoMCwgcXVlcnlJbmRleCA+IC0xID8gcXVlcnlJbmRleCA6IGhhc2hJbmRleCk7XG4gICAgfVxuICAgIHJldHVybiBwYXRoO1xufVxuZnVuY3Rpb24gaGFzQmFzZVBhdGgocGF0aCkge1xuICAgIHBhdGggPSBwYXRoTm9RdWVyeUhhc2gocGF0aCk7XG4gICAgcmV0dXJuIHBhdGggPT09IGJhc2VQYXRoIHx8IHBhdGguc3RhcnRzV2l0aChiYXNlUGF0aCArICcvJyk7XG59XG5mdW5jdGlvbiBhZGRCYXNlUGF0aChwYXRoKSB7XG4gICAgLy8gd2Ugb25seSBhZGQgdGhlIGJhc2VwYXRoIG9uIHJlbGF0aXZlIHVybHNcbiAgICByZXR1cm4gYWRkUGF0aFByZWZpeChwYXRoLCBiYXNlUGF0aCk7XG59XG5mdW5jdGlvbiBkZWxCYXNlUGF0aChwYXRoKSB7XG4gICAgcGF0aCA9IHBhdGguc2xpY2UoYmFzZVBhdGgubGVuZ3RoKTtcbiAgICBpZiAoIXBhdGguc3RhcnRzV2l0aCgnLycpKSBwYXRoID0gYC8ke3BhdGh9YDtcbiAgICByZXR1cm4gcGF0aDtcbn1cbmZ1bmN0aW9uIGlzTG9jYWxVUkwodXJsKSB7XG4gICAgLy8gcHJldmVudCBhIGh5ZHJhdGlvbiBtaXNtYXRjaCBvbiBocmVmIGZvciB1cmwgd2l0aCBhbmNob3IgcmVmc1xuICAgIGlmICh1cmwuc3RhcnRzV2l0aCgnLycpIHx8IHVybC5zdGFydHNXaXRoKCcjJykgfHwgdXJsLnN0YXJ0c1dpdGgoJz8nKSkgcmV0dXJuIHRydWU7XG4gICAgdHJ5IHtcbiAgICAgICAgLy8gYWJzb2x1dGUgdXJscyBjYW4gYmUgbG9jYWwgaWYgdGhleSBhcmUgb24gdGhlIHNhbWUgb3JpZ2luXG4gICAgICAgIGNvbnN0IGxvY2F0aW9uT3JpZ2luID0gKDAsIF91dGlscykuZ2V0TG9jYXRpb25PcmlnaW4oKTtcbiAgICAgICAgY29uc3QgcmVzb2x2ZWQgPSBuZXcgVVJMKHVybCwgbG9jYXRpb25PcmlnaW4pO1xuICAgICAgICByZXR1cm4gcmVzb2x2ZWQub3JpZ2luID09PSBsb2NhdGlvbk9yaWdpbiAmJiBoYXNCYXNlUGF0aChyZXNvbHZlZC5wYXRobmFtZSk7XG4gICAgfSBjYXRjaCAoXykge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufVxuZnVuY3Rpb24gaW50ZXJwb2xhdGVBcyhyb3V0ZSwgYXNQYXRobmFtZSwgcXVlcnkpIHtcbiAgICBsZXQgaW50ZXJwb2xhdGVkUm91dGUgPSAnJztcbiAgICBjb25zdCBkeW5hbWljUmVnZXggPSAoMCwgX3JvdXRlUmVnZXgpLmdldFJvdXRlUmVnZXgocm91dGUpO1xuICAgIGNvbnN0IGR5bmFtaWNHcm91cHMgPSBkeW5hbWljUmVnZXguZ3JvdXBzO1xuICAgIGNvbnN0IGR5bmFtaWNNYXRjaGVzID0gLy8gVHJ5IHRvIG1hdGNoIHRoZSBkeW5hbWljIHJvdXRlIGFnYWluc3QgdGhlIGFzUGF0aFxuICAgIChhc1BhdGhuYW1lICE9PSByb3V0ZSA/ICgwLCBfcm91dGVNYXRjaGVyKS5nZXRSb3V0ZU1hdGNoZXIoZHluYW1pY1JlZ2V4KShhc1BhdGhuYW1lKSA6ICcnKSB8fCAvLyBGYWxsIGJhY2sgdG8gcmVhZGluZyB0aGUgdmFsdWVzIGZyb20gdGhlIGhyZWZcbiAgICAvLyBUT0RPOiBzaG91bGQgdGhpcyB0YWtlIHByaW9yaXR5OyBhbHNvIG5lZWQgdG8gY2hhbmdlIGluIHRoZSByb3V0ZXIuXG4gICAgcXVlcnk7XG4gICAgaW50ZXJwb2xhdGVkUm91dGUgPSByb3V0ZTtcbiAgICBjb25zdCBwYXJhbXMgPSBPYmplY3Qua2V5cyhkeW5hbWljR3JvdXBzKTtcbiAgICBpZiAoIXBhcmFtcy5ldmVyeSgocGFyYW0pPT57XG4gICAgICAgIGxldCB2YWx1ZSA9IGR5bmFtaWNNYXRjaGVzW3BhcmFtXSB8fCAnJztcbiAgICAgICAgY29uc3QgeyByZXBlYXQgLCBvcHRpb25hbCAgfSA9IGR5bmFtaWNHcm91cHNbcGFyYW1dO1xuICAgICAgICAvLyBzdXBwb3J0IHNpbmdsZS1sZXZlbCBjYXRjaC1hbGxcbiAgICAgICAgLy8gVE9ETzogbW9yZSByb2J1c3QgaGFuZGxpbmcgZm9yIHVzZXItZXJyb3IgKHBhc3NpbmcgYC9gKVxuICAgICAgICBsZXQgcmVwbGFjZWQgPSBgWyR7cmVwZWF0ID8gJy4uLicgOiAnJ30ke3BhcmFtfV1gO1xuICAgICAgICBpZiAob3B0aW9uYWwpIHtcbiAgICAgICAgICAgIHJlcGxhY2VkID0gYCR7IXZhbHVlID8gJy8nIDogJyd9WyR7cmVwbGFjZWR9XWA7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlcGVhdCAmJiAhQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHZhbHVlID0gW1xuICAgICAgICAgICAgdmFsdWVcbiAgICAgICAgXTtcbiAgICAgICAgcmV0dXJuIChvcHRpb25hbCB8fCBwYXJhbSBpbiBkeW5hbWljTWF0Y2hlcykgJiYgLy8gSW50ZXJwb2xhdGUgZ3JvdXAgaW50byBkYXRhIFVSTCBpZiBwcmVzZW50XG4gICAgICAgIChpbnRlcnBvbGF0ZWRSb3V0ZSA9IGludGVycG9sYXRlZFJvdXRlLnJlcGxhY2UocmVwbGFjZWQsIHJlcGVhdCA/IHZhbHVlLm1hcCgvLyB0aGVzZSB2YWx1ZXMgc2hvdWxkIGJlIGZ1bGx5IGVuY29kZWQgaW5zdGVhZCBvZiBqdXN0XG4gICAgICAgIC8vIHBhdGggZGVsaW1pdGVyIGVzY2FwZWQgc2luY2UgdGhleSBhcmUgYmVpbmcgaW5zZXJ0ZWRcbiAgICAgICAgLy8gaW50byB0aGUgVVJMIGFuZCB3ZSBleHBlY3QgVVJMIGVuY29kZWQgc2VnbWVudHNcbiAgICAgICAgLy8gd2hlbiBwYXJzaW5nIGR5bmFtaWMgcm91dGUgcGFyYW1zXG4gICAgICAgIChzZWdtZW50KT0+ZW5jb2RlVVJJQ29tcG9uZW50KHNlZ21lbnQpXG4gICAgICAgICkuam9pbignLycpIDogZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKSkgfHwgJy8nKTtcbiAgICB9KSkge1xuICAgICAgICBpbnRlcnBvbGF0ZWRSb3V0ZSA9ICcnIC8vIGRpZCBub3Qgc2F0aXNmeSBhbGwgcmVxdWlyZW1lbnRzXG4gICAgICAgIDtcbiAgICAvLyBuLmIuIFdlIGlnbm9yZSB0aGlzIGVycm9yIGJlY2F1c2Ugd2UgaGFuZGxlIHdhcm5pbmcgZm9yIHRoaXMgY2FzZSBpblxuICAgIC8vIGRldmVsb3BtZW50IGluIHRoZSBgPExpbms+YCBjb21wb25lbnQgZGlyZWN0bHkuXG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIHBhcmFtcyxcbiAgICAgICAgcmVzdWx0OiBpbnRlcnBvbGF0ZWRSb3V0ZVxuICAgIH07XG59XG5mdW5jdGlvbiBvbWl0UGFybXNGcm9tUXVlcnkocXVlcnksIHBhcmFtcykge1xuICAgIGNvbnN0IGZpbHRlcmVkUXVlcnkgPSB7XG4gICAgfTtcbiAgICBPYmplY3Qua2V5cyhxdWVyeSkuZm9yRWFjaCgoa2V5KT0+e1xuICAgICAgICBpZiAoIXBhcmFtcy5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICAgICAgICBmaWx0ZXJlZFF1ZXJ5W2tleV0gPSBxdWVyeVtrZXldO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGZpbHRlcmVkUXVlcnk7XG59XG5mdW5jdGlvbiByZXNvbHZlSHJlZihyb3V0ZXIsIGhyZWYsIHJlc29sdmVBcykge1xuICAgIC8vIHdlIHVzZSBhIGR1bW15IGJhc2UgdXJsIGZvciByZWxhdGl2ZSB1cmxzXG4gICAgbGV0IGJhc2U7XG4gICAgbGV0IHVybEFzU3RyaW5nID0gdHlwZW9mIGhyZWYgPT09ICdzdHJpbmcnID8gaHJlZiA6ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKGhyZWYpO1xuICAgIC8vIHJlcGVhdGVkIHNsYXNoZXMgYW5kIGJhY2tzbGFzaGVzIGluIHRoZSBVUkwgYXJlIGNvbnNpZGVyZWRcbiAgICAvLyBpbnZhbGlkIGFuZCB3aWxsIG5ldmVyIG1hdGNoIGEgTmV4dC5qcyBwYWdlL2ZpbGVcbiAgICBjb25zdCB1cmxQcm90b01hdGNoID0gdXJsQXNTdHJpbmcubWF0Y2goL15bYS16QS1aXXsxLH06XFwvXFwvLyk7XG4gICAgY29uc3QgdXJsQXNTdHJpbmdOb1Byb3RvID0gdXJsUHJvdG9NYXRjaCA/IHVybEFzU3RyaW5nLnN1YnN0cih1cmxQcm90b01hdGNoWzBdLmxlbmd0aCkgOiB1cmxBc1N0cmluZztcbiAgICBjb25zdCB1cmxQYXJ0cyA9IHVybEFzU3RyaW5nTm9Qcm90by5zcGxpdCgnPycpO1xuICAgIGlmICgodXJsUGFydHNbMF0gfHwgJycpLm1hdGNoKC8oXFwvXFwvfFxcXFwpLykpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgSW52YWxpZCBocmVmIHBhc3NlZCB0byBuZXh0L3JvdXRlcjogJHt1cmxBc1N0cmluZ30sIHJlcGVhdGVkIGZvcndhcmQtc2xhc2hlcyAoLy8pIG9yIGJhY2tzbGFzaGVzIFxcXFwgYXJlIG5vdCB2YWxpZCBpbiB0aGUgaHJlZmApO1xuICAgICAgICBjb25zdCBub3JtYWxpemVkVXJsID0gKDAsIF91dGlscykubm9ybWFsaXplUmVwZWF0ZWRTbGFzaGVzKHVybEFzU3RyaW5nTm9Qcm90byk7XG4gICAgICAgIHVybEFzU3RyaW5nID0gKHVybFByb3RvTWF0Y2ggPyB1cmxQcm90b01hdGNoWzBdIDogJycpICsgbm9ybWFsaXplZFVybDtcbiAgICB9XG4gICAgLy8gUmV0dXJuIGJlY2F1c2UgaXQgY2Fubm90IGJlIHJvdXRlZCBieSB0aGUgTmV4dC5qcyByb3V0ZXJcbiAgICBpZiAoIWlzTG9jYWxVUkwodXJsQXNTdHJpbmcpKSB7XG4gICAgICAgIHJldHVybiByZXNvbHZlQXMgPyBbXG4gICAgICAgICAgICB1cmxBc1N0cmluZ1xuICAgICAgICBdIDogdXJsQXNTdHJpbmc7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIGJhc2UgPSBuZXcgVVJMKHVybEFzU3RyaW5nLnN0YXJ0c1dpdGgoJyMnKSA/IHJvdXRlci5hc1BhdGggOiByb3V0ZXIucGF0aG5hbWUsICdodHRwOi8vbicpO1xuICAgIH0gY2F0Y2ggKF8pIHtcbiAgICAgICAgLy8gZmFsbGJhY2sgdG8gLyBmb3IgaW52YWxpZCBhc1BhdGggdmFsdWVzIGUuZy4gLy9cbiAgICAgICAgYmFzZSA9IG5ldyBVUkwoJy8nLCAnaHR0cDovL24nKTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZmluYWxVcmwgPSBuZXcgVVJMKHVybEFzU3RyaW5nLCBiYXNlKTtcbiAgICAgICAgZmluYWxVcmwucGF0aG5hbWUgPSAoMCwgX25vcm1hbGl6ZVRyYWlsaW5nU2xhc2gpLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoKGZpbmFsVXJsLnBhdGhuYW1lKTtcbiAgICAgICAgbGV0IGludGVycG9sYXRlZEFzID0gJyc7XG4gICAgICAgIGlmICgoMCwgX2lzRHluYW1pYykuaXNEeW5hbWljUm91dGUoZmluYWxVcmwucGF0aG5hbWUpICYmIGZpbmFsVXJsLnNlYXJjaFBhcmFtcyAmJiByZXNvbHZlQXMpIHtcbiAgICAgICAgICAgIGNvbnN0IHF1ZXJ5ID0gKDAsIF9xdWVyeXN0cmluZykuc2VhcmNoUGFyYW1zVG9VcmxRdWVyeShmaW5hbFVybC5zZWFyY2hQYXJhbXMpO1xuICAgICAgICAgICAgY29uc3QgeyByZXN1bHQgLCBwYXJhbXMgIH0gPSBpbnRlcnBvbGF0ZUFzKGZpbmFsVXJsLnBhdGhuYW1lLCBmaW5hbFVybC5wYXRobmFtZSwgcXVlcnkpO1xuICAgICAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgIGludGVycG9sYXRlZEFzID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTogcmVzdWx0LFxuICAgICAgICAgICAgICAgICAgICBoYXNoOiBmaW5hbFVybC5oYXNoLFxuICAgICAgICAgICAgICAgICAgICBxdWVyeTogb21pdFBhcm1zRnJvbVF1ZXJ5KHF1ZXJ5LCBwYXJhbXMpXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gaWYgdGhlIG9yaWdpbiBkaWRuJ3QgY2hhbmdlLCBpdCBtZWFucyB3ZSByZWNlaXZlZCBhIHJlbGF0aXZlIGhyZWZcbiAgICAgICAgY29uc3QgcmVzb2x2ZWRIcmVmID0gZmluYWxVcmwub3JpZ2luID09PSBiYXNlLm9yaWdpbiA/IGZpbmFsVXJsLmhyZWYuc2xpY2UoZmluYWxVcmwub3JpZ2luLmxlbmd0aCkgOiBmaW5hbFVybC5ocmVmO1xuICAgICAgICByZXR1cm4gcmVzb2x2ZUFzID8gW1xuICAgICAgICAgICAgcmVzb2x2ZWRIcmVmLFxuICAgICAgICAgICAgaW50ZXJwb2xhdGVkQXMgfHwgcmVzb2x2ZWRIcmVmXG4gICAgICAgIF0gOiByZXNvbHZlZEhyZWY7XG4gICAgfSBjYXRjaCAoXykge1xuICAgICAgICByZXR1cm4gcmVzb2x2ZUFzID8gW1xuICAgICAgICAgICAgdXJsQXNTdHJpbmdcbiAgICAgICAgXSA6IHVybEFzU3RyaW5nO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHN0cmlwT3JpZ2luKHVybCkge1xuICAgIGNvbnN0IG9yaWdpbiA9ICgwLCBfdXRpbHMpLmdldExvY2F0aW9uT3JpZ2luKCk7XG4gICAgcmV0dXJuIHVybC5zdGFydHNXaXRoKG9yaWdpbikgPyB1cmwuc3Vic3RyaW5nKG9yaWdpbi5sZW5ndGgpIDogdXJsO1xufVxuZnVuY3Rpb24gcHJlcGFyZVVybEFzKHJvdXRlciwgdXJsLCBhcykge1xuICAgIC8vIElmIHVybCBhbmQgYXMgcHJvdmlkZWQgYXMgYW4gb2JqZWN0IHJlcHJlc2VudGF0aW9uLFxuICAgIC8vIHdlJ2xsIGZvcm1hdCB0aGVtIGludG8gdGhlIHN0cmluZyB2ZXJzaW9uIGhlcmUuXG4gICAgbGV0IFtyZXNvbHZlZEhyZWYsIHJlc29sdmVkQXNdID0gcmVzb2x2ZUhyZWYocm91dGVyLCB1cmwsIHRydWUpO1xuICAgIGNvbnN0IG9yaWdpbiA9ICgwLCBfdXRpbHMpLmdldExvY2F0aW9uT3JpZ2luKCk7XG4gICAgY29uc3QgaHJlZkhhZE9yaWdpbiA9IHJlc29sdmVkSHJlZi5zdGFydHNXaXRoKG9yaWdpbik7XG4gICAgY29uc3QgYXNIYWRPcmlnaW4gPSByZXNvbHZlZEFzICYmIHJlc29sdmVkQXMuc3RhcnRzV2l0aChvcmlnaW4pO1xuICAgIHJlc29sdmVkSHJlZiA9IHN0cmlwT3JpZ2luKHJlc29sdmVkSHJlZik7XG4gICAgcmVzb2x2ZWRBcyA9IHJlc29sdmVkQXMgPyBzdHJpcE9yaWdpbihyZXNvbHZlZEFzKSA6IHJlc29sdmVkQXM7XG4gICAgY29uc3QgcHJlcGFyZWRVcmwgPSBocmVmSGFkT3JpZ2luID8gcmVzb2x2ZWRIcmVmIDogYWRkQmFzZVBhdGgocmVzb2x2ZWRIcmVmKTtcbiAgICBjb25zdCBwcmVwYXJlZEFzID0gYXMgPyBzdHJpcE9yaWdpbihyZXNvbHZlSHJlZihyb3V0ZXIsIGFzKSkgOiByZXNvbHZlZEFzIHx8IHJlc29sdmVkSHJlZjtcbiAgICByZXR1cm4ge1xuICAgICAgICB1cmw6IHByZXBhcmVkVXJsLFxuICAgICAgICBhczogYXNIYWRPcmlnaW4gPyBwcmVwYXJlZEFzIDogYWRkQmFzZVBhdGgocHJlcGFyZWRBcylcbiAgICB9O1xufVxuZnVuY3Rpb24gcmVzb2x2ZUR5bmFtaWNSb3V0ZShwYXRobmFtZSwgcGFnZXMpIHtcbiAgICBjb25zdCBjbGVhblBhdGhuYW1lID0gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaCgoMCwgX2Rlbm9ybWFsaXplUGFnZVBhdGgpLmRlbm9ybWFsaXplUGFnZVBhdGgocGF0aG5hbWUpKTtcbiAgICBpZiAoY2xlYW5QYXRobmFtZSA9PT0gJy80MDQnIHx8IGNsZWFuUGF0aG5hbWUgPT09ICcvX2Vycm9yJykge1xuICAgICAgICByZXR1cm4gcGF0aG5hbWU7XG4gICAgfVxuICAgIC8vIGhhbmRsZSByZXNvbHZpbmcgaHJlZiBmb3IgZHluYW1pYyByb3V0ZXNcbiAgICBpZiAoIXBhZ2VzLmluY2x1ZGVzKGNsZWFuUGF0aG5hbWUpKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBhcnJheS1jYWxsYmFjay1yZXR1cm5cbiAgICAgICAgcGFnZXMuc29tZSgocGFnZSk9PntcbiAgICAgICAgICAgIGlmICgoMCwgX2lzRHluYW1pYykuaXNEeW5hbWljUm91dGUocGFnZSkgJiYgKDAsIF9yb3V0ZVJlZ2V4KS5nZXRSb3V0ZVJlZ2V4KHBhZ2UpLnJlLnRlc3QoY2xlYW5QYXRobmFtZSkpIHtcbiAgICAgICAgICAgICAgICBwYXRobmFtZSA9IHBhZ2U7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZSk7XG59XG5jb25zdCBtYW51YWxTY3JvbGxSZXN0b3JhdGlvbiA9IHByb2Nlc3MuZW52Ll9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04gJiYgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgJ3Njcm9sbFJlc3RvcmF0aW9uJyBpbiB3aW5kb3cuaGlzdG9yeSAmJiAhIWZ1bmN0aW9uKCkge1xuICAgIHRyeSB7XG4gICAgICAgIGxldCB2ID0gJ19fbmV4dCc7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1zZXF1ZW5jZXNcbiAgICAgICAgcmV0dXJuIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0odiwgdiksIHNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0odiksIHRydWU7XG4gICAgfSBjYXRjaCAobikge1xuICAgIH1cbn0oKTtcbmNvbnN0IFNTR19EQVRBX05PVF9GT1VORCA9IFN5bWJvbCgnU1NHX0RBVEFfTk9UX0ZPVU5EJyk7XG5mdW5jdGlvbiBmZXRjaFJldHJ5KHVybCwgYXR0ZW1wdHMpIHtcbiAgICByZXR1cm4gZmV0Y2godXJsLCB7XG4gICAgICAgIC8vIENvb2tpZXMgYXJlIHJlcXVpcmVkIHRvIGJlIHByZXNlbnQgZm9yIE5leHQuanMnIFNTRyBcIlByZXZpZXcgTW9kZVwiLlxuICAgICAgICAvLyBDb29raWVzIG1heSBhbHNvIGJlIHJlcXVpcmVkIGZvciBgZ2V0U2VydmVyU2lkZVByb3BzYC5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gPiBgZmV0Y2hgIHdvbuKAmXQgc2VuZCBjb29raWVzLCB1bmxlc3MgeW91IHNldCB0aGUgY3JlZGVudGlhbHMgaW5pdFxuICAgICAgICAvLyA+IG9wdGlvbi5cbiAgICAgICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0ZldGNoX0FQSS9Vc2luZ19GZXRjaFxuICAgICAgICAvL1xuICAgICAgICAvLyA+IEZvciBtYXhpbXVtIGJyb3dzZXIgY29tcGF0aWJpbGl0eSB3aGVuIGl0IGNvbWVzIHRvIHNlbmRpbmcgJlxuICAgICAgICAvLyA+IHJlY2VpdmluZyBjb29raWVzLCBhbHdheXMgc3VwcGx5IHRoZSBgY3JlZGVudGlhbHM6ICdzYW1lLW9yaWdpbidgXG4gICAgICAgIC8vID4gb3B0aW9uIGluc3RlYWQgb2YgcmVseWluZyBvbiB0aGUgZGVmYXVsdC5cbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2dpdGh1Yi9mZXRjaCNjYXZlYXRzXG4gICAgICAgIGNyZWRlbnRpYWxzOiAnc2FtZS1vcmlnaW4nXG4gICAgfSkudGhlbigocmVzKT0+e1xuICAgICAgICBpZiAoIXJlcy5vaykge1xuICAgICAgICAgICAgaWYgKGF0dGVtcHRzID4gMSAmJiByZXMuc3RhdHVzID49IDUwMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmZXRjaFJldHJ5KHVybCwgYXR0ZW1wdHMgLSAxKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzLmpzb24oKS50aGVuKChkYXRhKT0+e1xuICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YS5ub3RGb3VuZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBub3RGb3VuZDogU1NHX0RBVEFfTk9UX0ZPVU5EXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc3RhdGljIHByb3BzYCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBsb2FkIHN0YXRpYyBwcm9wc2ApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXMuanNvbigpO1xuICAgIH0pO1xufVxuZnVuY3Rpb24gZmV0Y2hOZXh0RGF0YShkYXRhSHJlZiwgaXNTZXJ2ZXJSZW5kZXIpIHtcbiAgICByZXR1cm4gZmV0Y2hSZXRyeShkYXRhSHJlZiwgaXNTZXJ2ZXJSZW5kZXIgPyAzIDogMSkuY2F0Y2goKGVycik9PntcbiAgICAgICAgLy8gV2Ugc2hvdWxkIG9ubHkgdHJpZ2dlciBhIHNlcnZlci1zaWRlIHRyYW5zaXRpb24gaWYgdGhpcyB3YXMgY2F1c2VkXG4gICAgICAgIC8vIG9uIGEgY2xpZW50LXNpZGUgdHJhbnNpdGlvbi4gT3RoZXJ3aXNlLCB3ZSdkIGdldCBpbnRvIGFuIGluZmluaXRlXG4gICAgICAgIC8vIGxvb3AuXG4gICAgICAgIGlmICghaXNTZXJ2ZXJSZW5kZXIpIHtcbiAgICAgICAgICAgICgwLCBfcm91dGVMb2FkZXIpLm1hcmtBc3NldEVycm9yKGVycik7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgZXJyO1xuICAgIH0pO1xufVxuY2xhc3MgUm91dGVyIHtcbiAgICBjb25zdHJ1Y3RvcihwYXRobmFtZTEsIHF1ZXJ5MSwgYXMxLCB7IGluaXRpYWxQcm9wcyAsIHBhZ2VMb2FkZXIgLCBBcHAgLCB3cmFwQXBwICwgQ29tcG9uZW50OiBDb21wb25lbnQxICwgZXJyOiBlcnIxICwgc3Vic2NyaXB0aW9uICwgaXNGYWxsYmFjayAsIGxvY2FsZSAsIGxvY2FsZXMgLCBkZWZhdWx0TG9jYWxlICwgZG9tYWluTG9jYWxlcyAsIGlzUHJldmlldyAgfSl7XG4gICAgICAgIC8vIFN0YXRpYyBEYXRhIENhY2hlXG4gICAgICAgIHRoaXMuc2RjID0ge1xuICAgICAgICB9O1xuICAgICAgICAvLyBJbi1mbGlnaHQgU2VydmVyIERhdGEgUmVxdWVzdHMsIGZvciBkZWR1cGluZ1xuICAgICAgICB0aGlzLnNkciA9IHtcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5faWR4ID0gMDtcbiAgICAgICAgdGhpcy5vblBvcFN0YXRlID0gKGUpPT57XG4gICAgICAgICAgICBjb25zdCBzdGF0ZSA9IGUuc3RhdGU7XG4gICAgICAgICAgICBpZiAoIXN0YXRlKSB7XG4gICAgICAgICAgICAgICAgLy8gV2UgZ2V0IHN0YXRlIGFzIHVuZGVmaW5lZCBmb3IgdHdvIHJlYXNvbnMuXG4gICAgICAgICAgICAgICAgLy8gIDEuIFdpdGggb2xkZXIgc2FmYXJpICg8IDgpIGFuZCBvbGRlciBjaHJvbWUgKDwgMzQpXG4gICAgICAgICAgICAgICAgLy8gIDIuIFdoZW4gdGhlIFVSTCBjaGFuZ2VkIHdpdGggI1xuICAgICAgICAgICAgICAgIC8vXG4gICAgICAgICAgICAgICAgLy8gSW4gdGhlIGJvdGggY2FzZXMsIHdlIGRvbid0IG5lZWQgdG8gcHJvY2VlZCBhbmQgY2hhbmdlIHRoZSByb3V0ZS5cbiAgICAgICAgICAgICAgICAvLyAoYXMgaXQncyBhbHJlYWR5IGNoYW5nZWQpXG4gICAgICAgICAgICAgICAgLy8gQnV0IHdlIGNhbiBzaW1wbHkgcmVwbGFjZSB0aGUgc3RhdGUgd2l0aCB0aGUgbmV3IGNoYW5nZXMuXG4gICAgICAgICAgICAgICAgLy8gQWN0dWFsbHksIGZvciAoMSkgd2UgZG9uJ3QgbmVlZCB0byBub3RoaW5nLiBCdXQgaXQncyBoYXJkIHRvIGRldGVjdCB0aGF0IGV2ZW50LlxuICAgICAgICAgICAgICAgIC8vIFNvLCBkb2luZyB0aGUgZm9sbG93aW5nIGZvciAoMSkgZG9lcyBubyBoYXJtLlxuICAgICAgICAgICAgICAgIGNvbnN0IHsgcGF0aG5hbWU6IHBhdGhuYW1lMSAsIHF1ZXJ5OiBxdWVyeTEgIH0gPSB0aGlzO1xuICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlU3RhdGUoJ3JlcGxhY2VTdGF0ZScsICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aG5hbWU6IGFkZEJhc2VQYXRoKHBhdGhuYW1lMSksXG4gICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiBxdWVyeTFcbiAgICAgICAgICAgICAgICB9KSwgKDAsIF91dGlscykuZ2V0VVJMKCkpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghc3RhdGUuX19OKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IGZvcmNlZFNjcm9sbDtcbiAgICAgICAgICAgIGNvbnN0IHsgdXJsICwgYXM6IGFzMSAsIG9wdGlvbnMgLCBpZHggIH0gPSBzdGF0ZTtcbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfU0NST0xMX1JFU1RPUkFUSU9OKSB7XG4gICAgICAgICAgICAgICAgaWYgKG1hbnVhbFNjcm9sbFJlc3RvcmF0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pZHggIT09IGlkeCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gU25hcHNob3QgY3VycmVudCBzY3JvbGwgcG9zaXRpb246XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ19fbmV4dF9zY3JvbGxfJyArIHRoaXMuX2lkeCwgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB4OiBzZWxmLnBhZ2VYT2Zmc2V0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB5OiBzZWxmLnBhZ2VZT2Zmc2V0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAge1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVzdG9yZSBvbGQgc2Nyb2xsIHBvc2l0aW9uOlxuICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2ID0gc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSgnX19uZXh0X3Njcm9sbF8nICsgaWR4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JjZWRTY3JvbGwgPSBKU09OLnBhcnNlKHYpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcmNlZFNjcm9sbCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeDogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeTogMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLl9pZHggPSBpZHg7XG4gICAgICAgICAgICBjb25zdCB7IHBhdGhuYW1lOiBwYXRobmFtZTEgIH0gPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwodXJsKTtcbiAgICAgICAgICAgIC8vIE1ha2Ugc3VyZSB3ZSBkb24ndCByZS1yZW5kZXIgb24gaW5pdGlhbCBsb2FkLFxuICAgICAgICAgICAgLy8gY2FuIGJlIGNhdXNlZCBieSBuYXZpZ2F0aW5nIGJhY2sgZnJvbSBhbiBleHRlcm5hbCBzaXRlXG4gICAgICAgICAgICBpZiAodGhpcy5pc1NzciAmJiBhczEgPT09IHRoaXMuYXNQYXRoICYmIHBhdGhuYW1lMSA9PT0gdGhpcy5wYXRobmFtZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIElmIHRoZSBkb3duc3RyZWFtIGFwcGxpY2F0aW9uIHJldHVybnMgZmFsc3ksIHJldHVybi5cbiAgICAgICAgICAgIC8vIFRoZXkgd2lsbCB0aGVuIGJlIHJlc3BvbnNpYmxlIGZvciBoYW5kbGluZyB0aGUgZXZlbnQuXG4gICAgICAgICAgICBpZiAodGhpcy5fYnBzICYmICF0aGlzLl9icHMoc3RhdGUpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5jaGFuZ2UoJ3JlcGxhY2VTdGF0ZScsIHVybCwgYXMxLCBPYmplY3QuYXNzaWduKHtcbiAgICAgICAgICAgIH0sIG9wdGlvbnMsIHtcbiAgICAgICAgICAgICAgICBzaGFsbG93OiBvcHRpb25zLnNoYWxsb3cgJiYgdGhpcy5fc2hhbGxvdyxcbiAgICAgICAgICAgICAgICBsb2NhbGU6IG9wdGlvbnMubG9jYWxlIHx8IHRoaXMuZGVmYXVsdExvY2FsZVxuICAgICAgICAgICAgfSksIGZvcmNlZFNjcm9sbCk7XG4gICAgICAgIH07XG4gICAgICAgIC8vIHJlcHJlc2VudHMgdGhlIGN1cnJlbnQgY29tcG9uZW50IGtleVxuICAgICAgICB0aGlzLnJvdXRlID0gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZTEpO1xuICAgICAgICAvLyBzZXQgdXAgdGhlIGNvbXBvbmVudCBjYWNoZSAoYnkgcm91dGUga2V5cylcbiAgICAgICAgdGhpcy5jb21wb25lbnRzID0ge1xuICAgICAgICB9O1xuICAgICAgICAvLyBXZSBzaG91bGQgbm90IGtlZXAgdGhlIGNhY2hlLCBpZiB0aGVyZSdzIGFuIGVycm9yXG4gICAgICAgIC8vIE90aGVyd2lzZSwgdGhpcyBjYXVzZSBpc3N1ZXMgd2hlbiB3aGVuIGdvaW5nIGJhY2sgYW5kXG4gICAgICAgIC8vIGNvbWUgYWdhaW4gdG8gdGhlIGVycm9yZWQgcGFnZS5cbiAgICAgICAgaWYgKHBhdGhuYW1lMSAhPT0gJy9fZXJyb3InKSB7XG4gICAgICAgICAgICB0aGlzLmNvbXBvbmVudHNbdGhpcy5yb3V0ZV0gPSB7XG4gICAgICAgICAgICAgICAgQ29tcG9uZW50OiBDb21wb25lbnQxLFxuICAgICAgICAgICAgICAgIGluaXRpYWw6IHRydWUsXG4gICAgICAgICAgICAgICAgcHJvcHM6IGluaXRpYWxQcm9wcyxcbiAgICAgICAgICAgICAgICBlcnI6IGVycjEsXG4gICAgICAgICAgICAgICAgX19OX1NTRzogaW5pdGlhbFByb3BzICYmIGluaXRpYWxQcm9wcy5fX05fU1NHLFxuICAgICAgICAgICAgICAgIF9fTl9TU1A6IGluaXRpYWxQcm9wcyAmJiBpbml0aWFsUHJvcHMuX19OX1NTUFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNvbXBvbmVudHNbJy9fYXBwJ10gPSB7XG4gICAgICAgICAgICBDb21wb25lbnQ6IEFwcCxcbiAgICAgICAgICAgIHN0eWxlU2hlZXRzOiBbXVxuICAgICAgICB9O1xuICAgICAgICAvLyBCYWNrd2FyZHMgY29tcGF0IGZvciBSb3V0ZXIucm91dGVyLmV2ZW50c1xuICAgICAgICAvLyBUT0RPOiBTaG91bGQgYmUgcmVtb3ZlIHRoZSBmb2xsb3dpbmcgbWFqb3IgdmVyc2lvbiBhcyBpdCB3YXMgbmV2ZXIgZG9jdW1lbnRlZFxuICAgICAgICB0aGlzLmV2ZW50cyA9IFJvdXRlci5ldmVudHM7XG4gICAgICAgIHRoaXMucGFnZUxvYWRlciA9IHBhZ2VMb2FkZXI7XG4gICAgICAgIHRoaXMucGF0aG5hbWUgPSBwYXRobmFtZTE7XG4gICAgICAgIHRoaXMucXVlcnkgPSBxdWVyeTE7XG4gICAgICAgIC8vIGlmIGF1dG8gcHJlcmVuZGVyZWQgYW5kIGR5bmFtaWMgcm91dGUgd2FpdCB0byB1cGRhdGUgYXNQYXRoXG4gICAgICAgIC8vIHVudGlsIGFmdGVyIG1vdW50IHRvIHByZXZlbnQgaHlkcmF0aW9uIG1pc21hdGNoXG4gICAgICAgIGNvbnN0IGF1dG9FeHBvcnREeW5hbWljID0gKDAsIF9pc0R5bmFtaWMpLmlzRHluYW1pY1JvdXRlKHBhdGhuYW1lMSkgJiYgc2VsZi5fX05FWFRfREFUQV9fLmF1dG9FeHBvcnQ7XG4gICAgICAgIHRoaXMuYXNQYXRoID0gYXV0b0V4cG9ydER5bmFtaWMgPyBwYXRobmFtZTEgOiBhczE7XG4gICAgICAgIHRoaXMuYmFzZVBhdGggPSBiYXNlUGF0aDtcbiAgICAgICAgdGhpcy5zdWIgPSBzdWJzY3JpcHRpb247XG4gICAgICAgIHRoaXMuY2xjID0gbnVsbDtcbiAgICAgICAgdGhpcy5fd3JhcEFwcCA9IHdyYXBBcHA7XG4gICAgICAgIC8vIG1ha2Ugc3VyZSB0byBpZ25vcmUgZXh0cmEgcG9wU3RhdGUgaW4gc2FmYXJpIG9uIG5hdmlnYXRpbmdcbiAgICAgICAgLy8gYmFjayBmcm9tIGV4dGVybmFsIHNpdGVcbiAgICAgICAgdGhpcy5pc1NzciA9IHRydWU7XG4gICAgICAgIHRoaXMuaXNGYWxsYmFjayA9IGlzRmFsbGJhY2s7XG4gICAgICAgIHRoaXMuaXNSZWFkeSA9ICEhKHNlbGYuX19ORVhUX0RBVEFfXy5nc3NwIHx8IHNlbGYuX19ORVhUX0RBVEFfXy5naXAgfHwgc2VsZi5fX05FWFRfREFUQV9fLmFwcEdpcCAmJiAhc2VsZi5fX05FWFRfREFUQV9fLmdzcCB8fCAhYXV0b0V4cG9ydER5bmFtaWMgJiYgIXNlbGYubG9jYXRpb24uc2VhcmNoICYmICFwcm9jZXNzLmVudi5fX05FWFRfSEFTX1JFV1JJVEVTKTtcbiAgICAgICAgdGhpcy5pc1ByZXZpZXcgPSAhIWlzUHJldmlldztcbiAgICAgICAgdGhpcy5pc0xvY2FsZURvbWFpbiA9IGZhbHNlO1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICAgICAgdGhpcy5sb2NhbGUgPSBsb2NhbGU7XG4gICAgICAgICAgICB0aGlzLmxvY2FsZXMgPSBsb2NhbGVzO1xuICAgICAgICAgICAgdGhpcy5kZWZhdWx0TG9jYWxlID0gZGVmYXVsdExvY2FsZTtcbiAgICAgICAgICAgIHRoaXMuZG9tYWluTG9jYWxlcyA9IGRvbWFpbkxvY2FsZXM7XG4gICAgICAgICAgICB0aGlzLmlzTG9jYWxlRG9tYWluID0gISFkZXRlY3REb21haW5Mb2NhbGUoZG9tYWluTG9jYWxlcywgc2VsZi5sb2NhdGlvbi5ob3N0bmFtZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAvLyBtYWtlIHN1cmUgXCJhc1wiIGRvZXNuJ3Qgc3RhcnQgd2l0aCBkb3VibGUgc2xhc2hlcyBvciBlbHNlIGl0IGNhblxuICAgICAgICAgICAgLy8gdGhyb3cgYW4gZXJyb3IgYXMgaXQncyBjb25zaWRlcmVkIGludmFsaWRcbiAgICAgICAgICAgIGlmIChhczEuc3Vic3RyKDAsIDIpICE9PSAnLy8nKSB7XG4gICAgICAgICAgICAgICAgLy8gaW4gb3JkZXIgZm9yIGBlLnN0YXRlYCB0byB3b3JrIG9uIHRoZSBgb25wb3BzdGF0ZWAgZXZlbnRcbiAgICAgICAgICAgICAgICAvLyB3ZSBoYXZlIHRvIHJlZ2lzdGVyIHRoZSBpbml0aWFsIHJvdXRlIHVwb24gaW5pdGlhbGl6YXRpb25cbiAgICAgICAgICAgICAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgICAgICAgICAgICAgICBsb2NhbGVcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIG9wdGlvbnMuX3Nob3VsZFJlc29sdmVIcmVmID0gYXMxICE9PSBwYXRobmFtZTE7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VTdGF0ZSgncmVwbGFjZVN0YXRlJywgKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTogYWRkQmFzZVBhdGgocGF0aG5hbWUxKSxcbiAgICAgICAgICAgICAgICAgICAgcXVlcnk6IHF1ZXJ5MVxuICAgICAgICAgICAgICAgIH0pLCAoMCwgX3V0aWxzKS5nZXRVUkwoKSwgb3B0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncG9wc3RhdGUnLCB0aGlzLm9uUG9wU3RhdGUpO1xuICAgICAgICAgICAgLy8gZW5hYmxlIGN1c3RvbSBzY3JvbGwgcmVzdG9yYXRpb24gaGFuZGxpbmcgd2hlbiBhdmFpbGFibGVcbiAgICAgICAgICAgIC8vIG90aGVyd2lzZSBmYWxsYmFjayB0byBicm93c2VyJ3MgZGVmYXVsdCBoYW5kbGluZ1xuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04pIHtcbiAgICAgICAgICAgICAgICBpZiAobWFudWFsU2Nyb2xsUmVzdG9yYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93Lmhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24gPSAnbWFudWFsJztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmVsb2FkKCkge1xuICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XG4gICAgfVxuICAgIC8qKlxuICAgKiBHbyBiYWNrIGluIGhpc3RvcnlcbiAgICovIGJhY2soKSB7XG4gICAgICAgIHdpbmRvdy5oaXN0b3J5LmJhY2soKTtcbiAgICB9XG4gICAgLyoqXG4gICAqIFBlcmZvcm1zIGEgYHB1c2hTdGF0ZWAgd2l0aCBhcmd1bWVudHNcbiAgICogQHBhcmFtIHVybCBvZiB0aGUgcm91dGVcbiAgICogQHBhcmFtIGFzIG1hc2tzIGB1cmxgIGZvciB0aGUgYnJvd3NlclxuICAgKiBAcGFyYW0gb3B0aW9ucyBvYmplY3QgeW91IGNhbiBkZWZpbmUgYHNoYWxsb3dgIGFuZCBvdGhlciBvcHRpb25zXG4gICAqLyBwdXNoKHVybCwgYXMsIG9wdGlvbnMgPSB7XG4gICAgfSkge1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX1NDUk9MTF9SRVNUT1JBVElPTikge1xuICAgICAgICAgICAgLy8gVE9ETzogcmVtb3ZlIGluIHRoZSBmdXR1cmUgd2hlbiB3ZSB1cGRhdGUgaGlzdG9yeSBiZWZvcmUgcm91dGUgY2hhbmdlXG4gICAgICAgICAgICAvLyBpcyBjb21wbGV0ZSwgYXMgdGhlIHBvcHN0YXRlIGV2ZW50IHNob3VsZCBoYW5kbGUgdGhpcyBjYXB0dXJlLlxuICAgICAgICAgICAgaWYgKG1hbnVhbFNjcm9sbFJlc3RvcmF0aW9uKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgLy8gU25hcHNob3Qgc2Nyb2xsIHBvc2l0aW9uIHJpZ2h0IGJlZm9yZSBuYXZpZ2F0aW5nIHRvIGEgbmV3IHBhZ2U6XG4gICAgICAgICAgICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ19fbmV4dF9zY3JvbGxfJyArIHRoaXMuX2lkeCwgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgeDogc2VsZi5wYWdlWE9mZnNldCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHk6IHNlbGYucGFnZVlPZmZzZXRcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggIHtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgKHsgdXJsICwgYXMgIH0gPSBwcmVwYXJlVXJsQXModGhpcywgdXJsLCBhcykpO1xuICAgICAgICByZXR1cm4gdGhpcy5jaGFuZ2UoJ3B1c2hTdGF0ZScsIHVybCwgYXMsIG9wdGlvbnMpO1xuICAgIH1cbiAgICAvKipcbiAgICogUGVyZm9ybXMgYSBgcmVwbGFjZVN0YXRlYCB3aXRoIGFyZ3VtZW50c1xuICAgKiBAcGFyYW0gdXJsIG9mIHRoZSByb3V0ZVxuICAgKiBAcGFyYW0gYXMgbWFza3MgYHVybGAgZm9yIHRoZSBicm93c2VyXG4gICAqIEBwYXJhbSBvcHRpb25zIG9iamVjdCB5b3UgY2FuIGRlZmluZSBgc2hhbGxvd2AgYW5kIG90aGVyIG9wdGlvbnNcbiAgICovIHJlcGxhY2UodXJsLCBhcywgb3B0aW9ucyA9IHtcbiAgICB9KSB7XG4gICAgICAgICh7IHVybCAsIGFzICB9ID0gcHJlcGFyZVVybEFzKHRoaXMsIHVybCwgYXMpKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuY2hhbmdlKCdyZXBsYWNlU3RhdGUnLCB1cmwsIGFzLCBvcHRpb25zKTtcbiAgICB9XG4gICAgYXN5bmMgY2hhbmdlKG1ldGhvZCwgdXJsLCBhcywgb3B0aW9ucywgZm9yY2VkU2Nyb2xsKSB7XG4gICAgICAgIGlmICghaXNMb2NhbFVSTCh1cmwpKSB7XG4gICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IHVybDtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzaG91bGRSZXNvbHZlSHJlZiA9IHVybCA9PT0gYXMgfHwgb3B0aW9ucy5faCB8fCBvcHRpb25zLl9zaG91bGRSZXNvbHZlSHJlZjtcbiAgICAgICAgLy8gZm9yIHN0YXRpYyBwYWdlcyB3aXRoIHF1ZXJ5IHBhcmFtcyBpbiB0aGUgVVJMIHdlIGRlbGF5XG4gICAgICAgIC8vIG1hcmtpbmcgdGhlIHJvdXRlciByZWFkeSB1bnRpbCBhZnRlciB0aGUgcXVlcnkgaXMgdXBkYXRlZFxuICAgICAgICBpZiAob3B0aW9ucy5faCkge1xuICAgICAgICAgICAgdGhpcy5pc1JlYWR5ID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwcmV2TG9jYWxlID0gdGhpcy5sb2NhbGU7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgICAgICB0aGlzLmxvY2FsZSA9IG9wdGlvbnMubG9jYWxlID09PSBmYWxzZSA/IHRoaXMuZGVmYXVsdExvY2FsZSA6IG9wdGlvbnMubG9jYWxlIHx8IHRoaXMubG9jYWxlO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBvcHRpb25zLmxvY2FsZSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICBvcHRpb25zLmxvY2FsZSA9IHRoaXMubG9jYWxlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgcGFyc2VkQXMgPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwoaGFzQmFzZVBhdGgoYXMpID8gZGVsQmFzZVBhdGgoYXMpIDogYXMpO1xuICAgICAgICAgICAgY29uc3QgbG9jYWxlUGF0aFJlc3VsdCA9ICgwLCBfbm9ybWFsaXplTG9jYWxlUGF0aCkubm9ybWFsaXplTG9jYWxlUGF0aChwYXJzZWRBcy5wYXRobmFtZSwgdGhpcy5sb2NhbGVzKTtcbiAgICAgICAgICAgIGlmIChsb2NhbGVQYXRoUmVzdWx0LmRldGVjdGVkTG9jYWxlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2NhbGUgPSBsb2NhbGVQYXRoUmVzdWx0LmRldGVjdGVkTG9jYWxlO1xuICAgICAgICAgICAgICAgIHBhcnNlZEFzLnBhdGhuYW1lID0gYWRkQmFzZVBhdGgocGFyc2VkQXMucGF0aG5hbWUpO1xuICAgICAgICAgICAgICAgIGFzID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkQXMpO1xuICAgICAgICAgICAgICAgIHVybCA9IGFkZEJhc2VQYXRoKCgwLCBfbm9ybWFsaXplTG9jYWxlUGF0aCkubm9ybWFsaXplTG9jYWxlUGF0aChoYXNCYXNlUGF0aCh1cmwpID8gZGVsQmFzZVBhdGgodXJsKSA6IHVybCwgdGhpcy5sb2NhbGVzKS5wYXRobmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgZGlkTmF2aWdhdGUgPSBmYWxzZTtcbiAgICAgICAgICAgIC8vIHdlIG5lZWQgdG8gd3JhcCB0aGlzIGluIHRoZSBlbnYgY2hlY2sgYWdhaW4gc2luY2UgcmVnZW5lcmF0b3IgcnVudGltZVxuICAgICAgICAgICAgLy8gbW92ZXMgdGhpcyBvbiBpdHMgb3duIGR1ZSB0byB0aGUgcmV0dXJuXG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICAgICAgICAgIHZhciByZWY7XG4gICAgICAgICAgICAgICAgLy8gaWYgdGhlIGxvY2FsZSBpc24ndCBjb25maWd1cmVkIGhhcmQgbmF2aWdhdGUgdG8gc2hvdyA0MDQgcGFnZVxuICAgICAgICAgICAgICAgIGlmICghKChyZWYgPSB0aGlzLmxvY2FsZXMpID09PSBudWxsIHx8IHJlZiA9PT0gdm9pZCAwID8gdm9pZCAwIDogcmVmLmluY2x1ZGVzKHRoaXMubG9jYWxlKSkpIHtcbiAgICAgICAgICAgICAgICAgICAgcGFyc2VkQXMucGF0aG5hbWUgPSBhZGRMb2NhbGUocGFyc2VkQXMucGF0aG5hbWUsIHRoaXMubG9jYWxlKTtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWRBcyk7XG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMgd2FzIHByZXZpb3VzbHkgYSByZXR1cm4gYnV0IHdhcyByZW1vdmVkIGluIGZhdm9yXG4gICAgICAgICAgICAgICAgICAgIC8vIG9mIGJldHRlciBkZWFkIGNvZGUgZWxpbWluYXRpb24gd2l0aCByZWdlbmVyYXRvciBydW50aW1lXG4gICAgICAgICAgICAgICAgICAgIGRpZE5hdmlnYXRlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBkZXRlY3RlZERvbWFpbiA9IGRldGVjdERvbWFpbkxvY2FsZSh0aGlzLmRvbWFpbkxvY2FsZXMsIHVuZGVmaW5lZCwgdGhpcy5sb2NhbGUpO1xuICAgICAgICAgICAgLy8gd2UgbmVlZCB0byB3cmFwIHRoaXMgaW4gdGhlIGVudiBjaGVjayBhZ2FpbiBzaW5jZSByZWdlbmVyYXRvciBydW50aW1lXG4gICAgICAgICAgICAvLyBtb3ZlcyB0aGlzIG9uIGl0cyBvd24gZHVlIHRvIHRoZSByZXR1cm5cbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgICAgICAgICAgLy8gaWYgd2UgYXJlIG5hdmlnYXRpbmcgdG8gYSBkb21haW4gbG9jYWxlIGVuc3VyZSB3ZSByZWRpcmVjdCB0byB0aGVcbiAgICAgICAgICAgICAgICAvLyBjb3JyZWN0IGRvbWFpblxuICAgICAgICAgICAgICAgIGlmICghZGlkTmF2aWdhdGUgJiYgZGV0ZWN0ZWREb21haW4gJiYgdGhpcy5pc0xvY2FsZURvbWFpbiAmJiBzZWxmLmxvY2F0aW9uLmhvc3RuYW1lICE9PSBkZXRlY3RlZERvbWFpbi5kb21haW4pIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYXNOb0Jhc2VQYXRoID0gZGVsQmFzZVBhdGgoYXMpO1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IGBodHRwJHtkZXRlY3RlZERvbWFpbi5odHRwID8gJycgOiAncyd9Oi8vJHtkZXRlY3RlZERvbWFpbi5kb21haW59JHthZGRCYXNlUGF0aChgJHt0aGlzLmxvY2FsZSA9PT0gZGV0ZWN0ZWREb21haW4uZGVmYXVsdExvY2FsZSA/ICcnIDogYC8ke3RoaXMubG9jYWxlfWB9JHthc05vQmFzZVBhdGggPT09ICcvJyA/ICcnIDogYXNOb0Jhc2VQYXRofWAgfHwgJy8nKX1gO1xuICAgICAgICAgICAgICAgICAgICAvLyB0aGlzIHdhcyBwcmV2aW91c2x5IGEgcmV0dXJuIGJ1dCB3YXMgcmVtb3ZlZCBpbiBmYXZvclxuICAgICAgICAgICAgICAgICAgICAvLyBvZiBiZXR0ZXIgZGVhZCBjb2RlIGVsaW1pbmF0aW9uIHdpdGggcmVnZW5lcmF0b3IgcnVudGltZVxuICAgICAgICAgICAgICAgICAgICBkaWROYXZpZ2F0ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGRpZE5hdmlnYXRlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKCgpPT57XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFvcHRpb25zLl9oKSB7XG4gICAgICAgICAgICB0aGlzLmlzU3NyID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgLy8gbWFya2luZyByb3V0ZSBjaGFuZ2VzIGFzIGEgbmF2aWdhdGlvbiBzdGFydCBlbnRyeVxuICAgICAgICBpZiAoX3V0aWxzLlNUKSB7XG4gICAgICAgICAgICBwZXJmb3JtYW5jZS5tYXJrKCdyb3V0ZUNoYW5nZScpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgc2hhbGxvdyA9ZmFsc2UgIH0gPSBvcHRpb25zO1xuICAgICAgICBjb25zdCByb3V0ZVByb3BzID0ge1xuICAgICAgICAgICAgc2hhbGxvd1xuICAgICAgICB9O1xuICAgICAgICBpZiAodGhpcy5faW5GbGlnaHRSb3V0ZSkge1xuICAgICAgICAgICAgdGhpcy5hYm9ydENvbXBvbmVudExvYWQodGhpcy5faW5GbGlnaHRSb3V0ZSwgcm91dGVQcm9wcyk7XG4gICAgICAgIH1cbiAgICAgICAgYXMgPSBhZGRCYXNlUGF0aChhZGRMb2NhbGUoaGFzQmFzZVBhdGgoYXMpID8gZGVsQmFzZVBhdGgoYXMpIDogYXMsIG9wdGlvbnMubG9jYWxlLCB0aGlzLmRlZmF1bHRMb2NhbGUpKTtcbiAgICAgICAgY29uc3QgY2xlYW5lZEFzID0gZGVsTG9jYWxlKGhhc0Jhc2VQYXRoKGFzKSA/IGRlbEJhc2VQYXRoKGFzKSA6IGFzLCB0aGlzLmxvY2FsZSk7XG4gICAgICAgIHRoaXMuX2luRmxpZ2h0Um91dGUgPSBhcztcbiAgICAgICAgbGV0IGxvY2FsZUNoYW5nZSA9IHByZXZMb2NhbGUgIT09IHRoaXMubG9jYWxlO1xuICAgICAgICAvLyBJZiB0aGUgdXJsIGNoYW5nZSBpcyBvbmx5IHJlbGF0ZWQgdG8gYSBoYXNoIGNoYW5nZVxuICAgICAgICAvLyBXZSBzaG91bGQgbm90IHByb2NlZWQuIFdlIHNob3VsZCBvbmx5IGNoYW5nZSB0aGUgc3RhdGUuXG4gICAgICAgIC8vIFdBUk5JTkc6IGBfaGAgaXMgYW4gaW50ZXJuYWwgb3B0aW9uIGZvciBoYW5kaW5nIE5leHQuanMgY2xpZW50LXNpZGVcbiAgICAgICAgLy8gaHlkcmF0aW9uLiBZb3VyIGFwcCBzaG91bGQgX25ldmVyXyB1c2UgdGhpcyBwcm9wZXJ0eS4gSXQgbWF5IGNoYW5nZSBhdFxuICAgICAgICAvLyBhbnkgdGltZSB3aXRob3V0IG5vdGljZS5cbiAgICAgICAgaWYgKCFvcHRpb25zLl9oICYmIHRoaXMub25seUFIYXNoQ2hhbmdlKGNsZWFuZWRBcykgJiYgIWxvY2FsZUNoYW5nZSkge1xuICAgICAgICAgICAgdGhpcy5hc1BhdGggPSBjbGVhbmVkQXM7XG4gICAgICAgICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ2hhc2hDaGFuZ2VTdGFydCcsIGFzLCByb3V0ZVByb3BzKTtcbiAgICAgICAgICAgIC8vIFRPRE86IGRvIHdlIG5lZWQgdGhlIHJlc29sdmVkIGhyZWYgd2hlbiBvbmx5IGEgaGFzaCBjaGFuZ2U/XG4gICAgICAgICAgICB0aGlzLmNoYW5nZVN0YXRlKG1ldGhvZCwgdXJsLCBhcywgb3B0aW9ucyk7XG4gICAgICAgICAgICB0aGlzLnNjcm9sbFRvSGFzaChjbGVhbmVkQXMpO1xuICAgICAgICAgICAgdGhpcy5ub3RpZnkodGhpcy5jb21wb25lbnRzW3RoaXMucm91dGVdLCBudWxsKTtcbiAgICAgICAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgnaGFzaENoYW5nZUNvbXBsZXRlJywgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHBhcnNlZCA9ICgwLCBfcGFyc2VSZWxhdGl2ZVVybCkucGFyc2VSZWxhdGl2ZVVybCh1cmwpO1xuICAgICAgICBsZXQgeyBwYXRobmFtZTogcGF0aG5hbWUxICwgcXVlcnk6IHF1ZXJ5MSAgfSA9IHBhcnNlZDtcbiAgICAgICAgLy8gVGhlIGJ1aWxkIG1hbmlmZXN0IG5lZWRzIHRvIGJlIGxvYWRlZCBiZWZvcmUgYXV0by1zdGF0aWMgZHluYW1pYyBwYWdlc1xuICAgICAgICAvLyBnZXQgdGhlaXIgcXVlcnkgcGFyYW1ldGVycyB0byBhbGxvdyBlbnN1cmluZyB0aGV5IGNhbiBiZSBwYXJzZWQgcHJvcGVybHlcbiAgICAgICAgLy8gd2hlbiByZXdyaXR0ZW4gdG9cbiAgICAgICAgbGV0IHBhZ2VzLCByZXdyaXRlcztcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHBhZ2VzID0gYXdhaXQgdGhpcy5wYWdlTG9hZGVyLmdldFBhZ2VMaXN0KCk7XG4gICAgICAgICAgICAoeyBfX3Jld3JpdGVzOiByZXdyaXRlcyAgfSA9IGF3YWl0ICgwLCBfcm91dGVMb2FkZXIpLmdldENsaWVudEJ1aWxkTWFuaWZlc3QoKSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycjEpIHtcbiAgICAgICAgICAgIC8vIElmIHdlIGZhaWwgdG8gcmVzb2x2ZSB0aGUgcGFnZSBsaXN0IG9yIGNsaWVudC1idWlsZCBtYW5pZmVzdCwgd2UgbXVzdFxuICAgICAgICAgICAgLy8gZG8gYSBzZXJ2ZXItc2lkZSB0cmFuc2l0aW9uOlxuICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBhcztcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBJZiBhc2tlZCB0byBjaGFuZ2UgdGhlIGN1cnJlbnQgVVJMIHdlIHNob3VsZCByZWxvYWQgdGhlIGN1cnJlbnQgcGFnZVxuICAgICAgICAvLyAobm90IGxvY2F0aW9uLnJlbG9hZCgpIGJ1dCByZWxvYWQgZ2V0SW5pdGlhbFByb3BzIGFuZCBvdGhlciBOZXh0LmpzIHN0dWZmcylcbiAgICAgICAgLy8gV2UgYWxzbyBuZWVkIHRvIHNldCB0aGUgbWV0aG9kID0gcmVwbGFjZVN0YXRlIGFsd2F5c1xuICAgICAgICAvLyBhcyB0aGlzIHNob3VsZCBub3QgZ28gaW50byB0aGUgaGlzdG9yeSAoVGhhdCdzIGhvdyBicm93c2VycyB3b3JrKVxuICAgICAgICAvLyBXZSBzaG91bGQgY29tcGFyZSB0aGUgbmV3IGFzUGF0aCB0byB0aGUgY3VycmVudCBhc1BhdGgsIG5vdCB0aGUgdXJsXG4gICAgICAgIGlmICghdGhpcy51cmxJc05ldyhjbGVhbmVkQXMpICYmICFsb2NhbGVDaGFuZ2UpIHtcbiAgICAgICAgICAgIG1ldGhvZCA9ICdyZXBsYWNlU3RhdGUnO1xuICAgICAgICB9XG4gICAgICAgIC8vIHdlIG5lZWQgdG8gcmVzb2x2ZSB0aGUgYXMgdmFsdWUgdXNpbmcgcmV3cml0ZXMgZm9yIGR5bmFtaWMgU1NHXG4gICAgICAgIC8vIHBhZ2VzIHRvIGFsbG93IGJ1aWxkaW5nIHRoZSBkYXRhIFVSTCBjb3JyZWN0bHlcbiAgICAgICAgbGV0IHJlc29sdmVkQXMgPSBhcztcbiAgICAgICAgLy8gdXJsIGFuZCBhcyBzaG91bGQgYWx3YXlzIGJlIHByZWZpeGVkIHdpdGggYmFzZVBhdGggYnkgdGhpc1xuICAgICAgICAvLyBwb2ludCBieSBlaXRoZXIgbmV4dC9saW5rIG9yIHJvdXRlci5wdXNoL3JlcGxhY2Ugc28gc3RyaXAgdGhlXG4gICAgICAgIC8vIGJhc2VQYXRoIGZyb20gdGhlIHBhdGhuYW1lIHRvIG1hdGNoIHRoZSBwYWdlcyBkaXIgMS10by0xXG4gICAgICAgIHBhdGhuYW1lMSA9IHBhdGhuYW1lMSA/ICgwLCBfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCkucmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2goZGVsQmFzZVBhdGgocGF0aG5hbWUxKSkgOiBwYXRobmFtZTE7XG4gICAgICAgIGlmIChzaG91bGRSZXNvbHZlSHJlZiAmJiBwYXRobmFtZTEgIT09ICcvX2Vycm9yJykge1xuICAgICAgICAgICAgb3B0aW9ucy5fc2hvdWxkUmVzb2x2ZUhyZWYgPSB0cnVlO1xuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9IQVNfUkVXUklURVMgJiYgYXMuc3RhcnRzV2l0aCgnLycpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmV3cml0ZXNSZXN1bHQgPSAoMCwgX3Jlc29sdmVSZXdyaXRlcykuZGVmYXVsdChhZGRCYXNlUGF0aChhZGRMb2NhbGUoY2xlYW5lZEFzLCB0aGlzLmxvY2FsZSkpLCBwYWdlcywgcmV3cml0ZXMsIHF1ZXJ5MSwgKHApPT5yZXNvbHZlRHluYW1pY1JvdXRlKHAsIHBhZ2VzKVxuICAgICAgICAgICAgICAgICwgdGhpcy5sb2NhbGVzKTtcbiAgICAgICAgICAgICAgICByZXNvbHZlZEFzID0gcmV3cml0ZXNSZXN1bHQuYXNQYXRoO1xuICAgICAgICAgICAgICAgIGlmIChyZXdyaXRlc1Jlc3VsdC5tYXRjaGVkUGFnZSAmJiByZXdyaXRlc1Jlc3VsdC5yZXNvbHZlZEhyZWYpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gaWYgdGhpcyBkaXJlY3RseSBtYXRjaGVzIGEgcGFnZSB3ZSBuZWVkIHRvIHVwZGF0ZSB0aGUgaHJlZiB0b1xuICAgICAgICAgICAgICAgICAgICAvLyBhbGxvdyB0aGUgY29ycmVjdCBwYWdlIGNodW5rIHRvIGJlIGxvYWRlZFxuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTEgPSByZXdyaXRlc1Jlc3VsdC5yZXNvbHZlZEhyZWY7XG4gICAgICAgICAgICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IGFkZEJhc2VQYXRoKHBhdGhuYW1lMSk7XG4gICAgICAgICAgICAgICAgICAgIHVybCA9ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwYXJzZWQucGF0aG5hbWUgPSByZXNvbHZlRHluYW1pY1JvdXRlKHBhdGhuYW1lMSwgcGFnZXMpO1xuICAgICAgICAgICAgICAgIGlmIChwYXJzZWQucGF0aG5hbWUgIT09IHBhdGhuYW1lMSkge1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTEgPSBwYXJzZWQucGF0aG5hbWU7XG4gICAgICAgICAgICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IGFkZEJhc2VQYXRoKHBhdGhuYW1lMSk7XG4gICAgICAgICAgICAgICAgICAgIHVybCA9ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJvdXRlID0gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZTEpO1xuICAgICAgICBpZiAoIWlzTG9jYWxVUkwoYXMpKSB7XG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBocmVmOiBcIiR7dXJsfVwiIGFuZCBhczogXCIke2FzfVwiLCByZWNlaXZlZCByZWxhdGl2ZSBocmVmIGFuZCBleHRlcm5hbCBhc2AgKyBgXFxuU2VlIG1vcmUgaW5mbzogaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvaW52YWxpZC1yZWxhdGl2ZS11cmwtZXh0ZXJuYWwtYXNgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gYXM7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmVzb2x2ZWRBcyA9IGRlbExvY2FsZShkZWxCYXNlUGF0aChyZXNvbHZlZEFzKSwgdGhpcy5sb2NhbGUpO1xuICAgICAgICBpZiAoKDAsIF9pc0R5bmFtaWMpLmlzRHluYW1pY1JvdXRlKHJvdXRlKSkge1xuICAgICAgICAgICAgY29uc3QgcGFyc2VkQXMgPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwocmVzb2x2ZWRBcyk7XG4gICAgICAgICAgICBjb25zdCBhc1BhdGhuYW1lID0gcGFyc2VkQXMucGF0aG5hbWU7XG4gICAgICAgICAgICBjb25zdCByb3V0ZVJlZ2V4ID0gKDAsIF9yb3V0ZVJlZ2V4KS5nZXRSb3V0ZVJlZ2V4KHJvdXRlKTtcbiAgICAgICAgICAgIGNvbnN0IHJvdXRlTWF0Y2ggPSAoMCwgX3JvdXRlTWF0Y2hlcikuZ2V0Um91dGVNYXRjaGVyKHJvdXRlUmVnZXgpKGFzUGF0aG5hbWUpO1xuICAgICAgICAgICAgY29uc3Qgc2hvdWxkSW50ZXJwb2xhdGUgPSByb3V0ZSA9PT0gYXNQYXRobmFtZTtcbiAgICAgICAgICAgIGNvbnN0IGludGVycG9sYXRlZEFzID0gc2hvdWxkSW50ZXJwb2xhdGUgPyBpbnRlcnBvbGF0ZUFzKHJvdXRlLCBhc1BhdGhuYW1lLCBxdWVyeTEpIDoge1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmICghcm91dGVNYXRjaCB8fCBzaG91bGRJbnRlcnBvbGF0ZSAmJiAhaW50ZXJwb2xhdGVkQXMucmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbWlzc2luZ1BhcmFtcyA9IE9iamVjdC5rZXlzKHJvdXRlUmVnZXguZ3JvdXBzKS5maWx0ZXIoKHBhcmFtKT0+IXF1ZXJ5MVtwYXJhbV1cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIGlmIChtaXNzaW5nUGFyYW1zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgJHtzaG91bGRJbnRlcnBvbGF0ZSA/IGBJbnRlcnBvbGF0aW5nIGhyZWZgIDogYE1pc21hdGNoaW5nIFxcYGFzXFxgIGFuZCBcXGBocmVmXFxgYH0gZmFpbGVkIHRvIG1hbnVhbGx5IHByb3ZpZGUgYCArIGB0aGUgcGFyYW1zOiAke21pc3NpbmdQYXJhbXMuam9pbignLCAnKX0gaW4gdGhlIFxcYGhyZWZcXGAncyBcXGBxdWVyeVxcYGApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigoc2hvdWxkSW50ZXJwb2xhdGUgPyBgVGhlIHByb3ZpZGVkIFxcYGhyZWZcXGAgKCR7dXJsfSkgdmFsdWUgaXMgbWlzc2luZyBxdWVyeSB2YWx1ZXMgKCR7bWlzc2luZ1BhcmFtcy5qb2luKCcsICcpfSkgdG8gYmUgaW50ZXJwb2xhdGVkIHByb3Blcmx5LiBgIDogYFRoZSBwcm92aWRlZCBcXGBhc1xcYCB2YWx1ZSAoJHthc1BhdGhuYW1lfSkgaXMgaW5jb21wYXRpYmxlIHdpdGggdGhlIFxcYGhyZWZcXGAgdmFsdWUgKCR7cm91dGV9KS4gYCkgKyBgUmVhZCBtb3JlOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy8ke3Nob3VsZEludGVycG9sYXRlID8gJ2hyZWYtaW50ZXJwb2xhdGlvbi1mYWlsZWQnIDogJ2luY29tcGF0aWJsZS1ocmVmLWFzJ31gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHNob3VsZEludGVycG9sYXRlKSB7XG4gICAgICAgICAgICAgICAgYXMgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbihPYmplY3QuYXNzaWduKHtcbiAgICAgICAgICAgICAgICB9LCBwYXJzZWRBcywge1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTogaW50ZXJwb2xhdGVkQXMucmVzdWx0LFxuICAgICAgICAgICAgICAgICAgICBxdWVyeTogb21pdFBhcm1zRnJvbVF1ZXJ5KHF1ZXJ5MSwgaW50ZXJwb2xhdGVkQXMucGFyYW1zKVxuICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gTWVyZ2UgcGFyYW1zIGludG8gYHF1ZXJ5YCwgb3ZlcndyaXRpbmcgYW55IHNwZWNpZmllZCBpbiBzZWFyY2hcbiAgICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKHF1ZXJ5MSwgcm91dGVNYXRjaCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZVN0YXJ0JywgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgdmFyIHJlZiwgcmVmMTtcbiAgICAgICAgICAgIGxldCByb3V0ZUluZm8gPSBhd2FpdCB0aGlzLmdldFJvdXRlSW5mbyhyb3V0ZSwgcGF0aG5hbWUxLCBxdWVyeTEsIGFzLCByZXNvbHZlZEFzLCByb3V0ZVByb3BzKTtcbiAgICAgICAgICAgIGxldCB7IGVycm9yICwgcHJvcHMgLCBfX05fU1NHICwgX19OX1NTUCAgfSA9IHJvdXRlSW5mbztcbiAgICAgICAgICAgIC8vIGhhbmRsZSByZWRpcmVjdCBvbiBjbGllbnQtdHJhbnNpdGlvblxuICAgICAgICAgICAgaWYgKChfX05fU1NHIHx8IF9fTl9TU1ApICYmIHByb3BzKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb3BzLnBhZ2VQcm9wcyAmJiBwcm9wcy5wYWdlUHJvcHMuX19OX1JFRElSRUNUKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGRlc3RpbmF0aW9uID0gcHJvcHMucGFnZVByb3BzLl9fTl9SRURJUkVDVDtcbiAgICAgICAgICAgICAgICAgICAgLy8gY2hlY2sgaWYgZGVzdGluYXRpb24gaXMgaW50ZXJuYWwgKHJlc29sdmVzIHRvIGEgcGFnZSkgYW5kIGF0dGVtcHRcbiAgICAgICAgICAgICAgICAgICAgLy8gY2xpZW50LW5hdmlnYXRpb24gaWYgaXQgaXMgZmFsbGluZyBiYWNrIHRvIGhhcmQgbmF2aWdhdGlvbiBpZlxuICAgICAgICAgICAgICAgICAgICAvLyBpdCdzIG5vdFxuICAgICAgICAgICAgICAgICAgICBpZiAoZGVzdGluYXRpb24uc3RhcnRzV2l0aCgnLycpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJzZWRIcmVmID0gKDAsIF9wYXJzZVJlbGF0aXZlVXJsKS5wYXJzZVJlbGF0aXZlVXJsKGRlc3RpbmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlZEhyZWYucGF0aG5hbWUgPSByZXNvbHZlRHluYW1pY1JvdXRlKHBhcnNlZEhyZWYucGF0aG5hbWUsIHBhZ2VzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHsgdXJsOiBuZXdVcmwgLCBhczogbmV3QXMgIH0gPSBwcmVwYXJlVXJsQXModGhpcywgZGVzdGluYXRpb24sIGRlc3RpbmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNoYW5nZShtZXRob2QsIG5ld1VybCwgbmV3QXMsIG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gZGVzdGluYXRpb247XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgoKT0+e1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5pc1ByZXZpZXcgPSAhIXByb3BzLl9fTl9QUkVWSUVXO1xuICAgICAgICAgICAgICAgIC8vIGhhbmRsZSBTU0cgZGF0YSA0MDRcbiAgICAgICAgICAgICAgICBpZiAocHJvcHMubm90Rm91bmQgPT09IFNTR19EQVRBX05PVF9GT1VORCkge1xuICAgICAgICAgICAgICAgICAgICBsZXQgbm90Rm91bmRSb3V0ZTtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuZmV0Y2hDb21wb25lbnQoJy80MDQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vdEZvdW5kUm91dGUgPSAnLzQwNCc7XG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKF8pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vdEZvdW5kUm91dGUgPSAnL19lcnJvcic7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcm91dGVJbmZvID0gYXdhaXQgdGhpcy5nZXRSb3V0ZUluZm8obm90Rm91bmRSb3V0ZSwgbm90Rm91bmRSb3V0ZSwgcXVlcnkxLCBhcywgcmVzb2x2ZWRBcywge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2hhbGxvdzogZmFsc2VcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdiZWZvcmVIaXN0b3J5Q2hhbmdlJywgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICAgICAgdGhpcy5jaGFuZ2VTdGF0ZShtZXRob2QsIHVybCwgYXMsIG9wdGlvbnMpO1xuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBhcHBDb21wID0gdGhpcy5jb21wb25lbnRzWycvX2FwcCddLkNvbXBvbmVudDtcbiAgICAgICAgICAgICAgICB3aW5kb3cubmV4dC5pc1ByZXJlbmRlcmVkID0gYXBwQ29tcC5nZXRJbml0aWFsUHJvcHMgPT09IGFwcENvbXAub3JpZ0dldEluaXRpYWxQcm9wcyAmJiAhcm91dGVJbmZvLkNvbXBvbmVudC5nZXRJbml0aWFsUHJvcHM7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5faCAmJiBwYXRobmFtZTEgPT09ICcvX2Vycm9yJyAmJiAoKHJlZiA9IHNlbGYuX19ORVhUX0RBVEFfXy5wcm9wcykgPT09IG51bGwgfHwgcmVmID09PSB2b2lkIDAgPyB2b2lkIDAgOiAocmVmMSA9IHJlZi5wYWdlUHJvcHMpID09PSBudWxsIHx8IHJlZjEgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHJlZjEuc3RhdHVzQ29kZSkgPT09IDUwMCAmJiAocHJvcHMgPT09IG51bGwgfHwgcHJvcHMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHByb3BzLnBhZ2VQcm9wcykpIHtcbiAgICAgICAgICAgICAgICAvLyBlbnN1cmUgc3RhdHVzQ29kZSBpcyBzdGlsbCBjb3JyZWN0IGZvciBzdGF0aWMgNTAwIHBhZ2VcbiAgICAgICAgICAgICAgICAvLyB3aGVuIHVwZGF0aW5nIHF1ZXJ5IGluZm9ybWF0aW9uXG4gICAgICAgICAgICAgICAgcHJvcHMucGFnZVByb3BzLnN0YXR1c0NvZGUgPSA1MDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBzaGFsbG93IHJvdXRpbmcgaXMgb25seSBhbGxvd2VkIGZvciBzYW1lIHBhZ2UgVVJMIGNoYW5nZXMuXG4gICAgICAgICAgICBjb25zdCBpc1ZhbGlkU2hhbGxvd1JvdXRlID0gb3B0aW9ucy5zaGFsbG93ICYmIHRoaXMucm91dGUgPT09IHJvdXRlO1xuICAgICAgICAgICAgdmFyIF9zY3JvbGw7XG4gICAgICAgICAgICBjb25zdCBzaG91bGRTY3JvbGwgPSAoX3Njcm9sbCA9IG9wdGlvbnMuc2Nyb2xsKSAhPT0gbnVsbCAmJiBfc2Nyb2xsICE9PSB2b2lkIDAgPyBfc2Nyb2xsIDogIWlzVmFsaWRTaGFsbG93Um91dGU7XG4gICAgICAgICAgICBjb25zdCByZXNldFNjcm9sbCA9IHNob3VsZFNjcm9sbCA/IHtcbiAgICAgICAgICAgICAgICB4OiAwLFxuICAgICAgICAgICAgICAgIHk6IDBcbiAgICAgICAgICAgIH0gOiBudWxsO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5zZXQocm91dGUsIHBhdGhuYW1lMSwgcXVlcnkxLCBjbGVhbmVkQXMsIHJvdXRlSW5mbywgZm9yY2VkU2Nyb2xsICE9PSBudWxsICYmIGZvcmNlZFNjcm9sbCAhPT0gdm9pZCAwID8gZm9yY2VkU2Nyb2xsIDogcmVzZXRTY3JvbGwpLmNhdGNoKChlKT0+e1xuICAgICAgICAgICAgICAgIGlmIChlLmNhbmNlbGxlZCkgZXJyb3IgPSBlcnJvciB8fCBlO1xuICAgICAgICAgICAgICAgIGVsc2UgdGhyb3cgZTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUVycm9yJywgZXJyb3IsIGNsZWFuZWRBcywgcm91dGVQcm9wcyk7XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLmxvY2FsZSkge1xuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQubGFuZyA9IHRoaXMubG9jYWxlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgncm91dGVDaGFuZ2VDb21wbGV0ZScsIGFzLCByb3V0ZVByb3BzKTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9IGNhdGNoIChlcnIxKSB7XG4gICAgICAgICAgICBpZiAoZXJyMS5jYW5jZWxsZWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBlcnIxO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNoYW5nZVN0YXRlKG1ldGhvZCwgdXJsLCBhcywgb3B0aW9ucyA9IHtcbiAgICB9KSB7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHdpbmRvdy5oaXN0b3J5ID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYFdhcm5pbmc6IHdpbmRvdy5oaXN0b3J5IGlzIG5vdCBhdmFpbGFibGUuYCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cuaGlzdG9yeVttZXRob2RdID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYFdhcm5pbmc6IHdpbmRvdy5oaXN0b3J5LiR7bWV0aG9kfSBpcyBub3QgYXZhaWxhYmxlYCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChtZXRob2QgIT09ICdwdXNoU3RhdGUnIHx8ICgwLCBfdXRpbHMpLmdldFVSTCgpICE9PSBhcykge1xuICAgICAgICAgICAgdGhpcy5fc2hhbGxvdyA9IG9wdGlvbnMuc2hhbGxvdztcbiAgICAgICAgICAgIHdpbmRvdy5oaXN0b3J5W21ldGhvZF0oe1xuICAgICAgICAgICAgICAgIHVybCxcbiAgICAgICAgICAgICAgICBhcyxcbiAgICAgICAgICAgICAgICBvcHRpb25zLFxuICAgICAgICAgICAgICAgIF9fTjogdHJ1ZSxcbiAgICAgICAgICAgICAgICBpZHg6IHRoaXMuX2lkeCA9IG1ldGhvZCAhPT0gJ3B1c2hTdGF0ZScgPyB0aGlzLl9pZHggOiB0aGlzLl9pZHggKyAxXG4gICAgICAgICAgICB9LCAvLyBNb3N0IGJyb3dzZXJzIGN1cnJlbnRseSBpZ25vcmVzIHRoaXMgcGFyYW1ldGVyLCBhbHRob3VnaCB0aGV5IG1heSB1c2UgaXQgaW4gdGhlIGZ1dHVyZS5cbiAgICAgICAgICAgIC8vIFBhc3NpbmcgdGhlIGVtcHR5IHN0cmluZyBoZXJlIHNob3VsZCBiZSBzYWZlIGFnYWluc3QgZnV0dXJlIGNoYW5nZXMgdG8gdGhlIG1ldGhvZC5cbiAgICAgICAgICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9IaXN0b3J5L3JlcGxhY2VTdGF0ZVxuICAgICAgICAgICAgJycsIGFzKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyBoYW5kbGVSb3V0ZUluZm9FcnJvcihlcnIsIHBhdGhuYW1lLCBxdWVyeSwgYXMsIHJvdXRlUHJvcHMsIGxvYWRFcnJvckZhaWwpIHtcbiAgICAgICAgaWYgKGVyci5jYW5jZWxsZWQpIHtcbiAgICAgICAgICAgIC8vIGJ1YmJsZSB1cCBjYW5jZWxsYXRpb24gZXJyb3JzXG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCgwLCBfcm91dGVMb2FkZXIpLmlzQXNzZXRFcnJvcihlcnIpIHx8IGxvYWRFcnJvckZhaWwpIHtcbiAgICAgICAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgncm91dGVDaGFuZ2VFcnJvcicsIGVyciwgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICAgICAgLy8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgcGFnZSBpdCBjb3VsZCBiZSBvbmUgb2YgZm9sbG93aW5nIHJlYXNvbnNcbiAgICAgICAgICAgIC8vICAxLiBQYWdlIGRvZXNuJ3QgZXhpc3RzXG4gICAgICAgICAgICAvLyAgMi4gUGFnZSBkb2VzIGV4aXN0IGluIGEgZGlmZmVyZW50IHpvbmVcbiAgICAgICAgICAgIC8vICAzLiBJbnRlcm5hbCBlcnJvciB3aGlsZSBsb2FkaW5nIHRoZSBwYWdlXG4gICAgICAgICAgICAvLyBTbywgZG9pbmcgYSBoYXJkIHJlbG9hZCBpcyB0aGUgcHJvcGVyIHdheSB0byBkZWFsIHdpdGggdGhpcy5cbiAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gYXM7XG4gICAgICAgICAgICAvLyBDaGFuZ2luZyB0aGUgVVJMIGRvZXNuJ3QgYmxvY2sgZXhlY3V0aW5nIHRoZSBjdXJyZW50IGNvZGUgcGF0aC5cbiAgICAgICAgICAgIC8vIFNvIGxldCdzIHRocm93IGEgY2FuY2VsbGF0aW9uIGVycm9yIHN0b3AgdGhlIHJvdXRpbmcgbG9naWMuXG4gICAgICAgICAgICB0aHJvdyBidWlsZENhbmNlbGxhdGlvbkVycm9yKCk7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGxldCBDb21wb25lbnQxO1xuICAgICAgICAgICAgbGV0IHN0eWxlU2hlZXRzO1xuICAgICAgICAgICAgbGV0IHByb3BzO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBDb21wb25lbnQxID09PSAndW5kZWZpbmVkJyB8fCB0eXBlb2Ygc3R5bGVTaGVldHMgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgICAgKHsgcGFnZTogQ29tcG9uZW50MSAsIHN0eWxlU2hlZXRzICB9ID0gYXdhaXQgdGhpcy5mZXRjaENvbXBvbmVudCgnL19lcnJvcicpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHJvdXRlSW5mbyA9IHtcbiAgICAgICAgICAgICAgICBwcm9wcyxcbiAgICAgICAgICAgICAgICBDb21wb25lbnQ6IENvbXBvbmVudDEsXG4gICAgICAgICAgICAgICAgc3R5bGVTaGVldHMsXG4gICAgICAgICAgICAgICAgZXJyLFxuICAgICAgICAgICAgICAgIGVycm9yOiBlcnJcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAoIXJvdXRlSW5mby5wcm9wcykge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHJvdXRlSW5mby5wcm9wcyA9IGF3YWl0IHRoaXMuZ2V0SW5pdGlhbFByb3BzKENvbXBvbmVudDEsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycixcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGhuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnlcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSBjYXRjaCAoZ2lwRXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGluIGVycm9yIHBhZ2UgYGdldEluaXRpYWxQcm9wc2A6ICcsIGdpcEVycik7XG4gICAgICAgICAgICAgICAgICAgIHJvdXRlSW5mby5wcm9wcyA9IHtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcm91dGVJbmZvO1xuICAgICAgICB9IGNhdGNoIChyb3V0ZUluZm9FcnIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmhhbmRsZVJvdXRlSW5mb0Vycm9yKHJvdXRlSW5mb0VyciwgcGF0aG5hbWUsIHF1ZXJ5LCBhcywgcm91dGVQcm9wcywgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgYXN5bmMgZ2V0Um91dGVJbmZvKHJvdXRlLCBwYXRobmFtZSwgcXVlcnksIGFzLCByZXNvbHZlZEFzLCByb3V0ZVByb3BzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBleGlzdGluZ1JvdXRlSW5mbyA9IHRoaXMuY29tcG9uZW50c1tyb3V0ZV07XG4gICAgICAgICAgICBpZiAocm91dGVQcm9wcy5zaGFsbG93ICYmIGV4aXN0aW5nUm91dGVJbmZvICYmIHRoaXMucm91dGUgPT09IHJvdXRlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGV4aXN0aW5nUm91dGVJbmZvO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgY2FjaGVkUm91dGVJbmZvID0gZXhpc3RpbmdSb3V0ZUluZm8gJiYgJ2luaXRpYWwnIGluIGV4aXN0aW5nUm91dGVJbmZvID8gdW5kZWZpbmVkIDogZXhpc3RpbmdSb3V0ZUluZm87XG4gICAgICAgICAgICBjb25zdCByb3V0ZUluZm8gPSBjYWNoZWRSb3V0ZUluZm8gPyBjYWNoZWRSb3V0ZUluZm8gOiBhd2FpdCB0aGlzLmZldGNoQ29tcG9uZW50KHJvdXRlKS50aGVuKChyZXMpPT4oe1xuICAgICAgICAgICAgICAgICAgICBDb21wb25lbnQ6IHJlcy5wYWdlLFxuICAgICAgICAgICAgICAgICAgICBzdHlsZVNoZWV0czogcmVzLnN0eWxlU2hlZXRzLFxuICAgICAgICAgICAgICAgICAgICBfX05fU1NHOiByZXMubW9kLl9fTl9TU0csXG4gICAgICAgICAgICAgICAgICAgIF9fTl9TU1A6IHJlcy5tb2QuX19OX1NTUFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY29uc3QgeyBDb21wb25lbnQ6IENvbXBvbmVudDEgLCBfX05fU1NHICwgX19OX1NTUCAgfSA9IHJvdXRlSW5mbztcbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBpc1ZhbGlkRWxlbWVudFR5cGUgIH0gPSByZXF1aXJlKCdyZWFjdC1pcycpO1xuICAgICAgICAgICAgICAgIGlmICghaXNWYWxpZEVsZW1lbnRUeXBlKENvbXBvbmVudDEpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVGhlIGRlZmF1bHQgZXhwb3J0IGlzIG5vdCBhIFJlYWN0IENvbXBvbmVudCBpbiBwYWdlOiBcIiR7cGF0aG5hbWV9XCJgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgZGF0YUhyZWY7XG4gICAgICAgICAgICBpZiAoX19OX1NTRyB8fCBfX05fU1NQKSB7XG4gICAgICAgICAgICAgICAgZGF0YUhyZWYgPSB0aGlzLnBhZ2VMb2FkZXIuZ2V0RGF0YUhyZWYoKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZSxcbiAgICAgICAgICAgICAgICAgICAgcXVlcnlcbiAgICAgICAgICAgICAgICB9KSwgcmVzb2x2ZWRBcywgX19OX1NTRywgdGhpcy5sb2NhbGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgcHJvcHMgPSBhd2FpdCB0aGlzLl9nZXREYXRhKCgpPT5fX05fU1NHID8gdGhpcy5fZ2V0U3RhdGljRGF0YShkYXRhSHJlZikgOiBfX05fU1NQID8gdGhpcy5fZ2V0U2VydmVyRGF0YShkYXRhSHJlZikgOiB0aGlzLmdldEluaXRpYWxQcm9wcyhDb21wb25lbnQxLCAvLyB3ZSBwcm92aWRlIEFwcFRyZWUgbGF0ZXIgc28gdGhpcyBuZWVkcyB0byBiZSBgYW55YFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgICAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgICAgICAgICBhc1BhdGg6IGFzLFxuICAgICAgICAgICAgICAgICAgICBsb2NhbGU6IHRoaXMubG9jYWxlLFxuICAgICAgICAgICAgICAgICAgICBsb2NhbGVzOiB0aGlzLmxvY2FsZXMsXG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHRMb2NhbGU6IHRoaXMuZGVmYXVsdExvY2FsZVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgcm91dGVJbmZvLnByb3BzID0gcHJvcHM7XG4gICAgICAgICAgICB0aGlzLmNvbXBvbmVudHNbcm91dGVdID0gcm91dGVJbmZvO1xuICAgICAgICAgICAgcmV0dXJuIHJvdXRlSW5mbztcbiAgICAgICAgfSBjYXRjaCAoZXJyMikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlUm91dGVJbmZvRXJyb3IoZXJyMiwgcGF0aG5hbWUsIHF1ZXJ5LCBhcywgcm91dGVQcm9wcyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc2V0KHJvdXRlLCBwYXRobmFtZSwgcXVlcnksIGFzLCBkYXRhLCByZXNldFNjcm9sbCkge1xuICAgICAgICB0aGlzLmlzRmFsbGJhY2sgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5yb3V0ZSA9IHJvdXRlO1xuICAgICAgICB0aGlzLnBhdGhuYW1lID0gcGF0aG5hbWU7XG4gICAgICAgIHRoaXMucXVlcnkgPSBxdWVyeTtcbiAgICAgICAgdGhpcy5hc1BhdGggPSBhcztcbiAgICAgICAgcmV0dXJuIHRoaXMubm90aWZ5KGRhdGEsIHJlc2V0U2Nyb2xsKTtcbiAgICB9XG4gICAgLyoqXG4gICAqIENhbGxiYWNrIHRvIGV4ZWN1dGUgYmVmb3JlIHJlcGxhY2luZyByb3V0ZXIgc3RhdGVcbiAgICogQHBhcmFtIGNiIGNhbGxiYWNrIHRvIGJlIGV4ZWN1dGVkXG4gICAqLyBiZWZvcmVQb3BTdGF0ZShjYikge1xuICAgICAgICB0aGlzLl9icHMgPSBjYjtcbiAgICB9XG4gICAgb25seUFIYXNoQ2hhbmdlKGFzKSB7XG4gICAgICAgIGlmICghdGhpcy5hc1BhdGgpIHJldHVybiBmYWxzZTtcbiAgICAgICAgY29uc3QgW29sZFVybE5vSGFzaCwgb2xkSGFzaF0gPSB0aGlzLmFzUGF0aC5zcGxpdCgnIycpO1xuICAgICAgICBjb25zdCBbbmV3VXJsTm9IYXNoLCBuZXdIYXNoXSA9IGFzLnNwbGl0KCcjJyk7XG4gICAgICAgIC8vIE1ha2VzIHN1cmUgd2Ugc2Nyb2xsIHRvIHRoZSBwcm92aWRlZCBoYXNoIGlmIHRoZSB1cmwvaGFzaCBhcmUgdGhlIHNhbWVcbiAgICAgICAgaWYgKG5ld0hhc2ggJiYgb2xkVXJsTm9IYXNoID09PSBuZXdVcmxOb0hhc2ggJiYgb2xkSGFzaCA9PT0gbmV3SGFzaCkge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWYgdGhlIHVybHMgYXJlIGNoYW5nZSwgdGhlcmUncyBtb3JlIHRoYW4gYSBoYXNoIGNoYW5nZVxuICAgICAgICBpZiAob2xkVXJsTm9IYXNoICE9PSBuZXdVcmxOb0hhc2gpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBJZiB0aGUgaGFzaCBoYXMgY2hhbmdlZCwgdGhlbiBpdCdzIGEgaGFzaCBvbmx5IGNoYW5nZS5cbiAgICAgICAgLy8gVGhpcyBjaGVjayBpcyBuZWNlc3NhcnkgdG8gaGFuZGxlIGJvdGggdGhlIGVudGVyIGFuZFxuICAgICAgICAvLyBsZWF2ZSBoYXNoID09PSAnJyBjYXNlcy4gVGhlIGlkZW50aXR5IGNhc2UgZmFsbHMgdGhyb3VnaFxuICAgICAgICAvLyBhbmQgaXMgdHJlYXRlZCBhcyBhIG5leHQgcmVsb2FkLlxuICAgICAgICByZXR1cm4gb2xkSGFzaCAhPT0gbmV3SGFzaDtcbiAgICB9XG4gICAgc2Nyb2xsVG9IYXNoKGFzKSB7XG4gICAgICAgIGNvbnN0IFssIGhhc2hdID0gYXMuc3BsaXQoJyMnKTtcbiAgICAgICAgLy8gU2Nyb2xsIHRvIHRvcCBpZiB0aGUgaGFzaCBpcyBqdXN0IGAjYCB3aXRoIG5vIHZhbHVlIG9yIGAjdG9wYFxuICAgICAgICAvLyBUbyBtaXJyb3IgYnJvd3NlcnNcbiAgICAgICAgaWYgKGhhc2ggPT09ICcnIHx8IGhhc2ggPT09ICd0b3AnKSB7XG4gICAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgMCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gRmlyc3Qgd2UgY2hlY2sgaWYgdGhlIGVsZW1lbnQgYnkgaWQgaXMgZm91bmRcbiAgICAgICAgY29uc3QgaWRFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGhhc2gpO1xuICAgICAgICBpZiAoaWRFbCkge1xuICAgICAgICAgICAgaWRFbC5zY3JvbGxJbnRvVmlldygpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8vIElmIHRoZXJlJ3Mgbm8gZWxlbWVudCB3aXRoIHRoZSBpZCwgd2UgY2hlY2sgdGhlIGBuYW1lYCBwcm9wZXJ0eVxuICAgICAgICAvLyBUbyBtaXJyb3IgYnJvd3NlcnNcbiAgICAgICAgY29uc3QgbmFtZUVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeU5hbWUoaGFzaClbMF07XG4gICAgICAgIGlmIChuYW1lRWwpIHtcbiAgICAgICAgICAgIG5hbWVFbC5zY3JvbGxJbnRvVmlldygpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHVybElzTmV3KGFzUGF0aCkge1xuICAgICAgICByZXR1cm4gdGhpcy5hc1BhdGggIT09IGFzUGF0aDtcbiAgICB9XG4gICAgLyoqXG4gICAqIFByZWZldGNoIHBhZ2UgY29kZSwgeW91IG1heSB3YWl0IGZvciB0aGUgZGF0YSBkdXJpbmcgcGFnZSByZW5kZXJpbmcuXG4gICAqIFRoaXMgZmVhdHVyZSBvbmx5IHdvcmtzIGluIHByb2R1Y3Rpb24hXG4gICAqIEBwYXJhbSB1cmwgdGhlIGhyZWYgb2YgcHJlZmV0Y2hlZCBwYWdlXG4gICAqIEBwYXJhbSBhc1BhdGggdGhlIGFzIHBhdGggb2YgdGhlIHByZWZldGNoZWQgcGFnZVxuICAgKi8gYXN5bmMgcHJlZmV0Y2godXJsLCBhc1BhdGggPSB1cmwsIG9wdGlvbnMgPSB7XG4gICAgfSkge1xuICAgICAgICBsZXQgcGFyc2VkID0gKDAsIF9wYXJzZVJlbGF0aXZlVXJsKS5wYXJzZVJlbGF0aXZlVXJsKHVybCk7XG4gICAgICAgIGxldCB7IHBhdGhuYW1lOiBwYXRobmFtZTIgIH0gPSBwYXJzZWQ7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5sb2NhbGUgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICAgICAgcGF0aG5hbWUyID0gKDAsIF9ub3JtYWxpemVMb2NhbGVQYXRoKS5ub3JtYWxpemVMb2NhbGVQYXRoKHBhdGhuYW1lMiwgdGhpcy5sb2NhbGVzKS5wYXRobmFtZTtcbiAgICAgICAgICAgICAgICBwYXJzZWQucGF0aG5hbWUgPSBwYXRobmFtZTI7XG4gICAgICAgICAgICAgICAgdXJsID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkKTtcbiAgICAgICAgICAgICAgICBsZXQgcGFyc2VkQXMgPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwoYXNQYXRoKTtcbiAgICAgICAgICAgICAgICBjb25zdCBsb2NhbGVQYXRoUmVzdWx0ID0gKDAsIF9ub3JtYWxpemVMb2NhbGVQYXRoKS5ub3JtYWxpemVMb2NhbGVQYXRoKHBhcnNlZEFzLnBhdGhuYW1lLCB0aGlzLmxvY2FsZXMpO1xuICAgICAgICAgICAgICAgIHBhcnNlZEFzLnBhdGhuYW1lID0gbG9jYWxlUGF0aFJlc3VsdC5wYXRobmFtZTtcbiAgICAgICAgICAgICAgICBvcHRpb25zLmxvY2FsZSA9IGxvY2FsZVBhdGhSZXN1bHQuZGV0ZWN0ZWRMb2NhbGUgfHwgdGhpcy5kZWZhdWx0TG9jYWxlO1xuICAgICAgICAgICAgICAgIGFzUGF0aCA9ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZEFzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwYWdlcyA9IGF3YWl0IHRoaXMucGFnZUxvYWRlci5nZXRQYWdlTGlzdCgpO1xuICAgICAgICBsZXQgcmVzb2x2ZWRBcyA9IGFzUGF0aDtcbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9IQVNfUkVXUklURVMgJiYgYXNQYXRoLnN0YXJ0c1dpdGgoJy8nKSkge1xuICAgICAgICAgICAgbGV0IHJld3JpdGVzO1xuICAgICAgICAgICAgKHsgX19yZXdyaXRlczogcmV3cml0ZXMgIH0gPSBhd2FpdCAoMCwgX3JvdXRlTG9hZGVyKS5nZXRDbGllbnRCdWlsZE1hbmlmZXN0KCkpO1xuICAgICAgICAgICAgY29uc3QgcmV3cml0ZXNSZXN1bHQgPSAoMCwgX3Jlc29sdmVSZXdyaXRlcykuZGVmYXVsdChhZGRCYXNlUGF0aChhZGRMb2NhbGUoYXNQYXRoLCB0aGlzLmxvY2FsZSkpLCBwYWdlcywgcmV3cml0ZXMsIHBhcnNlZC5xdWVyeSwgKHApPT5yZXNvbHZlRHluYW1pY1JvdXRlKHAsIHBhZ2VzKVxuICAgICAgICAgICAgLCB0aGlzLmxvY2FsZXMpO1xuICAgICAgICAgICAgcmVzb2x2ZWRBcyA9IGRlbExvY2FsZShkZWxCYXNlUGF0aChyZXdyaXRlc1Jlc3VsdC5hc1BhdGgpLCB0aGlzLmxvY2FsZSk7XG4gICAgICAgICAgICBpZiAocmV3cml0ZXNSZXN1bHQubWF0Y2hlZFBhZ2UgJiYgcmV3cml0ZXNSZXN1bHQucmVzb2x2ZWRIcmVmKSB7XG4gICAgICAgICAgICAgICAgLy8gaWYgdGhpcyBkaXJlY3RseSBtYXRjaGVzIGEgcGFnZSB3ZSBuZWVkIHRvIHVwZGF0ZSB0aGUgaHJlZiB0b1xuICAgICAgICAgICAgICAgIC8vIGFsbG93IHRoZSBjb3JyZWN0IHBhZ2UgY2h1bmsgdG8gYmUgbG9hZGVkXG4gICAgICAgICAgICAgICAgcGF0aG5hbWUyID0gcmV3cml0ZXNSZXN1bHQucmVzb2x2ZWRIcmVmO1xuICAgICAgICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IHBhdGhuYW1lMjtcbiAgICAgICAgICAgICAgICB1cmwgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcGFyc2VkLnBhdGhuYW1lID0gcmVzb2x2ZUR5bmFtaWNSb3V0ZShwYXJzZWQucGF0aG5hbWUsIHBhZ2VzKTtcbiAgICAgICAgICAgIGlmIChwYXJzZWQucGF0aG5hbWUgIT09IHBhdGhuYW1lMikge1xuICAgICAgICAgICAgICAgIHBhdGhuYW1lMiA9IHBhcnNlZC5wYXRobmFtZTtcbiAgICAgICAgICAgICAgICBwYXJzZWQucGF0aG5hbWUgPSBwYXRobmFtZTI7XG4gICAgICAgICAgICAgICAgdXJsID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCByb3V0ZSA9ICgwLCBfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCkucmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2gocGF0aG5hbWUyKTtcbiAgICAgICAgLy8gUHJlZmV0Y2ggaXMgbm90IHN1cHBvcnRlZCBpbiBkZXZlbG9wbWVudCBtb2RlIGJlY2F1c2UgaXQgd291bGQgdHJpZ2dlciBvbi1kZW1hbmQtZW50cmllc1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgIHRoaXMucGFnZUxvYWRlci5faXNTc2cocm91dGUpLnRoZW4oKGlzU3NnKT0+e1xuICAgICAgICAgICAgICAgIHJldHVybiBpc1NzZyA/IHRoaXMuX2dldFN0YXRpY0RhdGEodGhpcy5wYWdlTG9hZGVyLmdldERhdGFIcmVmKHVybCwgcmVzb2x2ZWRBcywgdHJ1ZSwgdHlwZW9mIG9wdGlvbnMubG9jYWxlICE9PSAndW5kZWZpbmVkJyA/IG9wdGlvbnMubG9jYWxlIDogdGhpcy5sb2NhbGUpKSA6IGZhbHNlO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0aGlzLnBhZ2VMb2FkZXJbb3B0aW9ucy5wcmlvcml0eSA/ICdsb2FkUGFnZScgOiAncHJlZmV0Y2gnXShyb3V0ZSksIFxuICAgICAgICBdKTtcbiAgICB9XG4gICAgYXN5bmMgZmV0Y2hDb21wb25lbnQocm91dGUpIHtcbiAgICAgICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuICAgICAgICBjb25zdCBjYW5jZWwgPSB0aGlzLmNsYyA9ICgpPT57XG4gICAgICAgICAgICBjYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBjb21wb25lbnRSZXN1bHQgPSBhd2FpdCB0aGlzLnBhZ2VMb2FkZXIubG9hZFBhZ2Uocm91dGUpO1xuICAgICAgICBpZiAoY2FuY2VsbGVkKSB7XG4gICAgICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihgQWJvcnQgZmV0Y2hpbmcgY29tcG9uZW50IGZvciByb3V0ZTogXCIke3JvdXRlfVwiYCk7XG4gICAgICAgICAgICBlcnJvci5jYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNhbmNlbCA9PT0gdGhpcy5jbGMpIHtcbiAgICAgICAgICAgIHRoaXMuY2xjID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY29tcG9uZW50UmVzdWx0O1xuICAgIH1cbiAgICBfZ2V0RGF0YShmbikge1xuICAgICAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgICAgIGNvbnN0IGNhbmNlbCA9ICgpPT57XG4gICAgICAgICAgICBjYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLmNsYyA9IGNhbmNlbDtcbiAgICAgICAgcmV0dXJuIGZuKCkudGhlbigoZGF0YSk9PntcbiAgICAgICAgICAgIGlmIChjYW5jZWwgPT09IHRoaXMuY2xjKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jbGMgPSBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNhbmNlbGxlZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVycjIgPSBuZXcgRXJyb3IoJ0xvYWRpbmcgaW5pdGlhbCBwcm9wcyBjYW5jZWxsZWQnKTtcbiAgICAgICAgICAgICAgICBlcnIyLmNhbmNlbGxlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyMjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgX2dldFN0YXRpY0RhdGEoZGF0YUhyZWYpIHtcbiAgICAgICAgY29uc3QgeyBocmVmOiBjYWNoZUtleSAgfSA9IG5ldyBVUkwoZGF0YUhyZWYsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAncHJvZHVjdGlvbicgJiYgIXRoaXMuaXNQcmV2aWV3ICYmIHRoaXMuc2RjW2NhY2hlS2V5XSkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh0aGlzLnNkY1tjYWNoZUtleV0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmZXRjaE5leHREYXRhKGRhdGFIcmVmLCB0aGlzLmlzU3NyKS50aGVuKChkYXRhKT0+e1xuICAgICAgICAgICAgdGhpcy5zZGNbY2FjaGVLZXldID0gZGF0YTtcbiAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgX2dldFNlcnZlckRhdGEoZGF0YUhyZWYpIHtcbiAgICAgICAgY29uc3QgeyBocmVmOiByZXNvdXJjZUtleSAgfSA9IG5ldyBVUkwoZGF0YUhyZWYsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcbiAgICAgICAgaWYgKHRoaXMuc2RyW3Jlc291cmNlS2V5XSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc2RyW3Jlc291cmNlS2V5XTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5zZHJbcmVzb3VyY2VLZXldID0gZmV0Y2hOZXh0RGF0YShkYXRhSHJlZiwgdGhpcy5pc1NzcikudGhlbigoZGF0YSk9PntcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLnNkcltyZXNvdXJjZUtleV07XG4gICAgICAgICAgICByZXR1cm4gZGF0YTtcbiAgICAgICAgfSkuY2F0Y2goKGVycjIpPT57XG4gICAgICAgICAgICBkZWxldGUgdGhpcy5zZHJbcmVzb3VyY2VLZXldO1xuICAgICAgICAgICAgdGhyb3cgZXJyMjtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGdldEluaXRpYWxQcm9wcyhDb21wb25lbnQsIGN0eCkge1xuICAgICAgICBjb25zdCB7IENvbXBvbmVudDogQXBwMSAgfSA9IHRoaXMuY29tcG9uZW50c1snL19hcHAnXTtcbiAgICAgICAgY29uc3QgQXBwVHJlZSA9IHRoaXMuX3dyYXBBcHAoQXBwMSk7XG4gICAgICAgIGN0eC5BcHBUcmVlID0gQXBwVHJlZTtcbiAgICAgICAgcmV0dXJuICgwLCBfdXRpbHMpLmxvYWRHZXRJbml0aWFsUHJvcHMoQXBwMSwge1xuICAgICAgICAgICAgQXBwVHJlZSxcbiAgICAgICAgICAgIENvbXBvbmVudCxcbiAgICAgICAgICAgIHJvdXRlcjogdGhpcyxcbiAgICAgICAgICAgIGN0eFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgYWJvcnRDb21wb25lbnRMb2FkKGFzLCByb3V0ZVByb3BzKSB7XG4gICAgICAgIGlmICh0aGlzLmNsYykge1xuICAgICAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUVycm9yJywgYnVpbGRDYW5jZWxsYXRpb25FcnJvcigpLCBhcywgcm91dGVQcm9wcyk7XG4gICAgICAgICAgICB0aGlzLmNsYygpO1xuICAgICAgICAgICAgdGhpcy5jbGMgPSBudWxsO1xuICAgICAgICB9XG4gICAgfVxuICAgIG5vdGlmeShkYXRhLCByZXNldFNjcm9sbCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zdWIoZGF0YSwgdGhpcy5jb21wb25lbnRzWycvX2FwcCddLkNvbXBvbmVudCwgcmVzZXRTY3JvbGwpO1xuICAgIH1cbn1cblJvdXRlci5ldmVudHMgPSAoMCwgX21pdHQpLmRlZmF1bHQoKTtcbmV4cG9ydHMuZGVmYXVsdCA9IFJvdXRlcjtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGVyLmpzLm1hcCIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBEYXNoYm9hcmQgZnJvbSBcIi4uL2NvbXBvbmVudHMvRGFzaGJvYXJkXCJcclxuZnVuY3Rpb24gZGFzaGJvYXJkKCkge1xyXG4gICAgcmV0dXJuIDxEYXNoYm9hcmQvPjtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZGFzaGJvYXJkO1xyXG4iLCJpbXBvcnQgKiBhcyBhbmNob3IgZnJvbSBcIkBwcm9qZWN0LXNlcnVtL2FuY2hvclwiO1xyXG5pbXBvcnQgeyBNZXRhZGF0YSB9IGZyb20gXCJAbWV0YXBsZXgvanNcIjtcclxuXHJcbmltcG9ydCB7IE1pbnRMYXlvdXQsIFRPS0VOX1BST0dSQU1fSUQsIFRva2VuIH0gZnJvbSBcIkBzb2xhbmEvc3BsLXRva2VuXCI7XHJcbmltcG9ydCB7IHNlbmRUcmFuc2FjdGlvbnMsIHNsZWVwIH0gZnJvbSBcIi5cIjtcclxuaW1wb3J0IHsgZmV0Y2hIYXNoVGFibGUgfSBmcm9tIFwiLi4vaG9va3MvdXNlSGFzaFRhYmxlXCI7XHJcblxyXG5leHBvcnQgY29uc3QgQ0FORFlfTUFDSElORV9QUk9HUkFNID0gbmV3IGFuY2hvci53ZWIzLlB1YmxpY0tleShcclxuICBcImNuZHlBbnJMZHBqcTFTc3Axejh4eERzQjhkeGU3dTRITDVOeGkySzVXWFpcIlxyXG4pO1xyXG5cclxuY29uc3QgU1BMX0FTU09DSUFURURfVE9LRU5fQUNDT1VOVF9QUk9HUkFNX0lEID0gbmV3IGFuY2hvci53ZWIzLlB1YmxpY0tleShcclxuICBcIkFUb2tlbkdQdmJkR1Z4cjFiMmh2WmJzaXFXNXhXSDI1ZWZUTnNMSkE4a25MXCJcclxuKTtcclxuXHJcbmNvbnN0IFRPS0VOX01FVEFEQVRBX1BST0dSQU1fSUQgPSBuZXcgYW5jaG9yLndlYjMuUHVibGljS2V5KFxyXG4gIFwibWV0YXFieHhVZXJkcTI4Y2oxUmJBV2tZUW0zeWJ6amI2YThidDUxOHgxc1wiXHJcbik7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENhbmR5TWFjaGluZSB7XHJcbiAgaWQ6IGFuY2hvci53ZWIzLlB1YmxpY0tleTtcclxuICBjb25uZWN0aW9uOiBhbmNob3Iud2ViMy5Db25uZWN0aW9uO1xyXG4gIHByb2dyYW06IGFuY2hvci5Qcm9ncmFtO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgQ2FuZHlNYWNoaW5lU3RhdGUge1xyXG4gIGNhbmR5TWFjaGluZTogQ2FuZHlNYWNoaW5lO1xyXG4gIGl0ZW1zQXZhaWxhYmxlOiBudW1iZXI7XHJcbiAgaXRlbXNSZWRlZW1lZDogbnVtYmVyO1xyXG4gIGl0ZW1zUmVtYWluaW5nOiBudW1iZXI7XHJcbiAgZ29MaXZlRGF0ZTogRGF0ZTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGV4aXN0c093bmVyU1BMVG9rZW4oXHJcbiAgY29ubmVjdGlvbjogYW5jaG9yLndlYjMuQ29ubmVjdGlvbixcclxuICBvd25lckFkZHJlc3M6IGFuY2hvci53ZWIzLlB1YmxpY0tleVxyXG4pIHtcclxuICAvLyBjb25zb2xlLmxvZyhcIkFzIFRPS0VOIFwiKTtcclxuICBjb25zdCB0b2tlbkFjY291bnRzID0gYXdhaXQgY29ubmVjdGlvbi5nZXRQYXJzZWRUb2tlbkFjY291bnRzQnlPd25lcihcclxuICAgIG93bmVyQWRkcmVzcyxcclxuICAgIHtcclxuICAgICAgcHJvZ3JhbUlkOiBUT0tFTl9QUk9HUkFNX0lELFxyXG4gICAgfVxyXG4gICk7XHJcblxyXG4gIGNvbnNvbGUubG9nKHRva2VuQWNjb3VudHMpO1xyXG4gIC8vIGxldCBtdWx0aXBsZUFjY291bnRzID0gW107XHJcbiAgLy8gd2hpbGUgKHRva2VuQWNjb3VudHMubGVuZ3RoID4gMCkge1xyXG4gIC8vICAgY29uc3QgbG9va3VwcyA9IG1pbnRQdWJrZXlzLnNwbGljZSgwLCAxMDApO1xyXG4gIC8vICAgY29uc3QgbG9va3VwQWNjdHMgPSBhd2FpdCBjb25uLmdldE11bHRpcGxlQWNjb3VudHNJbmZvKGxvb2t1cHMpO1xyXG4gIC8vICAgbXVsdGlwbGVBY2NvdW50cy5wdXNoKC4uLmxvb2t1cEFjY3RzKTtcclxuICAvLyB9XHJcblxyXG4gIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCB0b2tlbkFjY291bnRzLnZhbHVlLmxlbmd0aDsgaW5kZXgrKykge1xyXG4gICAgY29uc3QgdG9rZW5BY2NvdW50ID0gdG9rZW5BY2NvdW50cy52YWx1ZVtpbmRleF07XHJcbiAgICBjb25zdCB0b2tlbkFtb3VudCA9IHRva2VuQWNjb3VudC5hY2NvdW50LmRhdGEucGFyc2VkLmluZm8udG9rZW5BbW91bnQ7XHJcblxyXG4gICAgY29uc3QgbWludCA9IHRva2VuQWNjb3VudC5hY2NvdW50LmRhdGEucGFyc2VkLmluZm8ubWludDtcclxuICAgIGlmIChcclxuICAgICAgbWludCA9PT0gcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQUlSRFJPUF9UT0tFTiAmJlxyXG4gICAgICB0b2tlbkFtb3VudC51aUFtb3VudCA+IDBcclxuICAgICkge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIkZvdW5kXCIsIG1pbnQgPT09IHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FJUkRST1BfVE9LRU4pO1xyXG4gICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIGZhbHNlO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgYXdhaXRUcmFuc2FjdGlvblNpZ25hdHVyZUNvbmZpcm1hdGlvbiA9IGFzeW5jIChcclxuICB0eGlkOiBhbmNob3Iud2ViMy5UcmFuc2FjdGlvblNpZ25hdHVyZSxcclxuICB0aW1lb3V0OiBudW1iZXIsXHJcbiAgY29ubmVjdGlvbjogYW5jaG9yLndlYjMuQ29ubmVjdGlvbixcclxuICBjb21taXRtZW50OiBhbmNob3Iud2ViMy5Db21taXRtZW50ID0gXCJyZWNlbnRcIixcclxuICBxdWVyeVN0YXR1cyA9IGZhbHNlXHJcbik6IFByb21pc2U8YW5jaG9yLndlYjMuU2lnbmF0dXJlU3RhdHVzIHwgbnVsbCB8IHZvaWQ+ID0+IHtcclxuICBsZXQgZG9uZSA9IGZhbHNlO1xyXG4gIGxldCBzdGF0dXM6IGFuY2hvci53ZWIzLlNpZ25hdHVyZVN0YXR1cyB8IG51bGwgfCB2b2lkID0ge1xyXG4gICAgc2xvdDogMCxcclxuICAgIGNvbmZpcm1hdGlvbnM6IDAsXHJcbiAgICBlcnI6IG51bGwsXHJcbiAgfTtcclxuICBsZXQgc3ViSWQgPSAwO1xyXG4gIHN0YXR1cyA9IGF3YWl0IG5ldyBQcm9taXNlKGFzeW5jIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBpZiAoZG9uZSkge1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG4gICAgICBkb25lID0gdHJ1ZTtcclxuICAgICAgY29uc29sZS5sb2coXCJSZWplY3RpbmcgZm9yIHRpbWVvdXQuLi5cIik7XHJcbiAgICAgIHJlamVjdCh7IHRpbWVvdXQ6IHRydWUgfSk7XHJcbiAgICB9LCB0aW1lb3V0KTtcclxuICAgIHRyeSB7XHJcbiAgICAgIHN1YklkID0gY29ubmVjdGlvbi5vblNpZ25hdHVyZShcclxuICAgICAgICB0eGlkLFxyXG4gICAgICAgIChyZXN1bHQ6IGFueSwgY29udGV4dDogYW55KSA9PiB7XHJcbiAgICAgICAgICBkb25lID0gdHJ1ZTtcclxuICAgICAgICAgIHN0YXR1cyA9IHtcclxuICAgICAgICAgICAgZXJyOiByZXN1bHQuZXJyLFxyXG4gICAgICAgICAgICBzbG90OiBjb250ZXh0LnNsb3QsXHJcbiAgICAgICAgICAgIGNvbmZpcm1hdGlvbnM6IDAsXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgICAgaWYgKHJlc3VsdC5lcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJSZWplY3RlZCB2aWEgd2Vic29ja2V0XCIsIHJlc3VsdC5lcnIpO1xyXG4gICAgICAgICAgICByZWplY3Qoc3RhdHVzKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiUmVzb2x2ZWQgdmlhIHdlYnNvY2tldFwiLCByZXN1bHQpO1xyXG4gICAgICAgICAgICByZXNvbHZlKHN0YXR1cyk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBjb21taXRtZW50XHJcbiAgICAgICk7XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIGRvbmUgPSB0cnVlO1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiV1MgZXJyb3IgaW4gc2V0dXBcIiwgdHhpZCwgZSk7XHJcbiAgICB9XHJcbiAgICB3aGlsZSAoIWRvbmUgJiYgcXVlcnlTdGF0dXMpIHtcclxuICAgICAgKGFzeW5jICgpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3Qgc2lnbmF0dXJlU3RhdHVzZXMgPSBhd2FpdCBjb25uZWN0aW9uLmdldFNpZ25hdHVyZVN0YXR1c2VzKFtcclxuICAgICAgICAgICAgdHhpZCxcclxuICAgICAgICAgIF0pO1xyXG4gICAgICAgICAgc3RhdHVzID0gc2lnbmF0dXJlU3RhdHVzZXMgJiYgc2lnbmF0dXJlU3RhdHVzZXMudmFsdWVbMF07XHJcbiAgICAgICAgICBpZiAoIWRvbmUpIHtcclxuICAgICAgICAgICAgaWYgKCFzdGF0dXMpIHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlJFU1QgbnVsbCByZXN1bHQgZm9yXCIsIHR4aWQsIHN0YXR1cyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoc3RhdHVzLmVycikge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiUkVTVCBlcnJvciBmb3JcIiwgdHhpZCwgc3RhdHVzKTtcclxuICAgICAgICAgICAgICBkb25lID0gdHJ1ZTtcclxuICAgICAgICAgICAgICByZWplY3Qoc3RhdHVzLmVycik7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoIXN0YXR1cy5jb25maXJtYXRpb25zKSB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJSRVNUIG5vIGNvbmZpcm1hdGlvbnMgZm9yXCIsIHR4aWQsIHN0YXR1cyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJSRVNUIGNvbmZpcm1hdGlvbiBmb3JcIiwgdHhpZCwgc3RhdHVzKTtcclxuICAgICAgICAgICAgICBkb25lID0gdHJ1ZTtcclxuICAgICAgICAgICAgICByZXNvbHZlKHN0YXR1cyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICBpZiAoIWRvbmUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJSRVNUIGNvbm5lY3Rpb24gZXJyb3I6IHR4aWRcIiwgdHhpZCwgZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9KSgpO1xyXG4gICAgICBhd2FpdCBzbGVlcCgyMDAwKTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgLy9AdHMtaWdub3JlXHJcbiAgaWYgKGNvbm5lY3Rpb24uX3NpZ25hdHVyZVN1YnNjcmlwdGlvbnNbc3ViSWRdKSB7XHJcbiAgICBjb25uZWN0aW9uLnJlbW92ZVNpZ25hdHVyZUxpc3RlbmVyKHN1YklkKTtcclxuICB9XHJcbiAgZG9uZSA9IHRydWU7XHJcbiAgY29uc29sZS5sb2coXCJSZXR1cm5pbmcgc3RhdHVzXCIsIHN0YXR1cyk7XHJcbiAgcmV0dXJuIHN0YXR1cztcclxufTtcclxuXHJcbmNvbnN0IGNyZWF0ZUFzc29jaWF0ZWRUb2tlbkFjY291bnRJbnN0cnVjdGlvbiA9IChcclxuICBhc3NvY2lhdGVkVG9rZW5BZGRyZXNzOiBhbmNob3Iud2ViMy5QdWJsaWNLZXksXHJcbiAgcGF5ZXI6IGFuY2hvci53ZWIzLlB1YmxpY0tleSxcclxuICB3YWxsZXRBZGRyZXNzOiBhbmNob3Iud2ViMy5QdWJsaWNLZXksXHJcbiAgc3BsVG9rZW5NaW50QWRkcmVzczogYW5jaG9yLndlYjMuUHVibGljS2V5XHJcbikgPT4ge1xyXG4gIGNvbnN0IGtleXMgPSBbXHJcbiAgICB7IHB1YmtleTogcGF5ZXIsIGlzU2lnbmVyOiB0cnVlLCBpc1dyaXRhYmxlOiB0cnVlIH0sXHJcbiAgICB7IHB1YmtleTogYXNzb2NpYXRlZFRva2VuQWRkcmVzcywgaXNTaWduZXI6IGZhbHNlLCBpc1dyaXRhYmxlOiB0cnVlIH0sXHJcbiAgICB7IHB1YmtleTogd2FsbGV0QWRkcmVzcywgaXNTaWduZXI6IGZhbHNlLCBpc1dyaXRhYmxlOiBmYWxzZSB9LFxyXG4gICAgeyBwdWJrZXk6IHNwbFRva2VuTWludEFkZHJlc3MsIGlzU2lnbmVyOiBmYWxzZSwgaXNXcml0YWJsZTogZmFsc2UgfSxcclxuICAgIHtcclxuICAgICAgcHVia2V5OiBhbmNob3Iud2ViMy5TeXN0ZW1Qcm9ncmFtLnByb2dyYW1JZCxcclxuICAgICAgaXNTaWduZXI6IGZhbHNlLFxyXG4gICAgICBpc1dyaXRhYmxlOiBmYWxzZSxcclxuICAgIH0sXHJcbiAgICB7IHB1YmtleTogVE9LRU5fUFJPR1JBTV9JRCwgaXNTaWduZXI6IGZhbHNlLCBpc1dyaXRhYmxlOiBmYWxzZSB9LFxyXG4gICAge1xyXG4gICAgICBwdWJrZXk6IGFuY2hvci53ZWIzLlNZU1ZBUl9SRU5UX1BVQktFWSxcclxuICAgICAgaXNTaWduZXI6IGZhbHNlLFxyXG4gICAgICBpc1dyaXRhYmxlOiBmYWxzZSxcclxuICAgIH0sXHJcbiAgXTtcclxuICByZXR1cm4gbmV3IGFuY2hvci53ZWIzLlRyYW5zYWN0aW9uSW5zdHJ1Y3Rpb24oe1xyXG4gICAga2V5cyxcclxuICAgIHByb2dyYW1JZDogU1BMX0FTU09DSUFURURfVE9LRU5fQUNDT1VOVF9QUk9HUkFNX0lELFxyXG4gICAgZGF0YTogQnVmZmVyLmZyb20oW10pLFxyXG4gIH0pO1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldENhbmR5TWFjaGluZVN0YXRlID0gYXN5bmMgKFxyXG4gIGFuY2hvcldhbGxldDogYW5jaG9yLldhbGxldCxcclxuICBjYW5keU1hY2hpbmVJZDogYW5jaG9yLndlYjMuUHVibGljS2V5LFxyXG4gIGNvbm5lY3Rpb246IGFuY2hvci53ZWIzLkNvbm5lY3Rpb25cclxuKTogUHJvbWlzZTxDYW5keU1hY2hpbmVTdGF0ZT4gPT4ge1xyXG4gIGNvbnN0IHByb3ZpZGVyID0gbmV3IGFuY2hvci5Qcm92aWRlcihjb25uZWN0aW9uLCBhbmNob3JXYWxsZXQsIHtcclxuICAgIHByZWZsaWdodENvbW1pdG1lbnQ6IFwicmVjZW50XCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGlkbCA9IGF3YWl0IGFuY2hvci5Qcm9ncmFtLmZldGNoSWRsKENBTkRZX01BQ0hJTkVfUFJPR1JBTSwgcHJvdmlkZXIpO1xyXG5cclxuICBpZiAoaWRsKSB7XHJcbiAgICBjb25zdCBwcm9ncmFtID0gbmV3IGFuY2hvci5Qcm9ncmFtKGlkbCwgQ0FORFlfTUFDSElORV9QUk9HUkFNLCBwcm92aWRlcik7XHJcbiAgICBjb25zdCBjYW5keU1hY2hpbmUgPSB7XHJcbiAgICAgIGlkOiBjYW5keU1hY2hpbmVJZCxcclxuICAgICAgY29ubmVjdGlvbixcclxuICAgICAgcHJvZ3JhbSxcclxuICAgIH07XHJcbiAgICBjb25zdCBzdGF0ZTogYW55ID0gYXdhaXQgcHJvZ3JhbS5hY2NvdW50LmNhbmR5TWFjaGluZS5mZXRjaChjYW5keU1hY2hpbmVJZCk7XHJcbiAgICBjb25zdCBpdGVtc0F2YWlsYWJsZSA9IHN0YXRlLmRhdGEuaXRlbXNBdmFpbGFibGUudG9OdW1iZXIoKTtcclxuICAgIGNvbnN0IGl0ZW1zUmVkZWVtZWQgPSBzdGF0ZS5pdGVtc1JlZGVlbWVkLnRvTnVtYmVyKCk7XHJcbiAgICBjb25zdCBpdGVtc1JlbWFpbmluZyA9IGl0ZW1zQXZhaWxhYmxlIC0gaXRlbXNSZWRlZW1lZDtcclxuXHJcbiAgICBsZXQgZ29MaXZlRGF0ZSA9IHN0YXRlLmRhdGEuZ29MaXZlRGF0ZS50b051bWJlcigpO1xyXG4gICAgZ29MaXZlRGF0ZSA9IG5ldyBEYXRlKGdvTGl2ZURhdGUgKiAxMDAwKTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBjYW5keU1hY2hpbmUsXHJcbiAgICAgIGl0ZW1zQXZhaWxhYmxlLFxyXG4gICAgICBpdGVtc1JlZGVlbWVkLFxyXG4gICAgICBpdGVtc1JlbWFpbmluZyxcclxuICAgICAgZ29MaXZlRGF0ZSxcclxuICAgIH07XHJcbiAgfSBlbHNlIHtcclxuICAgIHRocm93IG5ldyBFcnJvcihgRmV0Y2hpbmcgaWRsIHJldHVybmVkIG51bGw6IGNoZWNrIENBTkRZX01BQ0hJTkVfUFJPR1JBTWApO1xyXG4gIH1cclxufTtcclxuXHJcbmNvbnN0IGdldE1hc3RlckVkaXRpb24gPSBhc3luYyAoXHJcbiAgbWludDogYW5jaG9yLndlYjMuUHVibGljS2V5XHJcbik6IFByb21pc2U8YW5jaG9yLndlYjMuUHVibGljS2V5PiA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIGF3YWl0IGFuY2hvci53ZWIzLlB1YmxpY0tleS5maW5kUHJvZ3JhbUFkZHJlc3MoXHJcbiAgICAgIFtcclxuICAgICAgICBCdWZmZXIuZnJvbShcIm1ldGFkYXRhXCIpLFxyXG4gICAgICAgIFRPS0VOX01FVEFEQVRBX1BST0dSQU1fSUQudG9CdWZmZXIoKSxcclxuICAgICAgICBtaW50LnRvQnVmZmVyKCksXHJcbiAgICAgICAgQnVmZmVyLmZyb20oXCJlZGl0aW9uXCIpLFxyXG4gICAgICBdLFxyXG4gICAgICBUT0tFTl9NRVRBREFUQV9QUk9HUkFNX0lEXHJcbiAgICApXHJcbiAgKVswXTtcclxufTtcclxuXHJcbmNvbnN0IGdldE1ldGFkYXRhID0gYXN5bmMgKFxyXG4gIG1pbnQ6IGFuY2hvci53ZWIzLlB1YmxpY0tleVxyXG4pOiBQcm9taXNlPGFuY2hvci53ZWIzLlB1YmxpY0tleT4gPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICBhd2FpdCBhbmNob3Iud2ViMy5QdWJsaWNLZXkuZmluZFByb2dyYW1BZGRyZXNzKFxyXG4gICAgICBbXHJcbiAgICAgICAgQnVmZmVyLmZyb20oXCJtZXRhZGF0YVwiKSxcclxuICAgICAgICBUT0tFTl9NRVRBREFUQV9QUk9HUkFNX0lELnRvQnVmZmVyKCksXHJcbiAgICAgICAgbWludC50b0J1ZmZlcigpLFxyXG4gICAgICBdLFxyXG4gICAgICBUT0tFTl9NRVRBREFUQV9QUk9HUkFNX0lEXHJcbiAgICApXHJcbiAgKVswXTtcclxufTtcclxuXHJcbmNvbnN0IGdldFRva2VuV2FsbGV0ID0gYXN5bmMgKFxyXG4gIHdhbGxldDogYW5jaG9yLndlYjMuUHVibGljS2V5LFxyXG4gIG1pbnQ6IGFuY2hvci53ZWIzLlB1YmxpY0tleVxyXG4pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgYXdhaXQgYW5jaG9yLndlYjMuUHVibGljS2V5LmZpbmRQcm9ncmFtQWRkcmVzcyhcclxuICAgICAgW3dhbGxldC50b0J1ZmZlcigpLCBUT0tFTl9QUk9HUkFNX0lELnRvQnVmZmVyKCksIG1pbnQudG9CdWZmZXIoKV0sXHJcbiAgICAgIFNQTF9BU1NPQ0lBVEVEX1RPS0VOX0FDQ09VTlRfUFJPR1JBTV9JRFxyXG4gICAgKVxyXG4gIClbMF07XHJcbn07XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TkZUc0Zvck93bmVyKFxyXG4gIGNvbm5lY3Rpb246IGFuY2hvci53ZWIzLkNvbm5lY3Rpb24sXHJcbiAgb3duZXJBZGRyZXNzOiBhbmNob3Iud2ViMy5QdWJsaWNLZXlcclxuKSB7XHJcbiAgY29uc3QgYWxsVG9rZW5zID0gW107XHJcbiAgY29uc3QgdG9rZW5BY2NvdW50cyA9IGF3YWl0IGNvbm5lY3Rpb24uZ2V0UGFyc2VkVG9rZW5BY2NvdW50c0J5T3duZXIoXHJcbiAgICBvd25lckFkZHJlc3MsXHJcbiAgICB7XHJcbiAgICAgIHByb2dyYW1JZDogVE9LRU5fUFJPR1JBTV9JRCxcclxuICAgIH1cclxuICApO1xyXG5cclxuICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgdG9rZW5BY2NvdW50cy52YWx1ZS5sZW5ndGg7IGluZGV4KyspIHtcclxuICAgIGNvbnN0IHRva2VuQWNjb3VudCA9IHRva2VuQWNjb3VudHMudmFsdWVbaW5kZXhdO1xyXG4gICAgY29uc3QgdG9rZW5BbW91bnQgPSB0b2tlbkFjY291bnQuYWNjb3VudC5kYXRhLnBhcnNlZC5pbmZvLnRva2VuQW1vdW50O1xyXG5cclxuICAgIGlmIChcclxuICAgICAgdG9rZW5BbW91bnQuYW1vdW50ID09IFwiMVwiICYmXHJcbiAgICAgIHRva2VuQW1vdW50LmRlY2ltYWxzID09IFwiMFwiIFxyXG4gICAgKSB7XHJcbiAgICAgIGxldCBbcGRhXSA9IGF3YWl0IGFuY2hvci53ZWIzLlB1YmxpY0tleS5maW5kUHJvZ3JhbUFkZHJlc3MoXHJcbiAgICAgICAgW1xyXG4gICAgICAgICAgQnVmZmVyLmZyb20oXCJtZXRhZGF0YVwiKSxcclxuICAgICAgICAgIFRPS0VOX01FVEFEQVRBX1BST0dSQU1fSUQudG9CdWZmZXIoKSxcclxuICAgICAgICAgIG5ldyBhbmNob3Iud2ViMy5QdWJsaWNLZXkoXHJcbiAgICAgICAgICAgIHRva2VuQWNjb3VudC5hY2NvdW50LmRhdGEucGFyc2VkLmluZm8ubWludFxyXG4gICAgICAgICAgKS50b0J1ZmZlcigpLFxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgVE9LRU5fTUVUQURBVEFfUFJPR1JBTV9JRFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBhY2NvdW50SW5mbzogYW55ID0gYXdhaXQgY29ubmVjdGlvbi5nZXRQYXJzZWRBY2NvdW50SW5mbyhwZGEpO1xyXG5cclxuICAgICAgY29uc3QgbWV0YWRhdGE6IGFueSA9IG5ldyBNZXRhZGF0YShcclxuICAgICAgICBvd25lckFkZHJlc3MudG9TdHJpbmcoKSxcclxuICAgICAgICBhY2NvdW50SW5mby52YWx1ZVxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBkYXRhUmVzID0gYXdhaXQgZmV0Y2gobWV0YWRhdGEuZGF0YS5kYXRhLnVyaSk7XHJcbiAgICAgIGlmIChkYXRhUmVzLnN0YXR1cyA9PT0gMjAwKSB7XHJcbiAgICAgICAgYWxsVG9rZW5zLnB1c2goYXdhaXQgZGF0YVJlcy5qc29uKCkpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gYWxsVG9rZW5zO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgbWludE9uZVRva2VuID0gYXN5bmMgKFxyXG4gIGNhbmR5TWFjaGluZTogQ2FuZHlNYWNoaW5lLFxyXG4gIGNvbmZpZzogYW5jaG9yLndlYjMuUHVibGljS2V5LCAvLyBmZWVscyBsaWtlIHRoaXMgc2hvdWxkIGJlIHBhcnQgb2YgY2FuZHlNYWNoaW5lP1xyXG4gIHBheWVyOiBhbmNob3Iud2ViMy5QdWJsaWNLZXksXHJcbiAgdHJlYXN1cnk6IGFuY2hvci53ZWIzLlB1YmxpY0tleVxyXG4pOiBQcm9taXNlPHN0cmluZz4gPT4ge1xyXG4gIGNvbnN0IG1pbnQgPSBhbmNob3Iud2ViMy5LZXlwYWlyLmdlbmVyYXRlKCk7XHJcbiAgY29uc3QgdG9rZW4gPSBhd2FpdCBnZXRUb2tlbldhbGxldChwYXllciwgbWludC5wdWJsaWNLZXkpO1xyXG4gIGNvbnN0IHsgY29ubmVjdGlvbiwgcHJvZ3JhbSB9ID0gY2FuZHlNYWNoaW5lO1xyXG4gIGNvbnN0IG1ldGFkYXRhID0gYXdhaXQgZ2V0TWV0YWRhdGEobWludC5wdWJsaWNLZXkpO1xyXG4gIGNvbnN0IG1hc3RlckVkaXRpb24gPSBhd2FpdCBnZXRNYXN0ZXJFZGl0aW9uKG1pbnQucHVibGljS2V5KTtcclxuXHJcbiAgY29uc3QgcmVudCA9IGF3YWl0IGNvbm5lY3Rpb24uZ2V0TWluaW11bUJhbGFuY2VGb3JSZW50RXhlbXB0aW9uKFxyXG4gICAgTWludExheW91dC5zcGFuXHJcbiAgKTtcclxuXHJcbiAgcmV0dXJuIGF3YWl0IHByb2dyYW0ucnBjLm1pbnROZnQoe1xyXG4gICAgYWNjb3VudHM6IHtcclxuICAgICAgY29uZmlnLFxyXG4gICAgICBjYW5keU1hY2hpbmU6IGNhbmR5TWFjaGluZS5pZCxcclxuICAgICAgcGF5ZXI6IHBheWVyLFxyXG4gICAgICB3YWxsZXQ6IHRyZWFzdXJ5LFxyXG4gICAgICBtaW50OiBtaW50LnB1YmxpY0tleSxcclxuICAgICAgbWV0YWRhdGEsXHJcbiAgICAgIG1hc3RlckVkaXRpb24sXHJcbiAgICAgIG1pbnRBdXRob3JpdHk6IHBheWVyLFxyXG4gICAgICB1cGRhdGVBdXRob3JpdHk6IHBheWVyLFxyXG4gICAgICB0b2tlbk1ldGFkYXRhUHJvZ3JhbTogVE9LRU5fTUVUQURBVEFfUFJPR1JBTV9JRCxcclxuICAgICAgdG9rZW5Qcm9ncmFtOiBUT0tFTl9QUk9HUkFNX0lELFxyXG4gICAgICBzeXN0ZW1Qcm9ncmFtOiBhbmNob3Iud2ViMy5TeXN0ZW1Qcm9ncmFtLnByb2dyYW1JZCxcclxuICAgICAgcmVudDogYW5jaG9yLndlYjMuU1lTVkFSX1JFTlRfUFVCS0VZLFxyXG4gICAgICBjbG9jazogYW5jaG9yLndlYjMuU1lTVkFSX0NMT0NLX1BVQktFWSxcclxuICAgIH0sXHJcbiAgICBzaWduZXJzOiBbbWludF0sXHJcbiAgICBpbnN0cnVjdGlvbnM6IFtcclxuICAgICAgYW5jaG9yLndlYjMuU3lzdGVtUHJvZ3JhbS5jcmVhdGVBY2NvdW50KHtcclxuICAgICAgICBmcm9tUHVia2V5OiBwYXllcixcclxuICAgICAgICBuZXdBY2NvdW50UHVia2V5OiBtaW50LnB1YmxpY0tleSxcclxuICAgICAgICBzcGFjZTogTWludExheW91dC5zcGFuLFxyXG4gICAgICAgIGxhbXBvcnRzOiByZW50LFxyXG4gICAgICAgIHByb2dyYW1JZDogVE9LRU5fUFJPR1JBTV9JRCxcclxuICAgICAgfSksXHJcbiAgICAgIFRva2VuLmNyZWF0ZUluaXRNaW50SW5zdHJ1Y3Rpb24oXHJcbiAgICAgICAgVE9LRU5fUFJPR1JBTV9JRCxcclxuICAgICAgICBtaW50LnB1YmxpY0tleSxcclxuICAgICAgICAwLFxyXG4gICAgICAgIHBheWVyLFxyXG4gICAgICAgIHBheWVyXHJcbiAgICAgICksXHJcbiAgICAgIGNyZWF0ZUFzc29jaWF0ZWRUb2tlbkFjY291bnRJbnN0cnVjdGlvbihcclxuICAgICAgICB0b2tlbixcclxuICAgICAgICBwYXllcixcclxuICAgICAgICBwYXllcixcclxuICAgICAgICBtaW50LnB1YmxpY0tleVxyXG4gICAgICApLFxyXG4gICAgICBUb2tlbi5jcmVhdGVNaW50VG9JbnN0cnVjdGlvbihcclxuICAgICAgICBUT0tFTl9QUk9HUkFNX0lELFxyXG4gICAgICAgIG1pbnQucHVibGljS2V5LFxyXG4gICAgICAgIHRva2VuLFxyXG4gICAgICAgIHBheWVyLFxyXG4gICAgICAgIFtdLFxyXG4gICAgICAgIDFcclxuICAgICAgKSxcclxuICAgIF0sXHJcbiAgfSk7XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgbWludE11bHRpcGxlVG9rZW4gPSBhc3luYyAoXHJcbiAgY2FuZHlNYWNoaW5lOiBhbnksXHJcbiAgY29uZmlnOiBhbmNob3Iud2ViMy5QdWJsaWNLZXksXHJcbiAgcGF5ZXI6IGFuY2hvci53ZWIzLlB1YmxpY0tleSxcclxuICB0cmVhc3VyeTogYW5jaG9yLndlYjMuUHVibGljS2V5LFxyXG4gIHF1YW50aXR5OiBudW1iZXIgPSAyXHJcbikgPT4ge1xyXG4gIGNvbnN0IHNpZ25lcnNNYXRyaXggPSBbXTtcclxuICBjb25zdCBpbnN0cnVjdGlvbnNNYXRyaXggPSBbXTtcclxuXHJcbiAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IHF1YW50aXR5OyBpbmRleCsrKSB7XHJcbiAgICBjb25zdCBtaW50ID0gYW5jaG9yLndlYjMuS2V5cGFpci5nZW5lcmF0ZSgpO1xyXG4gICAgY29uc3QgdG9rZW4gPSBhd2FpdCBnZXRUb2tlbldhbGxldChwYXllciwgbWludC5wdWJsaWNLZXkpO1xyXG4gICAgY29uc3QgeyBjb25uZWN0aW9uIH0gPSBjYW5keU1hY2hpbmU7XHJcbiAgICBjb25zdCByZW50ID0gYXdhaXQgY29ubmVjdGlvbi5nZXRNaW5pbXVtQmFsYW5jZUZvclJlbnRFeGVtcHRpb24oXHJcbiAgICAgIE1pbnRMYXlvdXQuc3BhblxyXG4gICAgKTtcclxuICAgIGNvbnN0IGluc3RydWN0aW9ucyA9IFtcclxuICAgICAgYW5jaG9yLndlYjMuU3lzdGVtUHJvZ3JhbS5jcmVhdGVBY2NvdW50KHtcclxuICAgICAgICBmcm9tUHVia2V5OiBwYXllcixcclxuICAgICAgICBuZXdBY2NvdW50UHVia2V5OiBtaW50LnB1YmxpY0tleSxcclxuICAgICAgICBzcGFjZTogTWludExheW91dC5zcGFuLFxyXG4gICAgICAgIGxhbXBvcnRzOiByZW50LFxyXG4gICAgICAgIHByb2dyYW1JZDogVE9LRU5fUFJPR1JBTV9JRCxcclxuICAgICAgfSksXHJcbiAgICAgIFRva2VuLmNyZWF0ZUluaXRNaW50SW5zdHJ1Y3Rpb24oXHJcbiAgICAgICAgVE9LRU5fUFJPR1JBTV9JRCxcclxuICAgICAgICBtaW50LnB1YmxpY0tleSxcclxuICAgICAgICAwLFxyXG4gICAgICAgIHBheWVyLFxyXG4gICAgICAgIHBheWVyXHJcbiAgICAgICksXHJcbiAgICAgIGNyZWF0ZUFzc29jaWF0ZWRUb2tlbkFjY291bnRJbnN0cnVjdGlvbihcclxuICAgICAgICB0b2tlbixcclxuICAgICAgICBwYXllcixcclxuICAgICAgICBwYXllcixcclxuICAgICAgICBtaW50LnB1YmxpY0tleVxyXG4gICAgICApLFxyXG4gICAgICBUb2tlbi5jcmVhdGVNaW50VG9JbnN0cnVjdGlvbihcclxuICAgICAgICBUT0tFTl9QUk9HUkFNX0lELFxyXG4gICAgICAgIG1pbnQucHVibGljS2V5LFxyXG4gICAgICAgIHRva2VuLFxyXG4gICAgICAgIHBheWVyLFxyXG4gICAgICAgIFtdLFxyXG4gICAgICAgIDFcclxuICAgICAgKSxcclxuICAgIF07XHJcbiAgICBjb25zdCBtYXN0ZXJFZGl0aW9uID0gYXdhaXQgZ2V0TWFzdGVyRWRpdGlvbihtaW50LnB1YmxpY0tleSk7XHJcbiAgICBjb25zdCBtZXRhZGF0YSA9IGF3YWl0IGdldE1ldGFkYXRhKG1pbnQucHVibGljS2V5KTtcclxuXHJcbiAgICBpbnN0cnVjdGlvbnMucHVzaChcclxuICAgICAgYXdhaXQgY2FuZHlNYWNoaW5lLnByb2dyYW0uaW5zdHJ1Y3Rpb24ubWludE5mdCh7XHJcbiAgICAgICAgYWNjb3VudHM6IHtcclxuICAgICAgICAgIGNvbmZpZyxcclxuICAgICAgICAgIGNhbmR5TWFjaGluZTogY2FuZHlNYWNoaW5lLmlkLFxyXG4gICAgICAgICAgcGF5ZXI6IHBheWVyLFxyXG4gICAgICAgICAgd2FsbGV0OiB0cmVhc3VyeSxcclxuICAgICAgICAgIG1pbnQ6IG1pbnQucHVibGljS2V5LFxyXG4gICAgICAgICAgbWV0YWRhdGEsXHJcbiAgICAgICAgICBtYXN0ZXJFZGl0aW9uLFxyXG4gICAgICAgICAgbWludEF1dGhvcml0eTogcGF5ZXIsXHJcbiAgICAgICAgICB1cGRhdGVBdXRob3JpdHk6IHBheWVyLFxyXG4gICAgICAgICAgdG9rZW5NZXRhZGF0YVByb2dyYW06IFRPS0VOX01FVEFEQVRBX1BST0dSQU1fSUQsXHJcbiAgICAgICAgICB0b2tlblByb2dyYW06IFRPS0VOX1BST0dSQU1fSUQsXHJcbiAgICAgICAgICBzeXN0ZW1Qcm9ncmFtOiBhbmNob3Iud2ViMy5TeXN0ZW1Qcm9ncmFtLnByb2dyYW1JZCxcclxuICAgICAgICAgIHJlbnQ6IGFuY2hvci53ZWIzLlNZU1ZBUl9SRU5UX1BVQktFWSxcclxuICAgICAgICAgIGNsb2NrOiBhbmNob3Iud2ViMy5TWVNWQVJfQ0xPQ0tfUFVCS0VZLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pXHJcbiAgICApO1xyXG4gICAgY29uc3Qgc2lnbmVyczogYW5jaG9yLndlYjMuS2V5cGFpcltdID0gW21pbnRdO1xyXG5cclxuICAgIHNpZ25lcnNNYXRyaXgucHVzaChzaWduZXJzKTtcclxuICAgIGluc3RydWN0aW9uc01hdHJpeC5wdXNoKGluc3RydWN0aW9ucyk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gYXdhaXQgc2VuZFRyYW5zYWN0aW9ucyhcclxuICAgIGNhbmR5TWFjaGluZS5wcm9ncmFtLnByb3ZpZGVyLmNvbm5lY3Rpb24sXHJcbiAgICBjYW5keU1hY2hpbmUucHJvZ3JhbS5wcm92aWRlci53YWxsZXQsXHJcbiAgICBpbnN0cnVjdGlvbnNNYXRyaXgsXHJcbiAgICBzaWduZXJzTWF0cml4XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBzaG9ydGVuQWRkcmVzcyA9IChhZGRyZXNzOiBzdHJpbmcsIGNoYXJzID0gNCk6IHN0cmluZyA9PiB7XHJcbiAgcmV0dXJuIGAke2FkZHJlc3Muc2xpY2UoMCwgY2hhcnMpfS4uLiR7YWRkcmVzcy5zbGljZSgtY2hhcnMpfWA7XHJcbn07XHJcbiIsImltcG9ydCB7XHJcbiAgS2V5cGFpcixcclxuICBDb21taXRtZW50LFxyXG4gIENvbm5lY3Rpb24sXHJcbiAgUnBjUmVzcG9uc2VBbmRDb250ZXh0LFxyXG4gIFNpZ25hdHVyZVN0YXR1cyxcclxuICBTaW11bGF0ZWRUcmFuc2FjdGlvblJlc3BvbnNlLFxyXG4gIFRyYW5zYWN0aW9uLFxyXG4gIFRyYW5zYWN0aW9uSW5zdHJ1Y3Rpb24sXHJcbiAgVHJhbnNhY3Rpb25TaWduYXR1cmUsXHJcbiAgQmxvY2toYXNoLFxyXG4gIEZlZUNhbGN1bGF0b3IsXHJcbn0gZnJvbSBcIkBzb2xhbmEvd2ViMy5qc1wiO1xyXG5cclxuaW1wb3J0IHsgV2FsbGV0Tm90Q29ubmVjdGVkRXJyb3IgfSBmcm9tIFwiQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlXCI7XHJcblxyXG5pbnRlcmZhY2UgQmxvY2toYXNoQW5kRmVlQ2FsY3VsYXRvciB7XHJcbiAgYmxvY2toYXNoOiBCbG9ja2hhc2g7XHJcbiAgZmVlQ2FsY3VsYXRvcjogRmVlQ2FsY3VsYXRvcjtcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IGdldEVycm9yRm9yVHJhbnNhY3Rpb24gPSBhc3luYyAoXHJcbiAgY29ubmVjdGlvbjogQ29ubmVjdGlvbixcclxuICB0eGlkOiBzdHJpbmdcclxuKSA9PiB7XHJcbiAgLy8gd2FpdCBmb3IgYWxsIGNvbmZpcm1hdGlvbiBiZWZvcmUgZ2V0aW5nIHRyYW5zYWN0aW9uXHJcbiAgYXdhaXQgY29ubmVjdGlvbi5jb25maXJtVHJhbnNhY3Rpb24odHhpZCwgXCJtYXhcIik7XHJcblxyXG4gIGNvbnN0IHR4ID0gYXdhaXQgY29ubmVjdGlvbi5nZXRQYXJzZWRDb25maXJtZWRUcmFuc2FjdGlvbih0eGlkKTtcclxuXHJcbiAgY29uc3QgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xyXG4gIGlmICh0eD8ubWV0YSAmJiB0eC5tZXRhLmxvZ01lc3NhZ2VzKSB7XHJcbiAgICB0eC5tZXRhLmxvZ01lc3NhZ2VzLmZvckVhY2goKGxvZykgPT4ge1xyXG4gICAgICBjb25zdCByZWdleCA9IC9FcnJvcjogKC4qKS9nbTtcclxuICAgICAgbGV0IG07XHJcbiAgICAgIHdoaWxlICgobSA9IHJlZ2V4LmV4ZWMobG9nKSkgIT09IG51bGwpIHtcclxuICAgICAgICAvLyBUaGlzIGlzIG5lY2Vzc2FyeSB0byBhdm9pZCBpbmZpbml0ZSBsb29wcyB3aXRoIHplcm8td2lkdGggbWF0Y2hlc1xyXG4gICAgICAgIGlmIChtLmluZGV4ID09PSByZWdleC5sYXN0SW5kZXgpIHtcclxuICAgICAgICAgIHJlZ2V4Lmxhc3RJbmRleCsrO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKG0ubGVuZ3RoID4gMSkge1xyXG4gICAgICAgICAgZXJyb3JzLnB1c2gobVsxXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHJldHVybiBlcnJvcnM7XHJcbn07XHJcblxyXG5leHBvcnQgZW51bSBTZXF1ZW5jZVR5cGUge1xyXG4gIFNlcXVlbnRpYWwsXHJcbiAgUGFyYWxsZWwsXHJcbiAgU3RvcE9uRmFpbHVyZSxcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IHNlbmRUcmFuc2FjdGlvbnMgPSBhc3luYyAoXHJcbiAgY29ubmVjdGlvbjogQ29ubmVjdGlvbixcclxuICB3YWxsZXQ6IGFueSxcclxuICBpbnN0cnVjdGlvblNldDogVHJhbnNhY3Rpb25JbnN0cnVjdGlvbltdW10sXHJcbiAgc2lnbmVyc1NldDogS2V5cGFpcltdW10sXHJcbiAgc2VxdWVuY2VUeXBlOiBTZXF1ZW5jZVR5cGUgPSBTZXF1ZW5jZVR5cGUuUGFyYWxsZWwsXHJcbiAgY29tbWl0bWVudDogQ29tbWl0bWVudCA9IFwic2luZ2xlR29zc2lwXCIsXHJcbiAgYmxvY2s/OiBCbG9ja2hhc2hBbmRGZWVDYWxjdWxhdG9yXHJcbik6IFByb21pc2U8c3RyaW5nW10gfCBudW1iZXI+ID0+IHtcclxuICBpZiAoIXdhbGxldC5wdWJsaWNLZXkpIHRocm93IG5ldyBXYWxsZXROb3RDb25uZWN0ZWRFcnJvcigpO1xyXG5cclxuICBjb25zdCB1bnNpZ25lZFR4bnM6IFRyYW5zYWN0aW9uW10gPSBbXTtcclxuXHJcbiAgaWYgKCFibG9jaykge1xyXG4gICAgYmxvY2sgPSBhd2FpdCBjb25uZWN0aW9uLmdldFJlY2VudEJsb2NraGFzaChjb21taXRtZW50KTtcclxuICB9XHJcblxyXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgaW5zdHJ1Y3Rpb25TZXQubGVuZ3RoOyBpKyspIHtcclxuICAgIGNvbnN0IGluc3RydWN0aW9ucyA9IGluc3RydWN0aW9uU2V0W2ldO1xyXG4gICAgY29uc3Qgc2lnbmVycyA9IHNpZ25lcnNTZXRbaV07XHJcblxyXG4gICAgaWYgKGluc3RydWN0aW9ucy5sZW5ndGggPT09IDApIHtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHRyYW5zYWN0aW9uID0gbmV3IFRyYW5zYWN0aW9uKCk7XHJcbiAgICBpbnN0cnVjdGlvbnMuZm9yRWFjaCgoaW5zdHJ1Y3Rpb24pID0+IHRyYW5zYWN0aW9uLmFkZChpbnN0cnVjdGlvbikpO1xyXG4gICAgdHJhbnNhY3Rpb24ucmVjZW50QmxvY2toYXNoID0gYmxvY2suYmxvY2toYXNoO1xyXG4gICAgdHJhbnNhY3Rpb24uc2V0U2lnbmVycyhcclxuICAgICAgLy8gZmVlIHBheWVkIGJ5IHRoZSB3YWxsZXQgb3duZXJcclxuICAgICAgd2FsbGV0LnB1YmxpY0tleSxcclxuICAgICAgLi4uc2lnbmVycy5tYXAoKHMpID0+IHMucHVibGljS2V5KVxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAoc2lnbmVycy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIHRyYW5zYWN0aW9uLnBhcnRpYWxTaWduKC4uLnNpZ25lcnMpO1xyXG4gICAgfVxyXG5cclxuICAgIHVuc2lnbmVkVHhucy5wdXNoKHRyYW5zYWN0aW9uKTtcclxuICB9XHJcblxyXG4gIGNvbnN0IHNpZ25lZFR4bnMgPSBhd2FpdCB3YWxsZXQuc2lnbkFsbFRyYW5zYWN0aW9ucyh1bnNpZ25lZFR4bnMpO1xyXG5cclxuICBjb25zdCBwZW5kaW5nVHhuczogUHJvbWlzZTx7IHR4aWQ6IHN0cmluZzsgc2xvdDogbnVtYmVyIH0+W10gPSBbXTtcclxuXHJcbiAgbGV0IGJyZWFrRWFybHlPYmplY3QgPSB7IGJyZWFrRWFybHk6IGZhbHNlLCBpOiAwIH07XHJcbiAgY29uc29sZS5sb2coXHJcbiAgICBcIlNpZ25lZCB0eG5zIGxlbmd0aFwiLFxyXG4gICAgc2lnbmVkVHhucy5sZW5ndGgsXHJcbiAgICBcInZzIGhhbmRlZCBpbiBsZW5ndGhcIixcclxuICAgIGluc3RydWN0aW9uU2V0Lmxlbmd0aFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHR4SWRzID0gW107XHJcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBzaWduZWRUeG5zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICBjb25zdCBzaWduZWRUeG5Qcm9taXNlID0gc2VuZFNpZ25lZFRyYW5zYWN0aW9uKHtcclxuICAgICAgY29ubmVjdGlvbixcclxuICAgICAgc2lnbmVkVHJhbnNhY3Rpb246IHNpZ25lZFR4bnNbaV0sXHJcbiAgICB9KTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB7IHR4aWQgfSA9IGF3YWl0IHNpZ25lZFR4blByb21pc2U7XHJcbiAgICAgIHR4SWRzLnB1c2godHhpZCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgICBmYWlsQ2FsbGJhY2soc2lnbmVkVHhuc1tpXSwgaSk7XHJcbiAgICAgIGlmIChzZXF1ZW5jZVR5cGUgPT09IFNlcXVlbmNlVHlwZS5TdG9wT25GYWlsdXJlKSB7XHJcbiAgICAgICAgYnJlYWtFYXJseU9iamVjdC5icmVha0Vhcmx5ID0gdHJ1ZTtcclxuICAgICAgICBicmVha0Vhcmx5T2JqZWN0LmkgPSBpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHNlcXVlbmNlVHlwZSAhPT0gU2VxdWVuY2VUeXBlLlBhcmFsbGVsKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgc2lnbmVkVHhuUHJvbWlzZTtcclxuICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiQ2F1Z2h0IGZhaWx1cmVcIiwgZSk7XHJcbiAgICAgICAgaWYgKGJyZWFrRWFybHlPYmplY3QuYnJlYWtFYXJseSkge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJEaWVkIG9uIFwiLCBicmVha0Vhcmx5T2JqZWN0LmkpO1xyXG4gICAgICAgICAgcmV0dXJuIGJyZWFrRWFybHlPYmplY3QuaTsgLy8gUmV0dXJuIHRoZSB0eG4gd2UgZmFpbGVkIG9uIGJ5IGluZGV4XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBwZW5kaW5nVHhucy5wdXNoKHNpZ25lZFR4blByb21pc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgaWYgKHNlcXVlbmNlVHlwZSAhPT0gU2VxdWVuY2VUeXBlLlBhcmFsbGVsKSB7XHJcbiAgICBhd2FpdCBQcm9taXNlLmFsbChwZW5kaW5nVHhucyk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gdHhJZHM7XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3Qgc2VuZFRyYW5zYWN0aW9uID0gYXN5bmMgKFxyXG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb24sXHJcbiAgd2FsbGV0OiBhbnksXHJcbiAgaW5zdHJ1Y3Rpb25zOiBUcmFuc2FjdGlvbkluc3RydWN0aW9uW10sXHJcbiAgc2lnbmVyczogS2V5cGFpcltdLFxyXG4gIGF3YWl0Q29uZmlybWF0aW9uID0gdHJ1ZSxcclxuICBjb21taXRtZW50OiBDb21taXRtZW50ID0gXCJzaW5nbGVHb3NzaXBcIixcclxuICBpbmNsdWRlc0ZlZVBheWVyOiBib29sZWFuID0gZmFsc2UsXHJcbiAgYmxvY2s/OiBCbG9ja2hhc2hBbmRGZWVDYWxjdWxhdG9yXHJcbikgPT4ge1xyXG4gIGlmICghd2FsbGV0LnB1YmxpY0tleSkgdGhyb3cgbmV3IFdhbGxldE5vdENvbm5lY3RlZEVycm9yKCk7XHJcblxyXG4gIGxldCB0cmFuc2FjdGlvbiA9IG5ldyBUcmFuc2FjdGlvbigpO1xyXG4gIGluc3RydWN0aW9ucy5mb3JFYWNoKChpbnN0cnVjdGlvbikgPT4gdHJhbnNhY3Rpb24uYWRkKGluc3RydWN0aW9uKSk7XHJcbiAgdHJhbnNhY3Rpb24ucmVjZW50QmxvY2toYXNoID0gKFxyXG4gICAgYmxvY2sgfHwgKGF3YWl0IGNvbm5lY3Rpb24uZ2V0UmVjZW50QmxvY2toYXNoKGNvbW1pdG1lbnQpKVxyXG4gICkuYmxvY2toYXNoO1xyXG5cclxuICBpZiAoaW5jbHVkZXNGZWVQYXllcikge1xyXG4gICAgdHJhbnNhY3Rpb24uc2V0U2lnbmVycyguLi5zaWduZXJzLm1hcCgocykgPT4gcy5wdWJsaWNLZXkpKTtcclxuICB9IGVsc2Uge1xyXG4gICAgdHJhbnNhY3Rpb24uc2V0U2lnbmVycyhcclxuICAgICAgLy8gZmVlIHBheWVkIGJ5IHRoZSB3YWxsZXQgb3duZXJcclxuICAgICAgd2FsbGV0LnB1YmxpY0tleSxcclxuICAgICAgLi4uc2lnbmVycy5tYXAoKHMpID0+IHMucHVibGljS2V5KVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmIChzaWduZXJzLmxlbmd0aCA+IDApIHtcclxuICAgIHRyYW5zYWN0aW9uLnBhcnRpYWxTaWduKC4uLnNpZ25lcnMpO1xyXG4gIH1cclxuICBpZiAoIWluY2x1ZGVzRmVlUGF5ZXIpIHtcclxuICAgIHRyYW5zYWN0aW9uID0gYXdhaXQgd2FsbGV0LnNpZ25UcmFuc2FjdGlvbih0cmFuc2FjdGlvbik7XHJcbiAgfVxyXG5cclxuICBjb25zdCByYXdUcmFuc2FjdGlvbiA9IHRyYW5zYWN0aW9uLnNlcmlhbGl6ZSgpO1xyXG4gIGxldCBvcHRpb25zID0ge1xyXG4gICAgc2tpcFByZWZsaWdodDogdHJ1ZSxcclxuICAgIGNvbW1pdG1lbnQsXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdHhpZCA9IGF3YWl0IGNvbm5lY3Rpb24uc2VuZFJhd1RyYW5zYWN0aW9uKHJhd1RyYW5zYWN0aW9uLCBvcHRpb25zKTtcclxuICBsZXQgc2xvdCA9IDA7XHJcblxyXG4gIGlmIChhd2FpdENvbmZpcm1hdGlvbikge1xyXG4gICAgY29uc3QgY29uZmlybWF0aW9uID0gYXdhaXQgYXdhaXRUcmFuc2FjdGlvblNpZ25hdHVyZUNvbmZpcm1hdGlvbihcclxuICAgICAgdHhpZCxcclxuICAgICAgREVGQVVMVF9USU1FT1VULFxyXG4gICAgICBjb25uZWN0aW9uLFxyXG4gICAgICBjb21taXRtZW50XHJcbiAgICApO1xyXG5cclxuICAgIGlmICghY29uZmlybWF0aW9uKVxyXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUaW1lZCBvdXQgYXdhaXRpbmcgY29uZmlybWF0aW9uIG9uIHRyYW5zYWN0aW9uXCIpO1xyXG4gICAgc2xvdCA9IGNvbmZpcm1hdGlvbj8uc2xvdCB8fCAwO1xyXG5cclxuICAgIGlmIChjb25maXJtYXRpb24/LmVycikge1xyXG4gICAgICBjb25zdCBlcnJvcnMgPSBhd2FpdCBnZXRFcnJvckZvclRyYW5zYWN0aW9uKGNvbm5lY3Rpb24sIHR4aWQpO1xyXG5cclxuICAgICAgY29uc29sZS5sb2coZXJyb3JzKTtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKGBSYXcgdHJhbnNhY3Rpb24gJHt0eGlkfSBmYWlsZWRgKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiB7IHR4aWQsIHNsb3QgfTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBzZW5kVHJhbnNhY3Rpb25XaXRoUmV0cnkgPSBhc3luYyAoXHJcbiAgY29ubmVjdGlvbjogQ29ubmVjdGlvbixcclxuICB3YWxsZXQ6IGFueSxcclxuICBpbnN0cnVjdGlvbnM6IFRyYW5zYWN0aW9uSW5zdHJ1Y3Rpb25bXSxcclxuICBzaWduZXJzOiBLZXlwYWlyW10sXHJcbiAgY29tbWl0bWVudDogQ29tbWl0bWVudCA9IFwic2luZ2xlR29zc2lwXCIsXHJcbiAgaW5jbHVkZXNGZWVQYXllcjogYm9vbGVhbiA9IGZhbHNlLFxyXG4gIGJsb2NrPzogQmxvY2toYXNoQW5kRmVlQ2FsY3VsYXRvcixcclxuICBiZWZvcmVTZW5kPzogKCkgPT4gdm9pZFxyXG4pID0+IHtcclxuICBpZiAoIXdhbGxldC5wdWJsaWNLZXkpIHRocm93IG5ldyBXYWxsZXROb3RDb25uZWN0ZWRFcnJvcigpO1xyXG5cclxuICBsZXQgdHJhbnNhY3Rpb24gPSBuZXcgVHJhbnNhY3Rpb24oKTtcclxuICBpbnN0cnVjdGlvbnMuZm9yRWFjaCgoaW5zdHJ1Y3Rpb24pID0+IHRyYW5zYWN0aW9uLmFkZChpbnN0cnVjdGlvbikpO1xyXG4gIHRyYW5zYWN0aW9uLnJlY2VudEJsb2NraGFzaCA9IChcclxuICAgIGJsb2NrIHx8IChhd2FpdCBjb25uZWN0aW9uLmdldFJlY2VudEJsb2NraGFzaChjb21taXRtZW50KSlcclxuICApLmJsb2NraGFzaDtcclxuXHJcbiAgaWYgKGluY2x1ZGVzRmVlUGF5ZXIpIHtcclxuICAgIHRyYW5zYWN0aW9uLnNldFNpZ25lcnMoLi4uc2lnbmVycy5tYXAoKHMpID0+IHMucHVibGljS2V5KSk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHRyYW5zYWN0aW9uLnNldFNpZ25lcnMoXHJcbiAgICAgIC8vIGZlZSBwYXllZCBieSB0aGUgd2FsbGV0IG93bmVyXHJcbiAgICAgIHdhbGxldC5wdWJsaWNLZXksXHJcbiAgICAgIC4uLnNpZ25lcnMubWFwKChzKSA9PiBzLnB1YmxpY0tleSlcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAoc2lnbmVycy5sZW5ndGggPiAwKSB7XHJcbiAgICB0cmFuc2FjdGlvbi5wYXJ0aWFsU2lnbiguLi5zaWduZXJzKTtcclxuICB9XHJcbiAgaWYgKCFpbmNsdWRlc0ZlZVBheWVyKSB7XHJcbiAgICB0cmFuc2FjdGlvbiA9IGF3YWl0IHdhbGxldC5zaWduVHJhbnNhY3Rpb24odHJhbnNhY3Rpb24pO1xyXG4gIH1cclxuXHJcbiAgaWYgKGJlZm9yZVNlbmQpIHtcclxuICAgIGJlZm9yZVNlbmQoKTtcclxuICB9XHJcblxyXG4gIGNvbnN0IHsgdHhpZCwgc2xvdCB9ID0gYXdhaXQgc2VuZFNpZ25lZFRyYW5zYWN0aW9uKHtcclxuICAgIGNvbm5lY3Rpb24sXHJcbiAgICBzaWduZWRUcmFuc2FjdGlvbjogdHJhbnNhY3Rpb24sXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiB7IHR4aWQsIHNsb3QgfTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBnZXRVbml4VHMgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIG5ldyBEYXRlKCkuZ2V0VGltZSgpIC8gMTAwMDtcclxufTtcclxuXHJcbmNvbnN0IERFRkFVTFRfVElNRU9VVCA9IDE1MDAwO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmRTaWduZWRUcmFuc2FjdGlvbih7XHJcbiAgc2lnbmVkVHJhbnNhY3Rpb24sXHJcbiAgY29ubmVjdGlvbixcclxuICB0aW1lb3V0ID0gREVGQVVMVF9USU1FT1VULFxyXG59OiB7XHJcbiAgc2lnbmVkVHJhbnNhY3Rpb246IFRyYW5zYWN0aW9uO1xyXG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb247XHJcbiAgc2VuZGluZ01lc3NhZ2U/OiBzdHJpbmc7XHJcbiAgc2VudE1lc3NhZ2U/OiBzdHJpbmc7XHJcbiAgc3VjY2Vzc01lc3NhZ2U/OiBzdHJpbmc7XHJcbiAgdGltZW91dD86IG51bWJlcjtcclxufSk6IFByb21pc2U8eyB0eGlkOiBzdHJpbmc7IHNsb3Q6IG51bWJlciB9PiB7XHJcbiAgY29uc3QgcmF3VHJhbnNhY3Rpb24gPSBzaWduZWRUcmFuc2FjdGlvbi5zZXJpYWxpemUoKTtcclxuICBjb25zdCBzdGFydFRpbWUgPSBnZXRVbml4VHMoKTtcclxuICBsZXQgc2xvdCA9IDA7XHJcbiAgY29uc3QgdHhpZDogVHJhbnNhY3Rpb25TaWduYXR1cmUgPSBhd2FpdCBjb25uZWN0aW9uLnNlbmRSYXdUcmFuc2FjdGlvbihcclxuICAgIHJhd1RyYW5zYWN0aW9uLFxyXG4gICAge1xyXG4gICAgICBza2lwUHJlZmxpZ2h0OiB0cnVlLFxyXG4gICAgfVxyXG4gICk7XHJcblxyXG4gIGNvbnNvbGUubG9nKFwiU3RhcnRlZCBhd2FpdGluZyBjb25maXJtYXRpb24gZm9yXCIsIHR4aWQpO1xyXG5cclxuICBsZXQgZG9uZSA9IGZhbHNlO1xyXG4gIChhc3luYyAoKSA9PiB7XHJcbiAgICB3aGlsZSAoIWRvbmUgJiYgZ2V0VW5peFRzKCkgLSBzdGFydFRpbWUgPCB0aW1lb3V0KSB7XHJcbiAgICAgIGNvbm5lY3Rpb24uc2VuZFJhd1RyYW5zYWN0aW9uKHJhd1RyYW5zYWN0aW9uLCB7XHJcbiAgICAgICAgc2tpcFByZWZsaWdodDogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICAgIGF3YWl0IHNsZWVwKDUwMCk7XHJcbiAgICB9XHJcbiAgfSkoKTtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY29uZmlybWF0aW9uID0gYXdhaXQgYXdhaXRUcmFuc2FjdGlvblNpZ25hdHVyZUNvbmZpcm1hdGlvbihcclxuICAgICAgdHhpZCxcclxuICAgICAgdGltZW91dCxcclxuICAgICAgY29ubmVjdGlvbixcclxuICAgICAgXCJyZWNlbnRcIixcclxuICAgICAgdHJ1ZVxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAoIWNvbmZpcm1hdGlvbilcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVGltZWQgb3V0IGF3YWl0aW5nIGNvbmZpcm1hdGlvbiBvbiB0cmFuc2FjdGlvblwiKTtcclxuXHJcbiAgICBpZiAoY29uZmlybWF0aW9uLmVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGNvbmZpcm1hdGlvbi5lcnIpO1xyXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUcmFuc2FjdGlvbiBmYWlsZWQ6IEN1c3RvbSBpbnN0cnVjdGlvbiBlcnJvclwiKTtcclxuICAgIH1cclxuXHJcbiAgICBzbG90ID0gY29uZmlybWF0aW9uPy5zbG90IHx8IDA7XHJcbiAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJUaW1lb3V0IEVycm9yIGNhdWdodFwiLCBlcnIpO1xyXG4gICAgaWYgKGVyci50aW1lb3V0KSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRpbWVkIG91dCBhd2FpdGluZyBjb25maXJtYXRpb24gb24gdHJhbnNhY3Rpb25cIik7XHJcbiAgICB9XHJcbiAgICBsZXQgc2ltdWxhdGVSZXN1bHQ6IFNpbXVsYXRlZFRyYW5zYWN0aW9uUmVzcG9uc2UgfCBudWxsID0gbnVsbDtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNpbXVsYXRlUmVzdWx0ID0gKFxyXG4gICAgICAgIGF3YWl0IHNpbXVsYXRlVHJhbnNhY3Rpb24oY29ubmVjdGlvbiwgc2lnbmVkVHJhbnNhY3Rpb24sIFwic2luZ2xlXCIpXHJcbiAgICAgICkudmFsdWU7XHJcbiAgICB9IGNhdGNoIChlKSB7fVxyXG4gICAgaWYgKHNpbXVsYXRlUmVzdWx0ICYmIHNpbXVsYXRlUmVzdWx0LmVycikge1xyXG4gICAgICBpZiAoc2ltdWxhdGVSZXN1bHQubG9ncykge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSBzaW11bGF0ZVJlc3VsdC5sb2dzLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XHJcbiAgICAgICAgICBjb25zdCBsaW5lID0gc2ltdWxhdGVSZXN1bHQubG9nc1tpXTtcclxuICAgICAgICAgIGlmIChsaW5lLnN0YXJ0c1dpdGgoXCJQcm9ncmFtIGxvZzogXCIpKSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgICAgICAgICBcIlRyYW5zYWN0aW9uIGZhaWxlZDogXCIgKyBsaW5lLnNsaWNlKFwiUHJvZ3JhbSBsb2c6IFwiLmxlbmd0aClcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgdGhyb3cgbmV3IEVycm9yKEpTT04uc3RyaW5naWZ5KHNpbXVsYXRlUmVzdWx0LmVycikpO1xyXG4gICAgfVxyXG4gICAgLy8gdGhyb3cgbmV3IEVycm9yKCdUcmFuc2FjdGlvbiBmYWlsZWQnKTtcclxuICB9IGZpbmFsbHkge1xyXG4gICAgZG9uZSA9IHRydWU7XHJcbiAgfVxyXG5cclxuICBjb25zb2xlLmxvZyhcIkxhdGVuY3lcIiwgdHhpZCwgZ2V0VW5peFRzKCkgLSBzdGFydFRpbWUpO1xyXG4gIHJldHVybiB7IHR4aWQsIHNsb3QgfTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2ltdWxhdGVUcmFuc2FjdGlvbihcclxuICBjb25uZWN0aW9uOiBDb25uZWN0aW9uLFxyXG4gIHRyYW5zYWN0aW9uOiBUcmFuc2FjdGlvbixcclxuICBjb21taXRtZW50OiBDb21taXRtZW50XHJcbik6IFByb21pc2U8UnBjUmVzcG9uc2VBbmRDb250ZXh0PFNpbXVsYXRlZFRyYW5zYWN0aW9uUmVzcG9uc2U+PiB7XHJcbiAgLy8gQHRzLWlnbm9yZVxyXG4gIHRyYW5zYWN0aW9uLnJlY2VudEJsb2NraGFzaCA9IGF3YWl0IGNvbm5lY3Rpb24uX3JlY2VudEJsb2NraGFzaChcclxuICAgIC8vIEB0cy1pZ25vcmVcclxuICAgIGNvbm5lY3Rpb24uX2Rpc2FibGVCbG9ja2hhc2hDYWNoaW5nXHJcbiAgKTtcclxuXHJcbiAgY29uc3Qgc2lnbkRhdGEgPSB0cmFuc2FjdGlvbi5zZXJpYWxpemVNZXNzYWdlKCk7XHJcbiAgLy8gQHRzLWlnbm9yZVxyXG4gIGNvbnN0IHdpcmVUcmFuc2FjdGlvbiA9IHRyYW5zYWN0aW9uLl9zZXJpYWxpemUoc2lnbkRhdGEpO1xyXG4gIGNvbnN0IGVuY29kZWRUcmFuc2FjdGlvbiA9IHdpcmVUcmFuc2FjdGlvbi50b1N0cmluZyhcImJhc2U2NFwiKTtcclxuICBjb25zdCBjb25maWc6IGFueSA9IHsgZW5jb2Rpbmc6IFwiYmFzZTY0XCIsIGNvbW1pdG1lbnQgfTtcclxuICBjb25zdCBhcmdzID0gW2VuY29kZWRUcmFuc2FjdGlvbiwgY29uZmlnXTtcclxuXHJcbiAgLy8gQHRzLWlnbm9yZVxyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IGNvbm5lY3Rpb24uX3JwY1JlcXVlc3QoXCJzaW11bGF0ZVRyYW5zYWN0aW9uXCIsIGFyZ3MpO1xyXG4gIGlmIChyZXMuZXJyb3IpIHtcclxuICAgIHRocm93IG5ldyBFcnJvcihcImZhaWxlZCB0byBzaW11bGF0ZSB0cmFuc2FjdGlvbjogXCIgKyByZXMuZXJyb3IubWVzc2FnZSk7XHJcbiAgfVxyXG4gIHJldHVybiByZXMucmVzdWx0O1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBhd2FpdFRyYW5zYWN0aW9uU2lnbmF0dXJlQ29uZmlybWF0aW9uKFxyXG4gIHR4aWQ6IFRyYW5zYWN0aW9uU2lnbmF0dXJlLFxyXG4gIHRpbWVvdXQ6IG51bWJlcixcclxuICBjb25uZWN0aW9uOiBDb25uZWN0aW9uLFxyXG4gIGNvbW1pdG1lbnQ6IENvbW1pdG1lbnQgPSBcInJlY2VudFwiLFxyXG4gIHF1ZXJ5U3RhdHVzID0gZmFsc2VcclxuKTogUHJvbWlzZTxTaWduYXR1cmVTdGF0dXMgfCBudWxsIHwgdm9pZD4ge1xyXG4gIGxldCBkb25lID0gZmFsc2U7XHJcbiAgbGV0IHN0YXR1czogU2lnbmF0dXJlU3RhdHVzIHwgbnVsbCB8IHZvaWQgPSB7XHJcbiAgICBzbG90OiAwLFxyXG4gICAgY29uZmlybWF0aW9uczogMCxcclxuICAgIGVycjogbnVsbCxcclxuICB9O1xyXG4gIGxldCBzdWJJZCA9IDA7XHJcbiAgc3RhdHVzID0gYXdhaXQgbmV3IFByb21pc2UoYXN5bmMgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIGlmIChkb25lKSB7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcbiAgICAgIGRvbmUgPSB0cnVlO1xyXG4gICAgICBjb25zb2xlLmxvZyhcIlJlamVjdGluZyBmb3IgdGltZW91dC4uLlwiKTtcclxuICAgICAgcmVqZWN0KHsgdGltZW91dDogdHJ1ZSB9KTtcclxuICAgIH0sIHRpbWVvdXQpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgc3ViSWQgPSBjb25uZWN0aW9uLm9uU2lnbmF0dXJlKFxyXG4gICAgICAgIHR4aWQsXHJcbiAgICAgICAgKHJlc3VsdCwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgZG9uZSA9IHRydWU7XHJcbiAgICAgICAgICBzdGF0dXMgPSB7XHJcbiAgICAgICAgICAgIGVycjogcmVzdWx0LmVycixcclxuICAgICAgICAgICAgc2xvdDogY29udGV4dC5zbG90LFxyXG4gICAgICAgICAgICBjb25maXJtYXRpb25zOiAwLFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIGlmIChyZXN1bHQuZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiUmVqZWN0ZWQgdmlhIHdlYnNvY2tldFwiLCByZXN1bHQuZXJyKTtcclxuICAgICAgICAgICAgcmVqZWN0KHN0YXR1cyk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIlJlc29sdmVkIHZpYSB3ZWJzb2NrZXRcIiwgcmVzdWx0KTtcclxuICAgICAgICAgICAgcmVzb2x2ZShzdGF0dXMpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgY29tbWl0bWVudFxyXG4gICAgICApO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBkb25lID0gdHJ1ZTtcclxuICAgICAgY29uc29sZS5lcnJvcihcIldTIGVycm9yIGluIHNldHVwXCIsIHR4aWQsIGUpO1xyXG4gICAgfVxyXG4gICAgd2hpbGUgKCFkb25lICYmIHF1ZXJ5U3RhdHVzKSB7XHJcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1sb29wLWZ1bmNcclxuICAgICAgKGFzeW5jICgpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3Qgc2lnbmF0dXJlU3RhdHVzZXMgPSBhd2FpdCBjb25uZWN0aW9uLmdldFNpZ25hdHVyZVN0YXR1c2VzKFtcclxuICAgICAgICAgICAgdHhpZCxcclxuICAgICAgICAgIF0pO1xyXG4gICAgICAgICAgc3RhdHVzID0gc2lnbmF0dXJlU3RhdHVzZXMgJiYgc2lnbmF0dXJlU3RhdHVzZXMudmFsdWVbMF07XHJcbiAgICAgICAgICBpZiAoIWRvbmUpIHtcclxuICAgICAgICAgICAgaWYgKCFzdGF0dXMpIHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlJFU1QgbnVsbCByZXN1bHQgZm9yXCIsIHR4aWQsIHN0YXR1cyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoc3RhdHVzLmVycikge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiUkVTVCBlcnJvciBmb3JcIiwgdHhpZCwgc3RhdHVzKTtcclxuICAgICAgICAgICAgICBkb25lID0gdHJ1ZTtcclxuICAgICAgICAgICAgICByZWplY3Qoc3RhdHVzLmVycik7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoIXN0YXR1cy5jb25maXJtYXRpb25zKSB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJSRVNUIG5vIGNvbmZpcm1hdGlvbnMgZm9yXCIsIHR4aWQsIHN0YXR1cyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJSRVNUIGNvbmZpcm1hdGlvbiBmb3JcIiwgdHhpZCwgc3RhdHVzKTtcclxuICAgICAgICAgICAgICBkb25lID0gdHJ1ZTtcclxuICAgICAgICAgICAgICByZXNvbHZlKHN0YXR1cyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICBpZiAoIWRvbmUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJSRVNUIGNvbm5lY3Rpb24gZXJyb3I6IHR4aWRcIiwgdHhpZCwgZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9KSgpO1xyXG4gICAgICBhd2FpdCBzbGVlcCgyMDAwKTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgLy9AdHMtaWdub3JlXHJcbiAgaWYgKGNvbm5lY3Rpb24uX3NpZ25hdHVyZVN1YnNjcmlwdGlvbnNbc3ViSWRdKVxyXG4gICAgY29ubmVjdGlvbi5yZW1vdmVTaWduYXR1cmVMaXN0ZW5lcihzdWJJZCk7XHJcbiAgZG9uZSA9IHRydWU7XHJcbiAgY29uc29sZS5sb2coXCJSZXR1cm5pbmcgc3RhdHVzXCIsIHN0YXR1cyk7XHJcbiAgcmV0dXJuIHN0YXR1cztcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IHNsZWVwID0gKG1zOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+ID0+IHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgbXMpKTtcclxufTtcclxuIiwiaW1wb3J0IEV2ZW50RW1pdHRlciBmcm9tICdldmVudGVtaXR0ZXIzJztcbmV4cG9ydCB7IEV2ZW50RW1pdHRlciB9O1xuZXhwb3J0IGNsYXNzIEJhc2VXYWxsZXRBZGFwdGVyIGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbn1cbmV4cG9ydCB2YXIgV2FsbGV0QWRhcHRlck5ldHdvcms7XG4oZnVuY3Rpb24gKFdhbGxldEFkYXB0ZXJOZXR3b3JrKSB7XG4gICAgV2FsbGV0QWRhcHRlck5ldHdvcmtbXCJNYWlubmV0XCJdID0gXCJtYWlubmV0LWJldGFcIjtcbiAgICBXYWxsZXRBZGFwdGVyTmV0d29ya1tcIlRlc3RuZXRcIl0gPSBcInRlc3RuZXRcIjtcbiAgICBXYWxsZXRBZGFwdGVyTmV0d29ya1tcIkRldm5ldFwiXSA9IFwiZGV2bmV0XCI7XG59KShXYWxsZXRBZGFwdGVyTmV0d29yayB8fCAoV2FsbGV0QWRhcHRlck5ldHdvcmsgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YWRhcHRlci5qcy5tYXAiLCJleHBvcnQgY2xhc3MgV2FsbGV0RXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9leHBsaWNpdC1tb2R1bGUtYm91bmRhcnktdHlwZXNcbiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlLCBlcnJvcikge1xuICAgICAgICBzdXBlcihtZXNzYWdlKTtcbiAgICAgICAgdGhpcy5lcnJvciA9IGVycm9yO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXROb3RGb3VuZEVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0Tm90Rm91bmRFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldE5vdEluc3RhbGxlZEVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0Tm90SW5zdGFsbGVkRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXROb3RSZWFkeUVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0Tm90UmVhZHlFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldENvbm5lY3Rpb25FcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldENvbm5lY3Rpb25FcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldERpc2Nvbm5lY3RlZEVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0RGlzY29ubmVjdGVkRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXREaXNjb25uZWN0aW9uRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXREaXNjb25uZWN0aW9uRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRBY2NvdW50RXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXRBY2NvdW50RXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRQdWJsaWNLZXlFcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldFB1YmxpY0tleUVycm9yJztcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgV2FsbGV0S2V5cGFpckVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0S2V5cGFpckVycm9yJztcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgV2FsbGV0Tm90Q29ubmVjdGVkRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXROb3RDb25uZWN0ZWRFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldFNlbmRUcmFuc2FjdGlvbkVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0U2VuZFRyYW5zYWN0aW9uRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRTaWduTWVzc2FnZUVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0U2lnbk1lc3NhZ2VFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldFNpZ25UcmFuc2FjdGlvbkVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0U2lnblRyYW5zYWN0aW9uRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRUaW1lb3V0RXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXRUaW1lb3V0RXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRXaW5kb3dCbG9ja2VkRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXRXaW5kb3dCbG9ja2VkRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRXaW5kb3dDbG9zZWRFcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldFdpbmRvd0Nsb3NlZEVycm9yJztcbiAgICB9XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1lcnJvcnMuanMubWFwIiwiZXhwb3J0ICogZnJvbSAnLi9hZGFwdGVyJztcbmV4cG9ydCAqIGZyb20gJy4vZXJyb3JzJztcbmV4cG9ydCAqIGZyb20gJy4vcG9sbCc7XG5leHBvcnQgKiBmcm9tICcuL3NpZ25lcic7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJ2YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICAgIH0pO1xufTtcbmV4cG9ydCBmdW5jdGlvbiBwb2xsKGNhbGxiYWNrLCBpbnRlcnZhbCwgY291bnQpIHtcbiAgICBpZiAoY291bnQgPiAwKSB7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICAgICAgY29uc3QgZG9uZSA9IHlpZWxkIGNhbGxiYWNrKCk7XG4gICAgICAgICAgICBpZiAoIWRvbmUpXG4gICAgICAgICAgICAgICAgcG9sbChjYWxsYmFjaywgaW50ZXJ2YWwsIGNvdW50IC0gMSk7XG4gICAgICAgIH0pLCBpbnRlcnZhbCk7XG4gICAgfVxufVxuZXhwb3J0IGZ1bmN0aW9uIHBvbGxVbnRpbFJlYWR5KGFkYXB0ZXIsIHBvbGxJbnRlcnZhbCwgcG9sbENvdW50KSB7XG4gICAgcG9sbCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IHsgcmVhZHkgfSA9IGFkYXB0ZXI7XG4gICAgICAgIGlmIChyZWFkeSkge1xuICAgICAgICAgICAgaWYgKCFhZGFwdGVyLmVtaXQoJ3JlYWR5JykpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYCR7YWRhcHRlci5jb25zdHJ1Y3Rvci5uYW1lfSBpcyByZWFkeSBidXQgbm8gbGlzdGVuZXIgd2FzIHJlZ2lzdGVyZWRgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVhZHk7XG4gICAgfSwgcG9sbEludGVydmFsLCBwb2xsQ291bnQpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cG9sbC5qcy5tYXAiLCJ2YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICAgIH0pO1xufTtcbnZhciBfX3Jlc3QgPSAodGhpcyAmJiB0aGlzLl9fcmVzdCkgfHwgZnVuY3Rpb24gKHMsIGUpIHtcbiAgICB2YXIgdCA9IHt9O1xuICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxuICAgICAgICB0W3BdID0gc1twXTtcbiAgICBpZiAocyAhPSBudWxsICYmIHR5cGVvZiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzID09PSBcImZ1bmN0aW9uXCIpXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChlLmluZGV4T2YocFtpXSkgPCAwICYmIE9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChzLCBwW2ldKSlcbiAgICAgICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcbiAgICAgICAgfVxuICAgIHJldHVybiB0O1xufTtcbmltcG9ydCB7IEJhc2VXYWxsZXRBZGFwdGVyIH0gZnJvbSAnLi9hZGFwdGVyJztcbmltcG9ydCB7IFdhbGxldEVycm9yLCBXYWxsZXRTZW5kVHJhbnNhY3Rpb25FcnJvciB9IGZyb20gJy4vZXJyb3JzJztcbmV4cG9ydCBjbGFzcyBCYXNlU2lnbmVyV2FsbGV0QWRhcHRlciBleHRlbmRzIEJhc2VXYWxsZXRBZGFwdGVyIHtcbiAgICBzZW5kVHJhbnNhY3Rpb24odHJhbnNhY3Rpb24sIGNvbm5lY3Rpb24sIG9wdGlvbnMgPSB7fSkge1xuICAgICAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICAgICAgbGV0IGVtaXQgPSB0cnVlO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbi5mZWVQYXllciB8fCAodHJhbnNhY3Rpb24uZmVlUGF5ZXIgPSB0aGlzLnB1YmxpY0tleSB8fCB1bmRlZmluZWQpO1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbi5yZWNlbnRCbG9ja2hhc2ggfHwgKHRyYW5zYWN0aW9uLnJlY2VudEJsb2NraGFzaCA9ICh5aWVsZCBjb25uZWN0aW9uLmdldFJlY2VudEJsb2NraGFzaCgnZmluYWxpemVkJykpLmJsb2NraGFzaCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHsgc2lnbmVycyB9ID0gb3B0aW9ucywgc2VuZE9wdGlvbnMgPSBfX3Jlc3Qob3B0aW9ucywgW1wic2lnbmVyc1wiXSk7XG4gICAgICAgICAgICAgICAgICAgIChzaWduZXJzID09PSBudWxsIHx8IHNpZ25lcnMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNpZ25lcnMubGVuZ3RoKSAmJiB0cmFuc2FjdGlvbi5wYXJ0aWFsU2lnbiguLi5zaWduZXJzKTtcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNhY3Rpb24gPSB5aWVsZCB0aGlzLnNpZ25UcmFuc2FjdGlvbih0cmFuc2FjdGlvbik7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJhd1RyYW5zYWN0aW9uID0gdHJhbnNhY3Rpb24uc2VyaWFsaXplKCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB5aWVsZCBjb25uZWN0aW9uLnNlbmRSYXdUcmFuc2FjdGlvbihyYXdUcmFuc2FjdGlvbiwgc2VuZE9wdGlvbnMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gSWYgdGhlIGVycm9yIHdhcyB0aHJvd24gYnkgYHNpZ25UcmFuc2FjdGlvbmAsIHJldGhyb3cgaXQgYW5kIGRvbid0IGVtaXQgYSBkdXBsaWNhdGUgZXZlbnRcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgV2FsbGV0RXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtaXQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBXYWxsZXRTZW5kVHJhbnNhY3Rpb25FcnJvcihlcnJvciA9PT0gbnVsbCB8fCBlcnJvciA9PT0gdm9pZCAwID8gdm9pZCAwIDogZXJyb3IubWVzc2FnZSwgZXJyb3IpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGlmIChlbWl0KSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnJvcik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgQmFzZU1lc3NhZ2VTaWduZXJXYWxsZXRBZGFwdGVyIGV4dGVuZHMgQmFzZVNpZ25lcldhbGxldEFkYXB0ZXIge1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2lnbmVyLmpzLm1hcCIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgQnV0dG9uID0gKHByb3BzKSA9PiB7XG4gICAgY29uc3QganVzdGlmeUNvbnRlbnQgPSBwcm9wcy5lbmRJY29uIHx8IHByb3BzLnN0YXJ0SWNvbiA/ICdzcGFjZS1iZXR3ZWVuJyA6ICdjZW50ZXInO1xuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChcImJ1dHRvblwiLCB7IGNsYXNzTmFtZTogYHdhbGxldC1hZGFwdGVyLWJ1dHRvbiAke3Byb3BzLmNsYXNzTmFtZSB8fCAnJ31gLCBkaXNhYmxlZDogcHJvcHMuZGlzYWJsZWQsIG9uQ2xpY2s6IHByb3BzLm9uQ2xpY2ssIHN0eWxlOiBPYmplY3QuYXNzaWduKHsganVzdGlmeUNvbnRlbnQgfSwgcHJvcHMuc3R5bGUpLCB0YWJJbmRleDogcHJvcHMudGFiSW5kZXggfHwgMCwgdHlwZTogXCJidXR0b25cIiB9LFxuICAgICAgICBwcm9wcy5zdGFydEljb24gJiYgUmVhY3QuY3JlYXRlRWxlbWVudChcImlcIiwgeyBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItYnV0dG9uLXN0YXJ0LWljb25cIiB9LCBwcm9wcy5zdGFydEljb24pLFxuICAgICAgICBwcm9wcy5jaGlsZHJlbixcbiAgICAgICAgcHJvcHMuZW5kSWNvbiAmJiBSZWFjdC5jcmVhdGVFbGVtZW50KFwiaVwiLCB7IGNsYXNzTmFtZTogXCJ3YWxsZXQtYWRhcHRlci1idXR0b24tZW5kLWljb25cIiB9LCBwcm9wcy5lbmRJY29uKSkpO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUJ1dHRvbi5qcy5tYXAiLCJpbXBvcnQgUmVhY3QsIHsgdXNlTGF5b3V0RWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgQ29sbGFwc2UgPSAoeyBpZCwgY2hpbGRyZW4sIGV4cGFuZGVkID0gZmFsc2UgfSkgPT4ge1xuICAgIGNvbnN0IHJlZiA9IHVzZVJlZihudWxsKTtcbiAgICBjb25zdCBpbnN0YW50ID0gdXNlUmVmKHRydWUpO1xuICAgIGNvbnN0IHRyYW5zaXRpb24gPSAnaGVpZ2h0IDI1MG1zIGVhc2Utb3V0JztcbiAgICBjb25zdCBvcGVuQ29sbGFwc2UgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IG5vZGUgPSByZWYuY3VycmVudDtcbiAgICAgICAgaWYgKCFub2RlKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgICAgICAgICAgbm9kZS5zdHlsZS5oZWlnaHQgPSBub2RlLnNjcm9sbEhlaWdodCArICdweCc7XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgY2xvc2VDb2xsYXBzZSA9ICgpID0+IHtcbiAgICAgICAgY29uc3Qgbm9kZSA9IHJlZi5jdXJyZW50O1xuICAgICAgICBpZiAoIW5vZGUpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICAgICAgICBub2RlLnN0eWxlLmhlaWdodCA9IG5vZGUub2Zmc2V0SGVpZ2h0ICsgJ3B4JztcbiAgICAgICAgICAgIG5vZGUuc3R5bGUub3ZlcmZsb3cgPSAnaGlkZGVuJztcbiAgICAgICAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICAgICAgICAgICAgbm9kZS5zdHlsZS5oZWlnaHQgPSAnMCc7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICB1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoZXhwYW5kZWQpIHtcbiAgICAgICAgICAgIG9wZW5Db2xsYXBzZSgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY2xvc2VDb2xsYXBzZSgpO1xuICAgICAgICB9XG4gICAgfSwgW2V4cGFuZGVkXSk7XG4gICAgdXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3Qgbm9kZSA9IHJlZi5jdXJyZW50O1xuICAgICAgICBpZiAoIW5vZGUpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIGZ1bmN0aW9uIGhhbmRsZUNvbXBsZXRlKCkge1xuICAgICAgICAgICAgaWYgKCFub2RlKVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIG5vZGUuc3R5bGUub3ZlcmZsb3cgPSBleHBhbmRlZCA/ICdpbml0aWFsJyA6ICdoaWRkZW4nO1xuICAgICAgICAgICAgaWYgKGV4cGFuZGVkKSB7XG4gICAgICAgICAgICAgICAgbm9kZS5zdHlsZS5oZWlnaHQgPSAnYXV0byc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gaGFuZGxlVHJhbnNpdGlvbkVuZChldmVudCkge1xuICAgICAgICAgICAgaWYgKG5vZGUgJiYgZXZlbnQudGFyZ2V0ID09PSBub2RlICYmIGV2ZW50LnByb3BlcnR5TmFtZSA9PT0gJ2hlaWdodCcpIHtcbiAgICAgICAgICAgICAgICBoYW5kbGVDb21wbGV0ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChpbnN0YW50LmN1cnJlbnQpIHtcbiAgICAgICAgICAgIGhhbmRsZUNvbXBsZXRlKCk7XG4gICAgICAgICAgICBpbnN0YW50LmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBub2RlLmFkZEV2ZW50TGlzdGVuZXIoJ3RyYW5zaXRpb25lbmQnLCBoYW5kbGVUcmFuc2l0aW9uRW5kKTtcbiAgICAgICAgcmV0dXJuICgpID0+IG5vZGUucmVtb3ZlRXZlbnRMaXN0ZW5lcigndHJhbnNpdGlvbmVuZCcsIGhhbmRsZVRyYW5zaXRpb25FbmQpO1xuICAgIH0sIFtleHBhbmRlZF0pO1xuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNoaWxkcmVuOiBjaGlsZHJlbiwgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLWNvbGxhcHNlXCIsIGlkOiBpZCwgcmVmOiByZWYsIHJvbGU6IFwicmVnaW9uXCIsIHN0eWxlOiB7IGhlaWdodDogMCwgdHJhbnNpdGlvbjogaW5zdGFudC5jdXJyZW50ID8gdW5kZWZpbmVkIDogdHJhbnNpdGlvbiB9IH0pKTtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1Db2xsYXBzZS5qcy5tYXAiLCJ2YXIgX19yZXN0ID0gKHRoaXMgJiYgdGhpcy5fX3Jlc3QpIHx8IGZ1bmN0aW9uIChzLCBlKSB7XG4gICAgdmFyIHQgPSB7fTtcbiAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkgJiYgZS5pbmRleE9mKHApIDwgMClcbiAgICAgICAgdFtwXSA9IHNbcF07XG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxuICAgICAgICBmb3IgKHZhciBpID0gMCwgcCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMocyk7IGkgPCBwLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoZS5pbmRleE9mKHBbaV0pIDwgMCAmJiBPYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwocywgcFtpXSkpXG4gICAgICAgICAgICAgICAgdFtwW2ldXSA9IHNbcFtpXV07XG4gICAgICAgIH1cbiAgICByZXR1cm4gdDtcbn07XG5pbXBvcnQgeyB1c2VXYWxsZXQgfSBmcm9tICdAc29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0JztcbmltcG9ydCBSZWFjdCwgeyB1c2VDYWxsYmFjaywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4vQnV0dG9uJztcbmltcG9ydCB7IFdhbGxldEljb24gfSBmcm9tICcuL1dhbGxldEljb24nO1xuZXhwb3J0IGNvbnN0IFdhbGxldENvbm5lY3RCdXR0b24gPSAoX2EpID0+IHtcbiAgICB2YXIgeyBjaGlsZHJlbiwgZGlzYWJsZWQsIG9uQ2xpY2sgfSA9IF9hLCBwcm9wcyA9IF9fcmVzdChfYSwgW1wiY2hpbGRyZW5cIiwgXCJkaXNhYmxlZFwiLCBcIm9uQ2xpY2tcIl0pO1xuICAgIGNvbnN0IHsgd2FsbGV0LCBjb25uZWN0LCBjb25uZWN0aW5nLCBjb25uZWN0ZWQgfSA9IHVzZVdhbGxldCgpO1xuICAgIGNvbnN0IGhhbmRsZUNsaWNrID0gdXNlQ2FsbGJhY2soKGV2ZW50KSA9PiB7XG4gICAgICAgIGlmIChvbkNsaWNrKVxuICAgICAgICAgICAgb25DbGljayhldmVudCk7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZW1wdHktZnVuY3Rpb25cbiAgICAgICAgaWYgKCFldmVudC5kZWZhdWx0UHJldmVudGVkKVxuICAgICAgICAgICAgY29ubmVjdCgpLmNhdGNoKCgpID0+IHsgfSk7XG4gICAgfSwgW29uQ2xpY2ssIGNvbm5lY3RdKTtcbiAgICBjb25zdCBjb250ZW50ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGlmIChjaGlsZHJlbilcbiAgICAgICAgICAgIHJldHVybiBjaGlsZHJlbjtcbiAgICAgICAgaWYgKGNvbm5lY3RpbmcpXG4gICAgICAgICAgICByZXR1cm4gJ0Nvbm5lY3RpbmcgLi4uJztcbiAgICAgICAgaWYgKGNvbm5lY3RlZClcbiAgICAgICAgICAgIHJldHVybiAnQ29ubmVjdGVkJztcbiAgICAgICAgaWYgKHdhbGxldClcbiAgICAgICAgICAgIHJldHVybiAnQ29ubmVjdCc7XG4gICAgICAgIHJldHVybiAnQ29ubmVjdCBXYWxsZXQnO1xuICAgIH0sIFtjaGlsZHJlbiwgY29ubmVjdGluZywgY29ubmVjdGVkLCB3YWxsZXRdKTtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnV0dG9uLCBPYmplY3QuYXNzaWduKHsgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLWJ1dHRvbi10cmlnZ2VyXCIsIGRpc2FibGVkOiBkaXNhYmxlZCB8fCAhd2FsbGV0IHx8IGNvbm5lY3RpbmcgfHwgY29ubmVjdGVkLCBzdGFydEljb246IHdhbGxldCA/IFJlYWN0LmNyZWF0ZUVsZW1lbnQoV2FsbGV0SWNvbiwgeyB3YWxsZXQ6IHdhbGxldCB9KSA6IHVuZGVmaW5lZCwgb25DbGljazogaGFuZGxlQ2xpY2sgfSwgcHJvcHMpLCBjb250ZW50KSk7XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9V2FsbGV0Q29ubmVjdEJ1dHRvbi5qcy5tYXAiLCJ2YXIgX19yZXN0ID0gKHRoaXMgJiYgdGhpcy5fX3Jlc3QpIHx8IGZ1bmN0aW9uIChzLCBlKSB7XG4gICAgdmFyIHQgPSB7fTtcbiAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkgJiYgZS5pbmRleE9mKHApIDwgMClcbiAgICAgICAgdFtwXSA9IHNbcF07XG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxuICAgICAgICBmb3IgKHZhciBpID0gMCwgcCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMocyk7IGkgPCBwLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoZS5pbmRleE9mKHBbaV0pIDwgMCAmJiBPYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwocywgcFtpXSkpXG4gICAgICAgICAgICAgICAgdFtwW2ldXSA9IHNbcFtpXV07XG4gICAgICAgIH1cbiAgICByZXR1cm4gdDtcbn07XG5pbXBvcnQgeyB1c2VXYWxsZXQgfSBmcm9tICdAc29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0JztcbmltcG9ydCBSZWFjdCwgeyB1c2VDYWxsYmFjaywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4vQnV0dG9uJztcbmltcG9ydCB7IFdhbGxldEljb24gfSBmcm9tICcuL1dhbGxldEljb24nO1xuZXhwb3J0IGNvbnN0IFdhbGxldERpc2Nvbm5lY3RCdXR0b24gPSAoX2EpID0+IHtcbiAgICB2YXIgeyBjaGlsZHJlbiwgZGlzYWJsZWQsIG9uQ2xpY2sgfSA9IF9hLCBwcm9wcyA9IF9fcmVzdChfYSwgW1wiY2hpbGRyZW5cIiwgXCJkaXNhYmxlZFwiLCBcIm9uQ2xpY2tcIl0pO1xuICAgIGNvbnN0IHsgd2FsbGV0LCBkaXNjb25uZWN0LCBkaXNjb25uZWN0aW5nIH0gPSB1c2VXYWxsZXQoKTtcbiAgICBjb25zdCBoYW5kbGVDbGljayA9IHVzZUNhbGxiYWNrKChldmVudCkgPT4ge1xuICAgICAgICBpZiAob25DbGljaylcbiAgICAgICAgICAgIG9uQ2xpY2soZXZlbnQpO1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWVtcHR5LWZ1bmN0aW9uXG4gICAgICAgIGlmICghZXZlbnQuZGVmYXVsdFByZXZlbnRlZClcbiAgICAgICAgICAgIGRpc2Nvbm5lY3QoKS5jYXRjaCgoKSA9PiB7IH0pO1xuICAgIH0sIFtvbkNsaWNrLCBkaXNjb25uZWN0XSk7XG4gICAgY29uc3QgY29udGVudCA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoY2hpbGRyZW4pXG4gICAgICAgICAgICByZXR1cm4gY2hpbGRyZW47XG4gICAgICAgIGlmIChkaXNjb25uZWN0aW5nKVxuICAgICAgICAgICAgcmV0dXJuICdEaXNjb25uZWN0aW5nIC4uLic7XG4gICAgICAgIGlmICh3YWxsZXQpXG4gICAgICAgICAgICByZXR1cm4gJ0Rpc2Nvbm5lY3QnO1xuICAgICAgICByZXR1cm4gJ0Rpc2Nvbm5lY3QgV2FsbGV0JztcbiAgICB9LCBbY2hpbGRyZW4sIGRpc2Nvbm5lY3RpbmcsIHdhbGxldF0pO1xuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChCdXR0b24sIE9iamVjdC5hc3NpZ24oeyBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItYnV0dG9uLXRyaWdnZXJcIiwgZGlzYWJsZWQ6IGRpc2FibGVkIHx8ICF3YWxsZXQsIHN0YXJ0SWNvbjogd2FsbGV0ID8gUmVhY3QuY3JlYXRlRWxlbWVudChXYWxsZXRJY29uLCB7IHdhbGxldDogd2FsbGV0IH0pIDogdW5kZWZpbmVkLCBvbkNsaWNrOiBoYW5kbGVDbGljayB9LCBwcm9wcyksIGNvbnRlbnQpKTtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1XYWxsZXREaXNjb25uZWN0QnV0dG9uLmpzLm1hcCIsInZhciBfX3Jlc3QgPSAodGhpcyAmJiB0aGlzLl9fcmVzdCkgfHwgZnVuY3Rpb24gKHMsIGUpIHtcbiAgICB2YXIgdCA9IHt9O1xuICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxuICAgICAgICB0W3BdID0gc1twXTtcbiAgICBpZiAocyAhPSBudWxsICYmIHR5cGVvZiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzID09PSBcImZ1bmN0aW9uXCIpXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChlLmluZGV4T2YocFtpXSkgPCAwICYmIE9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChzLCBwW2ldKSlcbiAgICAgICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcbiAgICAgICAgfVxuICAgIHJldHVybiB0O1xufTtcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgV2FsbGV0SWNvbiA9IChfYSkgPT4ge1xuICAgIHZhciB7IHdhbGxldCB9ID0gX2EsIHByb3BzID0gX19yZXN0KF9hLCBbXCJ3YWxsZXRcIl0pO1xuICAgIHJldHVybiB3YWxsZXQgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChcImltZ1wiLCBPYmplY3QuYXNzaWduKHsgc3JjOiB3YWxsZXQuaWNvbiwgYWx0OiBgJHt3YWxsZXQubmFtZX0gaWNvbmAgfSwgcHJvcHMpKTtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1XYWxsZXRJY29uLmpzLm1hcCIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuL0J1dHRvbic7XG5pbXBvcnQgeyBXYWxsZXRJY29uIH0gZnJvbSAnLi9XYWxsZXRJY29uJztcbmV4cG9ydCBjb25zdCBXYWxsZXRMaXN0SXRlbSA9ICh7IGhhbmRsZUNsaWNrLCB0YWJJbmRleCwgd2FsbGV0IH0pID0+IHtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJsaVwiLCBudWxsLFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbiwgeyBvbkNsaWNrOiBoYW5kbGVDbGljaywgZW5kSWNvbjogUmVhY3QuY3JlYXRlRWxlbWVudChXYWxsZXRJY29uLCB7IHdhbGxldDogd2FsbGV0IH0pLCB0YWJJbmRleDogdGFiSW5kZXggfSwgd2FsbGV0Lm5hbWUpKSk7XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9V2FsbGV0TGlzdEl0ZW0uanMubWFwIiwiaW1wb3J0IHsgdXNlV2FsbGV0IH0gZnJvbSAnQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdCc7XG5pbXBvcnQgUmVhY3QsIHsgdXNlQ2FsbGJhY2ssIHVzZUxheW91dEVmZmVjdCwgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNyZWF0ZVBvcnRhbCB9IGZyb20gJ3JlYWN0LWRvbSc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuL0J1dHRvbic7XG5pbXBvcnQgeyBDb2xsYXBzZSB9IGZyb20gJy4vQ29sbGFwc2UnO1xuaW1wb3J0IHsgdXNlV2FsbGV0TW9kYWwgfSBmcm9tICcuL3VzZVdhbGxldE1vZGFsJztcbmltcG9ydCB7IFdhbGxldExpc3RJdGVtIH0gZnJvbSAnLi9XYWxsZXRMaXN0SXRlbSc7XG5leHBvcnQgY29uc3QgV2FsbGV0TW9kYWwgPSAoeyBjbGFzc05hbWUgPSAnJywgbG9nbywgZmVhdHVyZWRXYWxsZXRzID0gMywgY29udGFpbmVyID0gJ2JvZHknLCB9KSA9PiB7XG4gICAgY29uc3QgcmVmID0gdXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IHsgd2FsbGV0cywgc2VsZWN0IH0gPSB1c2VXYWxsZXQoKTtcbiAgICBjb25zdCB7IHNldFZpc2libGUgfSA9IHVzZVdhbGxldE1vZGFsKCk7XG4gICAgY29uc3QgW2V4cGFuZGVkLCBzZXRFeHBhbmRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2ZhZGVJbiwgc2V0RmFkZUluXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbcG9ydGFsLCBzZXRQb3J0YWxdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW2ZlYXR1cmVkLCBtb3JlXSA9IHVzZU1lbW8oKCkgPT4gW3dhbGxldHMuc2xpY2UoMCwgZmVhdHVyZWRXYWxsZXRzKSwgd2FsbGV0cy5zbGljZShmZWF0dXJlZFdhbGxldHMpXSwgW3dhbGxldHMsIGZlYXR1cmVkV2FsbGV0c10pO1xuICAgIGNvbnN0IGhpZGVNb2RhbCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICAgICAgc2V0RmFkZUluKGZhbHNlKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRWaXNpYmxlKGZhbHNlKSwgMTUwKTtcbiAgICB9LCBbc2V0RmFkZUluLCBzZXRWaXNpYmxlXSk7XG4gICAgY29uc3QgaGFuZGxlQ2xvc2UgPSB1c2VDYWxsYmFjaygoZXZlbnQpID0+IHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaGlkZU1vZGFsKCk7XG4gICAgfSwgW2hpZGVNb2RhbF0pO1xuICAgIGNvbnN0IGhhbmRsZVdhbGxldENsaWNrID0gdXNlQ2FsbGJhY2soKGV2ZW50LCB3YWxsZXROYW1lKSA9PiB7XG4gICAgICAgIHNlbGVjdCh3YWxsZXROYW1lKTtcbiAgICAgICAgaGFuZGxlQ2xvc2UoZXZlbnQpO1xuICAgIH0sIFtzZWxlY3QsIGhhbmRsZUNsb3NlXSk7XG4gICAgY29uc3QgaGFuZGxlQ29sbGFwc2VDbGljayA9IHVzZUNhbGxiYWNrKCgpID0+IHNldEV4cGFuZGVkKCFleHBhbmRlZCksIFtzZXRFeHBhbmRlZCwgZXhwYW5kZWRdKTtcbiAgICBjb25zdCBoYW5kbGVUYWJLZXkgPSB1c2VDYWxsYmFjaygoZXZlbnQpID0+IHtcbiAgICAgICAgY29uc3Qgbm9kZSA9IHJlZi5jdXJyZW50O1xuICAgICAgICBpZiAoIW5vZGUpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIC8vIGhlcmUgd2UgcXVlcnkgYWxsIGZvY3VzYWJsZSBlbGVtZW50c1xuICAgICAgICBjb25zdCBmb2N1c2FibGVFbGVtZW50cyA9IG5vZGUucXVlcnlTZWxlY3RvckFsbCgnYnV0dG9uJyk7XG4gICAgICAgIGNvbnN0IGZpcnN0RWxlbWVudCA9IGZvY3VzYWJsZUVsZW1lbnRzWzBdO1xuICAgICAgICBjb25zdCBsYXN0RWxlbWVudCA9IGZvY3VzYWJsZUVsZW1lbnRzW2ZvY3VzYWJsZUVsZW1lbnRzLmxlbmd0aCAtIDFdO1xuICAgICAgICBpZiAoZXZlbnQuc2hpZnRLZXkpIHtcbiAgICAgICAgICAgIC8vIGlmIGdvaW5nIGJhY2t3YXJkIGJ5IHByZXNzaW5nIHRhYiBhbmQgZmlyc3RFbGVtZW50IGlzIGFjdGl2ZSwgc2hpZnQgZm9jdXMgdG8gbGFzdCBmb2N1c2FibGUgZWxlbWVudFxuICAgICAgICAgICAgaWYgKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgPT09IGZpcnN0RWxlbWVudCkge1xuICAgICAgICAgICAgICAgIGxhc3RFbGVtZW50LmZvY3VzKCk7XG4gICAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIC8vIGlmIGdvaW5nIGZvcndhcmQgYnkgcHJlc3NpbmcgdGFiIGFuZCBsYXN0RWxlbWVudCBpcyBhY3RpdmUsIHNoaWZ0IGZvY3VzIHRvIGZpcnN0IGZvY3VzYWJsZSBlbGVtZW50XG4gICAgICAgICAgICBpZiAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA9PT0gbGFzdEVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICBmaXJzdEVsZW1lbnQuZm9jdXMoKTtcbiAgICAgICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW3JlZl0pO1xuICAgIHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgIGlmIChldmVudC5rZXkgPT09ICdFc2NhcGUnKSB7XG4gICAgICAgICAgICAgICAgaGlkZU1vZGFsKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChldmVudC5rZXkgPT09ICdUYWInKSB7XG4gICAgICAgICAgICAgICAgaGFuZGxlVGFiS2V5KGV2ZW50KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgLy8gR2V0IG9yaWdpbmFsIG92ZXJmbG93XG4gICAgICAgIGNvbnN0IHsgb3ZlcmZsb3cgfSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGRvY3VtZW50LmJvZHkpO1xuICAgICAgICAvLyBIYWNrIHRvIGVuYWJsZSBmYWRlIGluIGFuaW1hdGlvbiBhZnRlciBtb3VudFxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldEZhZGVJbih0cnVlKSwgMCk7XG4gICAgICAgIC8vIFByZXZlbnQgc2Nyb2xsaW5nIG9uIG1vdW50XG4gICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSAnaGlkZGVuJztcbiAgICAgICAgLy8gTGlzdGVuIGZvciBrZXlkb3duIGV2ZW50c1xuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24sIGZhbHNlKTtcbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIC8vIFJlLWVuYWJsZSBzY3JvbGxpbmcgd2hlbiBjb21wb25lbnQgdW5tb3VudHNcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSBvdmVyZmxvdztcbiAgICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93biwgZmFsc2UpO1xuICAgICAgICB9O1xuICAgIH0sIFtoaWRlTW9kYWwsIGhhbmRsZVRhYktleV0pO1xuICAgIHVzZUxheW91dEVmZmVjdCgoKSA9PiBzZXRQb3J0YWwoZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihjb250YWluZXIpKSwgW3NldFBvcnRhbCwgY29udGFpbmVyXSk7XG4gICAgcmV0dXJuIChwb3J0YWwgJiZcbiAgICAgICAgY3JlYXRlUG9ydGFsKFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBcImFyaWEtbGFiZWxsZWRieVwiOiBcIndhbGxldC1hZGFwdGVyLW1vZGFsLXRpdGxlXCIsIFwiYXJpYS1tb2RhbFwiOiBcInRydWVcIiwgY2xhc3NOYW1lOiBgd2FsbGV0LWFkYXB0ZXItbW9kYWwgJHtmYWRlSW4gJiYgJ3dhbGxldC1hZGFwdGVyLW1vZGFsLWZhZGUtaW4nfSAke2NsYXNzTmFtZX1gLCByZWY6IHJlZiwgcm9sZTogXCJkaWFsb2dcIiB9LFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogXCJ3YWxsZXQtYWRhcHRlci1tb2RhbC1jb250YWluZXJcIiB9LFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBjbGFzc05hbWU6IGB3YWxsZXQtYWRhcHRlci1tb2RhbC13cmFwcGVyICR7IWxvZ28gJiYgJ3dhbGxldC1hZGFwdGVyLW1vZGFsLXdyYXBwZXItbm8tbG9nbyd9YCB9LFxuICAgICAgICAgICAgICAgICAgICBsb2dvICYmIChSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLW1vZGFsLWxvZ28td3JhcHBlclwiIH0sIHR5cGVvZiBsb2dvID09PSAnc3RyaW5nJyA/IChSZWFjdC5jcmVhdGVFbGVtZW50KFwiaW1nXCIsIHsgYWx0OiBcImxvZ29cIiwgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLW1vZGFsLWxvZ29cIiwgc3JjOiBsb2dvIH0pKSA6IChsb2dvKSkpLFxuICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiaDFcIiwgeyBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItbW9kYWwtdGl0bGVcIiwgaWQ6IFwid2FsbGV0LWFkYXB0ZXItbW9kYWwtdGl0bGVcIiB9LCBcIkNvbm5lY3QgV2FsbGV0XCIpLFxuICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIsIHsgb25DbGljazogaGFuZGxlQ2xvc2UsIGNsYXNzTmFtZTogXCJ3YWxsZXQtYWRhcHRlci1tb2RhbC1idXR0b24tY2xvc2VcIiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcInN2Z1wiLCB7IHdpZHRoOiBcIjE0XCIsIGhlaWdodDogXCIxNFwiIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcInBhdGhcIiwgeyBkOiBcIk0xNCAxMi40NjEgOC4zIDYuNzcybDUuMjM0LTUuMjMzTDEyLjAwNiAwIDYuNzcyIDUuMjM0IDEuNTQgMCAwIDEuNTM5bDUuMjM0IDUuMjMzTDAgMTIuMDA2bDEuNTM5IDEuNTI4TDYuNzcyIDguM2w1LjY5IDUuN0wxNCAxMi40NjF6XCIgfSkpKSxcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcInVsXCIsIHsgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLW1vZGFsLWxpc3RcIiB9LCBmZWF0dXJlZC5tYXAoKHdhbGxldCkgPT4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoV2FsbGV0TGlzdEl0ZW0sIHsga2V5OiB3YWxsZXQubmFtZSwgaGFuZGxlQ2xpY2s6IChldmVudCkgPT4gaGFuZGxlV2FsbGV0Q2xpY2soZXZlbnQsIHdhbGxldC5uYW1lKSwgd2FsbGV0OiB3YWxsZXQgfSkpKSksXG4gICAgICAgICAgICAgICAgICAgIG1vcmUubGVuZ3RoID8gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KENvbGxhcHNlLCB7IGV4cGFuZGVkOiBleHBhbmRlZCwgaWQ6IFwid2FsbGV0LWFkYXB0ZXItbW9kYWwtY29sbGFwc2VcIiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJ1bFwiLCB7IGNsYXNzTmFtZTogXCJ3YWxsZXQtYWRhcHRlci1tb2RhbC1saXN0XCIgfSwgbW9yZS5tYXAoKHdhbGxldCkgPT4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoV2FsbGV0TGlzdEl0ZW0sIHsga2V5OiB3YWxsZXQubmFtZSwgaGFuZGxlQ2xpY2s6IChldmVudCkgPT4gaGFuZGxlV2FsbGV0Q2xpY2soZXZlbnQsIHdhbGxldC5uYW1lKSwgdGFiSW5kZXg6IGV4cGFuZGVkID8gMCA6IC0xLCB3YWxsZXQ6IHdhbGxldCB9KSkpKSksXG4gICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbiwgeyBcImFyaWEtY29udHJvbHNcIjogXCJ3YWxsZXQtYWRhcHRlci1tb2RhbC1jb2xsYXBzZVwiLCBcImFyaWEtZXhwYW5kZWRcIjogZXhwYW5kZWQsIGNsYXNzTmFtZTogYHdhbGxldC1hZGFwdGVyLW1vZGFsLWNvbGxhcHNlLWJ1dHRvbiAke2V4cGFuZGVkICYmICd3YWxsZXQtYWRhcHRlci1tb2RhbC1jb2xsYXBzZS1idXR0b24tYWN0aXZlJ31gLCBlbmRJY29uOiBSZWFjdC5jcmVhdGVFbGVtZW50KFwic3ZnXCIsIHsgd2lkdGg6IFwiMTFcIiwgaGVpZ2h0OiBcIjZcIiwgeG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwicGF0aFwiLCB7IGQ6IFwibTUuOTM4IDUuNzMgNC4yOC00LjEyNmEuOTE1LjkxNSAwIDAgMCAwLTEuMzIyIDEgMSAwIDAgMC0xLjM3MSAwTDUuMjUzIDMuNzM2IDEuNjU5LjI3MmExIDEgMCAwIDAtMS4zNzEgMEEuOTMuOTMgMCAwIDAgMCAuOTMyYzAgLjI0Ni4xLjQ4LjI4OC42NjJsNC4yOCA0LjEyNWEuOTkuOTkgMCAwIDAgMS4zNy4wMXpcIiB9KSksIG9uQ2xpY2s6IGhhbmRsZUNvbGxhcHNlQ2xpY2sgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBhbmRlZCA/ICdMZXNzJyA6ICdNb3JlJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIiBvcHRpb25zXCIpKSkgOiBudWxsKSksXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLW1vZGFsLW92ZXJsYXlcIiwgb25Nb3VzZURvd246IGhhbmRsZUNsb3NlIH0pKSwgcG9ydGFsKSk7XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9V2FsbGV0TW9kYWwuanMubWFwIiwidmFyIF9fcmVzdCA9ICh0aGlzICYmIHRoaXMuX19yZXN0KSB8fCBmdW5jdGlvbiAocywgZSkge1xuICAgIHZhciB0ID0ge307XG4gICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApICYmIGUuaW5kZXhPZihwKSA8IDApXG4gICAgICAgIHRbcF0gPSBzW3BdO1xuICAgIGlmIChzICE9IG51bGwgJiYgdHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgPT09IFwiZnVuY3Rpb25cIilcbiAgICAgICAgZm9yICh2YXIgaSA9IDAsIHAgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHMpOyBpIDwgcC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKGUuaW5kZXhPZihwW2ldKSA8IDAgJiYgT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKHMsIHBbaV0pKVxuICAgICAgICAgICAgICAgIHRbcFtpXV0gPSBzW3BbaV1dO1xuICAgICAgICB9XG4gICAgcmV0dXJuIHQ7XG59O1xuaW1wb3J0IFJlYWN0LCB7IHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi9CdXR0b24nO1xuaW1wb3J0IHsgdXNlV2FsbGV0TW9kYWwgfSBmcm9tICcuL3VzZVdhbGxldE1vZGFsJztcbmV4cG9ydCBjb25zdCBXYWxsZXRNb2RhbEJ1dHRvbiA9IChfYSkgPT4ge1xuICAgIHZhciB7IGNoaWxkcmVuID0gJ1NlbGVjdCBXYWxsZXQnLCBvbkNsaWNrIH0gPSBfYSwgcHJvcHMgPSBfX3Jlc3QoX2EsIFtcImNoaWxkcmVuXCIsIFwib25DbGlja1wiXSk7XG4gICAgY29uc3QgeyB2aXNpYmxlLCBzZXRWaXNpYmxlIH0gPSB1c2VXYWxsZXRNb2RhbCgpO1xuICAgIGNvbnN0IGhhbmRsZUNsaWNrID0gdXNlQ2FsbGJhY2soKGV2ZW50KSA9PiB7XG4gICAgICAgIGlmIChvbkNsaWNrKVxuICAgICAgICAgICAgb25DbGljayhldmVudCk7XG4gICAgICAgIGlmICghZXZlbnQuZGVmYXVsdFByZXZlbnRlZClcbiAgICAgICAgICAgIHNldFZpc2libGUoIXZpc2libGUpO1xuICAgIH0sIFtvbkNsaWNrLCBzZXRWaXNpYmxlLCB2aXNpYmxlXSk7XG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbiwgT2JqZWN0LmFzc2lnbih7IGNsYXNzTmFtZTogXCJ3YWxsZXQtYWRhcHRlci1idXR0b24tdHJpZ2dlclwiLCBvbkNsaWNrOiBoYW5kbGVDbGljayB9LCBwcm9wcyksIGNoaWxkcmVuKSk7XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9V2FsbGV0TW9kYWxCdXR0b24uanMubWFwIiwidmFyIF9fcmVzdCA9ICh0aGlzICYmIHRoaXMuX19yZXN0KSB8fCBmdW5jdGlvbiAocywgZSkge1xuICAgIHZhciB0ID0ge307XG4gICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApICYmIGUuaW5kZXhPZihwKSA8IDApXG4gICAgICAgIHRbcF0gPSBzW3BdO1xuICAgIGlmIChzICE9IG51bGwgJiYgdHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgPT09IFwiZnVuY3Rpb25cIilcbiAgICAgICAgZm9yICh2YXIgaSA9IDAsIHAgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHMpOyBpIDwgcC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKGUuaW5kZXhPZihwW2ldKSA8IDAgJiYgT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKHMsIHBbaV0pKVxuICAgICAgICAgICAgICAgIHRbcFtpXV0gPSBzW3BbaV1dO1xuICAgICAgICB9XG4gICAgcmV0dXJuIHQ7XG59O1xuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgV2FsbGV0TW9kYWxDb250ZXh0IH0gZnJvbSAnLi91c2VXYWxsZXRNb2RhbCc7XG5pbXBvcnQgeyBXYWxsZXRNb2RhbCB9IGZyb20gJy4vV2FsbGV0TW9kYWwnO1xuZXhwb3J0IGNvbnN0IFdhbGxldE1vZGFsUHJvdmlkZXIgPSAoX2EpID0+IHtcbiAgICB2YXIgeyBjaGlsZHJlbiB9ID0gX2EsIHByb3BzID0gX19yZXN0KF9hLCBbXCJjaGlsZHJlblwiXSk7XG4gICAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChXYWxsZXRNb2RhbENvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWU6IHtcbiAgICAgICAgICAgIHZpc2libGUsXG4gICAgICAgICAgICBzZXRWaXNpYmxlLFxuICAgICAgICB9IH0sXG4gICAgICAgIGNoaWxkcmVuLFxuICAgICAgICB2aXNpYmxlICYmIFJlYWN0LmNyZWF0ZUVsZW1lbnQoV2FsbGV0TW9kYWwsIE9iamVjdC5hc3NpZ24oe30sIHByb3BzKSkpKTtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1XYWxsZXRNb2RhbFByb3ZpZGVyLmpzLm1hcCIsInZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XG4gICAgfSk7XG59O1xudmFyIF9fcmVzdCA9ICh0aGlzICYmIHRoaXMuX19yZXN0KSB8fCBmdW5jdGlvbiAocywgZSkge1xuICAgIHZhciB0ID0ge307XG4gICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApICYmIGUuaW5kZXhPZihwKSA8IDApXG4gICAgICAgIHRbcF0gPSBzW3BdO1xuICAgIGlmIChzICE9IG51bGwgJiYgdHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgPT09IFwiZnVuY3Rpb25cIilcbiAgICAgICAgZm9yICh2YXIgaSA9IDAsIHAgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHMpOyBpIDwgcC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKGUuaW5kZXhPZihwW2ldKSA8IDAgJiYgT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKHMsIHBbaV0pKVxuICAgICAgICAgICAgICAgIHRbcFtpXV0gPSBzW3BbaV1dO1xuICAgICAgICB9XG4gICAgcmV0dXJuIHQ7XG59O1xuaW1wb3J0IHsgdXNlV2FsbGV0IH0gZnJvbSAnQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdCc7XG5pbXBvcnQgUmVhY3QsIHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4vQnV0dG9uJztcbmltcG9ydCB7IHVzZVdhbGxldE1vZGFsIH0gZnJvbSAnLi91c2VXYWxsZXRNb2RhbCc7XG5pbXBvcnQgeyBXYWxsZXRDb25uZWN0QnV0dG9uIH0gZnJvbSAnLi9XYWxsZXRDb25uZWN0QnV0dG9uJztcbmltcG9ydCB7IFdhbGxldEljb24gfSBmcm9tICcuL1dhbGxldEljb24nO1xuaW1wb3J0IHsgV2FsbGV0TW9kYWxCdXR0b24gfSBmcm9tICcuL1dhbGxldE1vZGFsQnV0dG9uJztcbmV4cG9ydCBjb25zdCBXYWxsZXRNdWx0aUJ1dHRvbiA9IChfYSkgPT4ge1xuICAgIHZhciB7IGNoaWxkcmVuIH0gPSBfYSwgcHJvcHMgPSBfX3Jlc3QoX2EsIFtcImNoaWxkcmVuXCJdKTtcbiAgICBjb25zdCB7IHB1YmxpY0tleSwgd2FsbGV0LCBkaXNjb25uZWN0IH0gPSB1c2VXYWxsZXQoKTtcbiAgICBjb25zdCB7IHNldFZpc2libGUgfSA9IHVzZVdhbGxldE1vZGFsKCk7XG4gICAgY29uc3QgW2NvcGllZCwgc2V0Q29waWVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbYWN0aXZlLCBzZXRBY3RpdmVdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IHJlZiA9IHVzZVJlZihudWxsKTtcbiAgICBjb25zdCBiYXNlNTggPSB1c2VNZW1vKCgpID0+IHB1YmxpY0tleSA9PT0gbnVsbCB8fCBwdWJsaWNLZXkgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHB1YmxpY0tleS50b0Jhc2U1OCgpLCBbcHVibGljS2V5XSk7XG4gICAgY29uc3QgY29udGVudCA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoY2hpbGRyZW4pXG4gICAgICAgICAgICByZXR1cm4gY2hpbGRyZW47XG4gICAgICAgIGlmICghd2FsbGV0IHx8ICFiYXNlNTgpXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgcmV0dXJuIGJhc2U1OC5zbGljZSgwLCA0KSArICcuLicgKyBiYXNlNTguc2xpY2UoLTQpO1xuICAgIH0sIFtjaGlsZHJlbiwgd2FsbGV0LCBiYXNlNThdKTtcbiAgICBjb25zdCBjb3B5QWRkcmVzcyA9IHVzZUNhbGxiYWNrKCgpID0+IF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICBpZiAoYmFzZTU4KSB7XG4gICAgICAgICAgICB5aWVsZCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChiYXNlNTgpO1xuICAgICAgICAgICAgc2V0Q29waWVkKHRydWUpO1xuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRDb3BpZWQoZmFsc2UpLCA0MDApO1xuICAgICAgICB9XG4gICAgfSksIFtiYXNlNThdKTtcbiAgICBjb25zdCBvcGVuRHJvcGRvd24gPSB1c2VDYWxsYmFjaygoKSA9PiBzZXRBY3RpdmUodHJ1ZSksIFtzZXRBY3RpdmVdKTtcbiAgICBjb25zdCBjbG9zZURyb3Bkb3duID0gdXNlQ2FsbGJhY2soKCkgPT4gc2V0QWN0aXZlKGZhbHNlKSwgW3NldEFjdGl2ZV0pO1xuICAgIGNvbnN0IG9wZW5Nb2RhbCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICAgICAgc2V0VmlzaWJsZSh0cnVlKTtcbiAgICAgICAgY2xvc2VEcm9wZG93bigpO1xuICAgIH0sIFtzZXRWaXNpYmxlLCBjbG9zZURyb3Bkb3duXSk7XG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgbGlzdGVuZXIgPSAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5vZGUgPSByZWYuY3VycmVudDtcbiAgICAgICAgICAgIC8vIERvIG5vdGhpbmcgaWYgY2xpY2tpbmcgZHJvcGRvd24gb3IgaXRzIGRlc2NlbmRhbnRzXG4gICAgICAgICAgICBpZiAoIW5vZGUgfHwgbm9kZS5jb250YWlucyhldmVudC50YXJnZXQpKVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIGNsb3NlRHJvcGRvd24oKTtcbiAgICAgICAgfTtcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgbGlzdGVuZXIpO1xuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCd0b3VjaHN0YXJ0JywgbGlzdGVuZXIpO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgbGlzdGVuZXIpO1xuICAgICAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigndG91Y2hzdGFydCcsIGxpc3RlbmVyKTtcbiAgICAgICAgfTtcbiAgICB9LCBbcmVmLCBjbG9zZURyb3Bkb3duXSk7XG4gICAgaWYgKCF3YWxsZXQpXG4gICAgICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFdhbGxldE1vZGFsQnV0dG9uLCBPYmplY3QuYXNzaWduKHt9LCBwcm9wcyksIGNoaWxkcmVuKTtcbiAgICBpZiAoIWJhc2U1OClcbiAgICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoV2FsbGV0Q29ubmVjdEJ1dHRvbiwgT2JqZWN0LmFzc2lnbih7fSwgcHJvcHMpLCBjaGlsZHJlbik7XG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLWRyb3Bkb3duXCIgfSxcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChCdXR0b24sIE9iamVjdC5hc3NpZ24oeyBcImFyaWEtZXhwYW5kZWRcIjogYWN0aXZlLCBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItYnV0dG9uLXRyaWdnZXJcIiwgc3R5bGU6IE9iamVjdC5hc3NpZ24oeyBwb2ludGVyRXZlbnRzOiBhY3RpdmUgPyAnbm9uZScgOiAnYXV0bycgfSwgcHJvcHMuc3R5bGUpLCBvbkNsaWNrOiBvcGVuRHJvcGRvd24sIHN0YXJ0SWNvbjogUmVhY3QuY3JlYXRlRWxlbWVudChXYWxsZXRJY29uLCB7IHdhbGxldDogd2FsbGV0IH0pIH0sIHByb3BzKSwgY29udGVudCksXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJ1bFwiLCB7IFwiYXJpYS1sYWJlbFwiOiBcImRyb3Bkb3duLWxpc3RcIiwgY2xhc3NOYW1lOiBgd2FsbGV0LWFkYXB0ZXItZHJvcGRvd24tbGlzdCAke2FjdGl2ZSAmJiAnd2FsbGV0LWFkYXB0ZXItZHJvcGRvd24tbGlzdC1hY3RpdmUnfWAsIHJlZjogcmVmLCByb2xlOiBcIm1lbnVcIiB9LFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImxpXCIsIHsgb25DbGljazogY29weUFkZHJlc3MsIGNsYXNzTmFtZTogXCJ3YWxsZXQtYWRhcHRlci1kcm9wZG93bi1saXN0LWl0ZW1cIiwgcm9sZTogXCJtZW51aXRlbVwiIH0sIGNvcGllZCA/ICdDb3BpZWQnIDogJ0NvcHkgYWRkcmVzcycpLFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImxpXCIsIHsgb25DbGljazogb3Blbk1vZGFsLCBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItZHJvcGRvd24tbGlzdC1pdGVtXCIsIHJvbGU6IFwibWVudWl0ZW1cIiB9LCBcIkNvbm5lY3QgYSBkaWZmZXJlbnQgd2FsbGV0XCIpLFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImxpXCIsIHsgb25DbGljazogZGlzY29ubmVjdCwgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLWRyb3Bkb3duLWxpc3QtaXRlbVwiLCByb2xlOiBcIm1lbnVpdGVtXCIgfSwgXCJEaXNjb25uZWN0XCIpKSkpO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVdhbGxldE11bHRpQnV0dG9uLmpzLm1hcCIsImV4cG9ydCAqIGZyb20gJy4vdXNlV2FsbGV0TW9kYWwnO1xuZXhwb3J0ICogZnJvbSAnLi9XYWxsZXRDb25uZWN0QnV0dG9uJztcbmV4cG9ydCAqIGZyb20gJy4vV2FsbGV0TW9kYWwnO1xuZXhwb3J0ICogZnJvbSAnLi9XYWxsZXRNb2RhbEJ1dHRvbic7XG5leHBvcnQgKiBmcm9tICcuL1dhbGxldE1vZGFsUHJvdmlkZXInO1xuZXhwb3J0ICogZnJvbSAnLi9XYWxsZXREaXNjb25uZWN0QnV0dG9uJztcbmV4cG9ydCAqIGZyb20gJy4vV2FsbGV0SWNvbic7XG5leHBvcnQgKiBmcm9tICcuL1dhbGxldE11bHRpQnV0dG9uJztcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNvbnRleHQgfSBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgV2FsbGV0TW9kYWxDb250ZXh0ID0gY3JlYXRlQ29udGV4dCh7fSk7XG5leHBvcnQgZnVuY3Rpb24gdXNlV2FsbGV0TW9kYWwoKSB7XG4gICAgcmV0dXJuIHVzZUNvbnRleHQoV2FsbGV0TW9kYWxDb250ZXh0KTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVdhbGxldE1vZGFsLmpzLm1hcCIsImltcG9ydCB7IENvbm5lY3Rpb24gfSBmcm9tICdAc29sYW5hL3dlYjMuanMnO1xuaW1wb3J0IFJlYWN0LCB7IHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBDb25uZWN0aW9uQ29udGV4dCB9IGZyb20gJy4vdXNlQ29ubmVjdGlvbic7XG5leHBvcnQgY29uc3QgQ29ubmVjdGlvblByb3ZpZGVyID0gKHsgY2hpbGRyZW4sIGVuZHBvaW50LCBjb25maWcgPSB7IGNvbW1pdG1lbnQ6ICdjb25maXJtZWQnIH0sIH0pID0+IHtcbiAgICBjb25zdCBjb25uZWN0aW9uID0gdXNlTWVtbygoKSA9PiBuZXcgQ29ubmVjdGlvbihlbmRwb2ludCwgY29uZmlnKSwgW2VuZHBvaW50LCBjb25maWddKTtcbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChDb25uZWN0aW9uQ29udGV4dC5Qcm92aWRlciwgeyB2YWx1ZTogeyBjb25uZWN0aW9uIH0gfSwgY2hpbGRyZW4pO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUNvbm5lY3Rpb25Qcm92aWRlci5qcy5tYXAiLCJ2YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICAgIH0pO1xufTtcbmltcG9ydCB7IFdhbGxldE5vdENvbm5lY3RlZEVycm9yLCBXYWxsZXROb3RSZWFkeUVycm9yLCB9IGZyb20gJ0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItYmFzZSc7XG5pbXBvcnQgUmVhY3QsIHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFdhbGxldE5vdFNlbGVjdGVkRXJyb3IgfSBmcm9tICcuL2Vycm9ycyc7XG5pbXBvcnQgeyB1c2VMb2NhbFN0b3JhZ2UgfSBmcm9tICcuL3VzZUxvY2FsU3RvcmFnZSc7XG5pbXBvcnQgeyBXYWxsZXRDb250ZXh0IH0gZnJvbSAnLi91c2VXYWxsZXQnO1xuY29uc3QgaW5pdGlhbFN0YXRlID0ge1xuICAgIHdhbGxldDogbnVsbCxcbiAgICBhZGFwdGVyOiBudWxsLFxuICAgIHJlYWR5OiBmYWxzZSxcbiAgICBwdWJsaWNLZXk6IG51bGwsXG4gICAgY29ubmVjdGVkOiBmYWxzZSxcbn07XG5leHBvcnQgY29uc3QgV2FsbGV0UHJvdmlkZXIgPSAoeyBjaGlsZHJlbiwgd2FsbGV0cywgYXV0b0Nvbm5lY3QgPSBmYWxzZSwgb25FcnJvcjogX29uRXJyb3IgPSAoZXJyb3IpID0+IGNvbnNvbGUuZXJyb3IoZXJyb3IpLCBsb2NhbFN0b3JhZ2VLZXkgPSAnd2FsbGV0TmFtZScsIH0pID0+IHtcbiAgICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VMb2NhbFN0b3JhZ2UobG9jYWxTdG9yYWdlS2V5LCBudWxsKTtcbiAgICBjb25zdCBbeyB3YWxsZXQsIGFkYXB0ZXIsIHJlYWR5LCBwdWJsaWNLZXksIGNvbm5lY3RlZCB9LCBzZXRTdGF0ZV0gPSB1c2VTdGF0ZShpbml0aWFsU3RhdGUpO1xuICAgIGNvbnN0IFtjb25uZWN0aW5nLCBzZXRDb25uZWN0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbZGlzY29ubmVjdGluZywgc2V0RGlzY29ubmVjdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgaXNDb25uZWN0aW5nID0gdXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCBpc0Rpc2Nvbm5lY3RpbmcgPSB1c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IGlzVW5sb2FkaW5nID0gdXNlUmVmKGZhbHNlKTtcbiAgICAvLyBNYXAgb2Ygd2FsbGV0IG5hbWVzIHRvIHdhbGxldHNcbiAgICBjb25zdCB3YWxsZXRzQnlOYW1lID0gdXNlTWVtbygoKSA9PiB3YWxsZXRzLnJlZHVjZSgod2FsbGV0c0J5TmFtZSwgd2FsbGV0KSA9PiB7XG4gICAgICAgIHdhbGxldHNCeU5hbWVbd2FsbGV0Lm5hbWVdID0gd2FsbGV0O1xuICAgICAgICByZXR1cm4gd2FsbGV0c0J5TmFtZTtcbiAgICB9LCB7fSksIFt3YWxsZXRzXSk7XG4gICAgLy8gV2hlbiB0aGUgc2VsZWN0ZWQgd2FsbGV0IGNoYW5nZXMsIGluaXRpYWxpemUgdGhlIHN0YXRlXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3Qgd2FsbGV0ID0gKG5hbWUgJiYgd2FsbGV0c0J5TmFtZVtuYW1lXSkgfHwgbnVsbDtcbiAgICAgICAgY29uc3QgYWRhcHRlciA9IHdhbGxldCAmJiB3YWxsZXQuYWRhcHRlcigpO1xuICAgICAgICBpZiAoYWRhcHRlcikge1xuICAgICAgICAgICAgY29uc3QgeyByZWFkeSwgcHVibGljS2V5LCBjb25uZWN0ZWQgfSA9IGFkYXB0ZXI7XG4gICAgICAgICAgICBzZXRTdGF0ZSh7IHdhbGxldCwgYWRhcHRlciwgY29ubmVjdGVkLCBwdWJsaWNLZXksIHJlYWR5IH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgc2V0U3RhdGUoaW5pdGlhbFN0YXRlKTtcbiAgICAgICAgfVxuICAgIH0sIFtuYW1lLCB3YWxsZXRzQnlOYW1lLCBzZXRTdGF0ZV0pO1xuICAgIC8vIElmIGF1dG9Db25uZWN0IGlzIGVuYWJsZWQsIHRyeSB0byBjb25uZWN0IHdoZW4gdGhlIGFkYXB0ZXIgY2hhbmdlcyBhbmQgaXMgcmVhZHlcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoaXNDb25uZWN0aW5nLmN1cnJlbnQgfHwgY29ubmVjdGluZyB8fCBjb25uZWN0ZWQgfHwgIWF1dG9Db25uZWN0IHx8ICFhZGFwdGVyIHx8ICFyZWFkeSlcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgICAgICAgICAgaXNDb25uZWN0aW5nLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHNldENvbm5lY3RpbmcodHJ1ZSk7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgeWllbGQgYWRhcHRlci5jb25uZWN0KCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAvLyBDbGVhciB0aGUgc2VsZWN0ZWQgd2FsbGV0XG4gICAgICAgICAgICAgICAgICAgIHNldE5hbWUobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIC8vIERvbid0IHRocm93IGVycm9yLCBidXQgb25FcnJvciB3aWxsIHN0aWxsIGJlIGNhbGxlZFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q29ubmVjdGluZyhmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIGlzQ29ubmVjdGluZy5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pKCk7XG4gICAgfSwgW2lzQ29ubmVjdGluZywgY29ubmVjdGluZywgY29ubmVjdGVkLCBhdXRvQ29ubmVjdCwgYWRhcHRlciwgcmVhZHksIHNldENvbm5lY3RpbmcsIHNldE5hbWVdKTtcbiAgICAvLyBJZiB0aGUgd2luZG93IGlzIGNsb3Npbmcgb3IgcmVsb2FkaW5nLCBpZ25vcmUgZGlzY29ubmVjdCBhbmQgZXJyb3IgZXZlbnRzIGZyb20gdGhlIGFkYXB0ZXJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBmdW5jdGlvbiBsaXN0ZW5lcigpIHtcbiAgICAgICAgICAgIGlzVW5sb2FkaW5nLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdiZWZvcmV1bmxvYWQnLCBsaXN0ZW5lcik7XG4gICAgICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignYmVmb3JldW5sb2FkJywgbGlzdGVuZXIpO1xuICAgIH0sIFtpc1VubG9hZGluZ10pO1xuICAgIC8vIFNlbGVjdCBhIHdhbGxldCBieSBuYW1lXG4gICAgY29uc3Qgc2VsZWN0ID0gdXNlQ2FsbGJhY2soKG5ld05hbWUpID0+IF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICBpZiAobmFtZSA9PT0gbmV3TmFtZSlcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgaWYgKGFkYXB0ZXIpXG4gICAgICAgICAgICB5aWVsZCBhZGFwdGVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgc2V0TmFtZShuZXdOYW1lKTtcbiAgICB9KSwgW25hbWUsIGFkYXB0ZXIsIHNldE5hbWVdKTtcbiAgICAvLyBIYW5kbGUgdGhlIGFkYXB0ZXIncyByZWFkeSBldmVudFxuICAgIGNvbnN0IG9uUmVhZHkgPSB1c2VDYWxsYmFjaygoKSA9PiBzZXRTdGF0ZSgoc3RhdGUpID0+IChPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHN0YXRlKSwgeyByZWFkeTogdHJ1ZSB9KSkpLCBbc2V0U3RhdGVdKTtcbiAgICAvLyBIYW5kbGUgdGhlIGFkYXB0ZXIncyBjb25uZWN0IGV2ZW50XG4gICAgY29uc3Qgb25Db25uZWN0ID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgICAgICBpZiAoIWFkYXB0ZXIpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIGNvbnN0IHsgY29ubmVjdGVkLCBwdWJsaWNLZXksIHJlYWR5IH0gPSBhZGFwdGVyO1xuICAgICAgICBzZXRTdGF0ZSgoc3RhdGUpID0+IChPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHN0YXRlKSwgeyBjb25uZWN0ZWQsXG4gICAgICAgICAgICBwdWJsaWNLZXksXG4gICAgICAgICAgICByZWFkeSB9KSkpO1xuICAgIH0sIFthZGFwdGVyLCBzZXRTdGF0ZV0pO1xuICAgIC8vIEhhbmRsZSB0aGUgYWRhcHRlcidzIGRpc2Nvbm5lY3QgZXZlbnRcbiAgICBjb25zdCBvbkRpc2Nvbm5lY3QgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICAgIC8vIENsZWFyIHRoZSBzZWxlY3RlZCB3YWxsZXQgdW5sZXNzIHRoZSB3aW5kb3cgaXMgdW5sb2FkaW5nXG4gICAgICAgIGlmICghaXNVbmxvYWRpbmcuY3VycmVudClcbiAgICAgICAgICAgIHNldE5hbWUobnVsbCk7XG4gICAgfSwgW2lzVW5sb2FkaW5nLCBzZXROYW1lXSk7XG4gICAgLy8gSGFuZGxlIHRoZSBhZGFwdGVyJ3MgZXJyb3IgZXZlbnQsIGFuZCBsb2NhbCBlcnJvcnNcbiAgICBjb25zdCBvbkVycm9yID0gdXNlQ2FsbGJhY2soKGVycm9yKSA9PiB7XG4gICAgICAgIC8vIENhbGwgdGhlIHByb3ZpZGVkIGVycm9yIGhhbmRsZXIgdW5sZXNzIHRoZSB3aW5kb3cgaXMgdW5sb2FkaW5nXG4gICAgICAgIGlmICghaXNVbmxvYWRpbmcuY3VycmVudClcbiAgICAgICAgICAgIF9vbkVycm9yKGVycm9yKTtcbiAgICAgICAgcmV0dXJuIGVycm9yO1xuICAgIH0sIFtpc1VubG9hZGluZywgX29uRXJyb3JdKTtcbiAgICAvLyBDb25uZWN0IHRoZSBhZGFwdGVyIHRvIHRoZSB3YWxsZXRcbiAgICBjb25zdCBjb25uZWN0ID0gdXNlQ2FsbGJhY2soKCkgPT4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgIGlmIChpc0Nvbm5lY3RpbmcuY3VycmVudCB8fCBjb25uZWN0aW5nIHx8IGRpc2Nvbm5lY3RpbmcgfHwgY29ubmVjdGVkKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBpZiAoIXdhbGxldCB8fCAhYWRhcHRlcilcbiAgICAgICAgICAgIHRocm93IG9uRXJyb3IobmV3IFdhbGxldE5vdFNlbGVjdGVkRXJyb3IoKSk7XG4gICAgICAgIGlmICghcmVhZHkpIHtcbiAgICAgICAgICAgIC8vIENsZWFyIHRoZSBzZWxlY3RlZCB3YWxsZXRcbiAgICAgICAgICAgIHNldE5hbWUobnVsbCk7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICB3aW5kb3cub3Blbih3YWxsZXQudXJsLCAnX2JsYW5rJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBvbkVycm9yKG5ldyBXYWxsZXROb3RSZWFkeUVycm9yKCkpO1xuICAgICAgICB9XG4gICAgICAgIGlzQ29ubmVjdGluZy5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgc2V0Q29ubmVjdGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHlpZWxkIGFkYXB0ZXIuY29ubmVjdCgpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgLy8gQ2xlYXIgdGhlIHNlbGVjdGVkIHdhbGxldFxuICAgICAgICAgICAgc2V0TmFtZShudWxsKTtcbiAgICAgICAgICAgIC8vIFJldGhyb3cgdGhlIGVycm9yLCBhbmQgb25FcnJvciB3aWxsIGFsc28gYmUgY2FsbGVkXG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldENvbm5lY3RpbmcoZmFsc2UpO1xuICAgICAgICAgICAgaXNDb25uZWN0aW5nLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0pLCBbaXNDb25uZWN0aW5nLCBjb25uZWN0aW5nLCBkaXNjb25uZWN0aW5nLCBjb25uZWN0ZWQsIHdhbGxldCwgYWRhcHRlciwgb25FcnJvciwgcmVhZHksIHNldENvbm5lY3RpbmcsIHNldE5hbWVdKTtcbiAgICAvLyBEaXNjb25uZWN0IHRoZSBhZGFwdGVyIGZyb20gdGhlIHdhbGxldFxuICAgIGNvbnN0IGRpc2Nvbm5lY3QgPSB1c2VDYWxsYmFjaygoKSA9PiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgaWYgKGlzRGlzY29ubmVjdGluZy5jdXJyZW50IHx8IGRpc2Nvbm5lY3RpbmcpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIGlmICghYWRhcHRlcilcbiAgICAgICAgICAgIHJldHVybiBzZXROYW1lKG51bGwpO1xuICAgICAgICBpc0Rpc2Nvbm5lY3RpbmcuY3VycmVudCA9IHRydWU7XG4gICAgICAgIHNldERpc2Nvbm5lY3RpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB5aWVsZCBhZGFwdGVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIC8vIENsZWFyIHRoZSBzZWxlY3RlZCB3YWxsZXRcbiAgICAgICAgICAgIHNldE5hbWUobnVsbCk7XG4gICAgICAgICAgICAvLyBSZXRocm93IHRoZSBlcnJvciwgYW5kIG9uRXJyb3Igd2lsbCBhbHNvIGJlIGNhbGxlZFxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICBzZXREaXNjb25uZWN0aW5nKGZhbHNlKTtcbiAgICAgICAgICAgIGlzRGlzY29ubmVjdGluZy5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9KSwgW2lzRGlzY29ubmVjdGluZywgZGlzY29ubmVjdGluZywgYWRhcHRlciwgc2V0RGlzY29ubmVjdGluZywgc2V0TmFtZV0pO1xuICAgIC8vIFNlbmQgYSB0cmFuc2FjdGlvbiB1c2luZyB0aGUgcHJvdmlkZWQgY29ubmVjdGlvblxuICAgIGNvbnN0IHNlbmRUcmFuc2FjdGlvbiA9IHVzZUNhbGxiYWNrKCh0cmFuc2FjdGlvbiwgY29ubmVjdGlvbiwgb3B0aW9ucykgPT4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgIGlmICghYWRhcHRlcilcbiAgICAgICAgICAgIHRocm93IG9uRXJyb3IobmV3IFdhbGxldE5vdFNlbGVjdGVkRXJyb3IoKSk7XG4gICAgICAgIGlmICghY29ubmVjdGVkKVxuICAgICAgICAgICAgdGhyb3cgb25FcnJvcihuZXcgV2FsbGV0Tm90Q29ubmVjdGVkRXJyb3IoKSk7XG4gICAgICAgIHJldHVybiB5aWVsZCBhZGFwdGVyLnNlbmRUcmFuc2FjdGlvbih0cmFuc2FjdGlvbiwgY29ubmVjdGlvbiwgb3B0aW9ucyk7XG4gICAgfSksIFthZGFwdGVyLCBvbkVycm9yLCBjb25uZWN0ZWRdKTtcbiAgICAvLyBTaWduIGEgdHJhbnNhY3Rpb24gaWYgdGhlIHdhbGxldCBzdXBwb3J0cyBpdFxuICAgIGNvbnN0IHNpZ25UcmFuc2FjdGlvbiA9IHVzZU1lbW8oKCkgPT4gYWRhcHRlciAmJiAnc2lnblRyYW5zYWN0aW9uJyBpbiBhZGFwdGVyXG4gICAgICAgID8gKHRyYW5zYWN0aW9uKSA9PiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgICAgIGlmICghY29ubmVjdGVkKVxuICAgICAgICAgICAgICAgIHRocm93IG9uRXJyb3IobmV3IFdhbGxldE5vdENvbm5lY3RlZEVycm9yKCkpO1xuICAgICAgICAgICAgcmV0dXJuIHlpZWxkIGFkYXB0ZXIuc2lnblRyYW5zYWN0aW9uKHRyYW5zYWN0aW9uKTtcbiAgICAgICAgfSlcbiAgICAgICAgOiB1bmRlZmluZWQsIFthZGFwdGVyLCBvbkVycm9yLCBjb25uZWN0ZWRdKTtcbiAgICAvLyBTaWduIG11bHRpcGxlIHRyYW5zYWN0aW9ucyBpZiB0aGUgd2FsbGV0IHN1cHBvcnRzIGl0XG4gICAgY29uc3Qgc2lnbkFsbFRyYW5zYWN0aW9ucyA9IHVzZU1lbW8oKCkgPT4gYWRhcHRlciAmJiAnc2lnbkFsbFRyYW5zYWN0aW9ucycgaW4gYWRhcHRlclxuICAgICAgICA/ICh0cmFuc2FjdGlvbnMpID0+IF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICAgICAgaWYgKCFjb25uZWN0ZWQpXG4gICAgICAgICAgICAgICAgdGhyb3cgb25FcnJvcihuZXcgV2FsbGV0Tm90Q29ubmVjdGVkRXJyb3IoKSk7XG4gICAgICAgICAgICByZXR1cm4geWllbGQgYWRhcHRlci5zaWduQWxsVHJhbnNhY3Rpb25zKHRyYW5zYWN0aW9ucyk7XG4gICAgICAgIH0pXG4gICAgICAgIDogdW5kZWZpbmVkLCBbYWRhcHRlciwgb25FcnJvciwgY29ubmVjdGVkXSk7XG4gICAgLy8gU2lnbiBhbiBhcmJpdHJhcnkgbWVzc2FnZSBpZiB0aGUgd2FsbGV0IHN1cHBvcnRzIGl0XG4gICAgY29uc3Qgc2lnbk1lc3NhZ2UgPSB1c2VNZW1vKCgpID0+IGFkYXB0ZXIgJiYgJ3NpZ25NZXNzYWdlJyBpbiBhZGFwdGVyXG4gICAgICAgID8gKG1lc3NhZ2UpID0+IF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICAgICAgaWYgKCFjb25uZWN0ZWQpXG4gICAgICAgICAgICAgICAgdGhyb3cgb25FcnJvcihuZXcgV2FsbGV0Tm90Q29ubmVjdGVkRXJyb3IoKSk7XG4gICAgICAgICAgICByZXR1cm4geWllbGQgYWRhcHRlci5zaWduTWVzc2FnZShtZXNzYWdlKTtcbiAgICAgICAgfSlcbiAgICAgICAgOiB1bmRlZmluZWQsIFthZGFwdGVyLCBvbkVycm9yLCBjb25uZWN0ZWRdKTtcbiAgICAvLyBTZXR1cCBhbmQgdGVhcmRvd24gZXZlbnQgbGlzdGVuZXJzIHdoZW4gdGhlIGFkYXB0ZXIgY2hhbmdlc1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChhZGFwdGVyKSB7XG4gICAgICAgICAgICBhZGFwdGVyLm9uKCdyZWFkeScsIG9uUmVhZHkpO1xuICAgICAgICAgICAgYWRhcHRlci5vbignY29ubmVjdCcsIG9uQ29ubmVjdCk7XG4gICAgICAgICAgICBhZGFwdGVyLm9uKCdkaXNjb25uZWN0Jywgb25EaXNjb25uZWN0KTtcbiAgICAgICAgICAgIGFkYXB0ZXIub24oJ2Vycm9yJywgb25FcnJvcik7XG4gICAgICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgICAgIGFkYXB0ZXIub2ZmKCdyZWFkeScsIG9uUmVhZHkpO1xuICAgICAgICAgICAgICAgIGFkYXB0ZXIub2ZmKCdjb25uZWN0Jywgb25Db25uZWN0KTtcbiAgICAgICAgICAgICAgICBhZGFwdGVyLm9mZignZGlzY29ubmVjdCcsIG9uRGlzY29ubmVjdCk7XG4gICAgICAgICAgICAgICAgYWRhcHRlci5vZmYoJ2Vycm9yJywgb25FcnJvcik7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgfSwgW2FkYXB0ZXIsIG9uUmVhZHksIG9uQ29ubmVjdCwgb25EaXNjb25uZWN0LCBvbkVycm9yXSk7XG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KFdhbGxldENvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWU6IHtcbiAgICAgICAgICAgIHdhbGxldHMsXG4gICAgICAgICAgICBhdXRvQ29ubmVjdCxcbiAgICAgICAgICAgIHdhbGxldCxcbiAgICAgICAgICAgIGFkYXB0ZXIsXG4gICAgICAgICAgICBwdWJsaWNLZXksXG4gICAgICAgICAgICByZWFkeSxcbiAgICAgICAgICAgIGNvbm5lY3RlZCxcbiAgICAgICAgICAgIGNvbm5lY3RpbmcsXG4gICAgICAgICAgICBkaXNjb25uZWN0aW5nLFxuICAgICAgICAgICAgc2VsZWN0LFxuICAgICAgICAgICAgY29ubmVjdCxcbiAgICAgICAgICAgIGRpc2Nvbm5lY3QsXG4gICAgICAgICAgICBzZW5kVHJhbnNhY3Rpb24sXG4gICAgICAgICAgICBzaWduVHJhbnNhY3Rpb24sXG4gICAgICAgICAgICBzaWduQWxsVHJhbnNhY3Rpb25zLFxuICAgICAgICAgICAgc2lnbk1lc3NhZ2UsXG4gICAgICAgIH0gfSwgY2hpbGRyZW4pKTtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1XYWxsZXRQcm92aWRlci5qcy5tYXAiLCJpbXBvcnQgeyBXYWxsZXRFcnJvciB9IGZyb20gJ0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItYmFzZSc7XG5leHBvcnQgY2xhc3MgV2FsbGV0Tm90U2VsZWN0ZWRFcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldE5vdFNlbGVjdGVkRXJyb3InO1xuICAgIH1cbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVycm9ycy5qcy5tYXAiLCJleHBvcnQgKiBmcm9tICcuL0Nvbm5lY3Rpb25Qcm92aWRlcic7XG5leHBvcnQgKiBmcm9tICcuL2Vycm9ycyc7XG5leHBvcnQgKiBmcm9tICcuL3VzZUFuY2hvcldhbGxldCc7XG5leHBvcnQgKiBmcm9tICcuL3VzZUNvbm5lY3Rpb24nO1xuZXhwb3J0ICogZnJvbSAnLi91c2VMb2NhbFN0b3JhZ2UnO1xuZXhwb3J0ICogZnJvbSAnLi91c2VXYWxsZXQnO1xuZXhwb3J0ICogZnJvbSAnLi9XYWxsZXRQcm92aWRlcic7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJpbXBvcnQgeyB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlV2FsbGV0IH0gZnJvbSAnLi91c2VXYWxsZXQnO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUFuY2hvcldhbGxldCgpIHtcbiAgICBjb25zdCB7IHB1YmxpY0tleSwgc2lnblRyYW5zYWN0aW9uLCBzaWduQWxsVHJhbnNhY3Rpb25zIH0gPSB1c2VXYWxsZXQoKTtcbiAgICByZXR1cm4gdXNlTWVtbygoKSA9PiBwdWJsaWNLZXkgJiYgc2lnblRyYW5zYWN0aW9uICYmIHNpZ25BbGxUcmFuc2FjdGlvbnNcbiAgICAgICAgPyB7IHB1YmxpY0tleSwgc2lnblRyYW5zYWN0aW9uLCBzaWduQWxsVHJhbnNhY3Rpb25zIH1cbiAgICAgICAgOiB1bmRlZmluZWQsIFtwdWJsaWNLZXksIHNpZ25UcmFuc2FjdGlvbiwgc2lnbkFsbFRyYW5zYWN0aW9uc10pO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlQW5jaG9yV2FsbGV0LmpzLm1hcCIsImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNvbnRleHQgfSBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgQ29ubmVjdGlvbkNvbnRleHQgPSBjcmVhdGVDb250ZXh0KHt9KTtcbmV4cG9ydCBmdW5jdGlvbiB1c2VDb25uZWN0aW9uKCkge1xuICAgIHJldHVybiB1c2VDb250ZXh0KENvbm5lY3Rpb25Db250ZXh0KTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUNvbm5lY3Rpb24uanMubWFwIiwiaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUxvY2FsU3RvcmFnZShrZXksIGRlZmF1bHRTdGF0ZSkge1xuICAgIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gdXNlU3RhdGUoKCkgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIGxvY2FsU3RvcmFnZSA9PT0gJ3VuZGVmaW5lZCcpXG4gICAgICAgICAgICByZXR1cm4gZGVmYXVsdFN0YXRlO1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWUgPyBKU09OLnBhcnNlKHZhbHVlKSA6IGRlZmF1bHRTdGF0ZTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihlcnJvcik7XG4gICAgICAgICAgICByZXR1cm4gZGVmYXVsdFN0YXRlO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgY29uc3Qgc2V0TG9jYWxTdG9yYWdlID0gdXNlQ2FsbGJhY2soKG5ld1ZhbHVlKSA9PiB7XG4gICAgICAgIGlmIChuZXdWYWx1ZSA9PT0gdmFsdWUpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIHNldFZhbHVlKG5ld1ZhbHVlKTtcbiAgICAgICAgaWYgKG5ld1ZhbHVlID09PSBudWxsKSB7XG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShrZXkpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShrZXksIEpTT04uc3RyaW5naWZ5KG5ld1ZhbHVlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sIFt2YWx1ZSwgc2V0VmFsdWUsIGtleV0pO1xuICAgIHJldHVybiBbdmFsdWUsIHNldExvY2FsU3RvcmFnZV07XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VMb2NhbFN0b3JhZ2UuanMubWFwIiwiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCB9IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBXYWxsZXRDb250ZXh0ID0gY3JlYXRlQ29udGV4dCh7fSk7XG5leHBvcnQgZnVuY3Rpb24gdXNlV2FsbGV0KCkge1xuICAgIHJldHVybiB1c2VDb250ZXh0KFdhbGxldENvbnRleHQpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlV2FsbGV0LmpzLm1hcCIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9kaXN0L2NsaWVudC9saW5rJylcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtZXRhcGxleC9qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAcHJvamVjdC1zZXJ1bS9hbmNob3JcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQHNvbGFuYS9zcGwtdG9rZW5cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQHNvbGFuYS93ZWIzLmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImV2ZW50ZW1pdHRlcjNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NlcnZlci9kZW5vcm1hbGl6ZS1wYWdlLXBhdGguanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvaTE4bi9ub3JtYWxpemUtbG9jYWxlLXBhdGguanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvbWl0dC5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXItY29udGV4dC5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvZ2V0LWFzc2V0LXBhdGgtZnJvbS1yb3V0ZS5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvaXMtZHluYW1pYy5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvcGFyc2UtcmVsYXRpdmUtdXJsLmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci91dGlscy9xdWVyeXN0cmluZy5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvcm91dGUtbWF0Y2hlci5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvcm91dGUtcmVnZXguanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvdXRpbHMuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtZG9tXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LWlzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LXJlZHV4XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LXNsaWNrXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdHN0cmFwXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlY2hhcnRzXCIpOyIsIi8qIChpZ25vcmVkKSAqLyJdLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwiZ2V0TkZUc0Zvck93bmVyIiwidXNlV2FsbGV0IiwidXNlV2FsbGV0TmZ0cyIsInVzZURpc3BhdGNoIiwiQ29ubmVjdFRvV2FsbGV0IiwicHJvcHMiLCJkaXNwYXRjaCIsInJwY1VybCIsInJwY0hvc3QiLCJ3YWxsZXQiLCJpc0xvYWRpbmciLCJuZnRzIiwiaXNTUExFeGlzdHMiLCJhbmNob3JXYWxsZXQiLCJwdWJsaWNLZXkiLCJzaWduQWxsVHJhbnNhY3Rpb25zIiwic2lnblRyYW5zYWN0aW9uIiwiY29uc29sZSIsImxvZyIsInR5cGUiLCJwYXlsb2FkIiwidG9TdHJpbmciLCJjb25uZWN0aW9uIiwibmZ0c0Zvck93bmVyIiwiY2FuZHlNYWNoaW5lSWQiLCJSZWFjdCIsIkxpbmVDaGFydCIsIkxpbmUiLCJYQXhpcyIsIllBeGlzIiwiQ2FydGVzaWFuR3JpZCIsIlRvb2x0aXAiLCJMZWdlbmQiLCJSZXNwb25zaXZlQ29udGFpbmVyIiwiQXJlYUNoYXJ0IiwiQXJlYSIsImRhdGEiLCJuYW1lIiwiYXZlcmFnZSIsImZsb29yIiwiZGFya1RoZW1lIiwiYmFja2dyb3VuZENvbG9yIiwiY29sb3IiLCJnZXRUb29sdGlwU3R5bGVzIiwiY29udGVudFN0eWxlIiwiaXRlbVN0eWxlIiwiTGluZUNoYXJ0eCIsInRvcCIsImxlZnQiLCJib3R0b20iLCJXYWxsZXRNdWx0aUJ1dHRvbiIsIk5vdENvbm5lY3RlZCIsIlBpZSIsIlBpZUNoYXJ0IiwiZGF0YTAxIiwidmFsdWUiLCJmaWxsIiwiZGF0YTAyIiwiU3Rha2luZ0NhcmQiLCJTdGF0cyIsIlByb2dyZXNzIiwiVG9rZW5DYXJkIiwiTmF2YmFyIiwiTkZUQ2Fyb3VzZWwiLCJEYXNoYm9hcmQiLCJzZW5kVHJhbnNhY3Rpb24iLCJORlQiLCJpbWciLCJ1c2VTZWxlY3RvciIsIlNsaWRlciIsInVzZXIiLCJ3YWxsZXRfaWQiLCJuZnRfbGlzdCIsInN0YXRlIiwiYXBwX3JlZHVjZXIiLCJzZXR0aW5ncyIsImRvdHMiLCJpbmZpbml0ZSIsInNwZWVkIiwiYXV0b3BsYXkiLCJzd2lwZVRvU2xpZGUiLCJzbGlkZXNUb1Njcm9sbCIsInJlc3BvbnNpdmUiLCJicmVha3BvaW50Iiwic2xpZGVzVG9TaG93IiwibWFwIiwiaXRlbSIsIndpZHRoIiwiaW1hZ2UiLCJMaW5rIiwidXNlQ29ubmVjdGlvbiIsInVzZVN0YXRlIiwiYW5jaG9yIiwiZXhpc3RzT3duZXJTUExUb2tlbiIsInByb2Nlc3MiLCJlbnYiLCJORVhUX1BVQkxJQ19TT0xBTkFfUlBDX0hPU1QiLCJ3ZWIzIiwiQ29ubmVjdGlvbiIsInNldElzTG9hZGluZyIsInNldFNQTEV4aXN0cyIsInNldE5mdHMiLCJpc0V4aXN0U1BMVG9rZW4iLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImV4cG9ydHMiLCJkZWZhdWx0IiwiX3JlYWN0IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsInJlcXVpcmUiLCJfcm91dGVyIiwiX3JvdXRlcjEiLCJfdXNlSW50ZXJzZWN0aW9uIiwib2JqIiwiX19lc01vZHVsZSIsInByZWZldGNoZWQiLCJwcmVmZXRjaCIsInJvdXRlciIsImhyZWYiLCJhcyIsIm9wdGlvbnMiLCJpc0xvY2FsVVJMIiwiY2F0Y2giLCJlcnIiLCJjdXJMb2NhbGUiLCJsb2NhbGUiLCJpc01vZGlmaWVkRXZlbnQiLCJldmVudCIsInRhcmdldCIsImN1cnJlbnRUYXJnZXQiLCJtZXRhS2V5IiwiY3RybEtleSIsInNoaWZ0S2V5IiwiYWx0S2V5IiwibmF0aXZlRXZlbnQiLCJ3aGljaCIsImxpbmtDbGlja2VkIiwiZSIsInJlcGxhY2UiLCJzaGFsbG93Iiwic2Nyb2xsIiwibm9kZU5hbWUiLCJwcmV2ZW50RGVmYXVsdCIsImluZGV4T2YiLCJjcmVhdGVQcm9wRXJyb3IiLCJhcmdzIiwiRXJyb3IiLCJrZXkiLCJleHBlY3RlZCIsImFjdHVhbCIsInJlcXVpcmVkUHJvcHNHdWFyZCIsInJlcXVpcmVkUHJvcHMiLCJrZXlzIiwiZm9yRWFjaCIsIl8iLCJvcHRpb25hbFByb3BzR3VhcmQiLCJwYXNzSHJlZiIsIm9wdGlvbmFsUHJvcHMiLCJ2YWxUeXBlIiwiaGFzV2FybmVkIiwidXNlUmVmIiwiY3VycmVudCIsIndhcm4iLCJwIiwidXNlUm91dGVyIiwicmVzb2x2ZWRIcmVmIiwicmVzb2x2ZWRBcyIsInJlc29sdmVIcmVmIiwiY2hpbGRyZW4iLCJjcmVhdGVFbGVtZW50IiwiY2hpbGQiLCJDaGlsZHJlbiIsIm9ubHkiLCJjaGlsZFJlZiIsInJlZiIsInNldEludGVyc2VjdGlvblJlZiIsImlzVmlzaWJsZSIsInVzZUludGVyc2VjdGlvbiIsInJvb3RNYXJnaW4iLCJzZXRSZWYiLCJ1c2VDYWxsYmFjayIsImVsIiwic2hvdWxkUHJlZmV0Y2giLCJpc1ByZWZldGNoZWQiLCJjaGlsZFByb3BzIiwib25DbGljayIsImRlZmF1bHRQcmV2ZW50ZWQiLCJvbk1vdXNlRW50ZXIiLCJwcmlvcml0eSIsImxvY2FsZURvbWFpbiIsImlzTG9jYWxlRG9tYWluIiwiZ2V0RG9tYWluTG9jYWxlIiwibG9jYWxlcyIsImRvbWFpbkxvY2FsZXMiLCJhZGRCYXNlUGF0aCIsImFkZExvY2FsZSIsImRlZmF1bHRMb2NhbGUiLCJjbG9uZUVsZW1lbnQiLCJfZGVmYXVsdCIsInJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoIiwibm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2giLCJwYXRoIiwiZW5kc1dpdGgiLCJzbGljZSIsIl9fTkVYVF9UUkFJTElOR19TTEFTSCIsInRlc3QiLCJyZXF1ZXN0SWRsZUNhbGxiYWNrIiwiY2FuY2VsSWRsZUNhbGxiYWNrIiwic2VsZiIsImJpbmQiLCJ3aW5kb3ciLCJjYiIsInN0YXJ0IiwiRGF0ZSIsIm5vdyIsInNldFRpbWVvdXQiLCJkaWRUaW1lb3V0IiwidGltZVJlbWFpbmluZyIsIk1hdGgiLCJtYXgiLCJpZCIsImNsZWFyVGltZW91dCIsIm1hcmtBc3NldEVycm9yIiwiaXNBc3NldEVycm9yIiwiZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCIsImNyZWF0ZVJvdXRlTG9hZGVyIiwiX2dldEFzc2V0UGF0aEZyb21Sb3V0ZSIsIl9yZXF1ZXN0SWRsZUNhbGxiYWNrIiwiTVNfTUFYX0lETEVfREVMQVkiLCJ3aXRoRnV0dXJlIiwiZ2VuZXJhdG9yIiwiZW50cnkiLCJnZXQiLCJmdXR1cmUiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlc29sdmVyIiwicHJvbSIsInNldCIsInRoZW4iLCJoYXNQcmVmZXRjaCIsImxpbmsiLCJkb2N1bWVudCIsIk1TSW5wdXRNZXRob2RDb250ZXh0IiwiZG9jdW1lbnRNb2RlIiwicmVsTGlzdCIsInN1cHBvcnRzIiwiY2FuUHJlZmV0Y2giLCJwcmVmZXRjaFZpYURvbSIsInJlcyIsInJlaiIsInF1ZXJ5U2VsZWN0b3IiLCJyZWwiLCJjcm9zc09yaWdpbiIsIl9fTkVYVF9DUk9TU19PUklHSU4iLCJvbmxvYWQiLCJvbmVycm9yIiwiaGVhZCIsImFwcGVuZENoaWxkIiwiQVNTRVRfTE9BRF9FUlJPUiIsIlN5bWJvbCIsImFwcGVuZFNjcmlwdCIsInNyYyIsInNjcmlwdCIsInJlamVjdCIsImJvZHkiLCJkZXZCdWlsZFByb21pc2UiLCJyZXNvbHZlUHJvbWlzZVdpdGhUaW1lb3V0IiwibXMiLCJjYW5jZWxsZWQiLCJyIiwiX19CVUlMRF9NQU5JRkVTVCIsIm9uQnVpbGRNYW5pZmVzdCIsIl9fQlVJTERfTUFOSUZFU1RfQ0IiLCJnZXRGaWxlc0ZvclJvdXRlIiwiYXNzZXRQcmVmaXgiLCJyb3V0ZSIsInNjcmlwdHMiLCJlbmNvZGVVUkkiLCJjc3MiLCJtYW5pZmVzdCIsImFsbEZpbGVzIiwiZmlsdGVyIiwidiIsImVudHJ5cG9pbnRzIiwiTWFwIiwibG9hZGVkU2NyaXB0cyIsInN0eWxlU2hlZXRzIiwicm91dGVzIiwibWF5YmVFeGVjdXRlU2NyaXB0IiwiZmV0Y2hTdHlsZVNoZWV0IiwiZmV0Y2giLCJvayIsInRleHQiLCJjb250ZW50Iiwid2hlbkVudHJ5cG9pbnQiLCJvbkVudHJ5cG9pbnQiLCJleGVjdXRlIiwiZm4iLCJjb21wb25lbnQiLCJlcnJvciIsImlucHV0Iiwib2xkIiwibG9hZFJvdXRlIiwicm91dGVGaWxlc1Byb21pc2UiLCJhbGwiLCJoYXMiLCJlbnRyeXBvaW50Iiwic3R5bGVzIiwiZmluYWxseSIsImFzc2lnbiIsImNuIiwibmF2aWdhdG9yIiwic2F2ZURhdGEiLCJlZmZlY3RpdmVUeXBlIiwib3V0cHV0IiwiZW51bWVyYWJsZSIsIl93aXRoUm91dGVyIiwiY3JlYXRlUm91dGVyIiwibWFrZVB1YmxpY1JvdXRlckluc3RhbmNlIiwiX3JvdXRlckNvbnRleHQiLCJzaW5nbGV0b25Sb3V0ZXIiLCJyZWFkeUNhbGxiYWNrcyIsInJlYWR5IiwicHVzaCIsInVybFByb3BlcnR5RmllbGRzIiwicm91dGVyRXZlbnRzIiwiY29yZU1ldGhvZEZpZWxkcyIsImV2ZW50cyIsImZpZWxkIiwiZ2V0Um91dGVyIiwib24iLCJldmVudEZpZWxkIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJzdWJzdHJpbmciLCJfc2luZ2xldG9uUm91dGVyIiwibWVzc2FnZSIsInN0YWNrIiwidXNlQ29udGV4dCIsIlJvdXRlckNvbnRleHQiLCJpbnN0YW5jZSIsInByb3BlcnR5IiwiQXJyYXkiLCJpc0FycmF5IiwiaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIiLCJJbnRlcnNlY3Rpb25PYnNlcnZlciIsImRpc2FibGVkIiwiaXNEaXNhYmxlZCIsInVub2JzZXJ2ZSIsInZpc2libGUiLCJzZXRWaXNpYmxlIiwidW5kZWZpbmVkIiwidGFnTmFtZSIsIm9ic2VydmUiLCJpZGxlQ2FsbGJhY2siLCJlbGVtZW50IiwiY2FsbGJhY2siLCJvYnNlcnZlciIsImVsZW1lbnRzIiwiY3JlYXRlT2JzZXJ2ZXIiLCJkZWxldGUiLCJzaXplIiwiZGlzY29ubmVjdCIsIm9ic2VydmVycyIsImVudHJpZXMiLCJpc0ludGVyc2VjdGluZyIsImludGVyc2VjdGlvblJhdGlvIiwid2l0aFJvdXRlciIsIkNvbXBvc2VkQ29tcG9uZW50IiwiV2l0aFJvdXRlcldyYXBwZXIiLCJnZXRJbml0aWFsUHJvcHMiLCJvcmlnR2V0SW5pdGlhbFByb3BzIiwiZGlzcGxheU5hbWUiLCJkZWxMb2NhbGUiLCJoYXNCYXNlUGF0aCIsImRlbEJhc2VQYXRoIiwiaW50ZXJwb2xhdGVBcyIsIl9ub3JtYWxpemVUcmFpbGluZ1NsYXNoIiwiX3JvdXRlTG9hZGVyIiwiX2Rlbm9ybWFsaXplUGFnZVBhdGgiLCJfbm9ybWFsaXplTG9jYWxlUGF0aCIsIl9taXR0IiwiX3V0aWxzIiwiX2lzRHluYW1pYyIsIl9wYXJzZVJlbGF0aXZlVXJsIiwiX3F1ZXJ5c3RyaW5nIiwiX3Jlc29sdmVSZXdyaXRlcyIsIl9yb3V0ZU1hdGNoZXIiLCJfcm91dGVSZWdleCIsImRldGVjdERvbWFpbkxvY2FsZSIsIl9fTkVYVF9JMThOX1NVUFBPUlQiLCJiYXNlUGF0aCIsIl9fTkVYVF9ST1VURVJfQkFTRVBBVEgiLCJidWlsZENhbmNlbGxhdGlvbkVycm9yIiwiYWRkUGF0aFByZWZpeCIsInByZWZpeCIsInN0YXJ0c1dpdGgiLCJwYXRoTm9RdWVyeUhhc2giLCJub3JtYWxpemVMb2NhbGVQYXRoIiwiZGV0ZWN0ZWRMb2NhbGUiLCJkZXRlY3RlZERvbWFpbiIsImh0dHAiLCJkb21haW4iLCJwYXRobmFtZSIsInBhdGhMb3dlciIsInRvTG93ZXJDYXNlIiwibG9jYWxlTG93ZXIiLCJsZW5ndGgiLCJzdWJzdHIiLCJxdWVyeUluZGV4IiwiaGFzaEluZGV4IiwidXJsIiwibG9jYXRpb25PcmlnaW4iLCJnZXRMb2NhdGlvbk9yaWdpbiIsInJlc29sdmVkIiwiVVJMIiwib3JpZ2luIiwiYXNQYXRobmFtZSIsInF1ZXJ5IiwiaW50ZXJwb2xhdGVkUm91dGUiLCJkeW5hbWljUmVnZXgiLCJnZXRSb3V0ZVJlZ2V4IiwiZHluYW1pY0dyb3VwcyIsImdyb3VwcyIsImR5bmFtaWNNYXRjaGVzIiwiZ2V0Um91dGVNYXRjaGVyIiwicGFyYW1zIiwiZXZlcnkiLCJwYXJhbSIsInJlcGVhdCIsIm9wdGlvbmFsIiwicmVwbGFjZWQiLCJzZWdtZW50IiwiZW5jb2RlVVJJQ29tcG9uZW50Iiwiam9pbiIsInJlc3VsdCIsIm9taXRQYXJtc0Zyb21RdWVyeSIsImZpbHRlcmVkUXVlcnkiLCJpbmNsdWRlcyIsInJlc29sdmVBcyIsImJhc2UiLCJ1cmxBc1N0cmluZyIsImZvcm1hdFdpdGhWYWxpZGF0aW9uIiwidXJsUHJvdG9NYXRjaCIsIm1hdGNoIiwidXJsQXNTdHJpbmdOb1Byb3RvIiwidXJsUGFydHMiLCJzcGxpdCIsIm5vcm1hbGl6ZWRVcmwiLCJub3JtYWxpemVSZXBlYXRlZFNsYXNoZXMiLCJhc1BhdGgiLCJmaW5hbFVybCIsImludGVycG9sYXRlZEFzIiwiaXNEeW5hbWljUm91dGUiLCJzZWFyY2hQYXJhbXMiLCJzZWFyY2hQYXJhbXNUb1VybFF1ZXJ5IiwiaGFzaCIsInN0cmlwT3JpZ2luIiwicHJlcGFyZVVybEFzIiwiaHJlZkhhZE9yaWdpbiIsImFzSGFkT3JpZ2luIiwicHJlcGFyZWRVcmwiLCJwcmVwYXJlZEFzIiwicmVzb2x2ZUR5bmFtaWNSb3V0ZSIsInBhZ2VzIiwiY2xlYW5QYXRobmFtZSIsImRlbm9ybWFsaXplUGFnZVBhdGgiLCJzb21lIiwicGFnZSIsInJlIiwibWFudWFsU2Nyb2xsUmVzdG9yYXRpb24iLCJfX05FWFRfU0NST0xMX1JFU1RPUkFUSU9OIiwiaGlzdG9yeSIsInNlc3Npb25TdG9yYWdlIiwic2V0SXRlbSIsInJlbW92ZUl0ZW0iLCJuIiwiU1NHX0RBVEFfTk9UX0ZPVU5EIiwiZmV0Y2hSZXRyeSIsImF0dGVtcHRzIiwiY3JlZGVudGlhbHMiLCJzdGF0dXMiLCJqc29uIiwibm90Rm91bmQiLCJmZXRjaE5leHREYXRhIiwiZGF0YUhyZWYiLCJpc1NlcnZlclJlbmRlciIsIlJvdXRlciIsImNvbnN0cnVjdG9yIiwicGF0aG5hbWUxIiwicXVlcnkxIiwiYXMxIiwiaW5pdGlhbFByb3BzIiwicGFnZUxvYWRlciIsIkFwcCIsIndyYXBBcHAiLCJDb21wb25lbnQiLCJDb21wb25lbnQxIiwiZXJyMSIsInN1YnNjcmlwdGlvbiIsImlzRmFsbGJhY2siLCJpc1ByZXZpZXciLCJzZGMiLCJzZHIiLCJfaWR4Iiwib25Qb3BTdGF0ZSIsImNoYW5nZVN0YXRlIiwiZ2V0VVJMIiwiX19OIiwiZm9yY2VkU2Nyb2xsIiwiaWR4IiwiSlNPTiIsInN0cmluZ2lmeSIsIngiLCJwYWdlWE9mZnNldCIsInkiLCJwYWdlWU9mZnNldCIsImdldEl0ZW0iLCJwYXJzZSIsInBhcnNlUmVsYXRpdmVVcmwiLCJpc1NzciIsIl9icHMiLCJjaGFuZ2UiLCJfc2hhbGxvdyIsImNvbXBvbmVudHMiLCJpbml0aWFsIiwiX19OX1NTRyIsIl9fTl9TU1AiLCJhdXRvRXhwb3J0RHluYW1pYyIsIl9fTkVYVF9EQVRBX18iLCJhdXRvRXhwb3J0Iiwic3ViIiwiY2xjIiwiX3dyYXBBcHAiLCJpc1JlYWR5IiwiZ3NzcCIsImdpcCIsImFwcEdpcCIsImdzcCIsImxvY2F0aW9uIiwic2VhcmNoIiwiX19ORVhUX0hBU19SRVdSSVRFUyIsImhvc3RuYW1lIiwiX3Nob3VsZFJlc29sdmVIcmVmIiwiYWRkRXZlbnRMaXN0ZW5lciIsInNjcm9sbFJlc3RvcmF0aW9uIiwicmVsb2FkIiwiYmFjayIsIm1ldGhvZCIsInNob3VsZFJlc29sdmVIcmVmIiwiX2giLCJwcmV2TG9jYWxlIiwicGFyc2VkQXMiLCJsb2NhbGVQYXRoUmVzdWx0IiwiZGlkTmF2aWdhdGUiLCJhc05vQmFzZVBhdGgiLCJTVCIsInBlcmZvcm1hbmNlIiwibWFyayIsInJvdXRlUHJvcHMiLCJfaW5GbGlnaHRSb3V0ZSIsImFib3J0Q29tcG9uZW50TG9hZCIsImNsZWFuZWRBcyIsImxvY2FsZUNoYW5nZSIsIm9ubHlBSGFzaENoYW5nZSIsImVtaXQiLCJzY3JvbGxUb0hhc2giLCJub3RpZnkiLCJwYXJzZWQiLCJyZXdyaXRlcyIsImdldFBhZ2VMaXN0IiwiX19yZXdyaXRlcyIsInVybElzTmV3IiwicmV3cml0ZXNSZXN1bHQiLCJtYXRjaGVkUGFnZSIsInJvdXRlUmVnZXgiLCJyb3V0ZU1hdGNoIiwic2hvdWxkSW50ZXJwb2xhdGUiLCJtaXNzaW5nUGFyYW1zIiwicmVmMSIsInJvdXRlSW5mbyIsImdldFJvdXRlSW5mbyIsInBhZ2VQcm9wcyIsIl9fTl9SRURJUkVDVCIsImRlc3RpbmF0aW9uIiwicGFyc2VkSHJlZiIsIm5ld1VybCIsIm5ld0FzIiwiX19OX1BSRVZJRVciLCJub3RGb3VuZFJvdXRlIiwiZmV0Y2hDb21wb25lbnQiLCJhcHBDb21wIiwibmV4dCIsImlzUHJlcmVuZGVyZWQiLCJzdGF0dXNDb2RlIiwiaXNWYWxpZFNoYWxsb3dSb3V0ZSIsIl9zY3JvbGwiLCJzaG91bGRTY3JvbGwiLCJyZXNldFNjcm9sbCIsImRvY3VtZW50RWxlbWVudCIsImxhbmciLCJoYW5kbGVSb3V0ZUluZm9FcnJvciIsImxvYWRFcnJvckZhaWwiLCJnaXBFcnIiLCJyb3V0ZUluZm9FcnIiLCJleGlzdGluZ1JvdXRlSW5mbyIsImNhY2hlZFJvdXRlSW5mbyIsIm1vZCIsImlzVmFsaWRFbGVtZW50VHlwZSIsImdldERhdGFIcmVmIiwiX2dldERhdGEiLCJfZ2V0U3RhdGljRGF0YSIsIl9nZXRTZXJ2ZXJEYXRhIiwiZXJyMiIsImJlZm9yZVBvcFN0YXRlIiwib2xkVXJsTm9IYXNoIiwib2xkSGFzaCIsIm5ld1VybE5vSGFzaCIsIm5ld0hhc2giLCJzY3JvbGxUbyIsImlkRWwiLCJnZXRFbGVtZW50QnlJZCIsInNjcm9sbEludG9WaWV3IiwibmFtZUVsIiwiZ2V0RWxlbWVudHNCeU5hbWUiLCJwYXRobmFtZTIiLCJfaXNTc2ciLCJpc1NzZyIsImNhbmNlbCIsImNvbXBvbmVudFJlc3VsdCIsImxvYWRQYWdlIiwiY2FjaGVLZXkiLCJyZXNvdXJjZUtleSIsImN0eCIsIkFwcDEiLCJBcHBUcmVlIiwibG9hZEdldEluaXRpYWxQcm9wcyIsImRhc2hib2FyZCIsIk1ldGFkYXRhIiwiTWludExheW91dCIsIlRPS0VOX1BST0dSQU1fSUQiLCJUb2tlbiIsInNlbmRUcmFuc2FjdGlvbnMiLCJzbGVlcCIsIkNBTkRZX01BQ0hJTkVfUFJPR1JBTSIsIlB1YmxpY0tleSIsIlNQTF9BU1NPQ0lBVEVEX1RPS0VOX0FDQ09VTlRfUFJPR1JBTV9JRCIsIlRPS0VOX01FVEFEQVRBX1BST0dSQU1fSUQiLCJvd25lckFkZHJlc3MiLCJ0b2tlbkFjY291bnRzIiwiZ2V0UGFyc2VkVG9rZW5BY2NvdW50c0J5T3duZXIiLCJwcm9ncmFtSWQiLCJpbmRleCIsInRva2VuQWNjb3VudCIsInRva2VuQW1vdW50IiwiYWNjb3VudCIsImluZm8iLCJtaW50IiwiTkVYVF9QVUJMSUNfQUlSRFJPUF9UT0tFTiIsInVpQW1vdW50IiwiYXdhaXRUcmFuc2FjdGlvblNpZ25hdHVyZUNvbmZpcm1hdGlvbiIsInR4aWQiLCJ0aW1lb3V0IiwiY29tbWl0bWVudCIsInF1ZXJ5U3RhdHVzIiwiZG9uZSIsInNsb3QiLCJjb25maXJtYXRpb25zIiwic3ViSWQiLCJvblNpZ25hdHVyZSIsImNvbnRleHQiLCJzaWduYXR1cmVTdGF0dXNlcyIsImdldFNpZ25hdHVyZVN0YXR1c2VzIiwiX3NpZ25hdHVyZVN1YnNjcmlwdGlvbnMiLCJyZW1vdmVTaWduYXR1cmVMaXN0ZW5lciIsImNyZWF0ZUFzc29jaWF0ZWRUb2tlbkFjY291bnRJbnN0cnVjdGlvbiIsImFzc29jaWF0ZWRUb2tlbkFkZHJlc3MiLCJwYXllciIsIndhbGxldEFkZHJlc3MiLCJzcGxUb2tlbk1pbnRBZGRyZXNzIiwicHVia2V5IiwiaXNTaWduZXIiLCJpc1dyaXRhYmxlIiwiU3lzdGVtUHJvZ3JhbSIsIlNZU1ZBUl9SRU5UX1BVQktFWSIsIlRyYW5zYWN0aW9uSW5zdHJ1Y3Rpb24iLCJCdWZmZXIiLCJmcm9tIiwiZ2V0Q2FuZHlNYWNoaW5lU3RhdGUiLCJwcm92aWRlciIsIlByb3ZpZGVyIiwicHJlZmxpZ2h0Q29tbWl0bWVudCIsImlkbCIsIlByb2dyYW0iLCJmZXRjaElkbCIsInByb2dyYW0iLCJjYW5keU1hY2hpbmUiLCJpdGVtc0F2YWlsYWJsZSIsInRvTnVtYmVyIiwiaXRlbXNSZWRlZW1lZCIsIml0ZW1zUmVtYWluaW5nIiwiZ29MaXZlRGF0ZSIsImdldE1hc3RlckVkaXRpb24iLCJmaW5kUHJvZ3JhbUFkZHJlc3MiLCJ0b0J1ZmZlciIsImdldE1ldGFkYXRhIiwiZ2V0VG9rZW5XYWxsZXQiLCJhbGxUb2tlbnMiLCJhbW91bnQiLCJkZWNpbWFscyIsInBkYSIsImFjY291bnRJbmZvIiwiZ2V0UGFyc2VkQWNjb3VudEluZm8iLCJtZXRhZGF0YSIsImRhdGFSZXMiLCJ1cmkiLCJtaW50T25lVG9rZW4iLCJjb25maWciLCJ0cmVhc3VyeSIsIktleXBhaXIiLCJnZW5lcmF0ZSIsInRva2VuIiwibWFzdGVyRWRpdGlvbiIsInJlbnQiLCJnZXRNaW5pbXVtQmFsYW5jZUZvclJlbnRFeGVtcHRpb24iLCJzcGFuIiwicnBjIiwibWludE5mdCIsImFjY291bnRzIiwibWludEF1dGhvcml0eSIsInVwZGF0ZUF1dGhvcml0eSIsInRva2VuTWV0YWRhdGFQcm9ncmFtIiwidG9rZW5Qcm9ncmFtIiwic3lzdGVtUHJvZ3JhbSIsImNsb2NrIiwiU1lTVkFSX0NMT0NLX1BVQktFWSIsInNpZ25lcnMiLCJpbnN0cnVjdGlvbnMiLCJjcmVhdGVBY2NvdW50IiwiZnJvbVB1YmtleSIsIm5ld0FjY291bnRQdWJrZXkiLCJzcGFjZSIsImxhbXBvcnRzIiwiY3JlYXRlSW5pdE1pbnRJbnN0cnVjdGlvbiIsImNyZWF0ZU1pbnRUb0luc3RydWN0aW9uIiwibWludE11bHRpcGxlVG9rZW4iLCJxdWFudGl0eSIsInNpZ25lcnNNYXRyaXgiLCJpbnN0cnVjdGlvbnNNYXRyaXgiLCJpbnN0cnVjdGlvbiIsInNob3J0ZW5BZGRyZXNzIiwiYWRkcmVzcyIsImNoYXJzIiwiVHJhbnNhY3Rpb24iLCJXYWxsZXROb3RDb25uZWN0ZWRFcnJvciIsImdldEVycm9yRm9yVHJhbnNhY3Rpb24iLCJjb25maXJtVHJhbnNhY3Rpb24iLCJ0eCIsImdldFBhcnNlZENvbmZpcm1lZFRyYW5zYWN0aW9uIiwiZXJyb3JzIiwibWV0YSIsImxvZ01lc3NhZ2VzIiwicmVnZXgiLCJtIiwiZXhlYyIsImxhc3RJbmRleCIsIlNlcXVlbmNlVHlwZSIsImluc3RydWN0aW9uU2V0Iiwic2lnbmVyc1NldCIsInNlcXVlbmNlVHlwZSIsIlBhcmFsbGVsIiwiYmxvY2siLCJ1bnNpZ25lZFR4bnMiLCJnZXRSZWNlbnRCbG9ja2hhc2giLCJpIiwidHJhbnNhY3Rpb24iLCJhZGQiLCJyZWNlbnRCbG9ja2hhc2giLCJibG9ja2hhc2giLCJzZXRTaWduZXJzIiwicyIsInBhcnRpYWxTaWduIiwic2lnbmVkVHhucyIsInBlbmRpbmdUeG5zIiwiYnJlYWtFYXJseU9iamVjdCIsImJyZWFrRWFybHkiLCJ0eElkcyIsInNpZ25lZFR4blByb21pc2UiLCJzZW5kU2lnbmVkVHJhbnNhY3Rpb24iLCJzaWduZWRUcmFuc2FjdGlvbiIsImZhaWxDYWxsYmFjayIsIlN0b3BPbkZhaWx1cmUiLCJhd2FpdENvbmZpcm1hdGlvbiIsImluY2x1ZGVzRmVlUGF5ZXIiLCJyYXdUcmFuc2FjdGlvbiIsInNlcmlhbGl6ZSIsInNraXBQcmVmbGlnaHQiLCJzZW5kUmF3VHJhbnNhY3Rpb24iLCJjb25maXJtYXRpb24iLCJERUZBVUxUX1RJTUVPVVQiLCJzZW5kVHJhbnNhY3Rpb25XaXRoUmV0cnkiLCJiZWZvcmVTZW5kIiwiZ2V0VW5peFRzIiwiZ2V0VGltZSIsInN0YXJ0VGltZSIsInNpbXVsYXRlUmVzdWx0Iiwic2ltdWxhdGVUcmFuc2FjdGlvbiIsImxvZ3MiLCJsaW5lIiwiX3JlY2VudEJsb2NraGFzaCIsIl9kaXNhYmxlQmxvY2toYXNoQ2FjaGluZyIsInNpZ25EYXRhIiwic2VyaWFsaXplTWVzc2FnZSIsIndpcmVUcmFuc2FjdGlvbiIsIl9zZXJpYWxpemUiLCJlbmNvZGVkVHJhbnNhY3Rpb24iLCJlbmNvZGluZyIsIl9ycGNSZXF1ZXN0IiwiRXZlbnRFbWl0dGVyIiwiQmFzZVdhbGxldEFkYXB0ZXIiLCJXYWxsZXRBZGFwdGVyTmV0d29yayIsIldhbGxldEVycm9yIiwiV2FsbGV0Tm90Rm91bmRFcnJvciIsImFyZ3VtZW50cyIsIldhbGxldE5vdEluc3RhbGxlZEVycm9yIiwiV2FsbGV0Tm90UmVhZHlFcnJvciIsIldhbGxldENvbm5lY3Rpb25FcnJvciIsIldhbGxldERpc2Nvbm5lY3RlZEVycm9yIiwiV2FsbGV0RGlzY29ubmVjdGlvbkVycm9yIiwiV2FsbGV0QWNjb3VudEVycm9yIiwiV2FsbGV0UHVibGljS2V5RXJyb3IiLCJXYWxsZXRLZXlwYWlyRXJyb3IiLCJXYWxsZXRTZW5kVHJhbnNhY3Rpb25FcnJvciIsIldhbGxldFNpZ25NZXNzYWdlRXJyb3IiLCJXYWxsZXRTaWduVHJhbnNhY3Rpb25FcnJvciIsIldhbGxldFRpbWVvdXRFcnJvciIsIldhbGxldFdpbmRvd0Jsb2NrZWRFcnJvciIsIldhbGxldFdpbmRvd0Nsb3NlZEVycm9yIiwiX19hd2FpdGVyIiwidGhpc0FyZyIsIl9hcmd1bWVudHMiLCJQIiwiYWRvcHQiLCJmdWxmaWxsZWQiLCJzdGVwIiwicmVqZWN0ZWQiLCJhcHBseSIsInBvbGwiLCJpbnRlcnZhbCIsImNvdW50IiwicG9sbFVudGlsUmVhZHkiLCJhZGFwdGVyIiwicG9sbEludGVydmFsIiwicG9sbENvdW50IiwiX19yZXN0IiwidCIsInByb3RvdHlwZSIsImhhc093blByb3BlcnR5IiwiY2FsbCIsImdldE93blByb3BlcnR5U3ltYm9scyIsInByb3BlcnR5SXNFbnVtZXJhYmxlIiwiQmFzZVNpZ25lcldhbGxldEFkYXB0ZXIiLCJmZWVQYXllciIsInNlbmRPcHRpb25zIiwiQmFzZU1lc3NhZ2VTaWduZXJXYWxsZXRBZGFwdGVyIiwiQnV0dG9uIiwianVzdGlmeUNvbnRlbnQiLCJlbmRJY29uIiwic3RhcnRJY29uIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJ0YWJJbmRleCIsInVzZUxheW91dEVmZmVjdCIsIkNvbGxhcHNlIiwiZXhwYW5kZWQiLCJpbnN0YW50IiwidHJhbnNpdGlvbiIsIm9wZW5Db2xsYXBzZSIsIm5vZGUiLCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJoZWlnaHQiLCJzY3JvbGxIZWlnaHQiLCJjbG9zZUNvbGxhcHNlIiwib2Zmc2V0SGVpZ2h0Iiwib3ZlcmZsb3ciLCJoYW5kbGVDb21wbGV0ZSIsImhhbmRsZVRyYW5zaXRpb25FbmQiLCJwcm9wZXJ0eU5hbWUiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwicm9sZSIsIldhbGxldEljb24iLCJXYWxsZXRDb25uZWN0QnV0dG9uIiwiX2EiLCJjb25uZWN0IiwiY29ubmVjdGluZyIsImNvbm5lY3RlZCIsImhhbmRsZUNsaWNrIiwiV2FsbGV0RGlzY29ubmVjdEJ1dHRvbiIsImRpc2Nvbm5lY3RpbmciLCJpY29uIiwiYWx0IiwiV2FsbGV0TGlzdEl0ZW0iLCJjcmVhdGVQb3J0YWwiLCJ1c2VXYWxsZXRNb2RhbCIsIldhbGxldE1vZGFsIiwibG9nbyIsImZlYXR1cmVkV2FsbGV0cyIsImNvbnRhaW5lciIsIndhbGxldHMiLCJzZWxlY3QiLCJzZXRFeHBhbmRlZCIsImZhZGVJbiIsInNldEZhZGVJbiIsInBvcnRhbCIsInNldFBvcnRhbCIsImZlYXR1cmVkIiwibW9yZSIsImhpZGVNb2RhbCIsImhhbmRsZUNsb3NlIiwiaGFuZGxlV2FsbGV0Q2xpY2siLCJ3YWxsZXROYW1lIiwiaGFuZGxlQ29sbGFwc2VDbGljayIsImhhbmRsZVRhYktleSIsImZvY3VzYWJsZUVsZW1lbnRzIiwicXVlcnlTZWxlY3RvckFsbCIsImZpcnN0RWxlbWVudCIsImxhc3RFbGVtZW50IiwiYWN0aXZlRWxlbWVudCIsImZvY3VzIiwiaGFuZGxlS2V5RG93biIsImdldENvbXB1dGVkU3R5bGUiLCJkIiwiRnJhZ21lbnQiLCJ4bWxucyIsIm9uTW91c2VEb3duIiwiV2FsbGV0TW9kYWxCdXR0b24iLCJXYWxsZXRNb2RhbENvbnRleHQiLCJXYWxsZXRNb2RhbFByb3ZpZGVyIiwiY29waWVkIiwic2V0Q29waWVkIiwiYWN0aXZlIiwic2V0QWN0aXZlIiwiYmFzZTU4IiwidG9CYXNlNTgiLCJjb3B5QWRkcmVzcyIsImNsaXBib2FyZCIsIndyaXRlVGV4dCIsIm9wZW5Ecm9wZG93biIsImNsb3NlRHJvcGRvd24iLCJvcGVuTW9kYWwiLCJsaXN0ZW5lciIsImNvbnRhaW5zIiwicG9pbnRlckV2ZW50cyIsImNyZWF0ZUNvbnRleHQiLCJDb25uZWN0aW9uQ29udGV4dCIsIkNvbm5lY3Rpb25Qcm92aWRlciIsImVuZHBvaW50IiwiV2FsbGV0Tm90U2VsZWN0ZWRFcnJvciIsInVzZUxvY2FsU3RvcmFnZSIsIldhbGxldENvbnRleHQiLCJpbml0aWFsU3RhdGUiLCJXYWxsZXRQcm92aWRlciIsImF1dG9Db25uZWN0Iiwib25FcnJvciIsIl9vbkVycm9yIiwibG9jYWxTdG9yYWdlS2V5Iiwic2V0TmFtZSIsInNldFN0YXRlIiwic2V0Q29ubmVjdGluZyIsInNldERpc2Nvbm5lY3RpbmciLCJpc0Nvbm5lY3RpbmciLCJpc0Rpc2Nvbm5lY3RpbmciLCJpc1VubG9hZGluZyIsIndhbGxldHNCeU5hbWUiLCJyZWR1Y2UiLCJuZXdOYW1lIiwib25SZWFkeSIsIm9uQ29ubmVjdCIsIm9uRGlzY29ubmVjdCIsIm9wZW4iLCJ0cmFuc2FjdGlvbnMiLCJzaWduTWVzc2FnZSIsIm9mZiIsInVzZUFuY2hvcldhbGxldCIsImRlZmF1bHRTdGF0ZSIsInNldFZhbHVlIiwibG9jYWxTdG9yYWdlIiwic2V0TG9jYWxTdG9yYWdlIiwibmV3VmFsdWUiXSwic291cmNlUm9vdCI6IiJ9