"use strict";
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./components/Dashboard/NotConnected.js":
/*!**********************************************!*\
  !*** ./components/Dashboard/NotConnected.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _solana_wallet_adapter_react_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @solana/wallet-adapter-react-ui */ "./node_modules/@solana/wallet-adapter-react-ui/lib/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\components\\Dashboard\\NotConnected.js";




function NotConnected() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
    className: "center p-6",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h1", {
        className: "text-3xl lg:text-5xl font-bold text-center py-6 ",
        children: ["Staking ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("span", {
          className: "text-brand_accent",
          children: "Project"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 9,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 8,
        columnNumber: 11
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
        className: "pb-4 text-2xl",
        children: "Log in with your web3 provider to continue"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 11
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
        className: "center",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_solana_wallet_adapter_react_ui__WEBPACK_IMPORTED_MODULE_1__.WalletMultiButton, {
          children: "Connect Wallet"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 9
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 7
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotConnected);

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var _components_Dashboard_NotConnected__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Dashboard/NotConnected */ "./components/Dashboard/NotConnected.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
var _jsxFileName = "G:\\clients\\dylan\\staking\\pages\\index.js";






function Home() {
  const {
    publicKey
  } = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_4__.useWallet)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();

  if (!publicKey) {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
      className: "center h-80vh",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_components_Dashboard_NotConnected__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 11,
        columnNumber: 10
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 8
    }, this);
  } else {
    router.push("/dashboard");
  }

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {}, void 0, false);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/adapter.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/adapter.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventEmitter": () => (/* reexport default from dynamic */ eventemitter3__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "BaseWalletAdapter": () => (/* binding */ BaseWalletAdapter),
/* harmony export */   "WalletAdapterNetwork": () => (/* binding */ WalletAdapterNetwork)
/* harmony export */ });
/* harmony import */ var eventemitter3__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! eventemitter3 */ "eventemitter3");
/* harmony import */ var eventemitter3__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(eventemitter3__WEBPACK_IMPORTED_MODULE_0__);


class BaseWalletAdapter extends (eventemitter3__WEBPACK_IMPORTED_MODULE_0___default()) {}
var WalletAdapterNetwork;

(function (WalletAdapterNetwork) {
  WalletAdapterNetwork["Mainnet"] = "mainnet-beta";
  WalletAdapterNetwork["Testnet"] = "testnet";
  WalletAdapterNetwork["Devnet"] = "devnet";
})(WalletAdapterNetwork || (WalletAdapterNetwork = {}));

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/errors.js":
/*!****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/errors.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletError": () => (/* binding */ WalletError),
/* harmony export */   "WalletNotFoundError": () => (/* binding */ WalletNotFoundError),
/* harmony export */   "WalletNotInstalledError": () => (/* binding */ WalletNotInstalledError),
/* harmony export */   "WalletNotReadyError": () => (/* binding */ WalletNotReadyError),
/* harmony export */   "WalletConnectionError": () => (/* binding */ WalletConnectionError),
/* harmony export */   "WalletDisconnectedError": () => (/* binding */ WalletDisconnectedError),
/* harmony export */   "WalletDisconnectionError": () => (/* binding */ WalletDisconnectionError),
/* harmony export */   "WalletAccountError": () => (/* binding */ WalletAccountError),
/* harmony export */   "WalletPublicKeyError": () => (/* binding */ WalletPublicKeyError),
/* harmony export */   "WalletKeypairError": () => (/* binding */ WalletKeypairError),
/* harmony export */   "WalletNotConnectedError": () => (/* binding */ WalletNotConnectedError),
/* harmony export */   "WalletSendTransactionError": () => (/* binding */ WalletSendTransactionError),
/* harmony export */   "WalletSignMessageError": () => (/* binding */ WalletSignMessageError),
/* harmony export */   "WalletSignTransactionError": () => (/* binding */ WalletSignTransactionError),
/* harmony export */   "WalletTimeoutError": () => (/* binding */ WalletTimeoutError),
/* harmony export */   "WalletWindowBlockedError": () => (/* binding */ WalletWindowBlockedError),
/* harmony export */   "WalletWindowClosedError": () => (/* binding */ WalletWindowClosedError)
/* harmony export */ });
class WalletError extends Error {
  // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
  constructor(message, error) {
    super(message);
    this.error = error;
  }

}
class WalletNotFoundError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotFoundError';
  }

}
class WalletNotInstalledError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotInstalledError';
  }

}
class WalletNotReadyError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotReadyError';
  }

}
class WalletConnectionError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletConnectionError';
  }

}
class WalletDisconnectedError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletDisconnectedError';
  }

}
class WalletDisconnectionError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletDisconnectionError';
  }

}
class WalletAccountError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletAccountError';
  }

}
class WalletPublicKeyError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletPublicKeyError';
  }

}
class WalletKeypairError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletKeypairError';
  }

}
class WalletNotConnectedError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotConnectedError';
  }

}
class WalletSendTransactionError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletSendTransactionError';
  }

}
class WalletSignMessageError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletSignMessageError';
  }

}
class WalletSignTransactionError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletSignTransactionError';
  }

}
class WalletTimeoutError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletTimeoutError';
  }

}
class WalletWindowBlockedError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletWindowBlockedError';
  }

}
class WalletWindowClosedError extends WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletWindowClosedError';
  }

}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/index.js":
/*!***************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _adapter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./adapter */ "./node_modules/@solana/wallet-adapter-base/lib/adapter.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _adapter__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _adapter__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors */ "./node_modules/@solana/wallet-adapter-base/lib/errors.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _errors__WEBPACK_IMPORTED_MODULE_1__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _errors__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _poll__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./poll */ "./node_modules/@solana/wallet-adapter-base/lib/poll.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _poll__WEBPACK_IMPORTED_MODULE_2__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _poll__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _signer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./signer */ "./node_modules/@solana/wallet-adapter-base/lib/signer.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _signer__WEBPACK_IMPORTED_MODULE_3__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _signer__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);





/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/poll.js":
/*!**************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/poll.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "poll": () => (/* binding */ poll),
/* harmony export */   "pollUntilReady": () => (/* binding */ pollUntilReady)
/* harmony export */ });
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

function poll(callback, interval, count) {
  if (count > 0) {
    setTimeout(() => __awaiter(this, void 0, void 0, function* () {
      const done = yield callback();
      if (!done) poll(callback, interval, count - 1);
    }), interval);
  }
}
function pollUntilReady(adapter, pollInterval, pollCount) {
  poll(() => {
    const {
      ready
    } = adapter;

    if (ready) {
      if (!adapter.emit('ready')) {
        console.warn(`${adapter.constructor.name} is ready but no listener was registered`);
      }
    }

    return ready;
  }, pollInterval, pollCount);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-base/lib/signer.js":
/*!****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-base/lib/signer.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BaseSignerWalletAdapter": () => (/* binding */ BaseSignerWalletAdapter),
/* harmony export */   "BaseMessageSignerWalletAdapter": () => (/* binding */ BaseMessageSignerWalletAdapter)
/* harmony export */ });
/* harmony import */ var _adapter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./adapter */ "./node_modules/@solana/wallet-adapter-base/lib/adapter.js");
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors */ "./node_modules/@solana/wallet-adapter-base/lib/errors.js");
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};



class BaseSignerWalletAdapter extends _adapter__WEBPACK_IMPORTED_MODULE_0__.BaseWalletAdapter {
  sendTransaction(transaction, connection, options = {}) {
    return __awaiter(this, void 0, void 0, function* () {
      let emit = true;

      try {
        try {
          transaction.feePayer || (transaction.feePayer = this.publicKey || undefined);
          transaction.recentBlockhash || (transaction.recentBlockhash = (yield connection.getRecentBlockhash('finalized')).blockhash);

          const {
            signers
          } = options,
                sendOptions = __rest(options, ["signers"]);

          (signers === null || signers === void 0 ? void 0 : signers.length) && transaction.partialSign(...signers);
          transaction = yield this.signTransaction(transaction);
          const rawTransaction = transaction.serialize();
          return yield connection.sendRawTransaction(rawTransaction, sendOptions);
        } catch (error) {
          // If the error was thrown by `signTransaction`, rethrow it and don't emit a duplicate event
          if (error instanceof _errors__WEBPACK_IMPORTED_MODULE_1__.WalletError) {
            emit = false;
            throw error;
          }

          throw new _errors__WEBPACK_IMPORTED_MODULE_1__.WalletSendTransactionError(error === null || error === void 0 ? void 0 : error.message, error);
        }
      } catch (error) {
        if (emit) {
          this.emit('error', error);
        }

        throw error;
      }
    });
  }

}
class BaseMessageSignerWalletAdapter extends BaseSignerWalletAdapter {}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js":
/*!********************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Button": () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const Button = props => {
  const justifyContent = props.endIcon || props.startIcon ? 'space-between' : 'center';
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", {
    className: `wallet-adapter-button ${props.className || ''}`,
    disabled: props.disabled,
    onClick: props.onClick,
    style: Object.assign({
      justifyContent
    }, props.style),
    tabIndex: props.tabIndex || 0,
    type: "button"
  }, props.startIcon && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", {
    className: "wallet-adapter-button-start-icon"
  }, props.startIcon), props.children, props.endIcon && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", {
    className: "wallet-adapter-button-end-icon"
  }, props.endIcon));
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/Collapse.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/Collapse.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Collapse": () => (/* binding */ Collapse)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const Collapse = ({
  id,
  children,
  expanded = false
}) => {
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const instant = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(true);
  const transition = 'height 250ms ease-out';

  const openCollapse = () => {
    const node = ref.current;
    if (!node) return;
    requestAnimationFrame(() => {
      node.style.height = node.scrollHeight + 'px';
    });
  };

  const closeCollapse = () => {
    const node = ref.current;
    if (!node) return;
    requestAnimationFrame(() => {
      node.style.height = node.offsetHeight + 'px';
      node.style.overflow = 'hidden';
      requestAnimationFrame(() => {
        node.style.height = '0';
      });
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    if (expanded) {
      openCollapse();
    } else {
      closeCollapse();
    }
  }, [expanded]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    const node = ref.current;
    if (!node) return;

    function handleComplete() {
      if (!node) return;
      node.style.overflow = expanded ? 'initial' : 'hidden';

      if (expanded) {
        node.style.height = 'auto';
      }
    }

    function handleTransitionEnd(event) {
      if (node && event.target === node && event.propertyName === 'height') {
        handleComplete();
      }
    }

    if (instant.current) {
      handleComplete();
      instant.current = false;
    }

    node.addEventListener('transitionend', handleTransitionEnd);
    return () => node.removeEventListener('transitionend', handleTransitionEnd);
  }, [expanded]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    children: children,
    className: "wallet-adapter-collapse",
    id: id,
    ref: ref,
    role: "region",
    style: {
      height: 0,
      transition: instant.current ? undefined : transition
    }
  });
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletConnectButton.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletConnectButton.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletConnectButton": () => (/* binding */ WalletConnectButton)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js");
/* harmony import */ var _WalletIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WalletIcon */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js");
var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};





const WalletConnectButton = _a => {
  var {
    children,
    disabled,
    onClick
  } = _a,
      props = __rest(_a, ["children", "disabled", "onClick"]);

  const {
    wallet,
    connect,
    connecting,
    connected
  } = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_3__.useWallet)();
  const handleClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    if (onClick) onClick(event); // eslint-disable-next-line @typescript-eslint/no-empty-function

    if (!event.defaultPrevented) connect().catch(() => {});
  }, [onClick, connect]);
  const content = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    if (children) return children;
    if (connecting) return 'Connecting ...';
    if (connected) return 'Connected';
    if (wallet) return 'Connect';
    return 'Connect Wallet';
  }, [children, connecting, connected, wallet]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, Object.assign({
    className: "wallet-adapter-button-trigger",
    disabled: disabled || !wallet || connecting || connected,
    startIcon: wallet ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletIcon__WEBPACK_IMPORTED_MODULE_2__.WalletIcon, {
      wallet: wallet
    }) : undefined,
    onClick: handleClick
  }, props), content);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletDisconnectButton.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletDisconnectButton.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletDisconnectButton": () => (/* binding */ WalletDisconnectButton)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js");
/* harmony import */ var _WalletIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WalletIcon */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js");
var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};





const WalletDisconnectButton = _a => {
  var {
    children,
    disabled,
    onClick
  } = _a,
      props = __rest(_a, ["children", "disabled", "onClick"]);

  const {
    wallet,
    disconnect,
    disconnecting
  } = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_3__.useWallet)();
  const handleClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    if (onClick) onClick(event); // eslint-disable-next-line @typescript-eslint/no-empty-function

    if (!event.defaultPrevented) disconnect().catch(() => {});
  }, [onClick, disconnect]);
  const content = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    if (children) return children;
    if (disconnecting) return 'Disconnecting ...';
    if (wallet) return 'Disconnect';
    return 'Disconnect Wallet';
  }, [children, disconnecting, wallet]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, Object.assign({
    className: "wallet-adapter-button-trigger",
    disabled: disabled || !wallet,
    startIcon: wallet ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletIcon__WEBPACK_IMPORTED_MODULE_2__.WalletIcon, {
      wallet: wallet
    }) : undefined,
    onClick: handleClick
  }, props), content);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js":
/*!************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletIcon": () => (/* binding */ WalletIcon)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};


const WalletIcon = _a => {
  var {
    wallet
  } = _a,
      props = __rest(_a, ["wallet"]);

  return wallet && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", Object.assign({
    src: wallet.icon,
    alt: `${wallet.name} icon`
  }, props));
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletListItem.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletListItem.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletListItem": () => (/* binding */ WalletListItem)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js");
/* harmony import */ var _WalletIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WalletIcon */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js");



const WalletListItem = ({
  handleClick,
  tabIndex,
  wallet
}) => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, {
    onClick: handleClick,
    endIcon: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletIcon__WEBPACK_IMPORTED_MODULE_2__.WalletIcon, {
      wallet: wallet
    }),
    tabIndex: tabIndex
  }, wallet.name));
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModal.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModal.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletModal": () => (/* binding */ WalletModal)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Button */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js");
/* harmony import */ var _Collapse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Collapse */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Collapse.js");
/* harmony import */ var _useWalletModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./useWalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js");
/* harmony import */ var _WalletListItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./WalletListItem */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletListItem.js");







const WalletModal = ({
  className = '',
  logo,
  featuredWallets = 3,
  container = 'body'
}) => {
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const {
    wallets,
    select
  } = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_6__.useWallet)();
  const {
    setVisible
  } = (0,_useWalletModal__WEBPACK_IMPORTED_MODULE_4__.useWalletModal)();
  const {
    0: expanded,
    1: setExpanded
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: fadeIn,
    1: setFadeIn
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: portal,
    1: setPortal
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const {
    0: featured,
    1: more
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => [wallets.slice(0, featuredWallets), wallets.slice(featuredWallets)], [wallets, featuredWallets]);
  const hideModal = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    setFadeIn(false);
    setTimeout(() => setVisible(false), 150);
  }, [setFadeIn, setVisible]);
  const handleClose = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    event.preventDefault();
    hideModal();
  }, [hideModal]);
  const handleWalletClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((event, walletName) => {
    select(walletName);
    handleClose(event);
  }, [select, handleClose]);
  const handleCollapseClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => setExpanded(!expanded), [setExpanded, expanded]);
  const handleTabKey = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    const node = ref.current;
    if (!node) return; // here we query all focusable elements

    const focusableElements = node.querySelectorAll('button');
    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];

    if (event.shiftKey) {
      // if going backward by pressing tab and firstElement is active, shift focus to last focusable element
      if (document.activeElement === firstElement) {
        lastElement.focus();
        event.preventDefault();
      }
    } else {
      // if going forward by pressing tab and lastElement is active, shift focus to first focusable element
      if (document.activeElement === lastElement) {
        firstElement.focus();
        event.preventDefault();
      }
    }
  }, [ref]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    const handleKeyDown = event => {
      if (event.key === 'Escape') {
        hideModal();
      } else if (event.key === 'Tab') {
        handleTabKey(event);
      }
    }; // Get original overflow


    const {
      overflow
    } = window.getComputedStyle(document.body); // Hack to enable fade in animation after mount

    setTimeout(() => setFadeIn(true), 0); // Prevent scrolling on mount

    document.body.style.overflow = 'hidden'; // Listen for keydown events

    window.addEventListener('keydown', handleKeyDown, false);
    return () => {
      // Re-enable scrolling when component unmounts
      document.body.style.overflow = overflow;
      window.removeEventListener('keydown', handleKeyDown, false);
    };
  }, [hideModal, handleTabKey]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => setPortal(document.querySelector(container)), [setPortal, container]);
  return portal && /*#__PURE__*/(0,react_dom__WEBPACK_IMPORTED_MODULE_1__.createPortal)( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    "aria-labelledby": "wallet-adapter-modal-title",
    "aria-modal": "true",
    className: `wallet-adapter-modal ${fadeIn && 'wallet-adapter-modal-fade-in'} ${className}`,
    ref: ref,
    role: "dialog"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    className: "wallet-adapter-modal-container"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    className: `wallet-adapter-modal-wrapper ${!logo && 'wallet-adapter-modal-wrapper-no-logo'}`
  }, logo && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    className: "wallet-adapter-modal-logo-wrapper"
  }, typeof logo === 'string' ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", {
    alt: "logo",
    className: "wallet-adapter-modal-logo",
    src: logo
  }) : logo), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", {
    className: "wallet-adapter-modal-title",
    id: "wallet-adapter-modal-title"
  }, "Connect Wallet"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", {
    onClick: handleClose,
    className: "wallet-adapter-modal-button-close"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", {
    width: "14",
    height: "14"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", {
    d: "M14 12.461 8.3 6.772l5.234-5.233L12.006 0 6.772 5.234 1.54 0 0 1.539l5.234 5.233L0 12.006l1.539 1.528L6.772 8.3l5.69 5.7L14 12.461z"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", {
    className: "wallet-adapter-modal-list"
  }, featured.map(wallet => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletListItem__WEBPACK_IMPORTED_MODULE_5__.WalletListItem, {
    key: wallet.name,
    handleClick: event => handleWalletClick(event, wallet.name),
    wallet: wallet
  }))), more.length ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Collapse__WEBPACK_IMPORTED_MODULE_3__.Collapse, {
    expanded: expanded,
    id: "wallet-adapter-modal-collapse"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", {
    className: "wallet-adapter-modal-list"
  }, more.map(wallet => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletListItem__WEBPACK_IMPORTED_MODULE_5__.WalletListItem, {
    key: wallet.name,
    handleClick: event => handleWalletClick(event, wallet.name),
    tabIndex: expanded ? 0 : -1,
    wallet: wallet
  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_2__.Button, {
    "aria-controls": "wallet-adapter-modal-collapse",
    "aria-expanded": expanded,
    className: `wallet-adapter-modal-collapse-button ${expanded && 'wallet-adapter-modal-collapse-button-active'}`,
    endIcon: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", {
      width: "11",
      height: "6",
      xmlns: "http://www.w3.org/2000/svg"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", {
      d: "m5.938 5.73 4.28-4.126a.915.915 0 0 0 0-1.322 1 1 0 0 0-1.371 0L5.253 3.736 1.659.272a1 1 0 0 0-1.371 0A.93.93 0 0 0 0 .932c0 .246.1.48.288.662l4.28 4.125a.99.99 0 0 0 1.37.01z"
    })),
    onClick: handleCollapseClick
  }, expanded ? 'Less' : 'More', " options")) : null)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    className: "wallet-adapter-modal-overlay",
    onMouseDown: handleClose
  })), portal);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalButton.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalButton.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletModalButton": () => (/* binding */ WalletModalButton)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js");
/* harmony import */ var _useWalletModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useWalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js");
var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};




const WalletModalButton = _a => {
  var {
    children = 'Select Wallet',
    onClick
  } = _a,
      props = __rest(_a, ["children", "onClick"]);

  const {
    visible,
    setVisible
  } = (0,_useWalletModal__WEBPACK_IMPORTED_MODULE_2__.useWalletModal)();
  const handleClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    if (onClick) onClick(event);
    if (!event.defaultPrevented) setVisible(!visible);
  }, [onClick, setVisible, visible]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, Object.assign({
    className: "wallet-adapter-button-trigger",
    onClick: handleClick
  }, props), children);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalProvider.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalProvider.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletModalProvider": () => (/* binding */ WalletModalProvider)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _useWalletModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./useWalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js");
/* harmony import */ var _WalletModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModal.js");
var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};




const WalletModalProvider = _a => {
  var {
    children
  } = _a,
      props = __rest(_a, ["children"]);

  const {
    0: visible,
    1: setVisible
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_useWalletModal__WEBPACK_IMPORTED_MODULE_1__.WalletModalContext.Provider, {
    value: {
      visible,
      setVisible
    }
  }, children, visible && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletModal__WEBPACK_IMPORTED_MODULE_2__.WalletModal, Object.assign({}, props)));
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletMultiButton.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/WalletMultiButton.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletMultiButton": () => (/* binding */ WalletMultiButton)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @solana/wallet-adapter-react */ "./node_modules/@solana/wallet-adapter-react/lib/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ "./node_modules/@solana/wallet-adapter-react-ui/lib/Button.js");
/* harmony import */ var _useWalletModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useWalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js");
/* harmony import */ var _WalletConnectButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./WalletConnectButton */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletConnectButton.js");
/* harmony import */ var _WalletIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./WalletIcon */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js");
/* harmony import */ var _WalletModalButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./WalletModalButton */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalButton.js");
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __rest = undefined && undefined.__rest || function (s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};








const WalletMultiButton = _a => {
  var {
    children
  } = _a,
      props = __rest(_a, ["children"]);

  const {
    publicKey,
    wallet,
    disconnect
  } = (0,_solana_wallet_adapter_react__WEBPACK_IMPORTED_MODULE_6__.useWallet)();
  const {
    setVisible
  } = (0,_useWalletModal__WEBPACK_IMPORTED_MODULE_2__.useWalletModal)();
  const {
    0: copied,
    1: setCopied
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: active,
    1: setActive
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const base58 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => publicKey === null || publicKey === void 0 ? void 0 : publicKey.toBase58(), [publicKey]);
  const content = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    if (children) return children;
    if (!wallet || !base58) return null;
    return base58.slice(0, 4) + '..' + base58.slice(-4);
  }, [children, wallet, base58]);
  const copyAddress = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => __awaiter(void 0, void 0, void 0, function* () {
    if (base58) {
      yield navigator.clipboard.writeText(base58);
      setCopied(true);
      setTimeout(() => setCopied(false), 400);
    }
  }), [base58]);
  const openDropdown = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => setActive(true), [setActive]);
  const closeDropdown = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => setActive(false), [setActive]);
  const openModal = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    setVisible(true);
    closeDropdown();
  }, [setVisible, closeDropdown]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const listener = event => {
      const node = ref.current; // Do nothing if clicking dropdown or its descendants

      if (!node || node.contains(event.target)) return;
      closeDropdown();
    };

    document.addEventListener('mousedown', listener);
    document.addEventListener('touchstart', listener);
    return () => {
      document.removeEventListener('mousedown', listener);
      document.removeEventListener('touchstart', listener);
    };
  }, [ref, closeDropdown]);
  if (!wallet) return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletModalButton__WEBPACK_IMPORTED_MODULE_5__.WalletModalButton, Object.assign({}, props), children);
  if (!base58) return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletConnectButton__WEBPACK_IMPORTED_MODULE_3__.WalletConnectButton, Object.assign({}, props), children);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    className: "wallet-adapter-dropdown"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, Object.assign({
    "aria-expanded": active,
    className: "wallet-adapter-button-trigger",
    style: Object.assign({
      pointerEvents: active ? 'none' : 'auto'
    }, props.style),
    onClick: openDropdown,
    startIcon: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WalletIcon__WEBPACK_IMPORTED_MODULE_4__.WalletIcon, {
      wallet: wallet
    })
  }, props), content), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", {
    "aria-label": "dropdown-list",
    className: `wallet-adapter-dropdown-list ${active && 'wallet-adapter-dropdown-list-active'}`,
    ref: ref,
    role: "menu"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", {
    onClick: copyAddress,
    className: "wallet-adapter-dropdown-list-item",
    role: "menuitem"
  }, copied ? 'Copied' : 'Copy address'), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", {
    onClick: openModal,
    className: "wallet-adapter-dropdown-list-item",
    role: "menuitem"
  }, "Connect a different wallet"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", {
    onClick: disconnect,
    className: "wallet-adapter-dropdown-list-item",
    role: "menuitem"
  }, "Disconnect")));
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/index.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/index.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _useWalletModal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./useWalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useWalletModal__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useWalletModal__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletConnectButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WalletConnectButton */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletConnectButton.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletConnectButton__WEBPACK_IMPORTED_MODULE_1__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletConnectButton__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WalletModal */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModal.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletModal__WEBPACK_IMPORTED_MODULE_2__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletModal__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletModalButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./WalletModalButton */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalButton.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletModalButton__WEBPACK_IMPORTED_MODULE_3__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletModalButton__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletModalProvider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./WalletModalProvider */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletModalProvider.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletModalProvider__WEBPACK_IMPORTED_MODULE_4__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletModalProvider__WEBPACK_IMPORTED_MODULE_4__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletDisconnectButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./WalletDisconnectButton */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletDisconnectButton.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletDisconnectButton__WEBPACK_IMPORTED_MODULE_5__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletDisconnectButton__WEBPACK_IMPORTED_MODULE_5__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./WalletIcon */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletIcon.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletIcon__WEBPACK_IMPORTED_MODULE_6__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletIcon__WEBPACK_IMPORTED_MODULE_6__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletMultiButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./WalletMultiButton */ "./node_modules/@solana/wallet-adapter-react-ui/lib/WalletMultiButton.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletMultiButton__WEBPACK_IMPORTED_MODULE_7__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletMultiButton__WEBPACK_IMPORTED_MODULE_7__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);









/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react-ui/lib/useWalletModal.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletModalContext": () => (/* binding */ WalletModalContext),
/* harmony export */   "useWalletModal": () => (/* binding */ useWalletModal)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const WalletModalContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
function useWalletModal() {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(WalletModalContext);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/ConnectionProvider.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/ConnectionProvider.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConnectionProvider": () => (/* binding */ ConnectionProvider)
/* harmony export */ });
/* harmony import */ var _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @solana/web3.js */ "@solana/web3.js");
/* harmony import */ var _solana_web3_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_solana_web3_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _useConnection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useConnection */ "./node_modules/@solana/wallet-adapter-react/lib/useConnection.js");



const ConnectionProvider = ({
  children,
  endpoint,
  config = {
    commitment: 'confirmed'
  }
}) => {
  const connection = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => new _solana_web3_js__WEBPACK_IMPORTED_MODULE_0__.Connection(endpoint, config), [endpoint, config]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_useConnection__WEBPACK_IMPORTED_MODULE_2__.ConnectionContext.Provider, {
    value: {
      connection
    }
  }, children);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/WalletProvider.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/WalletProvider.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletProvider": () => (/* binding */ WalletProvider)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @solana/wallet-adapter-base */ "./node_modules/@solana/wallet-adapter-base/lib/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./errors */ "./node_modules/@solana/wallet-adapter-react/lib/errors.js");
/* harmony import */ var _useLocalStorage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./useLocalStorage */ "./node_modules/@solana/wallet-adapter-react/lib/useLocalStorage.js");
/* harmony import */ var _useWallet__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./useWallet */ "./node_modules/@solana/wallet-adapter-react/lib/useWallet.js");
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};






const initialState = {
  wallet: null,
  adapter: null,
  ready: false,
  publicKey: null,
  connected: false
};
const WalletProvider = ({
  children,
  wallets,
  autoConnect = false,
  onError: _onError = error => console.error(error),
  localStorageKey = 'walletName'
}) => {
  const [name, setName] = (0,_useLocalStorage__WEBPACK_IMPORTED_MODULE_1__.useLocalStorage)(localStorageKey, null);
  const {
    0: {
      wallet,
      adapter,
      ready,
      publicKey,
      connected
    },
    1: setState
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialState);
  const {
    0: connecting,
    1: setConnecting
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: disconnecting,
    1: setDisconnecting
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const isConnecting = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
  const isDisconnecting = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
  const isUnloading = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false); // Map of wallet names to wallets

  const walletsByName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => wallets.reduce((walletsByName, wallet) => {
    walletsByName[wallet.name] = wallet;
    return walletsByName;
  }, {}), [wallets]); // When the selected wallet changes, initialize the state

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const wallet = name && walletsByName[name] || null;
    const adapter = wallet && wallet.adapter();

    if (adapter) {
      const {
        ready,
        publicKey,
        connected
      } = adapter;
      setState({
        wallet,
        adapter,
        connected,
        publicKey,
        ready
      });
    } else {
      setState(initialState);
    }
  }, [name, walletsByName, setState]); // If autoConnect is enabled, try to connect when the adapter changes and is ready

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (isConnecting.current || connecting || connected || !autoConnect || !adapter || !ready) return;

    (function () {
      return __awaiter(this, void 0, void 0, function* () {
        isConnecting.current = true;
        setConnecting(true);

        try {
          yield adapter.connect();
        } catch (error) {
          // Clear the selected wallet
          setName(null); // Don't throw error, but onError will still be called
        } finally {
          setConnecting(false);
          isConnecting.current = false;
        }
      });
    })();
  }, [isConnecting, connecting, connected, autoConnect, adapter, ready, setConnecting, setName]); // If the window is closing or reloading, ignore disconnect and error events from the adapter

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    function listener() {
      isUnloading.current = true;
    }

    window.addEventListener('beforeunload', listener);
    return () => window.removeEventListener('beforeunload', listener);
  }, [isUnloading]); // Select a wallet by name

  const select = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(newName => __awaiter(void 0, void 0, void 0, function* () {
    if (name === newName) return;
    if (adapter) yield adapter.disconnect();
    setName(newName);
  }), [name, adapter, setName]); // Handle the adapter's ready event

  const onReady = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => setState(state => Object.assign(Object.assign({}, state), {
    ready: true
  })), [setState]); // Handle the adapter's connect event

  const onConnect = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    if (!adapter) return;
    const {
      connected,
      publicKey,
      ready
    } = adapter;
    setState(state => Object.assign(Object.assign({}, state), {
      connected,
      publicKey,
      ready
    }));
  }, [adapter, setState]); // Handle the adapter's disconnect event

  const onDisconnect = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    // Clear the selected wallet unless the window is unloading
    if (!isUnloading.current) setName(null);
  }, [isUnloading, setName]); // Handle the adapter's error event, and local errors

  const onError = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(error => {
    // Call the provided error handler unless the window is unloading
    if (!isUnloading.current) _onError(error);
    return error;
  }, [isUnloading, _onError]); // Connect the adapter to the wallet

  const connect = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => __awaiter(void 0, void 0, void 0, function* () {
    if (isConnecting.current || connecting || disconnecting || connected) return;
    if (!wallet || !adapter) throw onError(new _errors__WEBPACK_IMPORTED_MODULE_2__.WalletNotSelectedError());

    if (!ready) {
      // Clear the selected wallet
      setName(null);

      if (false) {}

      throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotReadyError());
    }

    isConnecting.current = true;
    setConnecting(true);

    try {
      yield adapter.connect();
    } catch (error) {
      // Clear the selected wallet
      setName(null); // Rethrow the error, and onError will also be called

      throw error;
    } finally {
      setConnecting(false);
      isConnecting.current = false;
    }
  }), [isConnecting, connecting, disconnecting, connected, wallet, adapter, onError, ready, setConnecting, setName]); // Disconnect the adapter from the wallet

  const disconnect = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => __awaiter(void 0, void 0, void 0, function* () {
    if (isDisconnecting.current || disconnecting) return;
    if (!adapter) return setName(null);
    isDisconnecting.current = true;
    setDisconnecting(true);

    try {
      yield adapter.disconnect();
    } catch (error) {
      // Clear the selected wallet
      setName(null); // Rethrow the error, and onError will also be called

      throw error;
    } finally {
      setDisconnecting(false);
      isDisconnecting.current = false;
    }
  }), [isDisconnecting, disconnecting, adapter, setDisconnecting, setName]); // Send a transaction using the provided connection

  const sendTransaction = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((transaction, connection, options) => __awaiter(void 0, void 0, void 0, function* () {
    if (!adapter) throw onError(new _errors__WEBPACK_IMPORTED_MODULE_2__.WalletNotSelectedError());
    if (!connected) throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotConnectedError());
    return yield adapter.sendTransaction(transaction, connection, options);
  }), [adapter, onError, connected]); // Sign a transaction if the wallet supports it

  const signTransaction = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => adapter && 'signTransaction' in adapter ? transaction => __awaiter(void 0, void 0, void 0, function* () {
    if (!connected) throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotConnectedError());
    return yield adapter.signTransaction(transaction);
  }) : undefined, [adapter, onError, connected]); // Sign multiple transactions if the wallet supports it

  const signAllTransactions = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => adapter && 'signAllTransactions' in adapter ? transactions => __awaiter(void 0, void 0, void 0, function* () {
    if (!connected) throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotConnectedError());
    return yield adapter.signAllTransactions(transactions);
  }) : undefined, [adapter, onError, connected]); // Sign an arbitrary message if the wallet supports it

  const signMessage = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => adapter && 'signMessage' in adapter ? message => __awaiter(void 0, void 0, void 0, function* () {
    if (!connected) throw onError(new _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_3__.WalletNotConnectedError());
    return yield adapter.signMessage(message);
  }) : undefined, [adapter, onError, connected]); // Setup and teardown event listeners when the adapter changes

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (adapter) {
      adapter.on('ready', onReady);
      adapter.on('connect', onConnect);
      adapter.on('disconnect', onDisconnect);
      adapter.on('error', onError);
      return () => {
        adapter.off('ready', onReady);
        adapter.off('connect', onConnect);
        adapter.off('disconnect', onDisconnect);
        adapter.off('error', onError);
      };
    }
  }, [adapter, onReady, onConnect, onDisconnect, onError]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_useWallet__WEBPACK_IMPORTED_MODULE_4__.WalletContext.Provider, {
    value: {
      wallets,
      autoConnect,
      wallet,
      adapter,
      publicKey,
      ready,
      connected,
      connecting,
      disconnecting,
      select,
      connect,
      disconnect,
      sendTransaction,
      signTransaction,
      signAllTransactions,
      signMessage
    }
  }, children);
};

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/errors.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/errors.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletNotSelectedError": () => (/* binding */ WalletNotSelectedError)
/* harmony export */ });
/* harmony import */ var _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @solana/wallet-adapter-base */ "./node_modules/@solana/wallet-adapter-base/lib/index.js");

class WalletNotSelectedError extends _solana_wallet_adapter_base__WEBPACK_IMPORTED_MODULE_0__.WalletError {
  constructor() {
    super(...arguments);
    this.name = 'WalletNotSelectedError';
  }

}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/index.js":
/*!****************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/index.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ConnectionProvider__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ConnectionProvider */ "./node_modules/@solana/wallet-adapter-react/lib/ConnectionProvider.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _ConnectionProvider__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _ConnectionProvider__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors */ "./node_modules/@solana/wallet-adapter-react/lib/errors.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _errors__WEBPACK_IMPORTED_MODULE_1__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _errors__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _useAnchorWallet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useAnchorWallet */ "./node_modules/@solana/wallet-adapter-react/lib/useAnchorWallet.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useAnchorWallet__WEBPACK_IMPORTED_MODULE_2__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useAnchorWallet__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _useConnection__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./useConnection */ "./node_modules/@solana/wallet-adapter-react/lib/useConnection.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useConnection__WEBPACK_IMPORTED_MODULE_3__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useConnection__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _useLocalStorage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./useLocalStorage */ "./node_modules/@solana/wallet-adapter-react/lib/useLocalStorage.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useLocalStorage__WEBPACK_IMPORTED_MODULE_4__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useLocalStorage__WEBPACK_IMPORTED_MODULE_4__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _useWallet__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./useWallet */ "./node_modules/@solana/wallet-adapter-react/lib/useWallet.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _useWallet__WEBPACK_IMPORTED_MODULE_5__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _useWallet__WEBPACK_IMPORTED_MODULE_5__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _WalletProvider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./WalletProvider */ "./node_modules/@solana/wallet-adapter-react/lib/WalletProvider.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _WalletProvider__WEBPACK_IMPORTED_MODULE_6__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _WalletProvider__WEBPACK_IMPORTED_MODULE_6__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);








/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/useAnchorWallet.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/useAnchorWallet.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useAnchorWallet": () => (/* binding */ useAnchorWallet)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _useWallet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./useWallet */ "./node_modules/@solana/wallet-adapter-react/lib/useWallet.js");


function useAnchorWallet() {
  const {
    publicKey,
    signTransaction,
    signAllTransactions
  } = (0,_useWallet__WEBPACK_IMPORTED_MODULE_1__.useWallet)();
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => publicKey && signTransaction && signAllTransactions ? {
    publicKey,
    signTransaction,
    signAllTransactions
  } : undefined, [publicKey, signTransaction, signAllTransactions]);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/useConnection.js":
/*!************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/useConnection.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConnectionContext": () => (/* binding */ ConnectionContext),
/* harmony export */   "useConnection": () => (/* binding */ useConnection)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const ConnectionContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
function useConnection() {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(ConnectionContext);
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/useLocalStorage.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/useLocalStorage.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useLocalStorage": () => (/* binding */ useLocalStorage)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useLocalStorage(key, defaultState) {
  const {
    0: value,
    1: setValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => {
    if (typeof localStorage === 'undefined') return defaultState;
    const value = localStorage.getItem(key);

    try {
      return value ? JSON.parse(value) : defaultState;
    } catch (error) {
      console.warn(error);
      return defaultState;
    }
  });
  const setLocalStorage = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(newValue => {
    if (newValue === value) return;
    setValue(newValue);

    if (newValue === null) {
      localStorage.removeItem(key);
    } else {
      try {
        localStorage.setItem(key, JSON.stringify(newValue));
      } catch (error) {
        console.error(error);
      }
    }
  }, [value, setValue, key]);
  return [value, setLocalStorage];
}

/***/ }),

/***/ "./node_modules/@solana/wallet-adapter-react/lib/useWallet.js":
/*!********************************************************************!*\
  !*** ./node_modules/@solana/wallet-adapter-react/lib/useWallet.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletContext": () => (/* binding */ WalletContext),
/* harmony export */   "useWallet": () => (/* binding */ useWallet)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const WalletContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
function useWallet() {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(WalletContext);
}

/***/ }),

/***/ "@solana/web3.js":
/*!**********************************!*\
  !*** external "@solana/web3.js" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("@solana/web3.js");

/***/ }),

/***/ "eventemitter3":
/*!********************************!*\
  !*** external "eventemitter3" ***!
  \********************************/
/***/ ((module) => {

module.exports = require("eventemitter3");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUVBOzs7QUFDQSxTQUFTRSxZQUFULEdBQXdCO0FBQ3BCLHNCQUNFO0FBQUssYUFBUyxFQUFDLFlBQWY7QUFBQSwyQkFDRTtBQUFBLDhCQUNFO0FBQUksaUJBQVMsRUFBQyxrREFBZDtBQUFBLDRDQUNVO0FBQU0sbUJBQVMsRUFBQyxtQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFLRTtBQUFHLGlCQUFTLEVBQUMsZUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUxGLGVBUUU7QUFBSyxpQkFBUyxFQUFDLFFBQWY7QUFBQSwrQkFDRSw4REFBQyw4RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFnQkg7O0FBRUQsaUVBQWVBLFlBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEJBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDZSxTQUFTSSxJQUFULEdBQWdCO0FBQzdCLFFBQU07QUFBRUMsSUFBQUE7QUFBRixNQUFnQkYsdUVBQVMsRUFBL0I7QUFDQSxRQUFNRyxNQUFNLEdBQUdKLHNEQUFTLEVBQXhCOztBQUNDLE1BQUksQ0FBQ0csU0FBTCxFQUFnQjtBQUNkLHdCQUNFO0FBQUssZUFBUyxFQUFDLGVBQWY7QUFBQSw2QkFDRSw4REFBQyx1RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBS0QsR0FORCxNQU1PO0FBQ0xDLElBQUFBLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVo7QUFDRDs7QUFFRixzQkFBTyw2SUFBUDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsQkQ7QUFDQTtBQUNPLE1BQU1FLGlCQUFOLFNBQWdDRCxzREFBaEMsQ0FBNkM7QUFFN0MsSUFBSUUsb0JBQUo7O0FBQ1AsQ0FBQyxVQUFVQSxvQkFBVixFQUFnQztBQUM3QkEsRUFBQUEsb0JBQW9CLENBQUMsU0FBRCxDQUFwQixHQUFrQyxjQUFsQztBQUNBQSxFQUFBQSxvQkFBb0IsQ0FBQyxTQUFELENBQXBCLEdBQWtDLFNBQWxDO0FBQ0FBLEVBQUFBLG9CQUFvQixDQUFDLFFBQUQsQ0FBcEIsR0FBaUMsUUFBakM7QUFDSCxDQUpELEVBSUdBLG9CQUFvQixLQUFLQSxvQkFBb0IsR0FBRyxFQUE1QixDQUp2Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTE8sTUFBTUMsV0FBTixTQUEwQkMsS0FBMUIsQ0FBZ0M7QUFDbkM7QUFDQUMsRUFBQUEsV0FBVyxDQUFDQyxPQUFELEVBQVVDLEtBQVYsRUFBaUI7QUFDeEIsVUFBTUQsT0FBTjtBQUNBLFNBQUtDLEtBQUwsR0FBYUEsS0FBYjtBQUNIOztBQUxrQztBQU9oQyxNQUFNQyxtQkFBTixTQUFrQ0wsV0FBbEMsQ0FBOEM7QUFDakRFLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0ksU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSxxQkFBWjtBQUNIOztBQUpnRDtBQU05QyxNQUFNQyx1QkFBTixTQUFzQ1IsV0FBdEMsQ0FBa0Q7QUFDckRFLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0ksU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSx5QkFBWjtBQUNIOztBQUpvRDtBQU1sRCxNQUFNRSxtQkFBTixTQUFrQ1QsV0FBbEMsQ0FBOEM7QUFDakRFLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0ksU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSxxQkFBWjtBQUNIOztBQUpnRDtBQU05QyxNQUFNRyxxQkFBTixTQUFvQ1YsV0FBcEMsQ0FBZ0Q7QUFDbkRFLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0ksU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSx1QkFBWjtBQUNIOztBQUprRDtBQU1oRCxNQUFNSSx1QkFBTixTQUFzQ1gsV0FBdEMsQ0FBa0Q7QUFDckRFLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0ksU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSx5QkFBWjtBQUNIOztBQUpvRDtBQU1sRCxNQUFNSyx3QkFBTixTQUF1Q1osV0FBdkMsQ0FBbUQ7QUFDdERFLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0ksU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSwwQkFBWjtBQUNIOztBQUpxRDtBQU1uRCxNQUFNTSxrQkFBTixTQUFpQ2IsV0FBakMsQ0FBNkM7QUFDaERFLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0ksU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSxvQkFBWjtBQUNIOztBQUorQztBQU03QyxNQUFNTyxvQkFBTixTQUFtQ2QsV0FBbkMsQ0FBK0M7QUFDbERFLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0ksU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSxzQkFBWjtBQUNIOztBQUppRDtBQU0vQyxNQUFNUSxrQkFBTixTQUFpQ2YsV0FBakMsQ0FBNkM7QUFDaERFLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0ksU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSxvQkFBWjtBQUNIOztBQUorQztBQU03QyxNQUFNUyx1QkFBTixTQUFzQ2hCLFdBQXRDLENBQWtEO0FBQ3JERSxFQUFBQSxXQUFXLEdBQUc7QUFDVixVQUFNLEdBQUdJLFNBQVQ7QUFDQSxTQUFLQyxJQUFMLEdBQVkseUJBQVo7QUFDSDs7QUFKb0Q7QUFNbEQsTUFBTVUsMEJBQU4sU0FBeUNqQixXQUF6QyxDQUFxRDtBQUN4REUsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHSSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLDRCQUFaO0FBQ0g7O0FBSnVEO0FBTXJELE1BQU1XLHNCQUFOLFNBQXFDbEIsV0FBckMsQ0FBaUQ7QUFDcERFLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0ksU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSx3QkFBWjtBQUNIOztBQUptRDtBQU1qRCxNQUFNWSwwQkFBTixTQUF5Q25CLFdBQXpDLENBQXFEO0FBQ3hERSxFQUFBQSxXQUFXLEdBQUc7QUFDVixVQUFNLEdBQUdJLFNBQVQ7QUFDQSxTQUFLQyxJQUFMLEdBQVksNEJBQVo7QUFDSDs7QUFKdUQ7QUFNckQsTUFBTWEsa0JBQU4sU0FBaUNwQixXQUFqQyxDQUE2QztBQUNoREUsRUFBQUEsV0FBVyxHQUFHO0FBQ1YsVUFBTSxHQUFHSSxTQUFUO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLG9CQUFaO0FBQ0g7O0FBSitDO0FBTTdDLE1BQU1jLHdCQUFOLFNBQXVDckIsV0FBdkMsQ0FBbUQ7QUFDdERFLEVBQUFBLFdBQVcsR0FBRztBQUNWLFVBQU0sR0FBR0ksU0FBVDtBQUNBLFNBQUtDLElBQUwsR0FBWSwwQkFBWjtBQUNIOztBQUpxRDtBQU1uRCxNQUFNZSx1QkFBTixTQUFzQ3RCLFdBQXRDLENBQWtEO0FBQ3JERSxFQUFBQSxXQUFXLEdBQUc7QUFDVixVQUFNLEdBQUdJLFNBQVQ7QUFDQSxTQUFLQyxJQUFMLEdBQVkseUJBQVo7QUFDSDs7QUFKb0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pHekQ7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDRkEsSUFBSWdCLFNBQVMsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxTQUFkLElBQTRCLFVBQVVDLE9BQVYsRUFBbUJDLFVBQW5CLEVBQStCQyxDQUEvQixFQUFrQ0MsU0FBbEMsRUFBNkM7QUFDckYsV0FBU0MsS0FBVCxDQUFlQyxLQUFmLEVBQXNCO0FBQUUsV0FBT0EsS0FBSyxZQUFZSCxDQUFqQixHQUFxQkcsS0FBckIsR0FBNkIsSUFBSUgsQ0FBSixDQUFNLFVBQVVJLE9BQVYsRUFBbUI7QUFBRUEsTUFBQUEsT0FBTyxDQUFDRCxLQUFELENBQVA7QUFBaUIsS0FBNUMsQ0FBcEM7QUFBb0Y7O0FBQzVHLFNBQU8sS0FBS0gsQ0FBQyxLQUFLQSxDQUFDLEdBQUdLLE9BQVQsQ0FBTixFQUF5QixVQUFVRCxPQUFWLEVBQW1CRSxNQUFuQixFQUEyQjtBQUN2RCxhQUFTQyxTQUFULENBQW1CSixLQUFuQixFQUEwQjtBQUFFLFVBQUk7QUFBRUssUUFBQUEsSUFBSSxDQUFDUCxTQUFTLENBQUNRLElBQVYsQ0FBZU4sS0FBZixDQUFELENBQUo7QUFBOEIsT0FBcEMsQ0FBcUMsT0FBT08sQ0FBUCxFQUFVO0FBQUVKLFFBQUFBLE1BQU0sQ0FBQ0ksQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDM0YsYUFBU0MsUUFBVCxDQUFrQlIsS0FBbEIsRUFBeUI7QUFBRSxVQUFJO0FBQUVLLFFBQUFBLElBQUksQ0FBQ1AsU0FBUyxDQUFDLE9BQUQsQ0FBVCxDQUFtQkUsS0FBbkIsQ0FBRCxDQUFKO0FBQWtDLE9BQXhDLENBQXlDLE9BQU9PLENBQVAsRUFBVTtBQUFFSixRQUFBQSxNQUFNLENBQUNJLENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzlGLGFBQVNGLElBQVQsQ0FBY0ksTUFBZCxFQUFzQjtBQUFFQSxNQUFBQSxNQUFNLENBQUNDLElBQVAsR0FBY1QsT0FBTyxDQUFDUSxNQUFNLENBQUNULEtBQVIsQ0FBckIsR0FBc0NELEtBQUssQ0FBQ1UsTUFBTSxDQUFDVCxLQUFSLENBQUwsQ0FBb0JXLElBQXBCLENBQXlCUCxTQUF6QixFQUFvQ0ksUUFBcEMsQ0FBdEM7QUFBc0Y7O0FBQzlHSCxJQUFBQSxJQUFJLENBQUMsQ0FBQ1AsU0FBUyxHQUFHQSxTQUFTLENBQUNjLEtBQVYsQ0FBZ0JqQixPQUFoQixFQUF5QkMsVUFBVSxJQUFJLEVBQXZDLENBQWIsRUFBeURVLElBQXpELEVBQUQsQ0FBSjtBQUNILEdBTE0sQ0FBUDtBQU1ILENBUkQ7O0FBU08sU0FBU08sSUFBVCxDQUFjQyxRQUFkLEVBQXdCQyxRQUF4QixFQUFrQ0MsS0FBbEMsRUFBeUM7QUFDNUMsTUFBSUEsS0FBSyxHQUFHLENBQVosRUFBZTtBQUNYQyxJQUFBQSxVQUFVLENBQUMsTUFBTXZCLFNBQVMsQ0FBQyxJQUFELEVBQU8sS0FBSyxDQUFaLEVBQWUsS0FBSyxDQUFwQixFQUF1QixhQUFhO0FBQzFELFlBQU1nQixJQUFJLEdBQUcsTUFBTUksUUFBUSxFQUEzQjtBQUNBLFVBQUksQ0FBQ0osSUFBTCxFQUNJRyxJQUFJLENBQUNDLFFBQUQsRUFBV0MsUUFBWCxFQUFxQkMsS0FBSyxHQUFHLENBQTdCLENBQUo7QUFDUCxLQUp5QixDQUFoQixFQUlORCxRQUpNLENBQVY7QUFLSDtBQUNKO0FBQ00sU0FBU0csY0FBVCxDQUF3QkMsT0FBeEIsRUFBaUNDLFlBQWpDLEVBQStDQyxTQUEvQyxFQUEwRDtBQUM3RFIsRUFBQUEsSUFBSSxDQUFDLE1BQU07QUFDUCxVQUFNO0FBQUVTLE1BQUFBO0FBQUYsUUFBWUgsT0FBbEI7O0FBQ0EsUUFBSUcsS0FBSixFQUFXO0FBQ1AsVUFBSSxDQUFDSCxPQUFPLENBQUNJLElBQVIsQ0FBYSxPQUFiLENBQUwsRUFBNEI7QUFDeEJDLFFBQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFjLEdBQUVOLE9BQU8sQ0FBQzlDLFdBQVIsQ0FBb0JLLElBQUssMENBQXpDO0FBQ0g7QUFDSjs7QUFDRCxXQUFPNEMsS0FBUDtBQUNILEdBUkcsRUFRREYsWUFSQyxFQVFhQyxTQVJiLENBQUo7QUFTSDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1QkQsSUFBSTNCLFNBQVMsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxTQUFkLElBQTRCLFVBQVVDLE9BQVYsRUFBbUJDLFVBQW5CLEVBQStCQyxDQUEvQixFQUFrQ0MsU0FBbEMsRUFBNkM7QUFDckYsV0FBU0MsS0FBVCxDQUFlQyxLQUFmLEVBQXNCO0FBQUUsV0FBT0EsS0FBSyxZQUFZSCxDQUFqQixHQUFxQkcsS0FBckIsR0FBNkIsSUFBSUgsQ0FBSixDQUFNLFVBQVVJLE9BQVYsRUFBbUI7QUFBRUEsTUFBQUEsT0FBTyxDQUFDRCxLQUFELENBQVA7QUFBaUIsS0FBNUMsQ0FBcEM7QUFBb0Y7O0FBQzVHLFNBQU8sS0FBS0gsQ0FBQyxLQUFLQSxDQUFDLEdBQUdLLE9BQVQsQ0FBTixFQUF5QixVQUFVRCxPQUFWLEVBQW1CRSxNQUFuQixFQUEyQjtBQUN2RCxhQUFTQyxTQUFULENBQW1CSixLQUFuQixFQUEwQjtBQUFFLFVBQUk7QUFBRUssUUFBQUEsSUFBSSxDQUFDUCxTQUFTLENBQUNRLElBQVYsQ0FBZU4sS0FBZixDQUFELENBQUo7QUFBOEIsT0FBcEMsQ0FBcUMsT0FBT08sQ0FBUCxFQUFVO0FBQUVKLFFBQUFBLE1BQU0sQ0FBQ0ksQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDM0YsYUFBU0MsUUFBVCxDQUFrQlIsS0FBbEIsRUFBeUI7QUFBRSxVQUFJO0FBQUVLLFFBQUFBLElBQUksQ0FBQ1AsU0FBUyxDQUFDLE9BQUQsQ0FBVCxDQUFtQkUsS0FBbkIsQ0FBRCxDQUFKO0FBQWtDLE9BQXhDLENBQXlDLE9BQU9PLENBQVAsRUFBVTtBQUFFSixRQUFBQSxNQUFNLENBQUNJLENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzlGLGFBQVNGLElBQVQsQ0FBY0ksTUFBZCxFQUFzQjtBQUFFQSxNQUFBQSxNQUFNLENBQUNDLElBQVAsR0FBY1QsT0FBTyxDQUFDUSxNQUFNLENBQUNULEtBQVIsQ0FBckIsR0FBc0NELEtBQUssQ0FBQ1UsTUFBTSxDQUFDVCxLQUFSLENBQUwsQ0FBb0JXLElBQXBCLENBQXlCUCxTQUF6QixFQUFvQ0ksUUFBcEMsQ0FBdEM7QUFBc0Y7O0FBQzlHSCxJQUFBQSxJQUFJLENBQUMsQ0FBQ1AsU0FBUyxHQUFHQSxTQUFTLENBQUNjLEtBQVYsQ0FBZ0JqQixPQUFoQixFQUF5QkMsVUFBVSxJQUFJLEVBQXZDLENBQWIsRUFBeURVLElBQXpELEVBQUQsQ0FBSjtBQUNILEdBTE0sQ0FBUDtBQU1ILENBUkQ7O0FBU0EsSUFBSW9CLE1BQU0sR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxNQUFkLElBQXlCLFVBQVVDLENBQVYsRUFBYXBCLENBQWIsRUFBZ0I7QUFDbEQsTUFBSXFCLENBQUMsR0FBRyxFQUFSOztBQUNBLE9BQUssSUFBSUMsQ0FBVCxJQUFjRixDQUFkLEVBQWlCLElBQUlHLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQkMsY0FBakIsQ0FBZ0NDLElBQWhDLENBQXFDTixDQUFyQyxFQUF3Q0UsQ0FBeEMsS0FBOEN0QixDQUFDLENBQUMyQixPQUFGLENBQVVMLENBQVYsSUFBZSxDQUFqRSxFQUNiRCxDQUFDLENBQUNDLENBQUQsQ0FBRCxHQUFPRixDQUFDLENBQUNFLENBQUQsQ0FBUjs7QUFDSixNQUFJRixDQUFDLElBQUksSUFBTCxJQUFhLE9BQU9HLE1BQU0sQ0FBQ0sscUJBQWQsS0FBd0MsVUFBekQsRUFDSSxLQUFLLElBQUlDLENBQUMsR0FBRyxDQUFSLEVBQVdQLENBQUMsR0FBR0MsTUFBTSxDQUFDSyxxQkFBUCxDQUE2QlIsQ0FBN0IsQ0FBcEIsRUFBcURTLENBQUMsR0FBR1AsQ0FBQyxDQUFDUSxNQUEzRCxFQUFtRUQsQ0FBQyxFQUFwRSxFQUF3RTtBQUNwRSxRQUFJN0IsQ0FBQyxDQUFDMkIsT0FBRixDQUFVTCxDQUFDLENBQUNPLENBQUQsQ0FBWCxJQUFrQixDQUFsQixJQUF1Qk4sTUFBTSxDQUFDQyxTQUFQLENBQWlCTyxvQkFBakIsQ0FBc0NMLElBQXRDLENBQTJDTixDQUEzQyxFQUE4Q0UsQ0FBQyxDQUFDTyxDQUFELENBQS9DLENBQTNCLEVBQ0lSLENBQUMsQ0FBQ0MsQ0FBQyxDQUFDTyxDQUFELENBQUYsQ0FBRCxHQUFVVCxDQUFDLENBQUNFLENBQUMsQ0FBQ08sQ0FBRCxDQUFGLENBQVg7QUFDUDtBQUNMLFNBQU9SLENBQVA7QUFDSCxDQVZEOztBQVdBO0FBQ0E7QUFDTyxNQUFNVyx1QkFBTixTQUFzQ3RFLHVEQUF0QyxDQUF3RDtBQUMzRHVFLEVBQUFBLGVBQWUsQ0FBQ0MsV0FBRCxFQUFjQyxVQUFkLEVBQTBCQyxPQUFPLEdBQUcsRUFBcEMsRUFBd0M7QUFDbkQsV0FBT2pELFNBQVMsQ0FBQyxJQUFELEVBQU8sS0FBSyxDQUFaLEVBQWUsS0FBSyxDQUFwQixFQUF1QixhQUFhO0FBQ2hELFVBQUk2QixJQUFJLEdBQUcsSUFBWDs7QUFDQSxVQUFJO0FBQ0EsWUFBSTtBQUNBa0IsVUFBQUEsV0FBVyxDQUFDRyxRQUFaLEtBQXlCSCxXQUFXLENBQUNHLFFBQVosR0FBdUIsS0FBSy9FLFNBQUwsSUFBa0JnRixTQUFsRTtBQUNBSixVQUFBQSxXQUFXLENBQUNLLGVBQVosS0FBZ0NMLFdBQVcsQ0FBQ0ssZUFBWixHQUE4QixDQUFDLE1BQU1KLFVBQVUsQ0FBQ0ssa0JBQVgsQ0FBOEIsV0FBOUIsQ0FBUCxFQUFtREMsU0FBakg7O0FBQ0EsZ0JBQU07QUFBRUMsWUFBQUE7QUFBRixjQUFjTixPQUFwQjtBQUFBLGdCQUE2Qk8sV0FBVyxHQUFHeEIsTUFBTSxDQUFDaUIsT0FBRCxFQUFVLENBQUMsU0FBRCxDQUFWLENBQWpEOztBQUNBLFdBQUNNLE9BQU8sS0FBSyxJQUFaLElBQW9CQSxPQUFPLEtBQUssS0FBSyxDQUFyQyxHQUF5QyxLQUFLLENBQTlDLEdBQWtEQSxPQUFPLENBQUNaLE1BQTNELEtBQXNFSSxXQUFXLENBQUNVLFdBQVosQ0FBd0IsR0FBR0YsT0FBM0IsQ0FBdEU7QUFDQVIsVUFBQUEsV0FBVyxHQUFHLE1BQU0sS0FBS1csZUFBTCxDQUFxQlgsV0FBckIsQ0FBcEI7QUFDQSxnQkFBTVksY0FBYyxHQUFHWixXQUFXLENBQUNhLFNBQVosRUFBdkI7QUFDQSxpQkFBTyxNQUFNWixVQUFVLENBQUNhLGtCQUFYLENBQThCRixjQUE5QixFQUE4Q0gsV0FBOUMsQ0FBYjtBQUNILFNBUkQsQ0FTQSxPQUFPM0UsS0FBUCxFQUFjO0FBQ1Y7QUFDQSxjQUFJQSxLQUFLLFlBQVlKLGdEQUFyQixFQUFrQztBQUM5Qm9ELFlBQUFBLElBQUksR0FBRyxLQUFQO0FBQ0Esa0JBQU1oRCxLQUFOO0FBQ0g7O0FBQ0QsZ0JBQU0sSUFBSWEsK0RBQUosQ0FBK0JiLEtBQUssS0FBSyxJQUFWLElBQWtCQSxLQUFLLEtBQUssS0FBSyxDQUFqQyxHQUFxQyxLQUFLLENBQTFDLEdBQThDQSxLQUFLLENBQUNELE9BQW5GLEVBQTRGQyxLQUE1RixDQUFOO0FBQ0g7QUFDSixPQWxCRCxDQW1CQSxPQUFPQSxLQUFQLEVBQWM7QUFDVixZQUFJZ0QsSUFBSixFQUFVO0FBQ04sZUFBS0EsSUFBTCxDQUFVLE9BQVYsRUFBbUJoRCxLQUFuQjtBQUNIOztBQUNELGNBQU1BLEtBQU47QUFDSDtBQUNKLEtBM0JlLENBQWhCO0FBNEJIOztBQTlCMEQ7QUFnQ3hELE1BQU1pRiw4QkFBTixTQUE2Q2pCLHVCQUE3QyxDQUFxRTs7Ozs7Ozs7Ozs7Ozs7OztBQ3RENUU7QUFDTyxNQUFNa0IsTUFBTSxHQUFJQyxLQUFELElBQVc7QUFDN0IsUUFBTUMsY0FBYyxHQUFHRCxLQUFLLENBQUNFLE9BQU4sSUFBaUJGLEtBQUssQ0FBQ0csU0FBdkIsR0FBbUMsZUFBbkMsR0FBcUQsUUFBNUU7QUFDQSxzQkFBUXZHLDBEQUFBLENBQW9CLFFBQXBCLEVBQThCO0FBQUV5RyxJQUFBQSxTQUFTLEVBQUcseUJBQXdCTCxLQUFLLENBQUNLLFNBQU4sSUFBbUIsRUFBRyxFQUE1RDtBQUErREMsSUFBQUEsUUFBUSxFQUFFTixLQUFLLENBQUNNLFFBQS9FO0FBQXlGQyxJQUFBQSxPQUFPLEVBQUVQLEtBQUssQ0FBQ08sT0FBeEc7QUFBaUhDLElBQUFBLEtBQUssRUFBRXBDLE1BQU0sQ0FBQ3FDLE1BQVAsQ0FBYztBQUFFUixNQUFBQTtBQUFGLEtBQWQsRUFBa0NELEtBQUssQ0FBQ1EsS0FBeEMsQ0FBeEg7QUFBd0tFLElBQUFBLFFBQVEsRUFBRVYsS0FBSyxDQUFDVSxRQUFOLElBQWtCLENBQXBNO0FBQXVNQyxJQUFBQSxJQUFJLEVBQUU7QUFBN00sR0FBOUIsRUFDSlgsS0FBSyxDQUFDRyxTQUFOLGlCQUFtQnZHLDBEQUFBLENBQW9CLEdBQXBCLEVBQXlCO0FBQUV5RyxJQUFBQSxTQUFTLEVBQUU7QUFBYixHQUF6QixFQUE0RUwsS0FBSyxDQUFDRyxTQUFsRixDQURmLEVBRUpILEtBQUssQ0FBQ1ksUUFGRixFQUdKWixLQUFLLENBQUNFLE9BQU4saUJBQWlCdEcsMERBQUEsQ0FBb0IsR0FBcEIsRUFBeUI7QUFBRXlHLElBQUFBLFNBQVMsRUFBRTtBQUFiLEdBQXpCLEVBQTBFTCxLQUFLLENBQUNFLE9BQWhGLENBSGIsQ0FBUjtBQUlILENBTk07Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUDtBQUNPLE1BQU1hLFFBQVEsR0FBRyxDQUFDO0FBQUVDLEVBQUFBLEVBQUY7QUFBTUosRUFBQUEsUUFBTjtBQUFnQkssRUFBQUEsUUFBUSxHQUFHO0FBQTNCLENBQUQsS0FBd0M7QUFDNUQsUUFBTUMsR0FBRyxHQUFHSiw2Q0FBTSxDQUFDLElBQUQsQ0FBbEI7QUFDQSxRQUFNSyxPQUFPLEdBQUdMLDZDQUFNLENBQUMsSUFBRCxDQUF0QjtBQUNBLFFBQU1NLFVBQVUsR0FBRyx1QkFBbkI7O0FBQ0EsUUFBTUMsWUFBWSxHQUFHLE1BQU07QUFDdkIsVUFBTUMsSUFBSSxHQUFHSixHQUFHLENBQUNLLE9BQWpCO0FBQ0EsUUFBSSxDQUFDRCxJQUFMLEVBQ0k7QUFDSkUsSUFBQUEscUJBQXFCLENBQUMsTUFBTTtBQUN4QkYsTUFBQUEsSUFBSSxDQUFDZCxLQUFMLENBQVdpQixNQUFYLEdBQW9CSCxJQUFJLENBQUNJLFlBQUwsR0FBb0IsSUFBeEM7QUFDSCxLQUZvQixDQUFyQjtBQUdILEdBUEQ7O0FBUUEsUUFBTUMsYUFBYSxHQUFHLE1BQU07QUFDeEIsVUFBTUwsSUFBSSxHQUFHSixHQUFHLENBQUNLLE9BQWpCO0FBQ0EsUUFBSSxDQUFDRCxJQUFMLEVBQ0k7QUFDSkUsSUFBQUEscUJBQXFCLENBQUMsTUFBTTtBQUN4QkYsTUFBQUEsSUFBSSxDQUFDZCxLQUFMLENBQVdpQixNQUFYLEdBQW9CSCxJQUFJLENBQUNNLFlBQUwsR0FBb0IsSUFBeEM7QUFDQU4sTUFBQUEsSUFBSSxDQUFDZCxLQUFMLENBQVdxQixRQUFYLEdBQXNCLFFBQXRCO0FBQ0FMLE1BQUFBLHFCQUFxQixDQUFDLE1BQU07QUFDeEJGLFFBQUFBLElBQUksQ0FBQ2QsS0FBTCxDQUFXaUIsTUFBWCxHQUFvQixHQUFwQjtBQUNILE9BRm9CLENBQXJCO0FBR0gsS0FOb0IsQ0FBckI7QUFPSCxHQVhEOztBQVlBWixFQUFBQSxzREFBZSxDQUFDLE1BQU07QUFDbEIsUUFBSUksUUFBSixFQUFjO0FBQ1ZJLE1BQUFBLFlBQVk7QUFDZixLQUZELE1BR0s7QUFDRE0sTUFBQUEsYUFBYTtBQUNoQjtBQUNKLEdBUGMsRUFPWixDQUFDVixRQUFELENBUFksQ0FBZjtBQVFBSixFQUFBQSxzREFBZSxDQUFDLE1BQU07QUFDbEIsVUFBTVMsSUFBSSxHQUFHSixHQUFHLENBQUNLLE9BQWpCO0FBQ0EsUUFBSSxDQUFDRCxJQUFMLEVBQ0k7O0FBQ0osYUFBU1EsY0FBVCxHQUEwQjtBQUN0QixVQUFJLENBQUNSLElBQUwsRUFDSTtBQUNKQSxNQUFBQSxJQUFJLENBQUNkLEtBQUwsQ0FBV3FCLFFBQVgsR0FBc0JaLFFBQVEsR0FBRyxTQUFILEdBQWUsUUFBN0M7O0FBQ0EsVUFBSUEsUUFBSixFQUFjO0FBQ1ZLLFFBQUFBLElBQUksQ0FBQ2QsS0FBTCxDQUFXaUIsTUFBWCxHQUFvQixNQUFwQjtBQUNIO0FBQ0o7O0FBQ0QsYUFBU00sbUJBQVQsQ0FBNkJDLEtBQTdCLEVBQW9DO0FBQ2hDLFVBQUlWLElBQUksSUFBSVUsS0FBSyxDQUFDQyxNQUFOLEtBQWlCWCxJQUF6QixJQUFpQ1UsS0FBSyxDQUFDRSxZQUFOLEtBQXVCLFFBQTVELEVBQXNFO0FBQ2xFSixRQUFBQSxjQUFjO0FBQ2pCO0FBQ0o7O0FBQ0QsUUFBSVgsT0FBTyxDQUFDSSxPQUFaLEVBQXFCO0FBQ2pCTyxNQUFBQSxjQUFjO0FBQ2RYLE1BQUFBLE9BQU8sQ0FBQ0ksT0FBUixHQUFrQixLQUFsQjtBQUNIOztBQUNERCxJQUFBQSxJQUFJLENBQUNhLGdCQUFMLENBQXNCLGVBQXRCLEVBQXVDSixtQkFBdkM7QUFDQSxXQUFPLE1BQU1ULElBQUksQ0FBQ2MsbUJBQUwsQ0FBeUIsZUFBekIsRUFBMENMLG1CQUExQyxDQUFiO0FBQ0gsR0F2QmMsRUF1QlosQ0FBQ2QsUUFBRCxDQXZCWSxDQUFmO0FBd0JBLHNCQUFRckgsMERBQUEsQ0FBb0IsS0FBcEIsRUFBMkI7QUFBRWdILElBQUFBLFFBQVEsRUFBRUEsUUFBWjtBQUFzQlAsSUFBQUEsU0FBUyxFQUFFLHlCQUFqQztBQUE0RFcsSUFBQUEsRUFBRSxFQUFFQSxFQUFoRTtBQUFvRUUsSUFBQUEsR0FBRyxFQUFFQSxHQUF6RTtBQUE4RW1CLElBQUFBLElBQUksRUFBRSxRQUFwRjtBQUE4RjdCLElBQUFBLEtBQUssRUFBRTtBQUFFaUIsTUFBQUEsTUFBTSxFQUFFLENBQVY7QUFBYUwsTUFBQUEsVUFBVSxFQUFFRCxPQUFPLENBQUNJLE9BQVIsR0FBa0JwQyxTQUFsQixHQUE4QmlDO0FBQXZEO0FBQXJHLEdBQTNCLENBQVI7QUFDSCxDQXpETTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQLElBQUlwRCxNQUFNLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsTUFBZCxJQUF5QixVQUFVQyxDQUFWLEVBQWFwQixDQUFiLEVBQWdCO0FBQ2xELE1BQUlxQixDQUFDLEdBQUcsRUFBUjs7QUFDQSxPQUFLLElBQUlDLENBQVQsSUFBY0YsQ0FBZCxFQUFpQixJQUFJRyxNQUFNLENBQUNDLFNBQVAsQ0FBaUJDLGNBQWpCLENBQWdDQyxJQUFoQyxDQUFxQ04sQ0FBckMsRUFBd0NFLENBQXhDLEtBQThDdEIsQ0FBQyxDQUFDMkIsT0FBRixDQUFVTCxDQUFWLElBQWUsQ0FBakUsRUFDYkQsQ0FBQyxDQUFDQyxDQUFELENBQUQsR0FBT0YsQ0FBQyxDQUFDRSxDQUFELENBQVI7O0FBQ0osTUFBSUYsQ0FBQyxJQUFJLElBQUwsSUFBYSxPQUFPRyxNQUFNLENBQUNLLHFCQUFkLEtBQXdDLFVBQXpELEVBQ0ksS0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBUixFQUFXUCxDQUFDLEdBQUdDLE1BQU0sQ0FBQ0sscUJBQVAsQ0FBNkJSLENBQTdCLENBQXBCLEVBQXFEUyxDQUFDLEdBQUdQLENBQUMsQ0FBQ1EsTUFBM0QsRUFBbUVELENBQUMsRUFBcEUsRUFBd0U7QUFDcEUsUUFBSTdCLENBQUMsQ0FBQzJCLE9BQUYsQ0FBVUwsQ0FBQyxDQUFDTyxDQUFELENBQVgsSUFBa0IsQ0FBbEIsSUFBdUJOLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQk8sb0JBQWpCLENBQXNDTCxJQUF0QyxDQUEyQ04sQ0FBM0MsRUFBOENFLENBQUMsQ0FBQ08sQ0FBRCxDQUEvQyxDQUEzQixFQUNJUixDQUFDLENBQUNDLENBQUMsQ0FBQ08sQ0FBRCxDQUFGLENBQUQsR0FBVVQsQ0FBQyxDQUFDRSxDQUFDLENBQUNPLENBQUQsQ0FBRixDQUFYO0FBQ1A7QUFDTCxTQUFPUixDQUFQO0FBQ0gsQ0FWRDs7QUFXQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU11RSxtQkFBbUIsR0FBSUMsRUFBRCxJQUFRO0FBQ3ZDLE1BQUk7QUFBRTlCLElBQUFBLFFBQUY7QUFBWU4sSUFBQUEsUUFBWjtBQUFzQkMsSUFBQUE7QUFBdEIsTUFBa0NtQyxFQUF0QztBQUFBLE1BQTBDMUMsS0FBSyxHQUFHaEMsTUFBTSxDQUFDMEUsRUFBRCxFQUFLLENBQUMsVUFBRCxFQUFhLFVBQWIsRUFBeUIsU0FBekIsQ0FBTCxDQUF4RDs7QUFDQSxRQUFNO0FBQUVDLElBQUFBLE1BQUY7QUFBVUMsSUFBQUEsT0FBVjtBQUFtQkMsSUFBQUEsVUFBbkI7QUFBK0JDLElBQUFBO0FBQS9CLE1BQTZDN0ksdUVBQVMsRUFBNUQ7QUFDQSxRQUFNOEksV0FBVyxHQUFHVCxrREFBVyxDQUFFTixLQUFELElBQVc7QUFDdkMsUUFBSXpCLE9BQUosRUFDSUEsT0FBTyxDQUFDeUIsS0FBRCxDQUFQLENBRm1DLENBR3ZDOztBQUNBLFFBQUksQ0FBQ0EsS0FBSyxDQUFDZ0IsZ0JBQVgsRUFDSUosT0FBTyxHQUFHSyxLQUFWLENBQWdCLE1BQU0sQ0FBRyxDQUF6QjtBQUNQLEdBTjhCLEVBTTVCLENBQUMxQyxPQUFELEVBQVVxQyxPQUFWLENBTjRCLENBQS9CO0FBT0EsUUFBTU0sT0FBTyxHQUFHWCw4Q0FBTyxDQUFDLE1BQU07QUFDMUIsUUFBSTNCLFFBQUosRUFDSSxPQUFPQSxRQUFQO0FBQ0osUUFBSWlDLFVBQUosRUFDSSxPQUFPLGdCQUFQO0FBQ0osUUFBSUMsU0FBSixFQUNJLE9BQU8sV0FBUDtBQUNKLFFBQUlILE1BQUosRUFDSSxPQUFPLFNBQVA7QUFDSixXQUFPLGdCQUFQO0FBQ0gsR0FWc0IsRUFVcEIsQ0FBQy9CLFFBQUQsRUFBV2lDLFVBQVgsRUFBdUJDLFNBQXZCLEVBQWtDSCxNQUFsQyxDQVZvQixDQUF2QjtBQVdBLHNCQUFRL0ksMERBQUEsQ0FBb0JtRywyQ0FBcEIsRUFBNEIzQixNQUFNLENBQUNxQyxNQUFQLENBQWM7QUFBRUosSUFBQUEsU0FBUyxFQUFFLCtCQUFiO0FBQThDQyxJQUFBQSxRQUFRLEVBQUVBLFFBQVEsSUFBSSxDQUFDcUMsTUFBYixJQUF1QkUsVUFBdkIsSUFBcUNDLFNBQTdGO0FBQXdHM0MsSUFBQUEsU0FBUyxFQUFFd0MsTUFBTSxnQkFBRy9JLDBEQUFBLENBQW9CNEksbURBQXBCLEVBQWdDO0FBQUVHLE1BQUFBLE1BQU0sRUFBRUE7QUFBVixLQUFoQyxDQUFILEdBQXlEeEQsU0FBbEw7QUFBNkxvQixJQUFBQSxPQUFPLEVBQUV3QztBQUF0TSxHQUFkLEVBQW1PL0MsS0FBbk8sQ0FBNUIsRUFBdVFrRCxPQUF2USxDQUFSO0FBQ0gsQ0F0Qk07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNmUCxJQUFJbEYsTUFBTSxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLE1BQWQsSUFBeUIsVUFBVUMsQ0FBVixFQUFhcEIsQ0FBYixFQUFnQjtBQUNsRCxNQUFJcUIsQ0FBQyxHQUFHLEVBQVI7O0FBQ0EsT0FBSyxJQUFJQyxDQUFULElBQWNGLENBQWQsRUFBaUIsSUFBSUcsTUFBTSxDQUFDQyxTQUFQLENBQWlCQyxjQUFqQixDQUFnQ0MsSUFBaEMsQ0FBcUNOLENBQXJDLEVBQXdDRSxDQUF4QyxLQUE4Q3RCLENBQUMsQ0FBQzJCLE9BQUYsQ0FBVUwsQ0FBVixJQUFlLENBQWpFLEVBQ2JELENBQUMsQ0FBQ0MsQ0FBRCxDQUFELEdBQU9GLENBQUMsQ0FBQ0UsQ0FBRCxDQUFSOztBQUNKLE1BQUlGLENBQUMsSUFBSSxJQUFMLElBQWEsT0FBT0csTUFBTSxDQUFDSyxxQkFBZCxLQUF3QyxVQUF6RCxFQUNJLEtBQUssSUFBSUMsQ0FBQyxHQUFHLENBQVIsRUFBV1AsQ0FBQyxHQUFHQyxNQUFNLENBQUNLLHFCQUFQLENBQTZCUixDQUE3QixDQUFwQixFQUFxRFMsQ0FBQyxHQUFHUCxDQUFDLENBQUNRLE1BQTNELEVBQW1FRCxDQUFDLEVBQXBFLEVBQXdFO0FBQ3BFLFFBQUk3QixDQUFDLENBQUMyQixPQUFGLENBQVVMLENBQUMsQ0FBQ08sQ0FBRCxDQUFYLElBQWtCLENBQWxCLElBQXVCTixNQUFNLENBQUNDLFNBQVAsQ0FBaUJPLG9CQUFqQixDQUFzQ0wsSUFBdEMsQ0FBMkNOLENBQTNDLEVBQThDRSxDQUFDLENBQUNPLENBQUQsQ0FBL0MsQ0FBM0IsRUFDSVIsQ0FBQyxDQUFDQyxDQUFDLENBQUNPLENBQUQsQ0FBRixDQUFELEdBQVVULENBQUMsQ0FBQ0UsQ0FBQyxDQUFDTyxDQUFELENBQUYsQ0FBWDtBQUNQO0FBQ0wsU0FBT1IsQ0FBUDtBQUNILENBVkQ7O0FBV0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNaUYsc0JBQXNCLEdBQUlULEVBQUQsSUFBUTtBQUMxQyxNQUFJO0FBQUU5QixJQUFBQSxRQUFGO0FBQVlOLElBQUFBLFFBQVo7QUFBc0JDLElBQUFBO0FBQXRCLE1BQWtDbUMsRUFBdEM7QUFBQSxNQUEwQzFDLEtBQUssR0FBR2hDLE1BQU0sQ0FBQzBFLEVBQUQsRUFBSyxDQUFDLFVBQUQsRUFBYSxVQUFiLEVBQXlCLFNBQXpCLENBQUwsQ0FBeEQ7O0FBQ0EsUUFBTTtBQUFFQyxJQUFBQSxNQUFGO0FBQVVTLElBQUFBLFVBQVY7QUFBc0JDLElBQUFBO0FBQXRCLE1BQXdDcEosdUVBQVMsRUFBdkQ7QUFDQSxRQUFNOEksV0FBVyxHQUFHVCxrREFBVyxDQUFFTixLQUFELElBQVc7QUFDdkMsUUFBSXpCLE9BQUosRUFDSUEsT0FBTyxDQUFDeUIsS0FBRCxDQUFQLENBRm1DLENBR3ZDOztBQUNBLFFBQUksQ0FBQ0EsS0FBSyxDQUFDZ0IsZ0JBQVgsRUFDSUksVUFBVSxHQUFHSCxLQUFiLENBQW1CLE1BQU0sQ0FBRyxDQUE1QjtBQUNQLEdBTjhCLEVBTTVCLENBQUMxQyxPQUFELEVBQVU2QyxVQUFWLENBTjRCLENBQS9CO0FBT0EsUUFBTUYsT0FBTyxHQUFHWCw4Q0FBTyxDQUFDLE1BQU07QUFDMUIsUUFBSTNCLFFBQUosRUFDSSxPQUFPQSxRQUFQO0FBQ0osUUFBSXlDLGFBQUosRUFDSSxPQUFPLG1CQUFQO0FBQ0osUUFBSVYsTUFBSixFQUNJLE9BQU8sWUFBUDtBQUNKLFdBQU8sbUJBQVA7QUFDSCxHQVJzQixFQVFwQixDQUFDL0IsUUFBRCxFQUFXeUMsYUFBWCxFQUEwQlYsTUFBMUIsQ0FSb0IsQ0FBdkI7QUFTQSxzQkFBUS9JLDBEQUFBLENBQW9CbUcsMkNBQXBCLEVBQTRCM0IsTUFBTSxDQUFDcUMsTUFBUCxDQUFjO0FBQUVKLElBQUFBLFNBQVMsRUFBRSwrQkFBYjtBQUE4Q0MsSUFBQUEsUUFBUSxFQUFFQSxRQUFRLElBQUksQ0FBQ3FDLE1BQXJFO0FBQTZFeEMsSUFBQUEsU0FBUyxFQUFFd0MsTUFBTSxnQkFBRy9JLDBEQUFBLENBQW9CNEksbURBQXBCLEVBQWdDO0FBQUVHLE1BQUFBLE1BQU0sRUFBRUE7QUFBVixLQUFoQyxDQUFILEdBQXlEeEQsU0FBdko7QUFBa0tvQixJQUFBQSxPQUFPLEVBQUV3QztBQUEzSyxHQUFkLEVBQXdNL0MsS0FBeE0sQ0FBNUIsRUFBNE9rRCxPQUE1TyxDQUFSO0FBQ0gsQ0FwQk07Ozs7Ozs7Ozs7Ozs7Ozs7QUNmUCxJQUFJbEYsTUFBTSxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLE1BQWQsSUFBeUIsVUFBVUMsQ0FBVixFQUFhcEIsQ0FBYixFQUFnQjtBQUNsRCxNQUFJcUIsQ0FBQyxHQUFHLEVBQVI7O0FBQ0EsT0FBSyxJQUFJQyxDQUFULElBQWNGLENBQWQsRUFBaUIsSUFBSUcsTUFBTSxDQUFDQyxTQUFQLENBQWlCQyxjQUFqQixDQUFnQ0MsSUFBaEMsQ0FBcUNOLENBQXJDLEVBQXdDRSxDQUF4QyxLQUE4Q3RCLENBQUMsQ0FBQzJCLE9BQUYsQ0FBVUwsQ0FBVixJQUFlLENBQWpFLEVBQ2JELENBQUMsQ0FBQ0MsQ0FBRCxDQUFELEdBQU9GLENBQUMsQ0FBQ0UsQ0FBRCxDQUFSOztBQUNKLE1BQUlGLENBQUMsSUFBSSxJQUFMLElBQWEsT0FBT0csTUFBTSxDQUFDSyxxQkFBZCxLQUF3QyxVQUF6RCxFQUNJLEtBQUssSUFBSUMsQ0FBQyxHQUFHLENBQVIsRUFBV1AsQ0FBQyxHQUFHQyxNQUFNLENBQUNLLHFCQUFQLENBQTZCUixDQUE3QixDQUFwQixFQUFxRFMsQ0FBQyxHQUFHUCxDQUFDLENBQUNRLE1BQTNELEVBQW1FRCxDQUFDLEVBQXBFLEVBQXdFO0FBQ3BFLFFBQUk3QixDQUFDLENBQUMyQixPQUFGLENBQVVMLENBQUMsQ0FBQ08sQ0FBRCxDQUFYLElBQWtCLENBQWxCLElBQXVCTixNQUFNLENBQUNDLFNBQVAsQ0FBaUJPLG9CQUFqQixDQUFzQ0wsSUFBdEMsQ0FBMkNOLENBQTNDLEVBQThDRSxDQUFDLENBQUNPLENBQUQsQ0FBL0MsQ0FBM0IsRUFDSVIsQ0FBQyxDQUFDQyxDQUFDLENBQUNPLENBQUQsQ0FBRixDQUFELEdBQVVULENBQUMsQ0FBQ0UsQ0FBQyxDQUFDTyxDQUFELENBQUYsQ0FBWDtBQUNQO0FBQ0wsU0FBT1IsQ0FBUDtBQUNILENBVkQ7O0FBV0E7QUFDTyxNQUFNc0UsVUFBVSxHQUFJRSxFQUFELElBQVE7QUFDOUIsTUFBSTtBQUFFQyxJQUFBQTtBQUFGLE1BQWFELEVBQWpCO0FBQUEsTUFBcUIxQyxLQUFLLEdBQUdoQyxNQUFNLENBQUMwRSxFQUFELEVBQUssQ0FBQyxRQUFELENBQUwsQ0FBbkM7O0FBQ0EsU0FBT0MsTUFBTSxpQkFBSS9JLDBEQUFBLENBQW9CLEtBQXBCLEVBQTJCd0UsTUFBTSxDQUFDcUMsTUFBUCxDQUFjO0FBQUU2QyxJQUFBQSxHQUFHLEVBQUVYLE1BQU0sQ0FBQ1ksSUFBZDtBQUFvQkMsSUFBQUEsR0FBRyxFQUFHLEdBQUViLE1BQU0sQ0FBQzNILElBQUs7QUFBeEMsR0FBZCxFQUFnRWdGLEtBQWhFLENBQTNCLENBQWpCO0FBQ0gsQ0FITTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWlA7QUFDQTtBQUNBO0FBQ08sTUFBTXlELGNBQWMsR0FBRyxDQUFDO0FBQUVWLEVBQUFBLFdBQUY7QUFBZXJDLEVBQUFBLFFBQWY7QUFBeUJpQyxFQUFBQTtBQUF6QixDQUFELEtBQXVDO0FBQ2pFLHNCQUFRL0ksMERBQUEsQ0FBb0IsSUFBcEIsRUFBMEIsSUFBMUIsZUFDSkEsMERBQUEsQ0FBb0JtRywyQ0FBcEIsRUFBNEI7QUFBRVEsSUFBQUEsT0FBTyxFQUFFd0MsV0FBWDtBQUF3QjdDLElBQUFBLE9BQU8sZUFBRXRHLDBEQUFBLENBQW9CNEksbURBQXBCLEVBQWdDO0FBQUVHLE1BQUFBLE1BQU0sRUFBRUE7QUFBVixLQUFoQyxDQUFqQztBQUFzRmpDLElBQUFBLFFBQVEsRUFBRUE7QUFBaEcsR0FBNUIsRUFBd0lpQyxNQUFNLENBQUMzSCxJQUEvSSxDQURJLENBQVI7QUFFSCxDQUhNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0hQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTTZJLFdBQVcsR0FBRyxDQUFDO0FBQUV4RCxFQUFBQSxTQUFTLEdBQUcsRUFBZDtBQUFrQnlELEVBQUFBLElBQWxCO0FBQXdCQyxFQUFBQSxlQUFlLEdBQUcsQ0FBMUM7QUFBNkNDLEVBQUFBLFNBQVMsR0FBRztBQUF6RCxDQUFELEtBQXdFO0FBQy9GLFFBQU05QyxHQUFHLEdBQUdKLDZDQUFNLENBQUMsSUFBRCxDQUFsQjtBQUNBLFFBQU07QUFBRW1ELElBQUFBLE9BQUY7QUFBV0MsSUFBQUE7QUFBWCxNQUFzQmpLLHVFQUFTLEVBQXJDO0FBQ0EsUUFBTTtBQUFFa0ssSUFBQUE7QUFBRixNQUFpQlAsK0RBQWMsRUFBckM7QUFDQSxRQUFNO0FBQUEsT0FBQzNDLFFBQUQ7QUFBQSxPQUFXbUQ7QUFBWCxNQUEwQlYsK0NBQVEsQ0FBQyxLQUFELENBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUNXLE1BQUQ7QUFBQSxPQUFTQztBQUFULE1BQXNCWiwrQ0FBUSxDQUFDLEtBQUQsQ0FBcEM7QUFDQSxRQUFNO0FBQUEsT0FBQ2EsTUFBRDtBQUFBLE9BQVNDO0FBQVQsTUFBc0JkLCtDQUFRLENBQUMsSUFBRCxDQUFwQztBQUNBLFFBQU07QUFBQSxPQUFDZSxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUFtQm5DLDhDQUFPLENBQUMsTUFBTSxDQUFDMEIsT0FBTyxDQUFDVSxLQUFSLENBQWMsQ0FBZCxFQUFpQlosZUFBakIsQ0FBRCxFQUFvQ0UsT0FBTyxDQUFDVSxLQUFSLENBQWNaLGVBQWQsQ0FBcEMsQ0FBUCxFQUE0RSxDQUFDRSxPQUFELEVBQVVGLGVBQVYsQ0FBNUUsQ0FBaEM7QUFDQSxRQUFNYSxTQUFTLEdBQUd0QyxrREFBVyxDQUFDLE1BQU07QUFDaENnQyxJQUFBQSxTQUFTLENBQUMsS0FBRCxDQUFUO0FBQ0EvRyxJQUFBQSxVQUFVLENBQUMsTUFBTTRHLFVBQVUsQ0FBQyxLQUFELENBQWpCLEVBQTBCLEdBQTFCLENBQVY7QUFDSCxHQUg0QixFQUcxQixDQUFDRyxTQUFELEVBQVlILFVBQVosQ0FIMEIsQ0FBN0I7QUFJQSxRQUFNVSxXQUFXLEdBQUd2QyxrREFBVyxDQUFFTixLQUFELElBQVc7QUFDdkNBLElBQUFBLEtBQUssQ0FBQzhDLGNBQU47QUFDQUYsSUFBQUEsU0FBUztBQUNaLEdBSDhCLEVBRzVCLENBQUNBLFNBQUQsQ0FINEIsQ0FBL0I7QUFJQSxRQUFNRyxpQkFBaUIsR0FBR3pDLGtEQUFXLENBQUMsQ0FBQ04sS0FBRCxFQUFRZ0QsVUFBUixLQUF1QjtBQUN6RGQsSUFBQUEsTUFBTSxDQUFDYyxVQUFELENBQU47QUFDQUgsSUFBQUEsV0FBVyxDQUFDN0MsS0FBRCxDQUFYO0FBQ0gsR0FIb0MsRUFHbEMsQ0FBQ2tDLE1BQUQsRUFBU1csV0FBVCxDQUhrQyxDQUFyQztBQUlBLFFBQU1JLG1CQUFtQixHQUFHM0Msa0RBQVcsQ0FBQyxNQUFNOEIsV0FBVyxDQUFDLENBQUNuRCxRQUFGLENBQWxCLEVBQStCLENBQUNtRCxXQUFELEVBQWNuRCxRQUFkLENBQS9CLENBQXZDO0FBQ0EsUUFBTWlFLFlBQVksR0FBRzVDLGtEQUFXLENBQUVOLEtBQUQsSUFBVztBQUN4QyxVQUFNVixJQUFJLEdBQUdKLEdBQUcsQ0FBQ0ssT0FBakI7QUFDQSxRQUFJLENBQUNELElBQUwsRUFDSSxPQUhvQyxDQUl4Qzs7QUFDQSxVQUFNNkQsaUJBQWlCLEdBQUc3RCxJQUFJLENBQUM4RCxnQkFBTCxDQUFzQixRQUF0QixDQUExQjtBQUNBLFVBQU1DLFlBQVksR0FBR0YsaUJBQWlCLENBQUMsQ0FBRCxDQUF0QztBQUNBLFVBQU1HLFdBQVcsR0FBR0gsaUJBQWlCLENBQUNBLGlCQUFpQixDQUFDeEcsTUFBbEIsR0FBMkIsQ0FBNUIsQ0FBckM7O0FBQ0EsUUFBSXFELEtBQUssQ0FBQ3VELFFBQVYsRUFBb0I7QUFDaEI7QUFDQSxVQUFJQyxRQUFRLENBQUNDLGFBQVQsS0FBMkJKLFlBQS9CLEVBQTZDO0FBQ3pDQyxRQUFBQSxXQUFXLENBQUNJLEtBQVo7QUFDQTFELFFBQUFBLEtBQUssQ0FBQzhDLGNBQU47QUFDSDtBQUNKLEtBTkQsTUFPSztBQUNEO0FBQ0EsVUFBSVUsUUFBUSxDQUFDQyxhQUFULEtBQTJCSCxXQUEvQixFQUE0QztBQUN4Q0QsUUFBQUEsWUFBWSxDQUFDSyxLQUFiO0FBQ0ExRCxRQUFBQSxLQUFLLENBQUM4QyxjQUFOO0FBQ0g7QUFDSjtBQUNKLEdBdEIrQixFQXNCN0IsQ0FBQzVELEdBQUQsQ0F0QjZCLENBQWhDO0FBdUJBTCxFQUFBQSxzREFBZSxDQUFDLE1BQU07QUFDbEIsVUFBTThFLGFBQWEsR0FBSTNELEtBQUQsSUFBVztBQUM3QixVQUFJQSxLQUFLLENBQUM0RCxHQUFOLEtBQWMsUUFBbEIsRUFBNEI7QUFDeEJoQixRQUFBQSxTQUFTO0FBQ1osT0FGRCxNQUdLLElBQUk1QyxLQUFLLENBQUM0RCxHQUFOLEtBQWMsS0FBbEIsRUFBeUI7QUFDMUJWLFFBQUFBLFlBQVksQ0FBQ2xELEtBQUQsQ0FBWjtBQUNIO0FBQ0osS0FQRCxDQURrQixDQVNsQjs7O0FBQ0EsVUFBTTtBQUFFSCxNQUFBQTtBQUFGLFFBQWVnRSxNQUFNLENBQUNDLGdCQUFQLENBQXdCTixRQUFRLENBQUNPLElBQWpDLENBQXJCLENBVmtCLENBV2xCOztBQUNBeEksSUFBQUEsVUFBVSxDQUFDLE1BQU0rRyxTQUFTLENBQUMsSUFBRCxDQUFoQixFQUF3QixDQUF4QixDQUFWLENBWmtCLENBYWxCOztBQUNBa0IsSUFBQUEsUUFBUSxDQUFDTyxJQUFULENBQWN2RixLQUFkLENBQW9CcUIsUUFBcEIsR0FBK0IsUUFBL0IsQ0Fka0IsQ0FlbEI7O0FBQ0FnRSxJQUFBQSxNQUFNLENBQUMxRCxnQkFBUCxDQUF3QixTQUF4QixFQUFtQ3dELGFBQW5DLEVBQWtELEtBQWxEO0FBQ0EsV0FBTyxNQUFNO0FBQ1Q7QUFDQUgsTUFBQUEsUUFBUSxDQUFDTyxJQUFULENBQWN2RixLQUFkLENBQW9CcUIsUUFBcEIsR0FBK0JBLFFBQS9CO0FBQ0FnRSxNQUFBQSxNQUFNLENBQUN6RCxtQkFBUCxDQUEyQixTQUEzQixFQUFzQ3VELGFBQXRDLEVBQXFELEtBQXJEO0FBQ0gsS0FKRDtBQUtILEdBdEJjLEVBc0JaLENBQUNmLFNBQUQsRUFBWU0sWUFBWixDQXRCWSxDQUFmO0FBdUJBckUsRUFBQUEsc0RBQWUsQ0FBQyxNQUFNMkQsU0FBUyxDQUFDZ0IsUUFBUSxDQUFDUSxhQUFULENBQXVCaEMsU0FBdkIsQ0FBRCxDQUFoQixFQUFxRCxDQUFDUSxTQUFELEVBQVlSLFNBQVosQ0FBckQsQ0FBZjtBQUNBLFNBQVFPLE1BQU0saUJBQ1ZaLHVEQUFZLGVBQUMvSiwwREFBQSxDQUFvQixLQUFwQixFQUEyQjtBQUFFLHVCQUFtQiw0QkFBckI7QUFBbUQsa0JBQWMsTUFBakU7QUFBeUV5RyxJQUFBQSxTQUFTLEVBQUcsd0JBQXVCZ0UsTUFBTSxJQUFJLDhCQUErQixJQUFHaEUsU0FBVSxFQUFsSztBQUFxS2EsSUFBQUEsR0FBRyxFQUFFQSxHQUExSztBQUErS21CLElBQUFBLElBQUksRUFBRTtBQUFyTCxHQUEzQixlQUNUekksMERBQUEsQ0FBb0IsS0FBcEIsRUFBMkI7QUFBRXlHLElBQUFBLFNBQVMsRUFBRTtBQUFiLEdBQTNCLGVBQ0l6RywwREFBQSxDQUFvQixLQUFwQixFQUEyQjtBQUFFeUcsSUFBQUEsU0FBUyxFQUFHLGdDQUErQixDQUFDeUQsSUFBRCxJQUFTLHNDQUF1QztBQUE3RixHQUEzQixFQUNJQSxJQUFJLGlCQUFLbEssMERBQUEsQ0FBb0IsS0FBcEIsRUFBMkI7QUFBRXlHLElBQUFBLFNBQVMsRUFBRTtBQUFiLEdBQTNCLEVBQStFLE9BQU95RCxJQUFQLEtBQWdCLFFBQWhCLGdCQUE0QmxLLDBEQUFBLENBQW9CLEtBQXBCLEVBQTJCO0FBQUU0SixJQUFBQSxHQUFHLEVBQUUsTUFBUDtBQUFlbkQsSUFBQUEsU0FBUyxFQUFFLDJCQUExQjtBQUF1RGlELElBQUFBLEdBQUcsRUFBRVE7QUFBNUQsR0FBM0IsQ0FBNUIsR0FBK0hBLElBQTlNLENBRGIsZUFFSWxLLDBEQUFBLENBQW9CLElBQXBCLEVBQTBCO0FBQUV5RyxJQUFBQSxTQUFTLEVBQUUsNEJBQWI7QUFBMkNXLElBQUFBLEVBQUUsRUFBRTtBQUEvQyxHQUExQixFQUF5RyxnQkFBekcsQ0FGSixlQUdJcEgsMERBQUEsQ0FBb0IsUUFBcEIsRUFBOEI7QUFBRTJHLElBQUFBLE9BQU8sRUFBRXNFLFdBQVg7QUFBd0J4RSxJQUFBQSxTQUFTLEVBQUU7QUFBbkMsR0FBOUIsZUFDSXpHLDBEQUFBLENBQW9CLEtBQXBCLEVBQTJCO0FBQUVxTSxJQUFBQSxLQUFLLEVBQUUsSUFBVDtBQUFleEUsSUFBQUEsTUFBTSxFQUFFO0FBQXZCLEdBQTNCLGVBQ0k3SCwwREFBQSxDQUFvQixNQUFwQixFQUE0QjtBQUFFc00sSUFBQUEsQ0FBQyxFQUFFO0FBQUwsR0FBNUIsQ0FESixDQURKLENBSEosZUFNSXRNLDBEQUFBLENBQW9CLElBQXBCLEVBQTBCO0FBQUV5RyxJQUFBQSxTQUFTLEVBQUU7QUFBYixHQUExQixFQUFzRW9FLFFBQVEsQ0FBQzBCLEdBQVQsQ0FBY3hELE1BQUQsaUJBQWEvSSwwREFBQSxDQUFvQjZKLDJEQUFwQixFQUFvQztBQUFFbUMsSUFBQUEsR0FBRyxFQUFFakQsTUFBTSxDQUFDM0gsSUFBZDtBQUFvQitILElBQUFBLFdBQVcsRUFBR2YsS0FBRCxJQUFXK0MsaUJBQWlCLENBQUMvQyxLQUFELEVBQVFXLE1BQU0sQ0FBQzNILElBQWYsQ0FBN0Q7QUFBbUYySCxJQUFBQSxNQUFNLEVBQUVBO0FBQTNGLEdBQXBDLENBQTFCLENBQXRFLENBTkosRUFPSStCLElBQUksQ0FBQy9GLE1BQUwsZ0JBQWUvRSwwREFBQSxDQUFvQkEsdURBQXBCLEVBQW9DLElBQXBDLGVBQ1hBLDBEQUFBLENBQW9CbUgsK0NBQXBCLEVBQThCO0FBQUVFLElBQUFBLFFBQVEsRUFBRUEsUUFBWjtBQUFzQkQsSUFBQUEsRUFBRSxFQUFFO0FBQTFCLEdBQTlCLGVBQ0lwSCwwREFBQSxDQUFvQixJQUFwQixFQUEwQjtBQUFFeUcsSUFBQUEsU0FBUyxFQUFFO0FBQWIsR0FBMUIsRUFBc0VxRSxJQUFJLENBQUN5QixHQUFMLENBQVV4RCxNQUFELGlCQUFhL0ksMERBQUEsQ0FBb0I2SiwyREFBcEIsRUFBb0M7QUFBRW1DLElBQUFBLEdBQUcsRUFBRWpELE1BQU0sQ0FBQzNILElBQWQ7QUFBb0IrSCxJQUFBQSxXQUFXLEVBQUdmLEtBQUQsSUFBVytDLGlCQUFpQixDQUFDL0MsS0FBRCxFQUFRVyxNQUFNLENBQUMzSCxJQUFmLENBQTdEO0FBQW1GMEYsSUFBQUEsUUFBUSxFQUFFTyxRQUFRLEdBQUcsQ0FBSCxHQUFPLENBQUMsQ0FBN0c7QUFBZ0gwQixJQUFBQSxNQUFNLEVBQUVBO0FBQXhILEdBQXBDLENBQXRCLENBQXRFLENBREosQ0FEVyxlQUdYL0ksMERBQUEsQ0FBb0JtRywyQ0FBcEIsRUFBNEI7QUFBRSxxQkFBaUIsK0JBQW5CO0FBQW9ELHFCQUFpQmtCLFFBQXJFO0FBQStFWixJQUFBQSxTQUFTLEVBQUcsd0NBQXVDWSxRQUFRLElBQUksNkNBQThDLEVBQTVMO0FBQStMZixJQUFBQSxPQUFPLGVBQUV0RywwREFBQSxDQUFvQixLQUFwQixFQUEyQjtBQUFFcU0sTUFBQUEsS0FBSyxFQUFFLElBQVQ7QUFBZXhFLE1BQUFBLE1BQU0sRUFBRSxHQUF2QjtBQUE0QjRFLE1BQUFBLEtBQUssRUFBRTtBQUFuQyxLQUEzQixlQUM1TnpNLDBEQUFBLENBQW9CLE1BQXBCLEVBQTRCO0FBQUVzTSxNQUFBQSxDQUFDLEVBQUU7QUFBTCxLQUE1QixDQUQ0TixDQUF4TTtBQUNxTTNGLElBQUFBLE9BQU8sRUFBRTBFO0FBRDlNLEdBQTVCLEVBRUloRSxRQUFRLEdBQUcsTUFBSCxHQUFZLE1BRnhCLEVBR0ksVUFISixDQUhXLENBQWYsR0FNd0IsSUFiNUIsQ0FESixDQURTLGVBZ0JUckgsMERBQUEsQ0FBb0IsS0FBcEIsRUFBMkI7QUFBRXlHLElBQUFBLFNBQVMsRUFBRSw4QkFBYjtBQUE2Q2lHLElBQUFBLFdBQVcsRUFBRXpCO0FBQTFELEdBQTNCLENBaEJTLENBQUQsRUFnQjhGTixNQWhCOUYsQ0FEaEI7QUFrQkgsQ0F0Rk07Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BQLElBQUl2RyxNQUFNLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsTUFBZCxJQUF5QixVQUFVQyxDQUFWLEVBQWFwQixDQUFiLEVBQWdCO0FBQ2xELE1BQUlxQixDQUFDLEdBQUcsRUFBUjs7QUFDQSxPQUFLLElBQUlDLENBQVQsSUFBY0YsQ0FBZCxFQUFpQixJQUFJRyxNQUFNLENBQUNDLFNBQVAsQ0FBaUJDLGNBQWpCLENBQWdDQyxJQUFoQyxDQUFxQ04sQ0FBckMsRUFBd0NFLENBQXhDLEtBQThDdEIsQ0FBQyxDQUFDMkIsT0FBRixDQUFVTCxDQUFWLElBQWUsQ0FBakUsRUFDYkQsQ0FBQyxDQUFDQyxDQUFELENBQUQsR0FBT0YsQ0FBQyxDQUFDRSxDQUFELENBQVI7O0FBQ0osTUFBSUYsQ0FBQyxJQUFJLElBQUwsSUFBYSxPQUFPRyxNQUFNLENBQUNLLHFCQUFkLEtBQXdDLFVBQXpELEVBQ0ksS0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBUixFQUFXUCxDQUFDLEdBQUdDLE1BQU0sQ0FBQ0sscUJBQVAsQ0FBNkJSLENBQTdCLENBQXBCLEVBQXFEUyxDQUFDLEdBQUdQLENBQUMsQ0FBQ1EsTUFBM0QsRUFBbUVELENBQUMsRUFBcEUsRUFBd0U7QUFDcEUsUUFBSTdCLENBQUMsQ0FBQzJCLE9BQUYsQ0FBVUwsQ0FBQyxDQUFDTyxDQUFELENBQVgsSUFBa0IsQ0FBbEIsSUFBdUJOLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQk8sb0JBQWpCLENBQXNDTCxJQUF0QyxDQUEyQ04sQ0FBM0MsRUFBOENFLENBQUMsQ0FBQ08sQ0FBRCxDQUEvQyxDQUEzQixFQUNJUixDQUFDLENBQUNDLENBQUMsQ0FBQ08sQ0FBRCxDQUFGLENBQUQsR0FBVVQsQ0FBQyxDQUFDRSxDQUFDLENBQUNPLENBQUQsQ0FBRixDQUFYO0FBQ1A7QUFDTCxTQUFPUixDQUFQO0FBQ0gsQ0FWRDs7QUFXQTtBQUNBO0FBQ0E7QUFDTyxNQUFNcUksaUJBQWlCLEdBQUk3RCxFQUFELElBQVE7QUFDckMsTUFBSTtBQUFFOUIsSUFBQUEsUUFBUSxHQUFHLGVBQWI7QUFBOEJMLElBQUFBO0FBQTlCLE1BQTBDbUMsRUFBOUM7QUFBQSxNQUFrRDFDLEtBQUssR0FBR2hDLE1BQU0sQ0FBQzBFLEVBQUQsRUFBSyxDQUFDLFVBQUQsRUFBYSxTQUFiLENBQUwsQ0FBaEU7O0FBQ0EsUUFBTTtBQUFFOEQsSUFBQUEsT0FBRjtBQUFXckMsSUFBQUE7QUFBWCxNQUEwQlAsK0RBQWMsRUFBOUM7QUFDQSxRQUFNYixXQUFXLEdBQUdULGtEQUFXLENBQUVOLEtBQUQsSUFBVztBQUN2QyxRQUFJekIsT0FBSixFQUNJQSxPQUFPLENBQUN5QixLQUFELENBQVA7QUFDSixRQUFJLENBQUNBLEtBQUssQ0FBQ2dCLGdCQUFYLEVBQ0ltQixVQUFVLENBQUMsQ0FBQ3FDLE9BQUYsQ0FBVjtBQUNQLEdBTDhCLEVBSzVCLENBQUNqRyxPQUFELEVBQVU0RCxVQUFWLEVBQXNCcUMsT0FBdEIsQ0FMNEIsQ0FBL0I7QUFNQSxzQkFBUTVNLDBEQUFBLENBQW9CbUcsMkNBQXBCLEVBQTRCM0IsTUFBTSxDQUFDcUMsTUFBUCxDQUFjO0FBQUVKLElBQUFBLFNBQVMsRUFBRSwrQkFBYjtBQUE4Q0UsSUFBQUEsT0FBTyxFQUFFd0M7QUFBdkQsR0FBZCxFQUFvRi9DLEtBQXBGLENBQTVCLEVBQXdIWSxRQUF4SCxDQUFSO0FBQ0gsQ0FWTTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZFAsSUFBSTVDLE1BQU0sR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxNQUFkLElBQXlCLFVBQVVDLENBQVYsRUFBYXBCLENBQWIsRUFBZ0I7QUFDbEQsTUFBSXFCLENBQUMsR0FBRyxFQUFSOztBQUNBLE9BQUssSUFBSUMsQ0FBVCxJQUFjRixDQUFkLEVBQWlCLElBQUlHLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQkMsY0FBakIsQ0FBZ0NDLElBQWhDLENBQXFDTixDQUFyQyxFQUF3Q0UsQ0FBeEMsS0FBOEN0QixDQUFDLENBQUMyQixPQUFGLENBQVVMLENBQVYsSUFBZSxDQUFqRSxFQUNiRCxDQUFDLENBQUNDLENBQUQsQ0FBRCxHQUFPRixDQUFDLENBQUNFLENBQUQsQ0FBUjs7QUFDSixNQUFJRixDQUFDLElBQUksSUFBTCxJQUFhLE9BQU9HLE1BQU0sQ0FBQ0sscUJBQWQsS0FBd0MsVUFBekQsRUFDSSxLQUFLLElBQUlDLENBQUMsR0FBRyxDQUFSLEVBQVdQLENBQUMsR0FBR0MsTUFBTSxDQUFDSyxxQkFBUCxDQUE2QlIsQ0FBN0IsQ0FBcEIsRUFBcURTLENBQUMsR0FBR1AsQ0FBQyxDQUFDUSxNQUEzRCxFQUFtRUQsQ0FBQyxFQUFwRSxFQUF3RTtBQUNwRSxRQUFJN0IsQ0FBQyxDQUFDMkIsT0FBRixDQUFVTCxDQUFDLENBQUNPLENBQUQsQ0FBWCxJQUFrQixDQUFsQixJQUF1Qk4sTUFBTSxDQUFDQyxTQUFQLENBQWlCTyxvQkFBakIsQ0FBc0NMLElBQXRDLENBQTJDTixDQUEzQyxFQUE4Q0UsQ0FBQyxDQUFDTyxDQUFELENBQS9DLENBQTNCLEVBQ0lSLENBQUMsQ0FBQ0MsQ0FBQyxDQUFDTyxDQUFELENBQUYsQ0FBRCxHQUFVVCxDQUFDLENBQUNFLENBQUMsQ0FBQ08sQ0FBRCxDQUFGLENBQVg7QUFDUDtBQUNMLFNBQU9SLENBQVA7QUFDSCxDQVZEOztBQVdBO0FBQ0E7QUFDQTtBQUNPLE1BQU13SSxtQkFBbUIsR0FBSWhFLEVBQUQsSUFBUTtBQUN2QyxNQUFJO0FBQUU5QixJQUFBQTtBQUFGLE1BQWU4QixFQUFuQjtBQUFBLE1BQXVCMUMsS0FBSyxHQUFHaEMsTUFBTSxDQUFDMEUsRUFBRCxFQUFLLENBQUMsVUFBRCxDQUFMLENBQXJDOztBQUNBLFFBQU07QUFBQSxPQUFDOEQsT0FBRDtBQUFBLE9BQVVyQztBQUFWLE1BQXdCVCwrQ0FBUSxDQUFDLEtBQUQsQ0FBdEM7QUFDQSxzQkFBUTlKLDBEQUFBLENBQW9CNk0sd0VBQXBCLEVBQWlEO0FBQUVuSyxJQUFBQSxLQUFLLEVBQUU7QUFDMURrSyxNQUFBQSxPQUQwRDtBQUUxRHJDLE1BQUFBO0FBRjBEO0FBQVQsR0FBakQsRUFJSnZELFFBSkksRUFLSjRGLE9BQU8saUJBQUk1TSwwREFBQSxDQUFvQmlLLHFEQUFwQixFQUFpQ3pGLE1BQU0sQ0FBQ3FDLE1BQVAsQ0FBYyxFQUFkLEVBQWtCVCxLQUFsQixDQUFqQyxDQUxQLENBQVI7QUFNSCxDQVRNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZFAsSUFBSWhFLFNBQVMsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxTQUFkLElBQTRCLFVBQVVDLE9BQVYsRUFBbUJDLFVBQW5CLEVBQStCQyxDQUEvQixFQUFrQ0MsU0FBbEMsRUFBNkM7QUFDckYsV0FBU0MsS0FBVCxDQUFlQyxLQUFmLEVBQXNCO0FBQUUsV0FBT0EsS0FBSyxZQUFZSCxDQUFqQixHQUFxQkcsS0FBckIsR0FBNkIsSUFBSUgsQ0FBSixDQUFNLFVBQVVJLE9BQVYsRUFBbUI7QUFBRUEsTUFBQUEsT0FBTyxDQUFDRCxLQUFELENBQVA7QUFBaUIsS0FBNUMsQ0FBcEM7QUFBb0Y7O0FBQzVHLFNBQU8sS0FBS0gsQ0FBQyxLQUFLQSxDQUFDLEdBQUdLLE9BQVQsQ0FBTixFQUF5QixVQUFVRCxPQUFWLEVBQW1CRSxNQUFuQixFQUEyQjtBQUN2RCxhQUFTQyxTQUFULENBQW1CSixLQUFuQixFQUEwQjtBQUFFLFVBQUk7QUFBRUssUUFBQUEsSUFBSSxDQUFDUCxTQUFTLENBQUNRLElBQVYsQ0FBZU4sS0FBZixDQUFELENBQUo7QUFBOEIsT0FBcEMsQ0FBcUMsT0FBT08sQ0FBUCxFQUFVO0FBQUVKLFFBQUFBLE1BQU0sQ0FBQ0ksQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDM0YsYUFBU0MsUUFBVCxDQUFrQlIsS0FBbEIsRUFBeUI7QUFBRSxVQUFJO0FBQUVLLFFBQUFBLElBQUksQ0FBQ1AsU0FBUyxDQUFDLE9BQUQsQ0FBVCxDQUFtQkUsS0FBbkIsQ0FBRCxDQUFKO0FBQWtDLE9BQXhDLENBQXlDLE9BQU9PLENBQVAsRUFBVTtBQUFFSixRQUFBQSxNQUFNLENBQUNJLENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzlGLGFBQVNGLElBQVQsQ0FBY0ksTUFBZCxFQUFzQjtBQUFFQSxNQUFBQSxNQUFNLENBQUNDLElBQVAsR0FBY1QsT0FBTyxDQUFDUSxNQUFNLENBQUNULEtBQVIsQ0FBckIsR0FBc0NELEtBQUssQ0FBQ1UsTUFBTSxDQUFDVCxLQUFSLENBQUwsQ0FBb0JXLElBQXBCLENBQXlCUCxTQUF6QixFQUFvQ0ksUUFBcEMsQ0FBdEM7QUFBc0Y7O0FBQzlHSCxJQUFBQSxJQUFJLENBQUMsQ0FBQ1AsU0FBUyxHQUFHQSxTQUFTLENBQUNjLEtBQVYsQ0FBZ0JqQixPQUFoQixFQUF5QkMsVUFBVSxJQUFJLEVBQXZDLENBQWIsRUFBeURVLElBQXpELEVBQUQsQ0FBSjtBQUNILEdBTE0sQ0FBUDtBQU1ILENBUkQ7O0FBU0EsSUFBSW9CLE1BQU0sR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxNQUFkLElBQXlCLFVBQVVDLENBQVYsRUFBYXBCLENBQWIsRUFBZ0I7QUFDbEQsTUFBSXFCLENBQUMsR0FBRyxFQUFSOztBQUNBLE9BQUssSUFBSUMsQ0FBVCxJQUFjRixDQUFkLEVBQWlCLElBQUlHLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQkMsY0FBakIsQ0FBZ0NDLElBQWhDLENBQXFDTixDQUFyQyxFQUF3Q0UsQ0FBeEMsS0FBOEN0QixDQUFDLENBQUMyQixPQUFGLENBQVVMLENBQVYsSUFBZSxDQUFqRSxFQUNiRCxDQUFDLENBQUNDLENBQUQsQ0FBRCxHQUFPRixDQUFDLENBQUNFLENBQUQsQ0FBUjs7QUFDSixNQUFJRixDQUFDLElBQUksSUFBTCxJQUFhLE9BQU9HLE1BQU0sQ0FBQ0sscUJBQWQsS0FBd0MsVUFBekQsRUFDSSxLQUFLLElBQUlDLENBQUMsR0FBRyxDQUFSLEVBQVdQLENBQUMsR0FBR0MsTUFBTSxDQUFDSyxxQkFBUCxDQUE2QlIsQ0FBN0IsQ0FBcEIsRUFBcURTLENBQUMsR0FBR1AsQ0FBQyxDQUFDUSxNQUEzRCxFQUFtRUQsQ0FBQyxFQUFwRSxFQUF3RTtBQUNwRSxRQUFJN0IsQ0FBQyxDQUFDMkIsT0FBRixDQUFVTCxDQUFDLENBQUNPLENBQUQsQ0FBWCxJQUFrQixDQUFsQixJQUF1Qk4sTUFBTSxDQUFDQyxTQUFQLENBQWlCTyxvQkFBakIsQ0FBc0NMLElBQXRDLENBQTJDTixDQUEzQyxFQUE4Q0UsQ0FBQyxDQUFDTyxDQUFELENBQS9DLENBQTNCLEVBQ0lSLENBQUMsQ0FBQ0MsQ0FBQyxDQUFDTyxDQUFELENBQUYsQ0FBRCxHQUFVVCxDQUFDLENBQUNFLENBQUMsQ0FBQ08sQ0FBRCxDQUFGLENBQVg7QUFDUDtBQUNMLFNBQU9SLENBQVA7QUFDSCxDQVZEOztBQVdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTXJFLGlCQUFpQixHQUFJNkksRUFBRCxJQUFRO0FBQ3JDLE1BQUk7QUFBRTlCLElBQUFBO0FBQUYsTUFBZThCLEVBQW5CO0FBQUEsTUFBdUIxQyxLQUFLLEdBQUdoQyxNQUFNLENBQUMwRSxFQUFELEVBQUssQ0FBQyxVQUFELENBQUwsQ0FBckM7O0FBQ0EsUUFBTTtBQUFFdkksSUFBQUEsU0FBRjtBQUFhd0ksSUFBQUEsTUFBYjtBQUFxQlMsSUFBQUE7QUFBckIsTUFBb0NuSix1RUFBUyxFQUFuRDtBQUNBLFFBQU07QUFBRWtLLElBQUFBO0FBQUYsTUFBaUJQLCtEQUFjLEVBQXJDO0FBQ0EsUUFBTTtBQUFBLE9BQUNnRCxNQUFEO0FBQUEsT0FBU0M7QUFBVCxNQUFzQm5ELCtDQUFRLENBQUMsS0FBRCxDQUFwQztBQUNBLFFBQU07QUFBQSxPQUFDb0QsTUFBRDtBQUFBLE9BQVNDO0FBQVQsTUFBc0JyRCwrQ0FBUSxDQUFDLEtBQUQsQ0FBcEM7QUFDQSxRQUFNeEMsR0FBRyxHQUFHSiw2Q0FBTSxDQUFDLElBQUQsQ0FBbEI7QUFDQSxRQUFNa0csTUFBTSxHQUFHekUsOENBQU8sQ0FBQyxNQUFNcEksU0FBUyxLQUFLLElBQWQsSUFBc0JBLFNBQVMsS0FBSyxLQUFLLENBQXpDLEdBQTZDLEtBQUssQ0FBbEQsR0FBc0RBLFNBQVMsQ0FBQzhNLFFBQVYsRUFBN0QsRUFBbUYsQ0FBQzlNLFNBQUQsQ0FBbkYsQ0FBdEI7QUFDQSxRQUFNK0ksT0FBTyxHQUFHWCw4Q0FBTyxDQUFDLE1BQU07QUFDMUIsUUFBSTNCLFFBQUosRUFDSSxPQUFPQSxRQUFQO0FBQ0osUUFBSSxDQUFDK0IsTUFBRCxJQUFXLENBQUNxRSxNQUFoQixFQUNJLE9BQU8sSUFBUDtBQUNKLFdBQU9BLE1BQU0sQ0FBQ3JDLEtBQVAsQ0FBYSxDQUFiLEVBQWdCLENBQWhCLElBQXFCLElBQXJCLEdBQTRCcUMsTUFBTSxDQUFDckMsS0FBUCxDQUFhLENBQUMsQ0FBZCxDQUFuQztBQUNILEdBTnNCLEVBTXBCLENBQUMvRCxRQUFELEVBQVcrQixNQUFYLEVBQW1CcUUsTUFBbkIsQ0FOb0IsQ0FBdkI7QUFPQSxRQUFNRSxXQUFXLEdBQUc1RSxrREFBVyxDQUFDLE1BQU10RyxTQUFTLENBQUMsS0FBSyxDQUFOLEVBQVMsS0FBSyxDQUFkLEVBQWlCLEtBQUssQ0FBdEIsRUFBeUIsYUFBYTtBQUNqRixRQUFJZ0wsTUFBSixFQUFZO0FBQ1IsWUFBTUcsU0FBUyxDQUFDQyxTQUFWLENBQW9CQyxTQUFwQixDQUE4QkwsTUFBOUIsQ0FBTjtBQUNBSCxNQUFBQSxTQUFTLENBQUMsSUFBRCxDQUFUO0FBQ0F0SixNQUFBQSxVQUFVLENBQUMsTUFBTXNKLFNBQVMsQ0FBQyxLQUFELENBQWhCLEVBQXlCLEdBQXpCLENBQVY7QUFDSDtBQUNKLEdBTjhDLENBQWhCLEVBTTNCLENBQUNHLE1BQUQsQ0FOMkIsQ0FBL0I7QUFPQSxRQUFNTSxZQUFZLEdBQUdoRixrREFBVyxDQUFDLE1BQU15RSxTQUFTLENBQUMsSUFBRCxDQUFoQixFQUF3QixDQUFDQSxTQUFELENBQXhCLENBQWhDO0FBQ0EsUUFBTVEsYUFBYSxHQUFHakYsa0RBQVcsQ0FBQyxNQUFNeUUsU0FBUyxDQUFDLEtBQUQsQ0FBaEIsRUFBeUIsQ0FBQ0EsU0FBRCxDQUF6QixDQUFqQztBQUNBLFFBQU1TLFNBQVMsR0FBR2xGLGtEQUFXLENBQUMsTUFBTTtBQUNoQzZCLElBQUFBLFVBQVUsQ0FBQyxJQUFELENBQVY7QUFDQW9ELElBQUFBLGFBQWE7QUFDaEIsR0FINEIsRUFHMUIsQ0FBQ3BELFVBQUQsRUFBYW9ELGFBQWIsQ0FIMEIsQ0FBN0I7QUFJQXhOLEVBQUFBLGdEQUFTLENBQUMsTUFBTTtBQUNaLFVBQU0wTixRQUFRLEdBQUl6RixLQUFELElBQVc7QUFDeEIsWUFBTVYsSUFBSSxHQUFHSixHQUFHLENBQUNLLE9BQWpCLENBRHdCLENBRXhCOztBQUNBLFVBQUksQ0FBQ0QsSUFBRCxJQUFTQSxJQUFJLENBQUNvRyxRQUFMLENBQWMxRixLQUFLLENBQUNDLE1BQXBCLENBQWIsRUFDSTtBQUNKc0YsTUFBQUEsYUFBYTtBQUNoQixLQU5EOztBQU9BL0IsSUFBQUEsUUFBUSxDQUFDckQsZ0JBQVQsQ0FBMEIsV0FBMUIsRUFBdUNzRixRQUF2QztBQUNBakMsSUFBQUEsUUFBUSxDQUFDckQsZ0JBQVQsQ0FBMEIsWUFBMUIsRUFBd0NzRixRQUF4QztBQUNBLFdBQU8sTUFBTTtBQUNUakMsTUFBQUEsUUFBUSxDQUFDcEQsbUJBQVQsQ0FBNkIsV0FBN0IsRUFBMENxRixRQUExQztBQUNBakMsTUFBQUEsUUFBUSxDQUFDcEQsbUJBQVQsQ0FBNkIsWUFBN0IsRUFBMkNxRixRQUEzQztBQUNILEtBSEQ7QUFJSCxHQWRRLEVBY04sQ0FBQ3ZHLEdBQUQsRUFBTXFHLGFBQU4sQ0FkTSxDQUFUO0FBZUEsTUFBSSxDQUFDNUUsTUFBTCxFQUNJLG9CQUFPL0ksMERBQUEsQ0FBb0IyTSxpRUFBcEIsRUFBdUNuSSxNQUFNLENBQUNxQyxNQUFQLENBQWMsRUFBZCxFQUFrQlQsS0FBbEIsQ0FBdkMsRUFBaUVZLFFBQWpFLENBQVA7QUFDSixNQUFJLENBQUNvRyxNQUFMLEVBQ0ksb0JBQU9wTiwwREFBQSxDQUFvQjZJLHFFQUFwQixFQUF5Q3JFLE1BQU0sQ0FBQ3FDLE1BQVAsQ0FBYyxFQUFkLEVBQWtCVCxLQUFsQixDQUF6QyxFQUFtRVksUUFBbkUsQ0FBUDtBQUNKLHNCQUFRaEgsMERBQUEsQ0FBb0IsS0FBcEIsRUFBMkI7QUFBRXlHLElBQUFBLFNBQVMsRUFBRTtBQUFiLEdBQTNCLGVBQ0p6RywwREFBQSxDQUFvQm1HLDJDQUFwQixFQUE0QjNCLE1BQU0sQ0FBQ3FDLE1BQVAsQ0FBYztBQUFFLHFCQUFpQnFHLE1BQW5CO0FBQTJCekcsSUFBQUEsU0FBUyxFQUFFLCtCQUF0QztBQUF1RUcsSUFBQUEsS0FBSyxFQUFFcEMsTUFBTSxDQUFDcUMsTUFBUCxDQUFjO0FBQUVrSCxNQUFBQSxhQUFhLEVBQUViLE1BQU0sR0FBRyxNQUFILEdBQVk7QUFBbkMsS0FBZCxFQUEyRDlHLEtBQUssQ0FBQ1EsS0FBakUsQ0FBOUU7QUFBdUpELElBQUFBLE9BQU8sRUFBRStHLFlBQWhLO0FBQThLbkgsSUFBQUEsU0FBUyxlQUFFdkcsMERBQUEsQ0FBb0I0SSxtREFBcEIsRUFBZ0M7QUFBRUcsTUFBQUEsTUFBTSxFQUFFQTtBQUFWLEtBQWhDO0FBQXpMLEdBQWQsRUFBOFAzQyxLQUE5UCxDQUE1QixFQUFrU2tELE9BQWxTLENBREksZUFFSnRKLDBEQUFBLENBQW9CLElBQXBCLEVBQTBCO0FBQUUsa0JBQWMsZUFBaEI7QUFBaUN5RyxJQUFBQSxTQUFTLEVBQUcsZ0NBQStCeUcsTUFBTSxJQUFJLHFDQUFzQyxFQUE1SDtBQUErSDVGLElBQUFBLEdBQUcsRUFBRUEsR0FBcEk7QUFBeUltQixJQUFBQSxJQUFJLEVBQUU7QUFBL0ksR0FBMUIsZUFDSXpJLDBEQUFBLENBQW9CLElBQXBCLEVBQTBCO0FBQUUyRyxJQUFBQSxPQUFPLEVBQUUyRyxXQUFYO0FBQXdCN0csSUFBQUEsU0FBUyxFQUFFLG1DQUFuQztBQUF3RWdDLElBQUFBLElBQUksRUFBRTtBQUE5RSxHQUExQixFQUFzSHVFLE1BQU0sR0FBRyxRQUFILEdBQWMsY0FBMUksQ0FESixlQUVJaE4sMERBQUEsQ0FBb0IsSUFBcEIsRUFBMEI7QUFBRTJHLElBQUFBLE9BQU8sRUFBRWlILFNBQVg7QUFBc0JuSCxJQUFBQSxTQUFTLEVBQUUsbUNBQWpDO0FBQXNFZ0MsSUFBQUEsSUFBSSxFQUFFO0FBQTVFLEdBQTFCLEVBQW9ILDRCQUFwSCxDQUZKLGVBR0l6SSwwREFBQSxDQUFvQixJQUFwQixFQUEwQjtBQUFFMkcsSUFBQUEsT0FBTyxFQUFFNkMsVUFBWDtBQUF1Qi9DLElBQUFBLFNBQVMsRUFBRSxtQ0FBbEM7QUFBdUVnQyxJQUFBQSxJQUFJLEVBQUU7QUFBN0UsR0FBMUIsRUFBcUgsWUFBckgsQ0FISixDQUZJLENBQVI7QUFNSCxDQXJETTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNCUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTkE7QUFDTyxNQUFNb0Usa0JBQWtCLGdCQUFHbUIsb0RBQWEsQ0FBQyxFQUFELENBQXhDO0FBQ0EsU0FBU2hFLGNBQVQsR0FBMEI7QUFDN0IsU0FBT2lFLGlEQUFVLENBQUNwQixrQkFBRCxDQUFqQjtBQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSkQ7QUFDQTtBQUNBO0FBQ08sTUFBTXVCLGtCQUFrQixHQUFHLENBQUM7QUFBRXBILEVBQUFBLFFBQUY7QUFBWXFILEVBQUFBLFFBQVo7QUFBc0JDLEVBQUFBLE1BQU0sR0FBRztBQUFFQyxJQUFBQSxVQUFVLEVBQUU7QUFBZDtBQUEvQixDQUFELEtBQW1FO0FBQ2pHLFFBQU1uSixVQUFVLEdBQUd1RCw4Q0FBTyxDQUFDLE1BQU0sSUFBSXVGLHVEQUFKLENBQWVHLFFBQWYsRUFBeUJDLE1BQXpCLENBQVAsRUFBeUMsQ0FBQ0QsUUFBRCxFQUFXQyxNQUFYLENBQXpDLENBQTFCO0FBQ0Esc0JBQU90TywwREFBQSxDQUFvQm1PLHNFQUFwQixFQUFnRDtBQUFFekwsSUFBQUEsS0FBSyxFQUFFO0FBQUUwQyxNQUFBQTtBQUFGO0FBQVQsR0FBaEQsRUFBMkU0QixRQUEzRSxDQUFQO0FBQ0gsQ0FITTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIUCxJQUFJNUUsU0FBUyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFNBQWQsSUFBNEIsVUFBVUMsT0FBVixFQUFtQkMsVUFBbkIsRUFBK0JDLENBQS9CLEVBQWtDQyxTQUFsQyxFQUE2QztBQUNyRixXQUFTQyxLQUFULENBQWVDLEtBQWYsRUFBc0I7QUFBRSxXQUFPQSxLQUFLLFlBQVlILENBQWpCLEdBQXFCRyxLQUFyQixHQUE2QixJQUFJSCxDQUFKLENBQU0sVUFBVUksT0FBVixFQUFtQjtBQUFFQSxNQUFBQSxPQUFPLENBQUNELEtBQUQsQ0FBUDtBQUFpQixLQUE1QyxDQUFwQztBQUFvRjs7QUFDNUcsU0FBTyxLQUFLSCxDQUFDLEtBQUtBLENBQUMsR0FBR0ssT0FBVCxDQUFOLEVBQXlCLFVBQVVELE9BQVYsRUFBbUJFLE1BQW5CLEVBQTJCO0FBQ3ZELGFBQVNDLFNBQVQsQ0FBbUJKLEtBQW5CLEVBQTBCO0FBQUUsVUFBSTtBQUFFSyxRQUFBQSxJQUFJLENBQUNQLFNBQVMsQ0FBQ1EsSUFBVixDQUFlTixLQUFmLENBQUQsQ0FBSjtBQUE4QixPQUFwQyxDQUFxQyxPQUFPTyxDQUFQLEVBQVU7QUFBRUosUUFBQUEsTUFBTSxDQUFDSSxDQUFELENBQU47QUFBWTtBQUFFOztBQUMzRixhQUFTQyxRQUFULENBQWtCUixLQUFsQixFQUF5QjtBQUFFLFVBQUk7QUFBRUssUUFBQUEsSUFBSSxDQUFDUCxTQUFTLENBQUMsT0FBRCxDQUFULENBQW1CRSxLQUFuQixDQUFELENBQUo7QUFBa0MsT0FBeEMsQ0FBeUMsT0FBT08sQ0FBUCxFQUFVO0FBQUVKLFFBQUFBLE1BQU0sQ0FBQ0ksQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDOUYsYUFBU0YsSUFBVCxDQUFjSSxNQUFkLEVBQXNCO0FBQUVBLE1BQUFBLE1BQU0sQ0FBQ0MsSUFBUCxHQUFjVCxPQUFPLENBQUNRLE1BQU0sQ0FBQ1QsS0FBUixDQUFyQixHQUFzQ0QsS0FBSyxDQUFDVSxNQUFNLENBQUNULEtBQVIsQ0FBTCxDQUFvQlcsSUFBcEIsQ0FBeUJQLFNBQXpCLEVBQW9DSSxRQUFwQyxDQUF0QztBQUFzRjs7QUFDOUdILElBQUFBLElBQUksQ0FBQyxDQUFDUCxTQUFTLEdBQUdBLFNBQVMsQ0FBQ2MsS0FBVixDQUFnQmpCLE9BQWhCLEVBQXlCQyxVQUFVLElBQUksRUFBdkMsQ0FBYixFQUF5RFUsSUFBekQsRUFBRCxDQUFKO0FBQ0gsR0FMTSxDQUFQO0FBTUgsQ0FSRDs7QUFTQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTJMLFlBQVksR0FBRztBQUNqQjVGLEVBQUFBLE1BQU0sRUFBRSxJQURTO0FBRWpCbEYsRUFBQUEsT0FBTyxFQUFFLElBRlE7QUFHakJHLEVBQUFBLEtBQUssRUFBRSxLQUhVO0FBSWpCekQsRUFBQUEsU0FBUyxFQUFFLElBSk07QUFLakIySSxFQUFBQSxTQUFTLEVBQUU7QUFMTSxDQUFyQjtBQU9PLE1BQU0wRixjQUFjLEdBQUcsQ0FBQztBQUFFNUgsRUFBQUEsUUFBRjtBQUFZcUQsRUFBQUEsT0FBWjtBQUFxQndFLEVBQUFBLFdBQVcsR0FBRyxLQUFuQztBQUEwQ0MsRUFBQUEsT0FBTyxFQUFFQyxRQUFRLEdBQUk5TixLQUFELElBQVdpRCxPQUFPLENBQUNqRCxLQUFSLENBQWNBLEtBQWQsQ0FBekU7QUFBK0YrTixFQUFBQSxlQUFlLEdBQUc7QUFBakgsQ0FBRCxLQUFzSTtBQUNoSyxRQUFNLENBQUM1TixJQUFELEVBQU82TixPQUFQLElBQWtCUixpRUFBZSxDQUFDTyxlQUFELEVBQWtCLElBQWxCLENBQXZDO0FBQ0EsUUFBTTtBQUFBLE9BQUM7QUFBRWpHLE1BQUFBLE1BQUY7QUFBVWxGLE1BQUFBLE9BQVY7QUFBbUJHLE1BQUFBLEtBQW5CO0FBQTBCekQsTUFBQUEsU0FBMUI7QUFBcUMySSxNQUFBQTtBQUFyQyxLQUFEO0FBQUEsT0FBbURnRztBQUFuRCxNQUErRHBGLCtDQUFRLENBQUM2RSxZQUFELENBQTdFO0FBQ0EsUUFBTTtBQUFBLE9BQUMxRixVQUFEO0FBQUEsT0FBYWtHO0FBQWIsTUFBOEJyRiwrQ0FBUSxDQUFDLEtBQUQsQ0FBNUM7QUFDQSxRQUFNO0FBQUEsT0FBQ0wsYUFBRDtBQUFBLE9BQWdCMkY7QUFBaEIsTUFBb0N0RiwrQ0FBUSxDQUFDLEtBQUQsQ0FBbEQ7QUFDQSxRQUFNdUYsWUFBWSxHQUFHbkksNkNBQU0sQ0FBQyxLQUFELENBQTNCO0FBQ0EsUUFBTW9JLGVBQWUsR0FBR3BJLDZDQUFNLENBQUMsS0FBRCxDQUE5QjtBQUNBLFFBQU1xSSxXQUFXLEdBQUdySSw2Q0FBTSxDQUFDLEtBQUQsQ0FBMUIsQ0FQZ0ssQ0FRaEs7O0FBQ0EsUUFBTXNJLGFBQWEsR0FBRzdHLDhDQUFPLENBQUMsTUFBTTBCLE9BQU8sQ0FBQ29GLE1BQVIsQ0FBZSxDQUFDRCxhQUFELEVBQWdCekcsTUFBaEIsS0FBMkI7QUFDMUV5RyxJQUFBQSxhQUFhLENBQUN6RyxNQUFNLENBQUMzSCxJQUFSLENBQWIsR0FBNkIySCxNQUE3QjtBQUNBLFdBQU95RyxhQUFQO0FBQ0gsR0FIbUMsRUFHakMsRUFIaUMsQ0FBUCxFQUdyQixDQUFDbkYsT0FBRCxDQUhxQixDQUE3QixDQVRnSyxDQWFoSzs7QUFDQWxLLEVBQUFBLGdEQUFTLENBQUMsTUFBTTtBQUNaLFVBQU00SSxNQUFNLEdBQUkzSCxJQUFJLElBQUlvTyxhQUFhLENBQUNwTyxJQUFELENBQXRCLElBQWlDLElBQWhEO0FBQ0EsVUFBTXlDLE9BQU8sR0FBR2tGLE1BQU0sSUFBSUEsTUFBTSxDQUFDbEYsT0FBUCxFQUExQjs7QUFDQSxRQUFJQSxPQUFKLEVBQWE7QUFDVCxZQUFNO0FBQUVHLFFBQUFBLEtBQUY7QUFBU3pELFFBQUFBLFNBQVQ7QUFBb0IySSxRQUFBQTtBQUFwQixVQUFrQ3JGLE9BQXhDO0FBQ0FxTCxNQUFBQSxRQUFRLENBQUM7QUFBRW5HLFFBQUFBLE1BQUY7QUFBVWxGLFFBQUFBLE9BQVY7QUFBbUJxRixRQUFBQSxTQUFuQjtBQUE4QjNJLFFBQUFBLFNBQTlCO0FBQXlDeUQsUUFBQUE7QUFBekMsT0FBRCxDQUFSO0FBQ0gsS0FIRCxNQUlLO0FBQ0RrTCxNQUFBQSxRQUFRLENBQUNQLFlBQUQsQ0FBUjtBQUNIO0FBQ0osR0FWUSxFQVVOLENBQUN2TixJQUFELEVBQU9vTyxhQUFQLEVBQXNCTixRQUF0QixDQVZNLENBQVQsQ0FkZ0ssQ0F5QmhLOztBQUNBL08sRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ1osUUFBSWtQLFlBQVksQ0FBQzFILE9BQWIsSUFBd0JzQixVQUF4QixJQUFzQ0MsU0FBdEMsSUFBbUQsQ0FBQzJGLFdBQXBELElBQW1FLENBQUNoTCxPQUFwRSxJQUErRSxDQUFDRyxLQUFwRixFQUNJOztBQUNKLEtBQUMsWUFBWTtBQUNULGFBQU81QixTQUFTLENBQUMsSUFBRCxFQUFPLEtBQUssQ0FBWixFQUFlLEtBQUssQ0FBcEIsRUFBdUIsYUFBYTtBQUNoRGlOLFFBQUFBLFlBQVksQ0FBQzFILE9BQWIsR0FBdUIsSUFBdkI7QUFDQXdILFFBQUFBLGFBQWEsQ0FBQyxJQUFELENBQWI7O0FBQ0EsWUFBSTtBQUNBLGdCQUFNdEwsT0FBTyxDQUFDbUYsT0FBUixFQUFOO0FBQ0gsU0FGRCxDQUdBLE9BQU8vSCxLQUFQLEVBQWM7QUFDVjtBQUNBZ08sVUFBQUEsT0FBTyxDQUFDLElBQUQsQ0FBUCxDQUZVLENBR1Y7QUFDSCxTQVBELFNBUVE7QUFDSkUsVUFBQUEsYUFBYSxDQUFDLEtBQUQsQ0FBYjtBQUNBRSxVQUFBQSxZQUFZLENBQUMxSCxPQUFiLEdBQXVCLEtBQXZCO0FBQ0g7QUFDSixPQWZlLENBQWhCO0FBZ0JILEtBakJEO0FBa0JILEdBckJRLEVBcUJOLENBQUMwSCxZQUFELEVBQWVwRyxVQUFmLEVBQTJCQyxTQUEzQixFQUFzQzJGLFdBQXRDLEVBQW1EaEwsT0FBbkQsRUFBNERHLEtBQTVELEVBQW1FbUwsYUFBbkUsRUFBa0ZGLE9BQWxGLENBckJNLENBQVQsQ0ExQmdLLENBZ0RoSzs7QUFDQTlPLEVBQUFBLGdEQUFTLENBQUMsTUFBTTtBQUNaLGFBQVMwTixRQUFULEdBQW9CO0FBQ2hCMEIsTUFBQUEsV0FBVyxDQUFDNUgsT0FBWixHQUFzQixJQUF0QjtBQUNIOztBQUNEc0UsSUFBQUEsTUFBTSxDQUFDMUQsZ0JBQVAsQ0FBd0IsY0FBeEIsRUFBd0NzRixRQUF4QztBQUNBLFdBQU8sTUFBTTVCLE1BQU0sQ0FBQ3pELG1CQUFQLENBQTJCLGNBQTNCLEVBQTJDcUYsUUFBM0MsQ0FBYjtBQUNILEdBTlEsRUFNTixDQUFDMEIsV0FBRCxDQU5NLENBQVQsQ0FqRGdLLENBd0RoSzs7QUFDQSxRQUFNakYsTUFBTSxHQUFHNUIsa0RBQVcsQ0FBRWdILE9BQUQsSUFBYXROLFNBQVMsQ0FBQyxLQUFLLENBQU4sRUFBUyxLQUFLLENBQWQsRUFBaUIsS0FBSyxDQUF0QixFQUF5QixhQUFhO0FBQ25GLFFBQUloQixJQUFJLEtBQUtzTyxPQUFiLEVBQ0k7QUFDSixRQUFJN0wsT0FBSixFQUNJLE1BQU1BLE9BQU8sQ0FBQzJGLFVBQVIsRUFBTjtBQUNKeUYsSUFBQUEsT0FBTyxDQUFDUyxPQUFELENBQVA7QUFDSCxHQU5nRCxDQUF2QixFQU10QixDQUFDdE8sSUFBRCxFQUFPeUMsT0FBUCxFQUFnQm9MLE9BQWhCLENBTnNCLENBQTFCLENBekRnSyxDQWdFaEs7O0FBQ0EsUUFBTVUsT0FBTyxHQUFHakgsa0RBQVcsQ0FBQyxNQUFNd0csUUFBUSxDQUFFVSxLQUFELElBQVlwTCxNQUFNLENBQUNxQyxNQUFQLENBQWNyQyxNQUFNLENBQUNxQyxNQUFQLENBQWMsRUFBZCxFQUFrQitJLEtBQWxCLENBQWQsRUFBd0M7QUFBRTVMLElBQUFBLEtBQUssRUFBRTtBQUFULEdBQXhDLENBQWIsQ0FBZixFQUF3RixDQUFDa0wsUUFBRCxDQUF4RixDQUEzQixDQWpFZ0ssQ0FrRWhLOztBQUNBLFFBQU1XLFNBQVMsR0FBR25ILGtEQUFXLENBQUMsTUFBTTtBQUNoQyxRQUFJLENBQUM3RSxPQUFMLEVBQ0k7QUFDSixVQUFNO0FBQUVxRixNQUFBQSxTQUFGO0FBQWEzSSxNQUFBQSxTQUFiO0FBQXdCeUQsTUFBQUE7QUFBeEIsUUFBa0NILE9BQXhDO0FBQ0FxTCxJQUFBQSxRQUFRLENBQUVVLEtBQUQsSUFBWXBMLE1BQU0sQ0FBQ3FDLE1BQVAsQ0FBY3JDLE1BQU0sQ0FBQ3FDLE1BQVAsQ0FBYyxFQUFkLEVBQWtCK0ksS0FBbEIsQ0FBZCxFQUF3QztBQUFFMUcsTUFBQUEsU0FBRjtBQUN6RDNJLE1BQUFBLFNBRHlEO0FBRXpEeUQsTUFBQUE7QUFGeUQsS0FBeEMsQ0FBYixDQUFSO0FBR0gsR0FQNEIsRUFPMUIsQ0FBQ0gsT0FBRCxFQUFVcUwsUUFBVixDQVAwQixDQUE3QixDQW5FZ0ssQ0EyRWhLOztBQUNBLFFBQU1ZLFlBQVksR0FBR3BILGtEQUFXLENBQUMsTUFBTTtBQUNuQztBQUNBLFFBQUksQ0FBQzZHLFdBQVcsQ0FBQzVILE9BQWpCLEVBQ0lzSCxPQUFPLENBQUMsSUFBRCxDQUFQO0FBQ1AsR0FKK0IsRUFJN0IsQ0FBQ00sV0FBRCxFQUFjTixPQUFkLENBSjZCLENBQWhDLENBNUVnSyxDQWlGaEs7O0FBQ0EsUUFBTUgsT0FBTyxHQUFHcEcsa0RBQVcsQ0FBRXpILEtBQUQsSUFBVztBQUNuQztBQUNBLFFBQUksQ0FBQ3NPLFdBQVcsQ0FBQzVILE9BQWpCLEVBQ0lvSCxRQUFRLENBQUM5TixLQUFELENBQVI7QUFDSixXQUFPQSxLQUFQO0FBQ0gsR0FMMEIsRUFLeEIsQ0FBQ3NPLFdBQUQsRUFBY1IsUUFBZCxDQUx3QixDQUEzQixDQWxGZ0ssQ0F3RmhLOztBQUNBLFFBQU0vRixPQUFPLEdBQUdOLGtEQUFXLENBQUMsTUFBTXRHLFNBQVMsQ0FBQyxLQUFLLENBQU4sRUFBUyxLQUFLLENBQWQsRUFBaUIsS0FBSyxDQUF0QixFQUF5QixhQUFhO0FBQzdFLFFBQUlpTixZQUFZLENBQUMxSCxPQUFiLElBQXdCc0IsVUFBeEIsSUFBc0NRLGFBQXRDLElBQXVEUCxTQUEzRCxFQUNJO0FBQ0osUUFBSSxDQUFDSCxNQUFELElBQVcsQ0FBQ2xGLE9BQWhCLEVBQ0ksTUFBTWlMLE9BQU8sQ0FBQyxJQUFJTiwyREFBSixFQUFELENBQWI7O0FBQ0osUUFBSSxDQUFDeEssS0FBTCxFQUFZO0FBQ1I7QUFDQWlMLE1BQUFBLE9BQU8sQ0FBQyxJQUFELENBQVA7O0FBQ0EsaUJBQW1DLEVBRWxDOztBQUNELFlBQU1ILE9BQU8sQ0FBQyxJQUFJeE4sNEVBQUosRUFBRCxDQUFiO0FBQ0g7O0FBQ0QrTixJQUFBQSxZQUFZLENBQUMxSCxPQUFiLEdBQXVCLElBQXZCO0FBQ0F3SCxJQUFBQSxhQUFhLENBQUMsSUFBRCxDQUFiOztBQUNBLFFBQUk7QUFDQSxZQUFNdEwsT0FBTyxDQUFDbUYsT0FBUixFQUFOO0FBQ0gsS0FGRCxDQUdBLE9BQU8vSCxLQUFQLEVBQWM7QUFDVjtBQUNBZ08sTUFBQUEsT0FBTyxDQUFDLElBQUQsQ0FBUCxDQUZVLENBR1Y7O0FBQ0EsWUFBTWhPLEtBQU47QUFDSCxLQVJELFNBU1E7QUFDSmtPLE1BQUFBLGFBQWEsQ0FBQyxLQUFELENBQWI7QUFDQUUsTUFBQUEsWUFBWSxDQUFDMUgsT0FBYixHQUF1QixLQUF2QjtBQUNIO0FBQ0osR0E1QjBDLENBQWhCLEVBNEJ2QixDQUFDMEgsWUFBRCxFQUFlcEcsVUFBZixFQUEyQlEsYUFBM0IsRUFBMENQLFNBQTFDLEVBQXFESCxNQUFyRCxFQUE2RGxGLE9BQTdELEVBQXNFaUwsT0FBdEUsRUFBK0U5SyxLQUEvRSxFQUFzRm1MLGFBQXRGLEVBQXFHRixPQUFyRyxDQTVCdUIsQ0FBM0IsQ0F6RmdLLENBc0hoSzs7QUFDQSxRQUFNekYsVUFBVSxHQUFHZCxrREFBVyxDQUFDLE1BQU10RyxTQUFTLENBQUMsS0FBSyxDQUFOLEVBQVMsS0FBSyxDQUFkLEVBQWlCLEtBQUssQ0FBdEIsRUFBeUIsYUFBYTtBQUNoRixRQUFJa04sZUFBZSxDQUFDM0gsT0FBaEIsSUFBMkI4QixhQUEvQixFQUNJO0FBQ0osUUFBSSxDQUFDNUYsT0FBTCxFQUNJLE9BQU9vTCxPQUFPLENBQUMsSUFBRCxDQUFkO0FBQ0pLLElBQUFBLGVBQWUsQ0FBQzNILE9BQWhCLEdBQTBCLElBQTFCO0FBQ0F5SCxJQUFBQSxnQkFBZ0IsQ0FBQyxJQUFELENBQWhCOztBQUNBLFFBQUk7QUFDQSxZQUFNdkwsT0FBTyxDQUFDMkYsVUFBUixFQUFOO0FBQ0gsS0FGRCxDQUdBLE9BQU92SSxLQUFQLEVBQWM7QUFDVjtBQUNBZ08sTUFBQUEsT0FBTyxDQUFDLElBQUQsQ0FBUCxDQUZVLENBR1Y7O0FBQ0EsWUFBTWhPLEtBQU47QUFDSCxLQVJELFNBU1E7QUFDSm1PLE1BQUFBLGdCQUFnQixDQUFDLEtBQUQsQ0FBaEI7QUFDQUUsTUFBQUEsZUFBZSxDQUFDM0gsT0FBaEIsR0FBMEIsS0FBMUI7QUFDSDtBQUNKLEdBcEI2QyxDQUFoQixFQW9CMUIsQ0FBQzJILGVBQUQsRUFBa0I3RixhQUFsQixFQUFpQzVGLE9BQWpDLEVBQTBDdUwsZ0JBQTFDLEVBQTRESCxPQUE1RCxDQXBCMEIsQ0FBOUIsQ0F2SGdLLENBNEloSzs7QUFDQSxRQUFNL0osZUFBZSxHQUFHd0Qsa0RBQVcsQ0FBQyxDQUFDdkQsV0FBRCxFQUFjQyxVQUFkLEVBQTBCQyxPQUExQixLQUFzQ2pELFNBQVMsQ0FBQyxLQUFLLENBQU4sRUFBUyxLQUFLLENBQWQsRUFBaUIsS0FBSyxDQUF0QixFQUF5QixhQUFhO0FBQ3JILFFBQUksQ0FBQ3lCLE9BQUwsRUFDSSxNQUFNaUwsT0FBTyxDQUFDLElBQUlOLDJEQUFKLEVBQUQsQ0FBYjtBQUNKLFFBQUksQ0FBQ3RGLFNBQUwsRUFDSSxNQUFNNEYsT0FBTyxDQUFDLElBQUlqTixnRkFBSixFQUFELENBQWI7QUFDSixXQUFPLE1BQU1nQyxPQUFPLENBQUNxQixlQUFSLENBQXdCQyxXQUF4QixFQUFxQ0MsVUFBckMsRUFBaURDLE9BQWpELENBQWI7QUFDSCxHQU5rRixDQUFoRCxFQU0vQixDQUFDeEIsT0FBRCxFQUFVaUwsT0FBVixFQUFtQjVGLFNBQW5CLENBTitCLENBQW5DLENBN0lnSyxDQW9KaEs7O0FBQ0EsUUFBTXBELGVBQWUsR0FBRzZDLDhDQUFPLENBQUMsTUFBTTlFLE9BQU8sSUFBSSxxQkFBcUJBLE9BQWhDLEdBQy9Cc0IsV0FBRCxJQUFpQi9DLFNBQVMsQ0FBQyxLQUFLLENBQU4sRUFBUyxLQUFLLENBQWQsRUFBaUIsS0FBSyxDQUF0QixFQUF5QixhQUFhO0FBQzlELFFBQUksQ0FBQzhHLFNBQUwsRUFDSSxNQUFNNEYsT0FBTyxDQUFDLElBQUlqTixnRkFBSixFQUFELENBQWI7QUFDSixXQUFPLE1BQU1nQyxPQUFPLENBQUNpQyxlQUFSLENBQXdCWCxXQUF4QixDQUFiO0FBQ0gsR0FKMkIsQ0FETSxHQU1oQ0ksU0FOeUIsRUFNZCxDQUFDMUIsT0FBRCxFQUFVaUwsT0FBVixFQUFtQjVGLFNBQW5CLENBTmMsQ0FBL0IsQ0FySmdLLENBNEpoSzs7QUFDQSxRQUFNK0csbUJBQW1CLEdBQUd0SCw4Q0FBTyxDQUFDLE1BQU05RSxPQUFPLElBQUkseUJBQXlCQSxPQUFwQyxHQUNuQ3FNLFlBQUQsSUFBa0I5TixTQUFTLENBQUMsS0FBSyxDQUFOLEVBQVMsS0FBSyxDQUFkLEVBQWlCLEtBQUssQ0FBdEIsRUFBeUIsYUFBYTtBQUMvRCxRQUFJLENBQUM4RyxTQUFMLEVBQ0ksTUFBTTRGLE9BQU8sQ0FBQyxJQUFJak4sZ0ZBQUosRUFBRCxDQUFiO0FBQ0osV0FBTyxNQUFNZ0MsT0FBTyxDQUFDb00sbUJBQVIsQ0FBNEJDLFlBQTVCLENBQWI7QUFDSCxHQUo0QixDQURTLEdBTXBDM0ssU0FONkIsRUFNbEIsQ0FBQzFCLE9BQUQsRUFBVWlMLE9BQVYsRUFBbUI1RixTQUFuQixDQU5rQixDQUFuQyxDQTdKZ0ssQ0FvS2hLOztBQUNBLFFBQU1pSCxXQUFXLEdBQUd4SCw4Q0FBTyxDQUFDLE1BQU05RSxPQUFPLElBQUksaUJBQWlCQSxPQUE1QixHQUMzQjdDLE9BQUQsSUFBYW9CLFNBQVMsQ0FBQyxLQUFLLENBQU4sRUFBUyxLQUFLLENBQWQsRUFBaUIsS0FBSyxDQUF0QixFQUF5QixhQUFhO0FBQzFELFFBQUksQ0FBQzhHLFNBQUwsRUFDSSxNQUFNNEYsT0FBTyxDQUFDLElBQUlqTixnRkFBSixFQUFELENBQWI7QUFDSixXQUFPLE1BQU1nQyxPQUFPLENBQUNzTSxXQUFSLENBQW9CblAsT0FBcEIsQ0FBYjtBQUNILEdBSnVCLENBRE0sR0FNNUJ1RSxTQU5xQixFQU1WLENBQUMxQixPQUFELEVBQVVpTCxPQUFWLEVBQW1CNUYsU0FBbkIsQ0FOVSxDQUEzQixDQXJLZ0ssQ0E0S2hLOztBQUNBL0ksRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ1osUUFBSTBELE9BQUosRUFBYTtBQUNUQSxNQUFBQSxPQUFPLENBQUN1TSxFQUFSLENBQVcsT0FBWCxFQUFvQlQsT0FBcEI7QUFDQTlMLE1BQUFBLE9BQU8sQ0FBQ3VNLEVBQVIsQ0FBVyxTQUFYLEVBQXNCUCxTQUF0QjtBQUNBaE0sTUFBQUEsT0FBTyxDQUFDdU0sRUFBUixDQUFXLFlBQVgsRUFBeUJOLFlBQXpCO0FBQ0FqTSxNQUFBQSxPQUFPLENBQUN1TSxFQUFSLENBQVcsT0FBWCxFQUFvQnRCLE9BQXBCO0FBQ0EsYUFBTyxNQUFNO0FBQ1RqTCxRQUFBQSxPQUFPLENBQUN3TSxHQUFSLENBQVksT0FBWixFQUFxQlYsT0FBckI7QUFDQTlMLFFBQUFBLE9BQU8sQ0FBQ3dNLEdBQVIsQ0FBWSxTQUFaLEVBQXVCUixTQUF2QjtBQUNBaE0sUUFBQUEsT0FBTyxDQUFDd00sR0FBUixDQUFZLFlBQVosRUFBMEJQLFlBQTFCO0FBQ0FqTSxRQUFBQSxPQUFPLENBQUN3TSxHQUFSLENBQVksT0FBWixFQUFxQnZCLE9BQXJCO0FBQ0gsT0FMRDtBQU1IO0FBQ0osR0FiUSxFQWFOLENBQUNqTCxPQUFELEVBQVU4TCxPQUFWLEVBQW1CRSxTQUFuQixFQUE4QkMsWUFBOUIsRUFBNENoQixPQUE1QyxDQWJNLENBQVQ7QUFjQSxzQkFBUTlPLDBEQUFBLENBQW9CME8sOERBQXBCLEVBQTRDO0FBQUVoTSxJQUFBQSxLQUFLLEVBQUU7QUFDckQySCxNQUFBQSxPQURxRDtBQUVyRHdFLE1BQUFBLFdBRnFEO0FBR3JEOUYsTUFBQUEsTUFIcUQ7QUFJckRsRixNQUFBQSxPQUpxRDtBQUtyRHRELE1BQUFBLFNBTHFEO0FBTXJEeUQsTUFBQUEsS0FOcUQ7QUFPckRrRixNQUFBQSxTQVBxRDtBQVFyREQsTUFBQUEsVUFScUQ7QUFTckRRLE1BQUFBLGFBVHFEO0FBVXJEYSxNQUFBQSxNQVZxRDtBQVdyRHRCLE1BQUFBLE9BWHFEO0FBWXJEUSxNQUFBQSxVQVpxRDtBQWFyRHRFLE1BQUFBLGVBYnFEO0FBY3JEWSxNQUFBQSxlQWRxRDtBQWVyRG1LLE1BQUFBLG1CQWZxRDtBQWdCckRFLE1BQUFBO0FBaEJxRDtBQUFULEdBQTVDLEVBaUJDbkosUUFqQkQsQ0FBUjtBQWtCSCxDQTdNTTs7Ozs7Ozs7Ozs7Ozs7O0FDckJQO0FBQ08sTUFBTXdILHNCQUFOLFNBQXFDM04sb0VBQXJDLENBQWlEO0FBQ3BERSxFQUFBQSxXQUFXLEdBQUc7QUFDVixVQUFNLEdBQUdJLFNBQVQ7QUFDQSxTQUFLQyxJQUFMLEdBQVksd0JBQVo7QUFDSDs7QUFKbUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0R4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0xBO0FBQ0E7QUFDTyxTQUFTa1AsZUFBVCxHQUEyQjtBQUM5QixRQUFNO0FBQUUvUCxJQUFBQSxTQUFGO0FBQWF1RixJQUFBQSxlQUFiO0FBQThCbUssSUFBQUE7QUFBOUIsTUFBc0Q1UCxxREFBUyxFQUFyRTtBQUNBLFNBQU9zSSw4Q0FBTyxDQUFDLE1BQU1wSSxTQUFTLElBQUl1RixlQUFiLElBQWdDbUssbUJBQWhDLEdBQ2Y7QUFBRTFQLElBQUFBLFNBQUY7QUFBYXVGLElBQUFBLGVBQWI7QUFBOEJtSyxJQUFBQTtBQUE5QixHQURlLEdBRWYxSyxTQUZRLEVBRUcsQ0FBQ2hGLFNBQUQsRUFBWXVGLGVBQVosRUFBNkJtSyxtQkFBN0IsQ0FGSCxDQUFkO0FBR0g7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUEQ7QUFDTyxNQUFNOUIsaUJBQWlCLGdCQUFHSCxvREFBYSxDQUFDLEVBQUQsQ0FBdkM7QUFDQSxTQUFTdUMsYUFBVCxHQUF5QjtBQUM1QixTQUFPdEMsaURBQVUsQ0FBQ0UsaUJBQUQsQ0FBakI7QUFDSDs7Ozs7Ozs7Ozs7Ozs7OztBQ0pEO0FBQ08sU0FBU00sZUFBVCxDQUF5QnpDLEdBQXpCLEVBQThCd0UsWUFBOUIsRUFBNEM7QUFDL0MsUUFBTTtBQUFBLE9BQUM5TixLQUFEO0FBQUEsT0FBUStOO0FBQVIsTUFBb0IzRywrQ0FBUSxDQUFDLE1BQU07QUFDckMsUUFBSSxPQUFPNEcsWUFBUCxLQUF3QixXQUE1QixFQUNJLE9BQU9GLFlBQVA7QUFDSixVQUFNOU4sS0FBSyxHQUFHZ08sWUFBWSxDQUFDQyxPQUFiLENBQXFCM0UsR0FBckIsQ0FBZDs7QUFDQSxRQUFJO0FBQ0EsYUFBT3RKLEtBQUssR0FBR2tPLElBQUksQ0FBQ0MsS0FBTCxDQUFXbk8sS0FBWCxDQUFILEdBQXVCOE4sWUFBbkM7QUFDSCxLQUZELENBR0EsT0FBT3ZQLEtBQVAsRUFBYztBQUNWaUQsTUFBQUEsT0FBTyxDQUFDQyxJQUFSLENBQWFsRCxLQUFiO0FBQ0EsYUFBT3VQLFlBQVA7QUFDSDtBQUNKLEdBWGlDLENBQWxDO0FBWUEsUUFBTU0sZUFBZSxHQUFHcEksa0RBQVcsQ0FBRXFJLFFBQUQsSUFBYztBQUM5QyxRQUFJQSxRQUFRLEtBQUtyTyxLQUFqQixFQUNJO0FBQ0orTixJQUFBQSxRQUFRLENBQUNNLFFBQUQsQ0FBUjs7QUFDQSxRQUFJQSxRQUFRLEtBQUssSUFBakIsRUFBdUI7QUFDbkJMLE1BQUFBLFlBQVksQ0FBQ00sVUFBYixDQUF3QmhGLEdBQXhCO0FBQ0gsS0FGRCxNQUdLO0FBQ0QsVUFBSTtBQUNBMEUsUUFBQUEsWUFBWSxDQUFDTyxPQUFiLENBQXFCakYsR0FBckIsRUFBMEI0RSxJQUFJLENBQUNNLFNBQUwsQ0FBZUgsUUFBZixDQUExQjtBQUNILE9BRkQsQ0FHQSxPQUFPOVAsS0FBUCxFQUFjO0FBQ1ZpRCxRQUFBQSxPQUFPLENBQUNqRCxLQUFSLENBQWNBLEtBQWQ7QUFDSDtBQUNKO0FBQ0osR0Fma0MsRUFlaEMsQ0FBQ3lCLEtBQUQsRUFBUStOLFFBQVIsRUFBa0J6RSxHQUFsQixDQWZnQyxDQUFuQztBQWdCQSxTQUFPLENBQUN0SixLQUFELEVBQVFvTyxlQUFSLENBQVA7QUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvQkQ7QUFDTyxNQUFNcEMsYUFBYSxnQkFBR1Ysb0RBQWEsQ0FBQyxFQUFELENBQW5DO0FBQ0EsU0FBUzNOLFNBQVQsR0FBcUI7QUFDeEIsU0FBTzROLGlEQUFVLENBQUNTLGFBQUQsQ0FBakI7QUFDSDs7Ozs7Ozs7OztBQ0pEOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQSIsInNvdXJjZXMiOlsid2VicGFjazovL25leHQtY20tdjIvLi9jb21wb25lbnRzL0Rhc2hib2FyZC9Ob3RDb25uZWN0ZWQuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL3BhZ2VzL2luZGV4LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlL2xpYi9hZGFwdGVyLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlL2xpYi9lcnJvcnMuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLWJhc2UvbGliL2luZGV4LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlL2xpYi9wb2xsLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlL2xpYi9zaWduZXIuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0LXVpL2xpYi9CdXR0b24uanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0LXVpL2xpYi9Db2xsYXBzZS5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QtdWkvbGliL1dhbGxldENvbm5lY3RCdXR0b24uanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0LXVpL2xpYi9XYWxsZXREaXNjb25uZWN0QnV0dG9uLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC11aS9saWIvV2FsbGV0SWNvbi5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QtdWkvbGliL1dhbGxldExpc3RJdGVtLmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC11aS9saWIvV2FsbGV0TW9kYWwuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0LXVpL2xpYi9XYWxsZXRNb2RhbEJ1dHRvbi5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QtdWkvbGliL1dhbGxldE1vZGFsUHJvdmlkZXIuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0LXVpL2xpYi9XYWxsZXRNdWx0aUJ1dHRvbi5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QtdWkvbGliL2luZGV4LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC11aS9saWIvdXNlV2FsbGV0TW9kYWwuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0L2xpYi9Db25uZWN0aW9uUHJvdmlkZXIuanMiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi8uL25vZGVfbW9kdWxlcy9Ac29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0L2xpYi9XYWxsZXRQcm92aWRlci5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QvbGliL2Vycm9ycy5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QvbGliL2luZGV4LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC9saWIvdXNlQW5jaG9yV2FsbGV0LmpzIiwid2VicGFjazovL25leHQtY20tdjIvLi9ub2RlX21vZHVsZXMvQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdC9saWIvdXNlQ29ubmVjdGlvbi5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QvbGliL3VzZUxvY2FsU3RvcmFnZS5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyLy4vbm9kZV9tb2R1bGVzL0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QvbGliL3VzZVdhbGxldC5qcyIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwiQHNvbGFuYS93ZWIzLmpzXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcImV2ZW50ZW1pdHRlcjNcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwibmV4dC9yb3V0ZXJcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwicmVhY3RcIiIsIndlYnBhY2s6Ly9uZXh0LWNtLXYyL2V4dGVybmFsIFwicmVhY3QtZG9tXCIiLCJ3ZWJwYWNrOi8vbmV4dC1jbS12Mi9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcblxyXG5pbXBvcnQgeyBXYWxsZXRNdWx0aUJ1dHRvbiB9IGZyb20gXCJAc29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0LXVpXCI7XHJcbmZ1bmN0aW9uIE5vdENvbm5lY3RlZCgpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2VudGVyIHAtNlwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgbGc6dGV4dC01eGwgZm9udC1ib2xkIHRleHQtY2VudGVyIHB5LTYgXCI+XHJcbiAgICAgICAgICAgIFN0YWtpbmcgPHNwYW4gY2xhc3NOYW1lPSd0ZXh0LWJyYW5kX2FjY2VudCc+UHJvamVjdDwvc3Bhbj5cclxuICAgICAgICAgIDwvaDE+XHJcblxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwicGItNCB0ZXh0LTJ4bFwiPlxyXG4gICAgICAgICAgICBMb2cgaW4gd2l0aCB5b3VyIHdlYjMgcHJvdmlkZXIgdG8gY29udGludWVcclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxXYWxsZXRNdWx0aUJ1dHRvbj5Db25uZWN0IFdhbGxldDwvV2FsbGV0TXVsdGlCdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOb3RDb25uZWN0ZWQ7XHJcbiIsImltcG9ydCBSZWFjdCx7dXNlRWZmZWN0fSBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XG5pbXBvcnQgeyB1c2VXYWxsZXQgfSBmcm9tIFwiQHNvbGFuYS93YWxsZXQtYWRhcHRlci1yZWFjdFwiO1xuaW1wb3J0IE5vdENvbm5lY3RlZCBmcm9tIFwiLi4vY29tcG9uZW50cy9EYXNoYm9hcmQvTm90Q29ubmVjdGVkXCI7XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKCkge1xuICBjb25zdCB7IHB1YmxpY0tleSB9ID0gdXNlV2FsbGV0KCk7XG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuICAgaWYgKCFwdWJsaWNLZXkpIHtcbiAgICAgcmV0dXJuIChcbiAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNlbnRlciBoLTgwdmhcIj5cbiAgICAgICAgIDxOb3RDb25uZWN0ZWQgLz5cbiAgICAgICA8L2Rpdj5cbiAgICAgKTtcbiAgIH0gZWxzZSB7XG4gICAgIHJvdXRlci5wdXNoKFwiL2Rhc2hib2FyZFwiKTtcbiAgIH1cblxuICByZXR1cm4gPD48Lz47XG59XG4iLCJpbXBvcnQgRXZlbnRFbWl0dGVyIGZyb20gJ2V2ZW50ZW1pdHRlcjMnO1xuZXhwb3J0IHsgRXZlbnRFbWl0dGVyIH07XG5leHBvcnQgY2xhc3MgQmFzZVdhbGxldEFkYXB0ZXIgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xufVxuZXhwb3J0IHZhciBXYWxsZXRBZGFwdGVyTmV0d29yaztcbihmdW5jdGlvbiAoV2FsbGV0QWRhcHRlck5ldHdvcmspIHtcbiAgICBXYWxsZXRBZGFwdGVyTmV0d29ya1tcIk1haW5uZXRcIl0gPSBcIm1haW5uZXQtYmV0YVwiO1xuICAgIFdhbGxldEFkYXB0ZXJOZXR3b3JrW1wiVGVzdG5ldFwiXSA9IFwidGVzdG5ldFwiO1xuICAgIFdhbGxldEFkYXB0ZXJOZXR3b3JrW1wiRGV2bmV0XCJdID0gXCJkZXZuZXRcIjtcbn0pKFdhbGxldEFkYXB0ZXJOZXR3b3JrIHx8IChXYWxsZXRBZGFwdGVyTmV0d29yayA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1hZGFwdGVyLmpzLm1hcCIsImV4cG9ydCBjbGFzcyBXYWxsZXRFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2V4cGxpY2l0LW1vZHVsZS1ib3VuZGFyeS10eXBlc1xuICAgIGNvbnN0cnVjdG9yKG1lc3NhZ2UsIGVycm9yKSB7XG4gICAgICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgICAgICB0aGlzLmVycm9yID0gZXJyb3I7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldE5vdEZvdW5kRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXROb3RGb3VuZEVycm9yJztcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgV2FsbGV0Tm90SW5zdGFsbGVkRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXROb3RJbnN0YWxsZWRFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldE5vdFJlYWR5RXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXROb3RSZWFkeUVycm9yJztcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgV2FsbGV0Q29ubmVjdGlvbkVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0Q29ubmVjdGlvbkVycm9yJztcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgV2FsbGV0RGlzY29ubmVjdGVkRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXREaXNjb25uZWN0ZWRFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldERpc2Nvbm5lY3Rpb25FcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldERpc2Nvbm5lY3Rpb25FcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldEFjY291bnRFcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldEFjY291bnRFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldFB1YmxpY0tleUVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0UHVibGljS2V5RXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXRLZXlwYWlyRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXRLZXlwYWlyRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBXYWxsZXROb3RDb25uZWN0ZWRFcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldE5vdENvbm5lY3RlZEVycm9yJztcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgV2FsbGV0U2VuZFRyYW5zYWN0aW9uRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXRTZW5kVHJhbnNhY3Rpb25FcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldFNpZ25NZXNzYWdlRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXRTaWduTWVzc2FnZUVycm9yJztcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgV2FsbGV0U2lnblRyYW5zYWN0aW9uRXJyb3IgZXh0ZW5kcyBXYWxsZXRFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdXYWxsZXRTaWduVHJhbnNhY3Rpb25FcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldFRpbWVvdXRFcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldFRpbWVvdXRFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldFdpbmRvd0Jsb2NrZWRFcnJvciBleHRlbmRzIFdhbGxldEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ1dhbGxldFdpbmRvd0Jsb2NrZWRFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFdhbGxldFdpbmRvd0Nsb3NlZEVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0V2luZG93Q2xvc2VkRXJyb3InO1xuICAgIH1cbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVycm9ycy5qcy5tYXAiLCJleHBvcnQgKiBmcm9tICcuL2FkYXB0ZXInO1xuZXhwb3J0ICogZnJvbSAnLi9lcnJvcnMnO1xuZXhwb3J0ICogZnJvbSAnLi9wb2xsJztcbmV4cG9ydCAqIGZyb20gJy4vc2lnbmVyJztcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsInZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XG4gICAgfSk7XG59O1xuZXhwb3J0IGZ1bmN0aW9uIHBvbGwoY2FsbGJhY2ssIGludGVydmFsLCBjb3VudCkge1xuICAgIGlmIChjb3VudCA+IDApIHtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgICAgICBjb25zdCBkb25lID0geWllbGQgY2FsbGJhY2soKTtcbiAgICAgICAgICAgIGlmICghZG9uZSlcbiAgICAgICAgICAgICAgICBwb2xsKGNhbGxiYWNrLCBpbnRlcnZhbCwgY291bnQgLSAxKTtcbiAgICAgICAgfSksIGludGVydmFsKTtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gcG9sbFVudGlsUmVhZHkoYWRhcHRlciwgcG9sbEludGVydmFsLCBwb2xsQ291bnQpIHtcbiAgICBwb2xsKCgpID0+IHtcbiAgICAgICAgY29uc3QgeyByZWFkeSB9ID0gYWRhcHRlcjtcbiAgICAgICAgaWYgKHJlYWR5KSB7XG4gICAgICAgICAgICBpZiAoIWFkYXB0ZXIuZW1pdCgncmVhZHknKSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgJHthZGFwdGVyLmNvbnN0cnVjdG9yLm5hbWV9IGlzIHJlYWR5IGJ1dCBubyBsaXN0ZW5lciB3YXMgcmVnaXN0ZXJlZGApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZWFkeTtcbiAgICB9LCBwb2xsSW50ZXJ2YWwsIHBvbGxDb3VudCk7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1wb2xsLmpzLm1hcCIsInZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XG4gICAgfSk7XG59O1xudmFyIF9fcmVzdCA9ICh0aGlzICYmIHRoaXMuX19yZXN0KSB8fCBmdW5jdGlvbiAocywgZSkge1xuICAgIHZhciB0ID0ge307XG4gICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApICYmIGUuaW5kZXhPZihwKSA8IDApXG4gICAgICAgIHRbcF0gPSBzW3BdO1xuICAgIGlmIChzICE9IG51bGwgJiYgdHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgPT09IFwiZnVuY3Rpb25cIilcbiAgICAgICAgZm9yICh2YXIgaSA9IDAsIHAgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHMpOyBpIDwgcC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKGUuaW5kZXhPZihwW2ldKSA8IDAgJiYgT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKHMsIHBbaV0pKVxuICAgICAgICAgICAgICAgIHRbcFtpXV0gPSBzW3BbaV1dO1xuICAgICAgICB9XG4gICAgcmV0dXJuIHQ7XG59O1xuaW1wb3J0IHsgQmFzZVdhbGxldEFkYXB0ZXIgfSBmcm9tICcuL2FkYXB0ZXInO1xuaW1wb3J0IHsgV2FsbGV0RXJyb3IsIFdhbGxldFNlbmRUcmFuc2FjdGlvbkVycm9yIH0gZnJvbSAnLi9lcnJvcnMnO1xuZXhwb3J0IGNsYXNzIEJhc2VTaWduZXJXYWxsZXRBZGFwdGVyIGV4dGVuZHMgQmFzZVdhbGxldEFkYXB0ZXIge1xuICAgIHNlbmRUcmFuc2FjdGlvbih0cmFuc2FjdGlvbiwgY29ubmVjdGlvbiwgb3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgICAgICBsZXQgZW1pdCA9IHRydWU7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHRyYW5zYWN0aW9uLmZlZVBheWVyIHx8ICh0cmFuc2FjdGlvbi5mZWVQYXllciA9IHRoaXMucHVibGljS2V5IHx8IHVuZGVmaW5lZCk7XG4gICAgICAgICAgICAgICAgICAgIHRyYW5zYWN0aW9uLnJlY2VudEJsb2NraGFzaCB8fCAodHJhbnNhY3Rpb24ucmVjZW50QmxvY2toYXNoID0gKHlpZWxkIGNvbm5lY3Rpb24uZ2V0UmVjZW50QmxvY2toYXNoKCdmaW5hbGl6ZWQnKSkuYmxvY2toYXNoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgeyBzaWduZXJzIH0gPSBvcHRpb25zLCBzZW5kT3B0aW9ucyA9IF9fcmVzdChvcHRpb25zLCBbXCJzaWduZXJzXCJdKTtcbiAgICAgICAgICAgICAgICAgICAgKHNpZ25lcnMgPT09IG51bGwgfHwgc2lnbmVycyA9PT0gdm9pZCAwID8gdm9pZCAwIDogc2lnbmVycy5sZW5ndGgpICYmIHRyYW5zYWN0aW9uLnBhcnRpYWxTaWduKC4uLnNpZ25lcnMpO1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbiA9IHlpZWxkIHRoaXMuc2lnblRyYW5zYWN0aW9uKHRyYW5zYWN0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmF3VHJhbnNhY3Rpb24gPSB0cmFuc2FjdGlvbi5zZXJpYWxpemUoKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHlpZWxkIGNvbm5lY3Rpb24uc2VuZFJhd1RyYW5zYWN0aW9uKHJhd1RyYW5zYWN0aW9uLCBzZW5kT3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAvLyBJZiB0aGUgZXJyb3Igd2FzIHRocm93biBieSBgc2lnblRyYW5zYWN0aW9uYCwgcmV0aHJvdyBpdCBhbmQgZG9uJ3QgZW1pdCBhIGR1cGxpY2F0ZSBldmVudFxuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBXYWxsZXRFcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgZW1pdCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFdhbGxldFNlbmRUcmFuc2FjdGlvbkVycm9yKGVycm9yID09PSBudWxsIHx8IGVycm9yID09PSB2b2lkIDAgPyB2b2lkIDAgOiBlcnJvci5tZXNzYWdlLCBlcnJvcik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgaWYgKGVtaXQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycm9yKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBCYXNlTWVzc2FnZVNpZ25lcldhbGxldEFkYXB0ZXIgZXh0ZW5kcyBCYXNlU2lnbmVyV2FsbGV0QWRhcHRlciB7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1zaWduZXIuanMubWFwIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBCdXR0b24gPSAocHJvcHMpID0+IHtcbiAgICBjb25zdCBqdXN0aWZ5Q29udGVudCA9IHByb3BzLmVuZEljb24gfHwgcHJvcHMuc3RhcnRJY29uID8gJ3NwYWNlLWJldHdlZW4nIDogJ2NlbnRlcic7XG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIsIHsgY2xhc3NOYW1lOiBgd2FsbGV0LWFkYXB0ZXItYnV0dG9uICR7cHJvcHMuY2xhc3NOYW1lIHx8ICcnfWAsIGRpc2FibGVkOiBwcm9wcy5kaXNhYmxlZCwgb25DbGljazogcHJvcHMub25DbGljaywgc3R5bGU6IE9iamVjdC5hc3NpZ24oeyBqdXN0aWZ5Q29udGVudCB9LCBwcm9wcy5zdHlsZSksIHRhYkluZGV4OiBwcm9wcy50YWJJbmRleCB8fCAwLCB0eXBlOiBcImJ1dHRvblwiIH0sXG4gICAgICAgIHByb3BzLnN0YXJ0SWNvbiAmJiBSZWFjdC5jcmVhdGVFbGVtZW50KFwiaVwiLCB7IGNsYXNzTmFtZTogXCJ3YWxsZXQtYWRhcHRlci1idXR0b24tc3RhcnQtaWNvblwiIH0sIHByb3BzLnN0YXJ0SWNvbiksXG4gICAgICAgIHByb3BzLmNoaWxkcmVuLFxuICAgICAgICBwcm9wcy5lbmRJY29uICYmIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJpXCIsIHsgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLWJ1dHRvbi1lbmQtaWNvblwiIH0sIHByb3BzLmVuZEljb24pKSk7XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9QnV0dG9uLmpzLm1hcCIsImltcG9ydCBSZWFjdCwgeyB1c2VMYXlvdXRFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBDb2xsYXBzZSA9ICh7IGlkLCBjaGlsZHJlbiwgZXhwYW5kZWQgPSBmYWxzZSB9KSA9PiB7XG4gICAgY29uc3QgcmVmID0gdXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IGluc3RhbnQgPSB1c2VSZWYodHJ1ZSk7XG4gICAgY29uc3QgdHJhbnNpdGlvbiA9ICdoZWlnaHQgMjUwbXMgZWFzZS1vdXQnO1xuICAgIGNvbnN0IG9wZW5Db2xsYXBzZSA9ICgpID0+IHtcbiAgICAgICAgY29uc3Qgbm9kZSA9IHJlZi5jdXJyZW50O1xuICAgICAgICBpZiAoIW5vZGUpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICAgICAgICBub2RlLnN0eWxlLmhlaWdodCA9IG5vZGUuc2Nyb2xsSGVpZ2h0ICsgJ3B4JztcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBjbG9zZUNvbGxhcHNlID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBub2RlID0gcmVmLmN1cnJlbnQ7XG4gICAgICAgIGlmICghbm9kZSlcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcbiAgICAgICAgICAgIG5vZGUuc3R5bGUuaGVpZ2h0ID0gbm9kZS5vZmZzZXRIZWlnaHQgKyAncHgnO1xuICAgICAgICAgICAgbm9kZS5zdHlsZS5vdmVyZmxvdyA9ICdoaWRkZW4nO1xuICAgICAgICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcbiAgICAgICAgICAgICAgICBub2RlLnN0eWxlLmhlaWdodCA9ICcwJztcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChleHBhbmRlZCkge1xuICAgICAgICAgICAgb3BlbkNvbGxhcHNlKCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjbG9zZUNvbGxhcHNlKCk7XG4gICAgICAgIH1cbiAgICB9LCBbZXhwYW5kZWRdKTtcbiAgICB1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBub2RlID0gcmVmLmN1cnJlbnQ7XG4gICAgICAgIGlmICghbm9kZSlcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgZnVuY3Rpb24gaGFuZGxlQ29tcGxldGUoKSB7XG4gICAgICAgICAgICBpZiAoIW5vZGUpXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgbm9kZS5zdHlsZS5vdmVyZmxvdyA9IGV4cGFuZGVkID8gJ2luaXRpYWwnIDogJ2hpZGRlbic7XG4gICAgICAgICAgICBpZiAoZXhwYW5kZWQpIHtcbiAgICAgICAgICAgICAgICBub2RlLnN0eWxlLmhlaWdodCA9ICdhdXRvJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmdW5jdGlvbiBoYW5kbGVUcmFuc2l0aW9uRW5kKGV2ZW50KSB7XG4gICAgICAgICAgICBpZiAobm9kZSAmJiBldmVudC50YXJnZXQgPT09IG5vZGUgJiYgZXZlbnQucHJvcGVydHlOYW1lID09PSAnaGVpZ2h0Jykge1xuICAgICAgICAgICAgICAgIGhhbmRsZUNvbXBsZXRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGluc3RhbnQuY3VycmVudCkge1xuICAgICAgICAgICAgaGFuZGxlQ29tcGxldGUoKTtcbiAgICAgICAgICAgIGluc3RhbnQuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIG5vZGUuYWRkRXZlbnRMaXN0ZW5lcigndHJhbnNpdGlvbmVuZCcsIGhhbmRsZVRyYW5zaXRpb25FbmQpO1xuICAgICAgICByZXR1cm4gKCkgPT4gbm9kZS5yZW1vdmVFdmVudExpc3RlbmVyKCd0cmFuc2l0aW9uZW5kJywgaGFuZGxlVHJhbnNpdGlvbkVuZCk7XG4gICAgfSwgW2V4cGFuZGVkXSk7XG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgY2hpbGRyZW46IGNoaWxkcmVuLCBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItY29sbGFwc2VcIiwgaWQ6IGlkLCByZWY6IHJlZiwgcm9sZTogXCJyZWdpb25cIiwgc3R5bGU6IHsgaGVpZ2h0OiAwLCB0cmFuc2l0aW9uOiBpbnN0YW50LmN1cnJlbnQgPyB1bmRlZmluZWQgOiB0cmFuc2l0aW9uIH0gfSkpO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUNvbGxhcHNlLmpzLm1hcCIsInZhciBfX3Jlc3QgPSAodGhpcyAmJiB0aGlzLl9fcmVzdCkgfHwgZnVuY3Rpb24gKHMsIGUpIHtcbiAgICB2YXIgdCA9IHt9O1xuICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxuICAgICAgICB0W3BdID0gc1twXTtcbiAgICBpZiAocyAhPSBudWxsICYmIHR5cGVvZiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzID09PSBcImZ1bmN0aW9uXCIpXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChlLmluZGV4T2YocFtpXSkgPCAwICYmIE9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChzLCBwW2ldKSlcbiAgICAgICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcbiAgICAgICAgfVxuICAgIHJldHVybiB0O1xufTtcbmltcG9ydCB7IHVzZVdhbGxldCB9IGZyb20gJ0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QnO1xuaW1wb3J0IFJlYWN0LCB7IHVzZUNhbGxiYWNrLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi9CdXR0b24nO1xuaW1wb3J0IHsgV2FsbGV0SWNvbiB9IGZyb20gJy4vV2FsbGV0SWNvbic7XG5leHBvcnQgY29uc3QgV2FsbGV0Q29ubmVjdEJ1dHRvbiA9IChfYSkgPT4ge1xuICAgIHZhciB7IGNoaWxkcmVuLCBkaXNhYmxlZCwgb25DbGljayB9ID0gX2EsIHByb3BzID0gX19yZXN0KF9hLCBbXCJjaGlsZHJlblwiLCBcImRpc2FibGVkXCIsIFwib25DbGlja1wiXSk7XG4gICAgY29uc3QgeyB3YWxsZXQsIGNvbm5lY3QsIGNvbm5lY3RpbmcsIGNvbm5lY3RlZCB9ID0gdXNlV2FsbGV0KCk7XG4gICAgY29uc3QgaGFuZGxlQ2xpY2sgPSB1c2VDYWxsYmFjaygoZXZlbnQpID0+IHtcbiAgICAgICAgaWYgKG9uQ2xpY2spXG4gICAgICAgICAgICBvbkNsaWNrKGV2ZW50KTtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1lbXB0eS1mdW5jdGlvblxuICAgICAgICBpZiAoIWV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpXG4gICAgICAgICAgICBjb25uZWN0KCkuY2F0Y2goKCkgPT4geyB9KTtcbiAgICB9LCBbb25DbGljaywgY29ubmVjdF0pO1xuICAgIGNvbnN0IGNvbnRlbnQgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKGNoaWxkcmVuKVxuICAgICAgICAgICAgcmV0dXJuIGNoaWxkcmVuO1xuICAgICAgICBpZiAoY29ubmVjdGluZylcbiAgICAgICAgICAgIHJldHVybiAnQ29ubmVjdGluZyAuLi4nO1xuICAgICAgICBpZiAoY29ubmVjdGVkKVxuICAgICAgICAgICAgcmV0dXJuICdDb25uZWN0ZWQnO1xuICAgICAgICBpZiAod2FsbGV0KVxuICAgICAgICAgICAgcmV0dXJuICdDb25uZWN0JztcbiAgICAgICAgcmV0dXJuICdDb25uZWN0IFdhbGxldCc7XG4gICAgfSwgW2NoaWxkcmVuLCBjb25uZWN0aW5nLCBjb25uZWN0ZWQsIHdhbGxldF0pO1xuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChCdXR0b24sIE9iamVjdC5hc3NpZ24oeyBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItYnV0dG9uLXRyaWdnZXJcIiwgZGlzYWJsZWQ6IGRpc2FibGVkIHx8ICF3YWxsZXQgfHwgY29ubmVjdGluZyB8fCBjb25uZWN0ZWQsIHN0YXJ0SWNvbjogd2FsbGV0ID8gUmVhY3QuY3JlYXRlRWxlbWVudChXYWxsZXRJY29uLCB7IHdhbGxldDogd2FsbGV0IH0pIDogdW5kZWZpbmVkLCBvbkNsaWNrOiBoYW5kbGVDbGljayB9LCBwcm9wcyksIGNvbnRlbnQpKTtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1XYWxsZXRDb25uZWN0QnV0dG9uLmpzLm1hcCIsInZhciBfX3Jlc3QgPSAodGhpcyAmJiB0aGlzLl9fcmVzdCkgfHwgZnVuY3Rpb24gKHMsIGUpIHtcbiAgICB2YXIgdCA9IHt9O1xuICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxuICAgICAgICB0W3BdID0gc1twXTtcbiAgICBpZiAocyAhPSBudWxsICYmIHR5cGVvZiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzID09PSBcImZ1bmN0aW9uXCIpXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChlLmluZGV4T2YocFtpXSkgPCAwICYmIE9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChzLCBwW2ldKSlcbiAgICAgICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcbiAgICAgICAgfVxuICAgIHJldHVybiB0O1xufTtcbmltcG9ydCB7IHVzZVdhbGxldCB9IGZyb20gJ0Bzb2xhbmEvd2FsbGV0LWFkYXB0ZXItcmVhY3QnO1xuaW1wb3J0IFJlYWN0LCB7IHVzZUNhbGxiYWNrLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi9CdXR0b24nO1xuaW1wb3J0IHsgV2FsbGV0SWNvbiB9IGZyb20gJy4vV2FsbGV0SWNvbic7XG5leHBvcnQgY29uc3QgV2FsbGV0RGlzY29ubmVjdEJ1dHRvbiA9IChfYSkgPT4ge1xuICAgIHZhciB7IGNoaWxkcmVuLCBkaXNhYmxlZCwgb25DbGljayB9ID0gX2EsIHByb3BzID0gX19yZXN0KF9hLCBbXCJjaGlsZHJlblwiLCBcImRpc2FibGVkXCIsIFwib25DbGlja1wiXSk7XG4gICAgY29uc3QgeyB3YWxsZXQsIGRpc2Nvbm5lY3QsIGRpc2Nvbm5lY3RpbmcgfSA9IHVzZVdhbGxldCgpO1xuICAgIGNvbnN0IGhhbmRsZUNsaWNrID0gdXNlQ2FsbGJhY2soKGV2ZW50KSA9PiB7XG4gICAgICAgIGlmIChvbkNsaWNrKVxuICAgICAgICAgICAgb25DbGljayhldmVudCk7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZW1wdHktZnVuY3Rpb25cbiAgICAgICAgaWYgKCFldmVudC5kZWZhdWx0UHJldmVudGVkKVxuICAgICAgICAgICAgZGlzY29ubmVjdCgpLmNhdGNoKCgpID0+IHsgfSk7XG4gICAgfSwgW29uQ2xpY2ssIGRpc2Nvbm5lY3RdKTtcbiAgICBjb25zdCBjb250ZW50ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGlmIChjaGlsZHJlbilcbiAgICAgICAgICAgIHJldHVybiBjaGlsZHJlbjtcbiAgICAgICAgaWYgKGRpc2Nvbm5lY3RpbmcpXG4gICAgICAgICAgICByZXR1cm4gJ0Rpc2Nvbm5lY3RpbmcgLi4uJztcbiAgICAgICAgaWYgKHdhbGxldClcbiAgICAgICAgICAgIHJldHVybiAnRGlzY29ubmVjdCc7XG4gICAgICAgIHJldHVybiAnRGlzY29ubmVjdCBXYWxsZXQnO1xuICAgIH0sIFtjaGlsZHJlbiwgZGlzY29ubmVjdGluZywgd2FsbGV0XSk7XG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbiwgT2JqZWN0LmFzc2lnbih7IGNsYXNzTmFtZTogXCJ3YWxsZXQtYWRhcHRlci1idXR0b24tdHJpZ2dlclwiLCBkaXNhYmxlZDogZGlzYWJsZWQgfHwgIXdhbGxldCwgc3RhcnRJY29uOiB3YWxsZXQgPyBSZWFjdC5jcmVhdGVFbGVtZW50KFdhbGxldEljb24sIHsgd2FsbGV0OiB3YWxsZXQgfSkgOiB1bmRlZmluZWQsIG9uQ2xpY2s6IGhhbmRsZUNsaWNrIH0sIHByb3BzKSwgY29udGVudCkpO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVdhbGxldERpc2Nvbm5lY3RCdXR0b24uanMubWFwIiwidmFyIF9fcmVzdCA9ICh0aGlzICYmIHRoaXMuX19yZXN0KSB8fCBmdW5jdGlvbiAocywgZSkge1xuICAgIHZhciB0ID0ge307XG4gICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApICYmIGUuaW5kZXhPZihwKSA8IDApXG4gICAgICAgIHRbcF0gPSBzW3BdO1xuICAgIGlmIChzICE9IG51bGwgJiYgdHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgPT09IFwiZnVuY3Rpb25cIilcbiAgICAgICAgZm9yICh2YXIgaSA9IDAsIHAgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHMpOyBpIDwgcC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKGUuaW5kZXhPZihwW2ldKSA8IDAgJiYgT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKHMsIHBbaV0pKVxuICAgICAgICAgICAgICAgIHRbcFtpXV0gPSBzW3BbaV1dO1xuICAgICAgICB9XG4gICAgcmV0dXJuIHQ7XG59O1xuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBXYWxsZXRJY29uID0gKF9hKSA9PiB7XG4gICAgdmFyIHsgd2FsbGV0IH0gPSBfYSwgcHJvcHMgPSBfX3Jlc3QoX2EsIFtcIndhbGxldFwiXSk7XG4gICAgcmV0dXJuIHdhbGxldCAmJiBSZWFjdC5jcmVhdGVFbGVtZW50KFwiaW1nXCIsIE9iamVjdC5hc3NpZ24oeyBzcmM6IHdhbGxldC5pY29uLCBhbHQ6IGAke3dhbGxldC5uYW1lfSBpY29uYCB9LCBwcm9wcykpO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVdhbGxldEljb24uanMubWFwIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4vQnV0dG9uJztcbmltcG9ydCB7IFdhbGxldEljb24gfSBmcm9tICcuL1dhbGxldEljb24nO1xuZXhwb3J0IGNvbnN0IFdhbGxldExpc3RJdGVtID0gKHsgaGFuZGxlQ2xpY2ssIHRhYkluZGV4LCB3YWxsZXQgfSkgPT4ge1xuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChcImxpXCIsIG51bGwsXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnV0dG9uLCB7IG9uQ2xpY2s6IGhhbmRsZUNsaWNrLCBlbmRJY29uOiBSZWFjdC5jcmVhdGVFbGVtZW50KFdhbGxldEljb24sIHsgd2FsbGV0OiB3YWxsZXQgfSksIHRhYkluZGV4OiB0YWJJbmRleCB9LCB3YWxsZXQubmFtZSkpKTtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1XYWxsZXRMaXN0SXRlbS5qcy5tYXAiLCJpbXBvcnQgeyB1c2VXYWxsZXQgfSBmcm9tICdAc29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0JztcbmltcG9ydCBSZWFjdCwgeyB1c2VDYWxsYmFjaywgdXNlTGF5b3V0RWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY3JlYXRlUG9ydGFsIH0gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4vQnV0dG9uJztcbmltcG9ydCB7IENvbGxhcHNlIH0gZnJvbSAnLi9Db2xsYXBzZSc7XG5pbXBvcnQgeyB1c2VXYWxsZXRNb2RhbCB9IGZyb20gJy4vdXNlV2FsbGV0TW9kYWwnO1xuaW1wb3J0IHsgV2FsbGV0TGlzdEl0ZW0gfSBmcm9tICcuL1dhbGxldExpc3RJdGVtJztcbmV4cG9ydCBjb25zdCBXYWxsZXRNb2RhbCA9ICh7IGNsYXNzTmFtZSA9ICcnLCBsb2dvLCBmZWF0dXJlZFdhbGxldHMgPSAzLCBjb250YWluZXIgPSAnYm9keScsIH0pID0+IHtcbiAgICBjb25zdCByZWYgPSB1c2VSZWYobnVsbCk7XG4gICAgY29uc3QgeyB3YWxsZXRzLCBzZWxlY3QgfSA9IHVzZVdhbGxldCgpO1xuICAgIGNvbnN0IHsgc2V0VmlzaWJsZSB9ID0gdXNlV2FsbGV0TW9kYWwoKTtcbiAgICBjb25zdCBbZXhwYW5kZWQsIHNldEV4cGFuZGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbZmFkZUluLCBzZXRGYWRlSW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtwb3J0YWwsIHNldFBvcnRhbF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbZmVhdHVyZWQsIG1vcmVdID0gdXNlTWVtbygoKSA9PiBbd2FsbGV0cy5zbGljZSgwLCBmZWF0dXJlZFdhbGxldHMpLCB3YWxsZXRzLnNsaWNlKGZlYXR1cmVkV2FsbGV0cyldLCBbd2FsbGV0cywgZmVhdHVyZWRXYWxsZXRzXSk7XG4gICAgY29uc3QgaGlkZU1vZGFsID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgICAgICBzZXRGYWRlSW4oZmFsc2UpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFZpc2libGUoZmFsc2UpLCAxNTApO1xuICAgIH0sIFtzZXRGYWRlSW4sIHNldFZpc2libGVdKTtcbiAgICBjb25zdCBoYW5kbGVDbG9zZSA9IHVzZUNhbGxiYWNrKChldmVudCkgPT4ge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBoaWRlTW9kYWwoKTtcbiAgICB9LCBbaGlkZU1vZGFsXSk7XG4gICAgY29uc3QgaGFuZGxlV2FsbGV0Q2xpY2sgPSB1c2VDYWxsYmFjaygoZXZlbnQsIHdhbGxldE5hbWUpID0+IHtcbiAgICAgICAgc2VsZWN0KHdhbGxldE5hbWUpO1xuICAgICAgICBoYW5kbGVDbG9zZShldmVudCk7XG4gICAgfSwgW3NlbGVjdCwgaGFuZGxlQ2xvc2VdKTtcbiAgICBjb25zdCBoYW5kbGVDb2xsYXBzZUNsaWNrID0gdXNlQ2FsbGJhY2soKCkgPT4gc2V0RXhwYW5kZWQoIWV4cGFuZGVkKSwgW3NldEV4cGFuZGVkLCBleHBhbmRlZF0pO1xuICAgIGNvbnN0IGhhbmRsZVRhYktleSA9IHVzZUNhbGxiYWNrKChldmVudCkgPT4ge1xuICAgICAgICBjb25zdCBub2RlID0gcmVmLmN1cnJlbnQ7XG4gICAgICAgIGlmICghbm9kZSlcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgLy8gaGVyZSB3ZSBxdWVyeSBhbGwgZm9jdXNhYmxlIGVsZW1lbnRzXG4gICAgICAgIGNvbnN0IGZvY3VzYWJsZUVsZW1lbnRzID0gbm9kZS5xdWVyeVNlbGVjdG9yQWxsKCdidXR0b24nKTtcbiAgICAgICAgY29uc3QgZmlyc3RFbGVtZW50ID0gZm9jdXNhYmxlRWxlbWVudHNbMF07XG4gICAgICAgIGNvbnN0IGxhc3RFbGVtZW50ID0gZm9jdXNhYmxlRWxlbWVudHNbZm9jdXNhYmxlRWxlbWVudHMubGVuZ3RoIC0gMV07XG4gICAgICAgIGlmIChldmVudC5zaGlmdEtleSkge1xuICAgICAgICAgICAgLy8gaWYgZ29pbmcgYmFja3dhcmQgYnkgcHJlc3NpbmcgdGFiIGFuZCBmaXJzdEVsZW1lbnQgaXMgYWN0aXZlLCBzaGlmdCBmb2N1cyB0byBsYXN0IGZvY3VzYWJsZSBlbGVtZW50XG4gICAgICAgICAgICBpZiAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA9PT0gZmlyc3RFbGVtZW50KSB7XG4gICAgICAgICAgICAgICAgbGFzdEVsZW1lbnQuZm9jdXMoKTtcbiAgICAgICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgLy8gaWYgZ29pbmcgZm9yd2FyZCBieSBwcmVzc2luZyB0YWIgYW5kIGxhc3RFbGVtZW50IGlzIGFjdGl2ZSwgc2hpZnQgZm9jdXMgdG8gZmlyc3QgZm9jdXNhYmxlIGVsZW1lbnRcbiAgICAgICAgICAgIGlmIChkb2N1bWVudC5hY3RpdmVFbGVtZW50ID09PSBsYXN0RWxlbWVudCkge1xuICAgICAgICAgICAgICAgIGZpcnN0RWxlbWVudC5mb2N1cygpO1xuICAgICAgICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbcmVmXSk7XG4gICAgdXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgaGFuZGxlS2V5RG93biA9IChldmVudCkgPT4ge1xuICAgICAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VzY2FwZScpIHtcbiAgICAgICAgICAgICAgICBoaWRlTW9kYWwoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGV2ZW50LmtleSA9PT0gJ1RhYicpIHtcbiAgICAgICAgICAgICAgICBoYW5kbGVUYWJLZXkoZXZlbnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICAvLyBHZXQgb3JpZ2luYWwgb3ZlcmZsb3dcbiAgICAgICAgY29uc3QgeyBvdmVyZmxvdyB9ID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZG9jdW1lbnQuYm9keSk7XG4gICAgICAgIC8vIEhhY2sgdG8gZW5hYmxlIGZhZGUgaW4gYW5pbWF0aW9uIGFmdGVyIG1vdW50XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0RmFkZUluKHRydWUpLCAwKTtcbiAgICAgICAgLy8gUHJldmVudCBzY3JvbGxpbmcgb24gbW91bnRcbiAgICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9ICdoaWRkZW4nO1xuICAgICAgICAvLyBMaXN0ZW4gZm9yIGtleWRvd24gZXZlbnRzXG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93biwgZmFsc2UpO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgLy8gUmUtZW5hYmxlIHNjcm9sbGluZyB3aGVuIGNvbXBvbmVudCB1bm1vdW50c1xuICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9IG92ZXJmbG93O1xuICAgICAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVLZXlEb3duLCBmYWxzZSk7XG4gICAgICAgIH07XG4gICAgfSwgW2hpZGVNb2RhbCwgaGFuZGxlVGFiS2V5XSk7XG4gICAgdXNlTGF5b3V0RWZmZWN0KCgpID0+IHNldFBvcnRhbChkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGNvbnRhaW5lcikpLCBbc2V0UG9ydGFsLCBjb250YWluZXJdKTtcbiAgICByZXR1cm4gKHBvcnRhbCAmJlxuICAgICAgICBjcmVhdGVQb3J0YWwoUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IFwiYXJpYS1sYWJlbGxlZGJ5XCI6IFwid2FsbGV0LWFkYXB0ZXItbW9kYWwtdGl0bGVcIiwgXCJhcmlhLW1vZGFsXCI6IFwidHJ1ZVwiLCBjbGFzc05hbWU6IGB3YWxsZXQtYWRhcHRlci1tb2RhbCAke2ZhZGVJbiAmJiAnd2FsbGV0LWFkYXB0ZXItbW9kYWwtZmFkZS1pbid9ICR7Y2xhc3NOYW1lfWAsIHJlZjogcmVmLCByb2xlOiBcImRpYWxvZ1wiIH0sXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLW1vZGFsLWNvbnRhaW5lclwiIH0sXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogYHdhbGxldC1hZGFwdGVyLW1vZGFsLXdyYXBwZXIgJHshbG9nbyAmJiAnd2FsbGV0LWFkYXB0ZXItbW9kYWwtd3JhcHBlci1uby1sb2dvJ31gIH0sXG4gICAgICAgICAgICAgICAgICAgIGxvZ28gJiYgKFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItbW9kYWwtbG9nby13cmFwcGVyXCIgfSwgdHlwZW9mIGxvZ28gPT09ICdzdHJpbmcnID8gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJpbWdcIiwgeyBhbHQ6IFwibG9nb1wiLCBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItbW9kYWwtbG9nb1wiLCBzcmM6IGxvZ28gfSkpIDogKGxvZ28pKSksXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJoMVwiLCB7IGNsYXNzTmFtZTogXCJ3YWxsZXQtYWRhcHRlci1tb2RhbC10aXRsZVwiLCBpZDogXCJ3YWxsZXQtYWRhcHRlci1tb2RhbC10aXRsZVwiIH0sIFwiQ29ubmVjdCBXYWxsZXRcIiksXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIiwgeyBvbkNsaWNrOiBoYW5kbGVDbG9zZSwgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLW1vZGFsLWJ1dHRvbi1jbG9zZVwiIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwic3ZnXCIsIHsgd2lkdGg6IFwiMTRcIiwgaGVpZ2h0OiBcIjE0XCIgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwicGF0aFwiLCB7IGQ6IFwiTTE0IDEyLjQ2MSA4LjMgNi43NzJsNS4yMzQtNS4yMzNMMTIuMDA2IDAgNi43NzIgNS4yMzQgMS41NCAwIDAgMS41MzlsNS4yMzQgNS4yMzNMMCAxMi4wMDZsMS41MzkgMS41MjhMNi43NzIgOC4zbDUuNjkgNS43TDE0IDEyLjQ2MXpcIiB9KSkpLFxuICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwidWxcIiwgeyBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItbW9kYWwtbGlzdFwiIH0sIGZlYXR1cmVkLm1hcCgod2FsbGV0KSA9PiAoUmVhY3QuY3JlYXRlRWxlbWVudChXYWxsZXRMaXN0SXRlbSwgeyBrZXk6IHdhbGxldC5uYW1lLCBoYW5kbGVDbGljazogKGV2ZW50KSA9PiBoYW5kbGVXYWxsZXRDbGljayhldmVudCwgd2FsbGV0Lm5hbWUpLCB3YWxsZXQ6IHdhbGxldCB9KSkpKSxcbiAgICAgICAgICAgICAgICAgICAgbW9yZS5sZW5ndGggPyAoUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwgbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29sbGFwc2UsIHsgZXhwYW5kZWQ6IGV4cGFuZGVkLCBpZDogXCJ3YWxsZXQtYWRhcHRlci1tb2RhbC1jb2xsYXBzZVwiIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcInVsXCIsIHsgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLW1vZGFsLWxpc3RcIiB9LCBtb3JlLm1hcCgod2FsbGV0KSA9PiAoUmVhY3QuY3JlYXRlRWxlbWVudChXYWxsZXRMaXN0SXRlbSwgeyBrZXk6IHdhbGxldC5uYW1lLCBoYW5kbGVDbGljazogKGV2ZW50KSA9PiBoYW5kbGVXYWxsZXRDbGljayhldmVudCwgd2FsbGV0Lm5hbWUpLCB0YWJJbmRleDogZXhwYW5kZWQgPyAwIDogLTEsIHdhbGxldDogd2FsbGV0IH0pKSkpKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnV0dG9uLCB7IFwiYXJpYS1jb250cm9sc1wiOiBcIndhbGxldC1hZGFwdGVyLW1vZGFsLWNvbGxhcHNlXCIsIFwiYXJpYS1leHBhbmRlZFwiOiBleHBhbmRlZCwgY2xhc3NOYW1lOiBgd2FsbGV0LWFkYXB0ZXItbW9kYWwtY29sbGFwc2UtYnV0dG9uICR7ZXhwYW5kZWQgJiYgJ3dhbGxldC1hZGFwdGVyLW1vZGFsLWNvbGxhcHNlLWJ1dHRvbi1hY3RpdmUnfWAsIGVuZEljb246IFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgeyB3aWR0aDogXCIxMVwiLCBoZWlnaHQ6IFwiNlwiLCB4bWxuczogXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJwYXRoXCIsIHsgZDogXCJtNS45MzggNS43MyA0LjI4LTQuMTI2YS45MTUuOTE1IDAgMCAwIDAtMS4zMjIgMSAxIDAgMCAwLTEuMzcxIDBMNS4yNTMgMy43MzYgMS42NTkuMjcyYTEgMSAwIDAgMC0xLjM3MSAwQS45My45MyAwIDAgMCAwIC45MzJjMCAuMjQ2LjEuNDguMjg4LjY2Mmw0LjI4IDQuMTI1YS45OS45OSAwIDAgMCAxLjM3LjAxelwiIH0pKSwgb25DbGljazogaGFuZGxlQ29sbGFwc2VDbGljayB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGFuZGVkID8gJ0xlc3MnIDogJ01vcmUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiIG9wdGlvbnNcIikpKSA6IG51bGwpKSxcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItbW9kYWwtb3ZlcmxheVwiLCBvbk1vdXNlRG93bjogaGFuZGxlQ2xvc2UgfSkpLCBwb3J0YWwpKTtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1XYWxsZXRNb2RhbC5qcy5tYXAiLCJ2YXIgX19yZXN0ID0gKHRoaXMgJiYgdGhpcy5fX3Jlc3QpIHx8IGZ1bmN0aW9uIChzLCBlKSB7XG4gICAgdmFyIHQgPSB7fTtcbiAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkgJiYgZS5pbmRleE9mKHApIDwgMClcbiAgICAgICAgdFtwXSA9IHNbcF07XG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxuICAgICAgICBmb3IgKHZhciBpID0gMCwgcCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMocyk7IGkgPCBwLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoZS5pbmRleE9mKHBbaV0pIDwgMCAmJiBPYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwocywgcFtpXSkpXG4gICAgICAgICAgICAgICAgdFtwW2ldXSA9IHNbcFtpXV07XG4gICAgICAgIH1cbiAgICByZXR1cm4gdDtcbn07XG5pbXBvcnQgUmVhY3QsIHsgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuL0J1dHRvbic7XG5pbXBvcnQgeyB1c2VXYWxsZXRNb2RhbCB9IGZyb20gJy4vdXNlV2FsbGV0TW9kYWwnO1xuZXhwb3J0IGNvbnN0IFdhbGxldE1vZGFsQnV0dG9uID0gKF9hKSA9PiB7XG4gICAgdmFyIHsgY2hpbGRyZW4gPSAnU2VsZWN0IFdhbGxldCcsIG9uQ2xpY2sgfSA9IF9hLCBwcm9wcyA9IF9fcmVzdChfYSwgW1wiY2hpbGRyZW5cIiwgXCJvbkNsaWNrXCJdKTtcbiAgICBjb25zdCB7IHZpc2libGUsIHNldFZpc2libGUgfSA9IHVzZVdhbGxldE1vZGFsKCk7XG4gICAgY29uc3QgaGFuZGxlQ2xpY2sgPSB1c2VDYWxsYmFjaygoZXZlbnQpID0+IHtcbiAgICAgICAgaWYgKG9uQ2xpY2spXG4gICAgICAgICAgICBvbkNsaWNrKGV2ZW50KTtcbiAgICAgICAgaWYgKCFldmVudC5kZWZhdWx0UHJldmVudGVkKVxuICAgICAgICAgICAgc2V0VmlzaWJsZSghdmlzaWJsZSk7XG4gICAgfSwgW29uQ2xpY2ssIHNldFZpc2libGUsIHZpc2libGVdKTtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnV0dG9uLCBPYmplY3QuYXNzaWduKHsgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLWJ1dHRvbi10cmlnZ2VyXCIsIG9uQ2xpY2s6IGhhbmRsZUNsaWNrIH0sIHByb3BzKSwgY2hpbGRyZW4pKTtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1XYWxsZXRNb2RhbEJ1dHRvbi5qcy5tYXAiLCJ2YXIgX19yZXN0ID0gKHRoaXMgJiYgdGhpcy5fX3Jlc3QpIHx8IGZ1bmN0aW9uIChzLCBlKSB7XG4gICAgdmFyIHQgPSB7fTtcbiAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkgJiYgZS5pbmRleE9mKHApIDwgMClcbiAgICAgICAgdFtwXSA9IHNbcF07XG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxuICAgICAgICBmb3IgKHZhciBpID0gMCwgcCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMocyk7IGkgPCBwLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoZS5pbmRleE9mKHBbaV0pIDwgMCAmJiBPYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwocywgcFtpXSkpXG4gICAgICAgICAgICAgICAgdFtwW2ldXSA9IHNbcFtpXV07XG4gICAgICAgIH1cbiAgICByZXR1cm4gdDtcbn07XG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBXYWxsZXRNb2RhbENvbnRleHQgfSBmcm9tICcuL3VzZVdhbGxldE1vZGFsJztcbmltcG9ydCB7IFdhbGxldE1vZGFsIH0gZnJvbSAnLi9XYWxsZXRNb2RhbCc7XG5leHBvcnQgY29uc3QgV2FsbGV0TW9kYWxQcm92aWRlciA9IChfYSkgPT4ge1xuICAgIHZhciB7IGNoaWxkcmVuIH0gPSBfYSwgcHJvcHMgPSBfX3Jlc3QoX2EsIFtcImNoaWxkcmVuXCJdKTtcbiAgICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KFdhbGxldE1vZGFsQ29udGV4dC5Qcm92aWRlciwgeyB2YWx1ZToge1xuICAgICAgICAgICAgdmlzaWJsZSxcbiAgICAgICAgICAgIHNldFZpc2libGUsXG4gICAgICAgIH0gfSxcbiAgICAgICAgY2hpbGRyZW4sXG4gICAgICAgIHZpc2libGUgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChXYWxsZXRNb2RhbCwgT2JqZWN0LmFzc2lnbih7fSwgcHJvcHMpKSkpO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVdhbGxldE1vZGFsUHJvdmlkZXIuanMubWFwIiwidmFyIF9fYXdhaXRlciA9ICh0aGlzICYmIHRoaXMuX19hd2FpdGVyKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvci5uZXh0KHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogYWRvcHQocmVzdWx0LnZhbHVlKS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XG4gICAgICAgIHN0ZXAoKGdlbmVyYXRvciA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSkubmV4dCgpKTtcbiAgICB9KTtcbn07XG52YXIgX19yZXN0ID0gKHRoaXMgJiYgdGhpcy5fX3Jlc3QpIHx8IGZ1bmN0aW9uIChzLCBlKSB7XG4gICAgdmFyIHQgPSB7fTtcbiAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkgJiYgZS5pbmRleE9mKHApIDwgMClcbiAgICAgICAgdFtwXSA9IHNbcF07XG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxuICAgICAgICBmb3IgKHZhciBpID0gMCwgcCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMocyk7IGkgPCBwLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoZS5pbmRleE9mKHBbaV0pIDwgMCAmJiBPYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwocywgcFtpXSkpXG4gICAgICAgICAgICAgICAgdFtwW2ldXSA9IHNbcFtpXV07XG4gICAgICAgIH1cbiAgICByZXR1cm4gdDtcbn07XG5pbXBvcnQgeyB1c2VXYWxsZXQgfSBmcm9tICdAc29sYW5hL3dhbGxldC1hZGFwdGVyLXJlYWN0JztcbmltcG9ydCBSZWFjdCwgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi9CdXR0b24nO1xuaW1wb3J0IHsgdXNlV2FsbGV0TW9kYWwgfSBmcm9tICcuL3VzZVdhbGxldE1vZGFsJztcbmltcG9ydCB7IFdhbGxldENvbm5lY3RCdXR0b24gfSBmcm9tICcuL1dhbGxldENvbm5lY3RCdXR0b24nO1xuaW1wb3J0IHsgV2FsbGV0SWNvbiB9IGZyb20gJy4vV2FsbGV0SWNvbic7XG5pbXBvcnQgeyBXYWxsZXRNb2RhbEJ1dHRvbiB9IGZyb20gJy4vV2FsbGV0TW9kYWxCdXR0b24nO1xuZXhwb3J0IGNvbnN0IFdhbGxldE11bHRpQnV0dG9uID0gKF9hKSA9PiB7XG4gICAgdmFyIHsgY2hpbGRyZW4gfSA9IF9hLCBwcm9wcyA9IF9fcmVzdChfYSwgW1wiY2hpbGRyZW5cIl0pO1xuICAgIGNvbnN0IHsgcHVibGljS2V5LCB3YWxsZXQsIGRpc2Nvbm5lY3QgfSA9IHVzZVdhbGxldCgpO1xuICAgIGNvbnN0IHsgc2V0VmlzaWJsZSB9ID0gdXNlV2FsbGV0TW9kYWwoKTtcbiAgICBjb25zdCBbY29waWVkLCBzZXRDb3BpZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFthY3RpdmUsIHNldEFjdGl2ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgcmVmID0gdXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IGJhc2U1OCA9IHVzZU1lbW8oKCkgPT4gcHVibGljS2V5ID09PSBudWxsIHx8IHB1YmxpY0tleSA9PT0gdm9pZCAwID8gdm9pZCAwIDogcHVibGljS2V5LnRvQmFzZTU4KCksIFtwdWJsaWNLZXldKTtcbiAgICBjb25zdCBjb250ZW50ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGlmIChjaGlsZHJlbilcbiAgICAgICAgICAgIHJldHVybiBjaGlsZHJlbjtcbiAgICAgICAgaWYgKCF3YWxsZXQgfHwgIWJhc2U1OClcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICByZXR1cm4gYmFzZTU4LnNsaWNlKDAsIDQpICsgJy4uJyArIGJhc2U1OC5zbGljZSgtNCk7XG4gICAgfSwgW2NoaWxkcmVuLCB3YWxsZXQsIGJhc2U1OF0pO1xuICAgIGNvbnN0IGNvcHlBZGRyZXNzID0gdXNlQ2FsbGJhY2soKCkgPT4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgIGlmIChiYXNlNTgpIHtcbiAgICAgICAgICAgIHlpZWxkIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KGJhc2U1OCk7XG4gICAgICAgICAgICBzZXRDb3BpZWQodHJ1ZSk7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldENvcGllZChmYWxzZSksIDQwMCk7XG4gICAgICAgIH1cbiAgICB9KSwgW2Jhc2U1OF0pO1xuICAgIGNvbnN0IG9wZW5Ecm9wZG93biA9IHVzZUNhbGxiYWNrKCgpID0+IHNldEFjdGl2ZSh0cnVlKSwgW3NldEFjdGl2ZV0pO1xuICAgIGNvbnN0IGNsb3NlRHJvcGRvd24gPSB1c2VDYWxsYmFjaygoKSA9PiBzZXRBY3RpdmUoZmFsc2UpLCBbc2V0QWN0aXZlXSk7XG4gICAgY29uc3Qgb3Blbk1vZGFsID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgICAgICBzZXRWaXNpYmxlKHRydWUpO1xuICAgICAgICBjbG9zZURyb3Bkb3duKCk7XG4gICAgfSwgW3NldFZpc2libGUsIGNsb3NlRHJvcGRvd25dKTtcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBsaXN0ZW5lciA9IChldmVudCkgPT4ge1xuICAgICAgICAgICAgY29uc3Qgbm9kZSA9IHJlZi5jdXJyZW50O1xuICAgICAgICAgICAgLy8gRG8gbm90aGluZyBpZiBjbGlja2luZyBkcm9wZG93biBvciBpdHMgZGVzY2VuZGFudHNcbiAgICAgICAgICAgIGlmICghbm9kZSB8fCBub2RlLmNvbnRhaW5zKGV2ZW50LnRhcmdldCkpXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgY2xvc2VEcm9wZG93bigpO1xuICAgICAgICB9O1xuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBsaXN0ZW5lcik7XG4gICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3RvdWNoc3RhcnQnLCBsaXN0ZW5lcik7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBsaXN0ZW5lcik7XG4gICAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCd0b3VjaHN0YXJ0JywgbGlzdGVuZXIpO1xuICAgICAgICB9O1xuICAgIH0sIFtyZWYsIGNsb3NlRHJvcGRvd25dKTtcbiAgICBpZiAoIXdhbGxldClcbiAgICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoV2FsbGV0TW9kYWxCdXR0b24sIE9iamVjdC5hc3NpZ24oe30sIHByb3BzKSwgY2hpbGRyZW4pO1xuICAgIGlmICghYmFzZTU4KVxuICAgICAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChXYWxsZXRDb25uZWN0QnV0dG9uLCBPYmplY3QuYXNzaWduKHt9LCBwcm9wcyksIGNoaWxkcmVuKTtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItZHJvcGRvd25cIiB9LFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbiwgT2JqZWN0LmFzc2lnbih7IFwiYXJpYS1leHBhbmRlZFwiOiBhY3RpdmUsIGNsYXNzTmFtZTogXCJ3YWxsZXQtYWRhcHRlci1idXR0b24tdHJpZ2dlclwiLCBzdHlsZTogT2JqZWN0LmFzc2lnbih7IHBvaW50ZXJFdmVudHM6IGFjdGl2ZSA/ICdub25lJyA6ICdhdXRvJyB9LCBwcm9wcy5zdHlsZSksIG9uQ2xpY2s6IG9wZW5Ecm9wZG93biwgc3RhcnRJY29uOiBSZWFjdC5jcmVhdGVFbGVtZW50KFdhbGxldEljb24sIHsgd2FsbGV0OiB3YWxsZXQgfSkgfSwgcHJvcHMpLCBjb250ZW50KSxcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcInVsXCIsIHsgXCJhcmlhLWxhYmVsXCI6IFwiZHJvcGRvd24tbGlzdFwiLCBjbGFzc05hbWU6IGB3YWxsZXQtYWRhcHRlci1kcm9wZG93bi1saXN0ICR7YWN0aXZlICYmICd3YWxsZXQtYWRhcHRlci1kcm9wZG93bi1saXN0LWFjdGl2ZSd9YCwgcmVmOiByZWYsIHJvbGU6IFwibWVudVwiIH0sXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwibGlcIiwgeyBvbkNsaWNrOiBjb3B5QWRkcmVzcywgY2xhc3NOYW1lOiBcIndhbGxldC1hZGFwdGVyLWRyb3Bkb3duLWxpc3QtaXRlbVwiLCByb2xlOiBcIm1lbnVpdGVtXCIgfSwgY29waWVkID8gJ0NvcGllZCcgOiAnQ29weSBhZGRyZXNzJyksXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwibGlcIiwgeyBvbkNsaWNrOiBvcGVuTW9kYWwsIGNsYXNzTmFtZTogXCJ3YWxsZXQtYWRhcHRlci1kcm9wZG93bi1saXN0LWl0ZW1cIiwgcm9sZTogXCJtZW51aXRlbVwiIH0sIFwiQ29ubmVjdCBhIGRpZmZlcmVudCB3YWxsZXRcIiksXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwibGlcIiwgeyBvbkNsaWNrOiBkaXNjb25uZWN0LCBjbGFzc05hbWU6IFwid2FsbGV0LWFkYXB0ZXItZHJvcGRvd24tbGlzdC1pdGVtXCIsIHJvbGU6IFwibWVudWl0ZW1cIiB9LCBcIkRpc2Nvbm5lY3RcIikpKSk7XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9V2FsbGV0TXVsdGlCdXR0b24uanMubWFwIiwiZXhwb3J0ICogZnJvbSAnLi91c2VXYWxsZXRNb2RhbCc7XG5leHBvcnQgKiBmcm9tICcuL1dhbGxldENvbm5lY3RCdXR0b24nO1xuZXhwb3J0ICogZnJvbSAnLi9XYWxsZXRNb2RhbCc7XG5leHBvcnQgKiBmcm9tICcuL1dhbGxldE1vZGFsQnV0dG9uJztcbmV4cG9ydCAqIGZyb20gJy4vV2FsbGV0TW9kYWxQcm92aWRlcic7XG5leHBvcnQgKiBmcm9tICcuL1dhbGxldERpc2Nvbm5lY3RCdXR0b24nO1xuZXhwb3J0ICogZnJvbSAnLi9XYWxsZXRJY29uJztcbmV4cG9ydCAqIGZyb20gJy4vV2FsbGV0TXVsdGlCdXR0b24nO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCB9IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBXYWxsZXRNb2RhbENvbnRleHQgPSBjcmVhdGVDb250ZXh0KHt9KTtcbmV4cG9ydCBmdW5jdGlvbiB1c2VXYWxsZXRNb2RhbCgpIHtcbiAgICByZXR1cm4gdXNlQ29udGV4dChXYWxsZXRNb2RhbENvbnRleHQpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlV2FsbGV0TW9kYWwuanMubWFwIiwiaW1wb3J0IHsgQ29ubmVjdGlvbiB9IGZyb20gJ0Bzb2xhbmEvd2ViMy5qcyc7XG5pbXBvcnQgUmVhY3QsIHsgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IENvbm5lY3Rpb25Db250ZXh0IH0gZnJvbSAnLi91c2VDb25uZWN0aW9uJztcbmV4cG9ydCBjb25zdCBDb25uZWN0aW9uUHJvdmlkZXIgPSAoeyBjaGlsZHJlbiwgZW5kcG9pbnQsIGNvbmZpZyA9IHsgY29tbWl0bWVudDogJ2NvbmZpcm1lZCcgfSwgfSkgPT4ge1xuICAgIGNvbnN0IGNvbm5lY3Rpb24gPSB1c2VNZW1vKCgpID0+IG5ldyBDb25uZWN0aW9uKGVuZHBvaW50LCBjb25maWcpLCBbZW5kcG9pbnQsIGNvbmZpZ10pO1xuICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KENvbm5lY3Rpb25Db250ZXh0LlByb3ZpZGVyLCB7IHZhbHVlOiB7IGNvbm5lY3Rpb24gfSB9LCBjaGlsZHJlbik7XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Q29ubmVjdGlvblByb3ZpZGVyLmpzLm1hcCIsInZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XG4gICAgfSk7XG59O1xuaW1wb3J0IHsgV2FsbGV0Tm90Q29ubmVjdGVkRXJyb3IsIFdhbGxldE5vdFJlYWR5RXJyb3IsIH0gZnJvbSAnQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlJztcbmltcG9ydCBSZWFjdCwgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgV2FsbGV0Tm90U2VsZWN0ZWRFcnJvciB9IGZyb20gJy4vZXJyb3JzJztcbmltcG9ydCB7IHVzZUxvY2FsU3RvcmFnZSB9IGZyb20gJy4vdXNlTG9jYWxTdG9yYWdlJztcbmltcG9ydCB7IFdhbGxldENvbnRleHQgfSBmcm9tICcuL3VzZVdhbGxldCc7XG5jb25zdCBpbml0aWFsU3RhdGUgPSB7XG4gICAgd2FsbGV0OiBudWxsLFxuICAgIGFkYXB0ZXI6IG51bGwsXG4gICAgcmVhZHk6IGZhbHNlLFxuICAgIHB1YmxpY0tleTogbnVsbCxcbiAgICBjb25uZWN0ZWQ6IGZhbHNlLFxufTtcbmV4cG9ydCBjb25zdCBXYWxsZXRQcm92aWRlciA9ICh7IGNoaWxkcmVuLCB3YWxsZXRzLCBhdXRvQ29ubmVjdCA9IGZhbHNlLCBvbkVycm9yOiBfb25FcnJvciA9IChlcnJvcikgPT4gY29uc29sZS5lcnJvcihlcnJvciksIGxvY2FsU3RvcmFnZUtleSA9ICd3YWxsZXROYW1lJywgfSkgPT4ge1xuICAgIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZUxvY2FsU3RvcmFnZShsb2NhbFN0b3JhZ2VLZXksIG51bGwpO1xuICAgIGNvbnN0IFt7IHdhbGxldCwgYWRhcHRlciwgcmVhZHksIHB1YmxpY0tleSwgY29ubmVjdGVkIH0sIHNldFN0YXRlXSA9IHVzZVN0YXRlKGluaXRpYWxTdGF0ZSk7XG4gICAgY29uc3QgW2Nvbm5lY3RpbmcsIHNldENvbm5lY3RpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtkaXNjb25uZWN0aW5nLCBzZXREaXNjb25uZWN0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBpc0Nvbm5lY3RpbmcgPSB1c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IGlzRGlzY29ubmVjdGluZyA9IHVzZVJlZihmYWxzZSk7XG4gICAgY29uc3QgaXNVbmxvYWRpbmcgPSB1c2VSZWYoZmFsc2UpO1xuICAgIC8vIE1hcCBvZiB3YWxsZXQgbmFtZXMgdG8gd2FsbGV0c1xuICAgIGNvbnN0IHdhbGxldHNCeU5hbWUgPSB1c2VNZW1vKCgpID0+IHdhbGxldHMucmVkdWNlKCh3YWxsZXRzQnlOYW1lLCB3YWxsZXQpID0+IHtcbiAgICAgICAgd2FsbGV0c0J5TmFtZVt3YWxsZXQubmFtZV0gPSB3YWxsZXQ7XG4gICAgICAgIHJldHVybiB3YWxsZXRzQnlOYW1lO1xuICAgIH0sIHt9KSwgW3dhbGxldHNdKTtcbiAgICAvLyBXaGVuIHRoZSBzZWxlY3RlZCB3YWxsZXQgY2hhbmdlcywgaW5pdGlhbGl6ZSB0aGUgc3RhdGVcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCB3YWxsZXQgPSAobmFtZSAmJiB3YWxsZXRzQnlOYW1lW25hbWVdKSB8fCBudWxsO1xuICAgICAgICBjb25zdCBhZGFwdGVyID0gd2FsbGV0ICYmIHdhbGxldC5hZGFwdGVyKCk7XG4gICAgICAgIGlmIChhZGFwdGVyKSB7XG4gICAgICAgICAgICBjb25zdCB7IHJlYWR5LCBwdWJsaWNLZXksIGNvbm5lY3RlZCB9ID0gYWRhcHRlcjtcbiAgICAgICAgICAgIHNldFN0YXRlKHsgd2FsbGV0LCBhZGFwdGVyLCBjb25uZWN0ZWQsIHB1YmxpY0tleSwgcmVhZHkgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBzZXRTdGF0ZShpbml0aWFsU3RhdGUpO1xuICAgICAgICB9XG4gICAgfSwgW25hbWUsIHdhbGxldHNCeU5hbWUsIHNldFN0YXRlXSk7XG4gICAgLy8gSWYgYXV0b0Nvbm5lY3QgaXMgZW5hYmxlZCwgdHJ5IHRvIGNvbm5lY3Qgd2hlbiB0aGUgYWRhcHRlciBjaGFuZ2VzIGFuZCBpcyByZWFkeVxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChpc0Nvbm5lY3RpbmcuY3VycmVudCB8fCBjb25uZWN0aW5nIHx8IGNvbm5lY3RlZCB8fCAhYXV0b0Nvbm5lY3QgfHwgIWFkYXB0ZXIgfHwgIXJlYWR5KVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgICAgICAgICBpc0Nvbm5lY3RpbmcuY3VycmVudCA9IHRydWU7XG4gICAgICAgICAgICAgICAgc2V0Q29ubmVjdGluZyh0cnVlKTtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICB5aWVsZCBhZGFwdGVyLmNvbm5lY3QoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIENsZWFyIHRoZSBzZWxlY3RlZCB3YWxsZXRcbiAgICAgICAgICAgICAgICAgICAgc2V0TmFtZShudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gRG9uJ3QgdGhyb3cgZXJyb3IsIGJ1dCBvbkVycm9yIHdpbGwgc3RpbGwgYmUgY2FsbGVkXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgICAgICAgICBzZXRDb25uZWN0aW5nKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgaXNDb25uZWN0aW5nLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSkoKTtcbiAgICB9LCBbaXNDb25uZWN0aW5nLCBjb25uZWN0aW5nLCBjb25uZWN0ZWQsIGF1dG9Db25uZWN0LCBhZGFwdGVyLCByZWFkeSwgc2V0Q29ubmVjdGluZywgc2V0TmFtZV0pO1xuICAgIC8vIElmIHRoZSB3aW5kb3cgaXMgY2xvc2luZyBvciByZWxvYWRpbmcsIGlnbm9yZSBkaXNjb25uZWN0IGFuZCBlcnJvciBldmVudHMgZnJvbSB0aGUgYWRhcHRlclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGZ1bmN0aW9uIGxpc3RlbmVyKCkge1xuICAgICAgICAgICAgaXNVbmxvYWRpbmcuY3VycmVudCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2JlZm9yZXVubG9hZCcsIGxpc3RlbmVyKTtcbiAgICAgICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdiZWZvcmV1bmxvYWQnLCBsaXN0ZW5lcik7XG4gICAgfSwgW2lzVW5sb2FkaW5nXSk7XG4gICAgLy8gU2VsZWN0IGEgd2FsbGV0IGJ5IG5hbWVcbiAgICBjb25zdCBzZWxlY3QgPSB1c2VDYWxsYmFjaygobmV3TmFtZSkgPT4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgIGlmIChuYW1lID09PSBuZXdOYW1lKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBpZiAoYWRhcHRlcilcbiAgICAgICAgICAgIHlpZWxkIGFkYXB0ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICBzZXROYW1lKG5ld05hbWUpO1xuICAgIH0pLCBbbmFtZSwgYWRhcHRlciwgc2V0TmFtZV0pO1xuICAgIC8vIEhhbmRsZSB0aGUgYWRhcHRlcidzIHJlYWR5IGV2ZW50XG4gICAgY29uc3Qgb25SZWFkeSA9IHVzZUNhbGxiYWNrKCgpID0+IHNldFN0YXRlKChzdGF0ZSkgPT4gKE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgc3RhdGUpLCB7IHJlYWR5OiB0cnVlIH0pKSksIFtzZXRTdGF0ZV0pO1xuICAgIC8vIEhhbmRsZSB0aGUgYWRhcHRlcidzIGNvbm5lY3QgZXZlbnRcbiAgICBjb25zdCBvbkNvbm5lY3QgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICAgIGlmICghYWRhcHRlcilcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgY29uc3QgeyBjb25uZWN0ZWQsIHB1YmxpY0tleSwgcmVhZHkgfSA9IGFkYXB0ZXI7XG4gICAgICAgIHNldFN0YXRlKChzdGF0ZSkgPT4gKE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgc3RhdGUpLCB7IGNvbm5lY3RlZCxcbiAgICAgICAgICAgIHB1YmxpY0tleSxcbiAgICAgICAgICAgIHJlYWR5IH0pKSk7XG4gICAgfSwgW2FkYXB0ZXIsIHNldFN0YXRlXSk7XG4gICAgLy8gSGFuZGxlIHRoZSBhZGFwdGVyJ3MgZGlzY29ubmVjdCBldmVudFxuICAgIGNvbnN0IG9uRGlzY29ubmVjdCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICAgICAgLy8gQ2xlYXIgdGhlIHNlbGVjdGVkIHdhbGxldCB1bmxlc3MgdGhlIHdpbmRvdyBpcyB1bmxvYWRpbmdcbiAgICAgICAgaWYgKCFpc1VubG9hZGluZy5jdXJyZW50KVxuICAgICAgICAgICAgc2V0TmFtZShudWxsKTtcbiAgICB9LCBbaXNVbmxvYWRpbmcsIHNldE5hbWVdKTtcbiAgICAvLyBIYW5kbGUgdGhlIGFkYXB0ZXIncyBlcnJvciBldmVudCwgYW5kIGxvY2FsIGVycm9yc1xuICAgIGNvbnN0IG9uRXJyb3IgPSB1c2VDYWxsYmFjaygoZXJyb3IpID0+IHtcbiAgICAgICAgLy8gQ2FsbCB0aGUgcHJvdmlkZWQgZXJyb3IgaGFuZGxlciB1bmxlc3MgdGhlIHdpbmRvdyBpcyB1bmxvYWRpbmdcbiAgICAgICAgaWYgKCFpc1VubG9hZGluZy5jdXJyZW50KVxuICAgICAgICAgICAgX29uRXJyb3IoZXJyb3IpO1xuICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgfSwgW2lzVW5sb2FkaW5nLCBfb25FcnJvcl0pO1xuICAgIC8vIENvbm5lY3QgdGhlIGFkYXB0ZXIgdG8gdGhlIHdhbGxldFxuICAgIGNvbnN0IGNvbm5lY3QgPSB1c2VDYWxsYmFjaygoKSA9PiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgaWYgKGlzQ29ubmVjdGluZy5jdXJyZW50IHx8IGNvbm5lY3RpbmcgfHwgZGlzY29ubmVjdGluZyB8fCBjb25uZWN0ZWQpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIGlmICghd2FsbGV0IHx8ICFhZGFwdGVyKVxuICAgICAgICAgICAgdGhyb3cgb25FcnJvcihuZXcgV2FsbGV0Tm90U2VsZWN0ZWRFcnJvcigpKTtcbiAgICAgICAgaWYgKCFyZWFkeSkge1xuICAgICAgICAgICAgLy8gQ2xlYXIgdGhlIHNlbGVjdGVkIHdhbGxldFxuICAgICAgICAgICAgc2V0TmFtZShudWxsKTtcbiAgICAgICAgICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIHdpbmRvdy5vcGVuKHdhbGxldC51cmwsICdfYmxhbmsnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IG9uRXJyb3IobmV3IFdhbGxldE5vdFJlYWR5RXJyb3IoKSk7XG4gICAgICAgIH1cbiAgICAgICAgaXNDb25uZWN0aW5nLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICBzZXRDb25uZWN0aW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgeWllbGQgYWRhcHRlci5jb25uZWN0KCk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAvLyBDbGVhciB0aGUgc2VsZWN0ZWQgd2FsbGV0XG4gICAgICAgICAgICBzZXROYW1lKG51bGwpO1xuICAgICAgICAgICAgLy8gUmV0aHJvdyB0aGUgZXJyb3IsIGFuZCBvbkVycm9yIHdpbGwgYWxzbyBiZSBjYWxsZWRcbiAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0Q29ubmVjdGluZyhmYWxzZSk7XG4gICAgICAgICAgICBpc0Nvbm5lY3RpbmcuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgfSksIFtpc0Nvbm5lY3RpbmcsIGNvbm5lY3RpbmcsIGRpc2Nvbm5lY3RpbmcsIGNvbm5lY3RlZCwgd2FsbGV0LCBhZGFwdGVyLCBvbkVycm9yLCByZWFkeSwgc2V0Q29ubmVjdGluZywgc2V0TmFtZV0pO1xuICAgIC8vIERpc2Nvbm5lY3QgdGhlIGFkYXB0ZXIgZnJvbSB0aGUgd2FsbGV0XG4gICAgY29uc3QgZGlzY29ubmVjdCA9IHVzZUNhbGxiYWNrKCgpID0+IF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICBpZiAoaXNEaXNjb25uZWN0aW5nLmN1cnJlbnQgfHwgZGlzY29ubmVjdGluZylcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgaWYgKCFhZGFwdGVyKVxuICAgICAgICAgICAgcmV0dXJuIHNldE5hbWUobnVsbCk7XG4gICAgICAgIGlzRGlzY29ubmVjdGluZy5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgc2V0RGlzY29ubmVjdGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHlpZWxkIGFkYXB0ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgLy8gQ2xlYXIgdGhlIHNlbGVjdGVkIHdhbGxldFxuICAgICAgICAgICAgc2V0TmFtZShudWxsKTtcbiAgICAgICAgICAgIC8vIFJldGhyb3cgdGhlIGVycm9yLCBhbmQgb25FcnJvciB3aWxsIGFsc28gYmUgY2FsbGVkXG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldERpc2Nvbm5lY3RpbmcoZmFsc2UpO1xuICAgICAgICAgICAgaXNEaXNjb25uZWN0aW5nLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0pLCBbaXNEaXNjb25uZWN0aW5nLCBkaXNjb25uZWN0aW5nLCBhZGFwdGVyLCBzZXREaXNjb25uZWN0aW5nLCBzZXROYW1lXSk7XG4gICAgLy8gU2VuZCBhIHRyYW5zYWN0aW9uIHVzaW5nIHRoZSBwcm92aWRlZCBjb25uZWN0aW9uXG4gICAgY29uc3Qgc2VuZFRyYW5zYWN0aW9uID0gdXNlQ2FsbGJhY2soKHRyYW5zYWN0aW9uLCBjb25uZWN0aW9uLCBvcHRpb25zKSA9PiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgaWYgKCFhZGFwdGVyKVxuICAgICAgICAgICAgdGhyb3cgb25FcnJvcihuZXcgV2FsbGV0Tm90U2VsZWN0ZWRFcnJvcigpKTtcbiAgICAgICAgaWYgKCFjb25uZWN0ZWQpXG4gICAgICAgICAgICB0aHJvdyBvbkVycm9yKG5ldyBXYWxsZXROb3RDb25uZWN0ZWRFcnJvcigpKTtcbiAgICAgICAgcmV0dXJuIHlpZWxkIGFkYXB0ZXIuc2VuZFRyYW5zYWN0aW9uKHRyYW5zYWN0aW9uLCBjb25uZWN0aW9uLCBvcHRpb25zKTtcbiAgICB9KSwgW2FkYXB0ZXIsIG9uRXJyb3IsIGNvbm5lY3RlZF0pO1xuICAgIC8vIFNpZ24gYSB0cmFuc2FjdGlvbiBpZiB0aGUgd2FsbGV0IHN1cHBvcnRzIGl0XG4gICAgY29uc3Qgc2lnblRyYW5zYWN0aW9uID0gdXNlTWVtbygoKSA9PiBhZGFwdGVyICYmICdzaWduVHJhbnNhY3Rpb24nIGluIGFkYXB0ZXJcbiAgICAgICAgPyAodHJhbnNhY3Rpb24pID0+IF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICAgICAgaWYgKCFjb25uZWN0ZWQpXG4gICAgICAgICAgICAgICAgdGhyb3cgb25FcnJvcihuZXcgV2FsbGV0Tm90Q29ubmVjdGVkRXJyb3IoKSk7XG4gICAgICAgICAgICByZXR1cm4geWllbGQgYWRhcHRlci5zaWduVHJhbnNhY3Rpb24odHJhbnNhY3Rpb24pO1xuICAgICAgICB9KVxuICAgICAgICA6IHVuZGVmaW5lZCwgW2FkYXB0ZXIsIG9uRXJyb3IsIGNvbm5lY3RlZF0pO1xuICAgIC8vIFNpZ24gbXVsdGlwbGUgdHJhbnNhY3Rpb25zIGlmIHRoZSB3YWxsZXQgc3VwcG9ydHMgaXRcbiAgICBjb25zdCBzaWduQWxsVHJhbnNhY3Rpb25zID0gdXNlTWVtbygoKSA9PiBhZGFwdGVyICYmICdzaWduQWxsVHJhbnNhY3Rpb25zJyBpbiBhZGFwdGVyXG4gICAgICAgID8gKHRyYW5zYWN0aW9ucykgPT4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgICAgICBpZiAoIWNvbm5lY3RlZClcbiAgICAgICAgICAgICAgICB0aHJvdyBvbkVycm9yKG5ldyBXYWxsZXROb3RDb25uZWN0ZWRFcnJvcigpKTtcbiAgICAgICAgICAgIHJldHVybiB5aWVsZCBhZGFwdGVyLnNpZ25BbGxUcmFuc2FjdGlvbnModHJhbnNhY3Rpb25zKTtcbiAgICAgICAgfSlcbiAgICAgICAgOiB1bmRlZmluZWQsIFthZGFwdGVyLCBvbkVycm9yLCBjb25uZWN0ZWRdKTtcbiAgICAvLyBTaWduIGFuIGFyYml0cmFyeSBtZXNzYWdlIGlmIHRoZSB3YWxsZXQgc3VwcG9ydHMgaXRcbiAgICBjb25zdCBzaWduTWVzc2FnZSA9IHVzZU1lbW8oKCkgPT4gYWRhcHRlciAmJiAnc2lnbk1lc3NhZ2UnIGluIGFkYXB0ZXJcbiAgICAgICAgPyAobWVzc2FnZSkgPT4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgICAgICBpZiAoIWNvbm5lY3RlZClcbiAgICAgICAgICAgICAgICB0aHJvdyBvbkVycm9yKG5ldyBXYWxsZXROb3RDb25uZWN0ZWRFcnJvcigpKTtcbiAgICAgICAgICAgIHJldHVybiB5aWVsZCBhZGFwdGVyLnNpZ25NZXNzYWdlKG1lc3NhZ2UpO1xuICAgICAgICB9KVxuICAgICAgICA6IHVuZGVmaW5lZCwgW2FkYXB0ZXIsIG9uRXJyb3IsIGNvbm5lY3RlZF0pO1xuICAgIC8vIFNldHVwIGFuZCB0ZWFyZG93biBldmVudCBsaXN0ZW5lcnMgd2hlbiB0aGUgYWRhcHRlciBjaGFuZ2VzXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGFkYXB0ZXIpIHtcbiAgICAgICAgICAgIGFkYXB0ZXIub24oJ3JlYWR5Jywgb25SZWFkeSk7XG4gICAgICAgICAgICBhZGFwdGVyLm9uKCdjb25uZWN0Jywgb25Db25uZWN0KTtcbiAgICAgICAgICAgIGFkYXB0ZXIub24oJ2Rpc2Nvbm5lY3QnLCBvbkRpc2Nvbm5lY3QpO1xuICAgICAgICAgICAgYWRhcHRlci5vbignZXJyb3InLCBvbkVycm9yKTtcbiAgICAgICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgYWRhcHRlci5vZmYoJ3JlYWR5Jywgb25SZWFkeSk7XG4gICAgICAgICAgICAgICAgYWRhcHRlci5vZmYoJ2Nvbm5lY3QnLCBvbkNvbm5lY3QpO1xuICAgICAgICAgICAgICAgIGFkYXB0ZXIub2ZmKCdkaXNjb25uZWN0Jywgb25EaXNjb25uZWN0KTtcbiAgICAgICAgICAgICAgICBhZGFwdGVyLm9mZignZXJyb3InLCBvbkVycm9yKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9LCBbYWRhcHRlciwgb25SZWFkeSwgb25Db25uZWN0LCBvbkRpc2Nvbm5lY3QsIG9uRXJyb3JdKTtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoV2FsbGV0Q29udGV4dC5Qcm92aWRlciwgeyB2YWx1ZToge1xuICAgICAgICAgICAgd2FsbGV0cyxcbiAgICAgICAgICAgIGF1dG9Db25uZWN0LFxuICAgICAgICAgICAgd2FsbGV0LFxuICAgICAgICAgICAgYWRhcHRlcixcbiAgICAgICAgICAgIHB1YmxpY0tleSxcbiAgICAgICAgICAgIHJlYWR5LFxuICAgICAgICAgICAgY29ubmVjdGVkLFxuICAgICAgICAgICAgY29ubmVjdGluZyxcbiAgICAgICAgICAgIGRpc2Nvbm5lY3RpbmcsXG4gICAgICAgICAgICBzZWxlY3QsXG4gICAgICAgICAgICBjb25uZWN0LFxuICAgICAgICAgICAgZGlzY29ubmVjdCxcbiAgICAgICAgICAgIHNlbmRUcmFuc2FjdGlvbixcbiAgICAgICAgICAgIHNpZ25UcmFuc2FjdGlvbixcbiAgICAgICAgICAgIHNpZ25BbGxUcmFuc2FjdGlvbnMsXG4gICAgICAgICAgICBzaWduTWVzc2FnZSxcbiAgICAgICAgfSB9LCBjaGlsZHJlbikpO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVdhbGxldFByb3ZpZGVyLmpzLm1hcCIsImltcG9ydCB7IFdhbGxldEVycm9yIH0gZnJvbSAnQHNvbGFuYS93YWxsZXQtYWRhcHRlci1iYXNlJztcbmV4cG9ydCBjbGFzcyBXYWxsZXROb3RTZWxlY3RlZEVycm9yIGV4dGVuZHMgV2FsbGV0RXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnV2FsbGV0Tm90U2VsZWN0ZWRFcnJvcic7XG4gICAgfVxufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyb3JzLmpzLm1hcCIsImV4cG9ydCAqIGZyb20gJy4vQ29ubmVjdGlvblByb3ZpZGVyJztcbmV4cG9ydCAqIGZyb20gJy4vZXJyb3JzJztcbmV4cG9ydCAqIGZyb20gJy4vdXNlQW5jaG9yV2FsbGV0JztcbmV4cG9ydCAqIGZyb20gJy4vdXNlQ29ubmVjdGlvbic7XG5leHBvcnQgKiBmcm9tICcuL3VzZUxvY2FsU3RvcmFnZSc7XG5leHBvcnQgKiBmcm9tICcuL3VzZVdhbGxldCc7XG5leHBvcnQgKiBmcm9tICcuL1dhbGxldFByb3ZpZGVyJztcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImltcG9ydCB7IHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VXYWxsZXQgfSBmcm9tICcuL3VzZVdhbGxldCc7XG5leHBvcnQgZnVuY3Rpb24gdXNlQW5jaG9yV2FsbGV0KCkge1xuICAgIGNvbnN0IHsgcHVibGljS2V5LCBzaWduVHJhbnNhY3Rpb24sIHNpZ25BbGxUcmFuc2FjdGlvbnMgfSA9IHVzZVdhbGxldCgpO1xuICAgIHJldHVybiB1c2VNZW1vKCgpID0+IHB1YmxpY0tleSAmJiBzaWduVHJhbnNhY3Rpb24gJiYgc2lnbkFsbFRyYW5zYWN0aW9uc1xuICAgICAgICA/IHsgcHVibGljS2V5LCBzaWduVHJhbnNhY3Rpb24sIHNpZ25BbGxUcmFuc2FjdGlvbnMgfVxuICAgICAgICA6IHVuZGVmaW5lZCwgW3B1YmxpY0tleSwgc2lnblRyYW5zYWN0aW9uLCBzaWduQWxsVHJhbnNhY3Rpb25zXSk7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VBbmNob3JXYWxsZXQuanMubWFwIiwiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCB9IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBDb25uZWN0aW9uQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoe30pO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUNvbm5lY3Rpb24oKSB7XG4gICAgcmV0dXJuIHVzZUNvbnRleHQoQ29ubmVjdGlvbkNvbnRleHQpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlQ29ubmVjdGlvbi5qcy5tYXAiLCJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5leHBvcnQgZnVuY3Rpb24gdXNlTG9jYWxTdG9yYWdlKGtleSwgZGVmYXVsdFN0YXRlKSB7XG4gICAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgICAgIGlmICh0eXBlb2YgbG9jYWxTdG9yYWdlID09PSAndW5kZWZpbmVkJylcbiAgICAgICAgICAgIHJldHVybiBkZWZhdWx0U3RhdGU7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZSA/IEpTT04ucGFyc2UodmFsdWUpIDogZGVmYXVsdFN0YXRlO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKGVycm9yKTtcbiAgICAgICAgICAgIHJldHVybiBkZWZhdWx0U3RhdGU7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICBjb25zdCBzZXRMb2NhbFN0b3JhZ2UgPSB1c2VDYWxsYmFjaygobmV3VmFsdWUpID0+IHtcbiAgICAgICAgaWYgKG5ld1ZhbHVlID09PSB2YWx1ZSlcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgc2V0VmFsdWUobmV3VmFsdWUpO1xuICAgICAgICBpZiAobmV3VmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKGtleSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKGtleSwgSlNPTi5zdHJpbmdpZnkobmV3VmFsdWUpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW3ZhbHVlLCBzZXRWYWx1ZSwga2V5XSk7XG4gICAgcmV0dXJuIFt2YWx1ZSwgc2V0TG9jYWxTdG9yYWdlXTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUxvY2FsU3RvcmFnZS5qcy5tYXAiLCJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IFdhbGxldENvbnRleHQgPSBjcmVhdGVDb250ZXh0KHt9KTtcbmV4cG9ydCBmdW5jdGlvbiB1c2VXYWxsZXQoKSB7XG4gICAgcmV0dXJuIHVzZUNvbnRleHQoV2FsbGV0Q29udGV4dCk7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VXYWxsZXQuanMubWFwIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQHNvbGFuYS93ZWIzLmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImV2ZW50ZW1pdHRlcjNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9yb3V0ZXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtZG9tXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTsiXSwibmFtZXMiOlsiUmVhY3QiLCJXYWxsZXRNdWx0aUJ1dHRvbiIsIk5vdENvbm5lY3RlZCIsInVzZUVmZmVjdCIsInVzZVJvdXRlciIsInVzZVdhbGxldCIsIkhvbWUiLCJwdWJsaWNLZXkiLCJyb3V0ZXIiLCJwdXNoIiwiRXZlbnRFbWl0dGVyIiwiQmFzZVdhbGxldEFkYXB0ZXIiLCJXYWxsZXRBZGFwdGVyTmV0d29yayIsIldhbGxldEVycm9yIiwiRXJyb3IiLCJjb25zdHJ1Y3RvciIsIm1lc3NhZ2UiLCJlcnJvciIsIldhbGxldE5vdEZvdW5kRXJyb3IiLCJhcmd1bWVudHMiLCJuYW1lIiwiV2FsbGV0Tm90SW5zdGFsbGVkRXJyb3IiLCJXYWxsZXROb3RSZWFkeUVycm9yIiwiV2FsbGV0Q29ubmVjdGlvbkVycm9yIiwiV2FsbGV0RGlzY29ubmVjdGVkRXJyb3IiLCJXYWxsZXREaXNjb25uZWN0aW9uRXJyb3IiLCJXYWxsZXRBY2NvdW50RXJyb3IiLCJXYWxsZXRQdWJsaWNLZXlFcnJvciIsIldhbGxldEtleXBhaXJFcnJvciIsIldhbGxldE5vdENvbm5lY3RlZEVycm9yIiwiV2FsbGV0U2VuZFRyYW5zYWN0aW9uRXJyb3IiLCJXYWxsZXRTaWduTWVzc2FnZUVycm9yIiwiV2FsbGV0U2lnblRyYW5zYWN0aW9uRXJyb3IiLCJXYWxsZXRUaW1lb3V0RXJyb3IiLCJXYWxsZXRXaW5kb3dCbG9ja2VkRXJyb3IiLCJXYWxsZXRXaW5kb3dDbG9zZWRFcnJvciIsIl9fYXdhaXRlciIsInRoaXNBcmciLCJfYXJndW1lbnRzIiwiUCIsImdlbmVyYXRvciIsImFkb3B0IiwidmFsdWUiLCJyZXNvbHZlIiwiUHJvbWlzZSIsInJlamVjdCIsImZ1bGZpbGxlZCIsInN0ZXAiLCJuZXh0IiwiZSIsInJlamVjdGVkIiwicmVzdWx0IiwiZG9uZSIsInRoZW4iLCJhcHBseSIsInBvbGwiLCJjYWxsYmFjayIsImludGVydmFsIiwiY291bnQiLCJzZXRUaW1lb3V0IiwicG9sbFVudGlsUmVhZHkiLCJhZGFwdGVyIiwicG9sbEludGVydmFsIiwicG9sbENvdW50IiwicmVhZHkiLCJlbWl0IiwiY29uc29sZSIsIndhcm4iLCJfX3Jlc3QiLCJzIiwidCIsInAiLCJPYmplY3QiLCJwcm90b3R5cGUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJpbmRleE9mIiwiZ2V0T3duUHJvcGVydHlTeW1ib2xzIiwiaSIsImxlbmd0aCIsInByb3BlcnR5SXNFbnVtZXJhYmxlIiwiQmFzZVNpZ25lcldhbGxldEFkYXB0ZXIiLCJzZW5kVHJhbnNhY3Rpb24iLCJ0cmFuc2FjdGlvbiIsImNvbm5lY3Rpb24iLCJvcHRpb25zIiwiZmVlUGF5ZXIiLCJ1bmRlZmluZWQiLCJyZWNlbnRCbG9ja2hhc2giLCJnZXRSZWNlbnRCbG9ja2hhc2giLCJibG9ja2hhc2giLCJzaWduZXJzIiwic2VuZE9wdGlvbnMiLCJwYXJ0aWFsU2lnbiIsInNpZ25UcmFuc2FjdGlvbiIsInJhd1RyYW5zYWN0aW9uIiwic2VyaWFsaXplIiwic2VuZFJhd1RyYW5zYWN0aW9uIiwiQmFzZU1lc3NhZ2VTaWduZXJXYWxsZXRBZGFwdGVyIiwiQnV0dG9uIiwicHJvcHMiLCJqdXN0aWZ5Q29udGVudCIsImVuZEljb24iLCJzdGFydEljb24iLCJjcmVhdGVFbGVtZW50IiwiY2xhc3NOYW1lIiwiZGlzYWJsZWQiLCJvbkNsaWNrIiwic3R5bGUiLCJhc3NpZ24iLCJ0YWJJbmRleCIsInR5cGUiLCJjaGlsZHJlbiIsInVzZUxheW91dEVmZmVjdCIsInVzZVJlZiIsIkNvbGxhcHNlIiwiaWQiLCJleHBhbmRlZCIsInJlZiIsImluc3RhbnQiLCJ0cmFuc2l0aW9uIiwib3BlbkNvbGxhcHNlIiwibm9kZSIsImN1cnJlbnQiLCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJoZWlnaHQiLCJzY3JvbGxIZWlnaHQiLCJjbG9zZUNvbGxhcHNlIiwib2Zmc2V0SGVpZ2h0Iiwib3ZlcmZsb3ciLCJoYW5kbGVDb21wbGV0ZSIsImhhbmRsZVRyYW5zaXRpb25FbmQiLCJldmVudCIsInRhcmdldCIsInByb3BlcnR5TmFtZSIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwicm9sZSIsInVzZUNhbGxiYWNrIiwidXNlTWVtbyIsIldhbGxldEljb24iLCJXYWxsZXRDb25uZWN0QnV0dG9uIiwiX2EiLCJ3YWxsZXQiLCJjb25uZWN0IiwiY29ubmVjdGluZyIsImNvbm5lY3RlZCIsImhhbmRsZUNsaWNrIiwiZGVmYXVsdFByZXZlbnRlZCIsImNhdGNoIiwiY29udGVudCIsIldhbGxldERpc2Nvbm5lY3RCdXR0b24iLCJkaXNjb25uZWN0IiwiZGlzY29ubmVjdGluZyIsInNyYyIsImljb24iLCJhbHQiLCJXYWxsZXRMaXN0SXRlbSIsInVzZVN0YXRlIiwiY3JlYXRlUG9ydGFsIiwidXNlV2FsbGV0TW9kYWwiLCJXYWxsZXRNb2RhbCIsImxvZ28iLCJmZWF0dXJlZFdhbGxldHMiLCJjb250YWluZXIiLCJ3YWxsZXRzIiwic2VsZWN0Iiwic2V0VmlzaWJsZSIsInNldEV4cGFuZGVkIiwiZmFkZUluIiwic2V0RmFkZUluIiwicG9ydGFsIiwic2V0UG9ydGFsIiwiZmVhdHVyZWQiLCJtb3JlIiwic2xpY2UiLCJoaWRlTW9kYWwiLCJoYW5kbGVDbG9zZSIsInByZXZlbnREZWZhdWx0IiwiaGFuZGxlV2FsbGV0Q2xpY2siLCJ3YWxsZXROYW1lIiwiaGFuZGxlQ29sbGFwc2VDbGljayIsImhhbmRsZVRhYktleSIsImZvY3VzYWJsZUVsZW1lbnRzIiwicXVlcnlTZWxlY3RvckFsbCIsImZpcnN0RWxlbWVudCIsImxhc3RFbGVtZW50Iiwic2hpZnRLZXkiLCJkb2N1bWVudCIsImFjdGl2ZUVsZW1lbnQiLCJmb2N1cyIsImhhbmRsZUtleURvd24iLCJrZXkiLCJ3aW5kb3ciLCJnZXRDb21wdXRlZFN0eWxlIiwiYm9keSIsInF1ZXJ5U2VsZWN0b3IiLCJ3aWR0aCIsImQiLCJtYXAiLCJGcmFnbWVudCIsInhtbG5zIiwib25Nb3VzZURvd24iLCJXYWxsZXRNb2RhbEJ1dHRvbiIsInZpc2libGUiLCJXYWxsZXRNb2RhbENvbnRleHQiLCJXYWxsZXRNb2RhbFByb3ZpZGVyIiwiUHJvdmlkZXIiLCJjb3BpZWQiLCJzZXRDb3BpZWQiLCJhY3RpdmUiLCJzZXRBY3RpdmUiLCJiYXNlNTgiLCJ0b0Jhc2U1OCIsImNvcHlBZGRyZXNzIiwibmF2aWdhdG9yIiwiY2xpcGJvYXJkIiwid3JpdGVUZXh0Iiwib3BlbkRyb3Bkb3duIiwiY2xvc2VEcm9wZG93biIsIm9wZW5Nb2RhbCIsImxpc3RlbmVyIiwiY29udGFpbnMiLCJwb2ludGVyRXZlbnRzIiwiY3JlYXRlQ29udGV4dCIsInVzZUNvbnRleHQiLCJDb25uZWN0aW9uIiwiQ29ubmVjdGlvbkNvbnRleHQiLCJDb25uZWN0aW9uUHJvdmlkZXIiLCJlbmRwb2ludCIsImNvbmZpZyIsImNvbW1pdG1lbnQiLCJXYWxsZXROb3RTZWxlY3RlZEVycm9yIiwidXNlTG9jYWxTdG9yYWdlIiwiV2FsbGV0Q29udGV4dCIsImluaXRpYWxTdGF0ZSIsIldhbGxldFByb3ZpZGVyIiwiYXV0b0Nvbm5lY3QiLCJvbkVycm9yIiwiX29uRXJyb3IiLCJsb2NhbFN0b3JhZ2VLZXkiLCJzZXROYW1lIiwic2V0U3RhdGUiLCJzZXRDb25uZWN0aW5nIiwic2V0RGlzY29ubmVjdGluZyIsImlzQ29ubmVjdGluZyIsImlzRGlzY29ubmVjdGluZyIsImlzVW5sb2FkaW5nIiwid2FsbGV0c0J5TmFtZSIsInJlZHVjZSIsIm5ld05hbWUiLCJvblJlYWR5Iiwic3RhdGUiLCJvbkNvbm5lY3QiLCJvbkRpc2Nvbm5lY3QiLCJvcGVuIiwidXJsIiwic2lnbkFsbFRyYW5zYWN0aW9ucyIsInRyYW5zYWN0aW9ucyIsInNpZ25NZXNzYWdlIiwib24iLCJvZmYiLCJ1c2VBbmNob3JXYWxsZXQiLCJ1c2VDb25uZWN0aW9uIiwiZGVmYXVsdFN0YXRlIiwic2V0VmFsdWUiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwic2V0TG9jYWxTdG9yYWdlIiwibmV3VmFsdWUiLCJyZW1vdmVJdGVtIiwic2V0SXRlbSIsInN0cmluZ2lmeSJdLCJzb3VyY2VSb290IjoiIn0=