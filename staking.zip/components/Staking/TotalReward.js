import React from 'react';

function TotalReward() {
  return (
    <div className="w-full bg-white p-6 lg:w-3/12 mr-2">
      <h5 className="text-xl font-medium">Total Reward</h5>
      <p className="text-xl pt-4">0.00</p>
    </div>
  )
}

export default TotalReward;
