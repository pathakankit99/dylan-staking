import React from 'react';
import Dashboard from "../components/Dashboard"
function dashboard() {
    return <Dashboard/>;
}

export default dashboard;
