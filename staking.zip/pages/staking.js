import React from 'react';
import Staking from "../components/Staking"
function staking() {
    return <div>
      <Staking/>
  </div>;
}

export default staking;
