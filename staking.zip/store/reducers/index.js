
import app_reducer from "./app_reducer";
// import menu from "./menu";
import { combineReducers } from "redux";

export default combineReducers({
  app_reducer,
});
